Zadání

V tomto projektu budu dělat zařízení které se pomocí servo motorů bodou otáčet za sluncem

Zatím jsem zprovoznil servo motory jako takové bohužel jsem více nestihl neboť windowsy nechtěli spolupracovat a nešel mě pc


