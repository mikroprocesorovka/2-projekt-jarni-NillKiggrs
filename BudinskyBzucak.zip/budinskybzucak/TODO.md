TODO list
===============

* udělat pořádek `.vscode`
  - lepší integrace CPP extention
  - začlenění stm8-debug extention https://github.com/github0null/stm8-debug

