                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module milis
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _TIM4_ClearFlag
                                     12 	.globl _TIM4_ITConfig
                                     13 	.globl _TIM4_Cmd
                                     14 	.globl _TIM4_TimeBaseInit
                                     15 	.globl _ITC_SetSoftwarePriority
                                     16 	.globl _miliseconds
                                     17 	.globl _milis
                                     18 	.globl _init_milis
                                     19 	.globl _TIM4_UPD_OVF_IRQHandler
                                     20 ;--------------------------------------------------------
                                     21 ; ram data
                                     22 ;--------------------------------------------------------
                                     23 	.area DATA
                                     24 ;--------------------------------------------------------
                                     25 ; ram data
                                     26 ;--------------------------------------------------------
                                     27 	.area INITIALIZED
                           000000    28 G$miliseconds$0_0$0==.
      000001                         29 _miliseconds::
      000001                         30 	.ds 4
                                     31 ;--------------------------------------------------------
                                     32 ; absolute external ram data
                                     33 ;--------------------------------------------------------
                                     34 	.area DABS (ABS)
                                     35 
                                     36 ; default segment ordering for linker
                                     37 	.area HOME
                                     38 	.area GSINIT
                                     39 	.area GSFINAL
                                     40 	.area CONST
                                     41 	.area INITIALIZER
                                     42 	.area CODE
                                     43 
                                     44 ;--------------------------------------------------------
                                     45 ; global & static initialisations
                                     46 ;--------------------------------------------------------
                                     47 	.area HOME
                                     48 	.area GSINIT
                                     49 	.area GSFINAL
                                     50 	.area GSINIT
                                     51 ;--------------------------------------------------------
                                     52 ; Home
                                     53 ;--------------------------------------------------------
                                     54 	.area HOME
                                     55 	.area HOME
                                     56 ;--------------------------------------------------------
                                     57 ; code
                                     58 ;--------------------------------------------------------
                                     59 	.area CODE
                           000000    60 	Smilis$milis$0 ==.
                                     61 ;	./src/milis.c: 13: MILIS_PROTOTYPE
                                     62 ; genLabel
                                     63 ;	-----------------------------------------
                                     64 ;	 function milis
                                     65 ;	-----------------------------------------
                                     66 ;	Register assignment is optimal.
                                     67 ;	Stack space usage: 4 bytes.
      008171                         68 _milis:
                           000000    69 	Smilis$milis$1 ==.
      008171 52 04            [ 2]   70 	sub	sp, #4
                           000002    71 	Smilis$milis$2 ==.
                           000002    72 	Smilis$milis$3 ==.
                                     73 ;	./src/milis.c: 20: TIM4_ITConfig(TIM4_IT_UPDATE, DISABLE);
                                     74 ; genIPush
      008173 4B 00            [ 1]   75 	push	#0x00
                           000004    76 	Smilis$milis$4 ==.
                                     77 ; genIPush
      008175 4B 01            [ 1]   78 	push	#0x01
                           000006    79 	Smilis$milis$5 ==.
                                     80 ; genCall
      008177 CD 94 EC         [ 4]   81 	call	_TIM4_ITConfig
      00817A 85               [ 2]   82 	popw	x
                           00000A    83 	Smilis$milis$6 ==.
                           00000A    84 	Smilis$milis$7 ==.
                                     85 ;	./src/milis.c: 21: tmp = miliseconds;
                                     86 ; genAssign
      00817B CE 00 03         [ 2]   87 	ldw	x, _miliseconds+2
      00817E 90 CE 00 01      [ 2]   88 	ldw	y, _miliseconds+0
      008182 17 01            [ 2]   89 	ldw	(0x01, sp), y
                           000013    90 	Smilis$milis$8 ==.
                                     91 ;	./src/milis.c: 22: TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);
                                     92 ; genIPush
      008184 89               [ 2]   93 	pushw	x
                           000014    94 	Smilis$milis$9 ==.
      008185 4B 01            [ 1]   95 	push	#0x01
                           000016    96 	Smilis$milis$10 ==.
                                     97 ; genIPush
      008187 4B 01            [ 1]   98 	push	#0x01
                           000018    99 	Smilis$milis$11 ==.
                                    100 ; genCall
      008189 CD 94 EC         [ 4]  101 	call	_TIM4_ITConfig
      00818C 85               [ 2]  102 	popw	x
                           00001C   103 	Smilis$milis$12 ==.
      00818D 85               [ 2]  104 	popw	x
                           00001D   105 	Smilis$milis$13 ==.
                           00001D   106 	Smilis$milis$14 ==.
                                    107 ;	./src/milis.c: 23: return tmp;
                                    108 ; genReturn
      00818E 16 01            [ 2]  109 	ldw	y, (0x01, sp)
                                    110 ; genLabel
      008190                        111 00101$:
                           00001F   112 	Smilis$milis$15 ==.
                                    113 ;	./src/milis.c: 24: }
                                    114 ; genEndFunction
      008190 5B 04            [ 2]  115 	addw	sp, #4
                           000021   116 	Smilis$milis$16 ==.
                           000021   117 	Smilis$milis$17 ==.
                           000021   118 	XG$milis$0$0 ==.
      008192 81               [ 4]  119 	ret
                           000022   120 	Smilis$milis$18 ==.
                           000022   121 	Smilis$init_milis$19 ==.
                                    122 ;	./src/milis.c: 27: void init_milis(void)
                                    123 ; genLabel
                                    124 ;	-----------------------------------------
                                    125 ;	 function init_milis
                                    126 ;	-----------------------------------------
                                    127 ;	Register assignment is optimal.
                                    128 ;	Stack space usage: 0 bytes.
      008193                        129 _init_milis:
                           000022   130 	Smilis$init_milis$20 ==.
                           000022   131 	Smilis$init_milis$21 ==.
                                    132 ;	./src/milis.c: 29: TIM4_TimeBaseInit(PRESCALER, PERIOD);       // (16MHz / 128) / 125 = 1000Hz
                                    133 ; genIPush
      008193 4B 7C            [ 1]  134 	push	#0x7c
                           000024   135 	Smilis$init_milis$22 ==.
                                    136 ; genIPush
      008195 4B 07            [ 1]  137 	push	#0x07
                           000026   138 	Smilis$init_milis$23 ==.
                                    139 ; genCall
      008197 CD 94 C7         [ 4]  140 	call	_TIM4_TimeBaseInit
      00819A 85               [ 2]  141 	popw	x
                           00002A   142 	Smilis$init_milis$24 ==.
                           00002A   143 	Smilis$init_milis$25 ==.
                                    144 ;	./src/milis.c: 30: TIM4_ClearFlag(TIM4_FLAG_UPDATE);
                                    145 ; genIPush
      00819B 4B 01            [ 1]  146 	push	#0x01
                           00002C   147 	Smilis$init_milis$26 ==.
                                    148 ; genCall
      00819D CD 95 A9         [ 4]  149 	call	_TIM4_ClearFlag
      0081A0 84               [ 1]  150 	pop	a
                           000030   151 	Smilis$init_milis$27 ==.
                           000030   152 	Smilis$init_milis$28 ==.
                                    153 ;	./src/milis.c: 31: TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);
                                    154 ; genIPush
      0081A1 4B 01            [ 1]  155 	push	#0x01
                           000032   156 	Smilis$init_milis$29 ==.
                                    157 ; genIPush
      0081A3 4B 01            [ 1]  158 	push	#0x01
                           000034   159 	Smilis$init_milis$30 ==.
                                    160 ; genCall
      0081A5 CD 94 EC         [ 4]  161 	call	_TIM4_ITConfig
      0081A8 85               [ 2]  162 	popw	x
                           000038   163 	Smilis$init_milis$31 ==.
                           000038   164 	Smilis$init_milis$32 ==.
                                    165 ;	./src/milis.c: 32: ITC_SetSoftwarePriority(ITC_IRQ_TIM4_OVF, ITC_PRIORITYLEVEL_1);     // n�zk� priorita p�eru�en�
                                    166 ; genIPush
      0081A9 4B 01            [ 1]  167 	push	#0x01
                           00003A   168 	Smilis$init_milis$33 ==.
                                    169 ; genIPush
      0081AB 4B 17            [ 1]  170 	push	#0x17
                           00003C   171 	Smilis$init_milis$34 ==.
                                    172 ; genCall
      0081AD CD 96 AC         [ 4]  173 	call	_ITC_SetSoftwarePriority
      0081B0 85               [ 2]  174 	popw	x
                           000040   175 	Smilis$init_milis$35 ==.
                           000040   176 	Smilis$init_milis$36 ==.
                                    177 ;	./src/milis.c: 33: enableInterrupts();
                                    178 ;	genInline
      0081B1 9A               [ 1]  179 	rim
                           000041   180 	Smilis$init_milis$37 ==.
                                    181 ;	./src/milis.c: 34: TIM4_Cmd(ENABLE);
                                    182 ; genIPush
      0081B2 4B 01            [ 1]  183 	push	#0x01
                           000043   184 	Smilis$init_milis$38 ==.
                                    185 ; genCall
      0081B4 CD 94 D4         [ 4]  186 	call	_TIM4_Cmd
      0081B7 84               [ 1]  187 	pop	a
                           000047   188 	Smilis$init_milis$39 ==.
                                    189 ; genLabel
      0081B8                        190 00101$:
                           000047   191 	Smilis$init_milis$40 ==.
                                    192 ;	./src/milis.c: 35: }
                                    193 ; genEndFunction
                           000047   194 	Smilis$init_milis$41 ==.
                           000047   195 	XG$init_milis$0$0 ==.
      0081B8 81               [ 4]  196 	ret
                           000048   197 	Smilis$init_milis$42 ==.
                           000048   198 	Smilis$TIM4_UPD_OVF_IRQHandler$43 ==.
                                    199 ;	./src/milis.c: 38: INTERRUPT_HANDLER(TIM4_UPD_OVF_IRQHandler, 23)
                                    200 ; genLabel
                                    201 ;	-----------------------------------------
                                    202 ;	 function TIM4_UPD_OVF_IRQHandler
                                    203 ;	-----------------------------------------
                                    204 ;	Register assignment might be sub-optimal.
                                    205 ;	Stack space usage: 0 bytes.
      0081B9                        206 _TIM4_UPD_OVF_IRQHandler:
                                    207 ;	Reset bit 6 of reg CC. Hardware bug workaround.
      0081B9 62               [ 2]  208 	div	x, a
                           000049   209 	Smilis$TIM4_UPD_OVF_IRQHandler$44 ==.
                           000049   210 	Smilis$TIM4_UPD_OVF_IRQHandler$45 ==.
                                    211 ;	./src/milis.c: 40: TIM4_ClearFlag(TIM4_FLAG_UPDATE);
                                    212 ; genIPush
      0081BA 4B 01            [ 1]  213 	push	#0x01
                           00004B   214 	Smilis$TIM4_UPD_OVF_IRQHandler$46 ==.
                                    215 ; genCall
      0081BC CD 95 A9         [ 4]  216 	call	_TIM4_ClearFlag
      0081BF 84               [ 1]  217 	pop	a
                           00004F   218 	Smilis$TIM4_UPD_OVF_IRQHandler$47 ==.
                           00004F   219 	Smilis$TIM4_UPD_OVF_IRQHandler$48 ==.
                                    220 ;	./src/milis.c: 41: miliseconds++;
                                    221 ; genAssign
      0081C0 CE 00 03         [ 2]  222 	ldw	x, _miliseconds+2
      0081C3 90 CE 00 01      [ 2]  223 	ldw	y, _miliseconds+0
                                    224 ; genPlus
      0081C7 5C               [ 1]  225 	incw	x
      0081C8 26 02            [ 1]  226 	jrne	00103$
      0081CA 90 5C            [ 1]  227 	incw	y
      0081CC                        228 00103$:
                                    229 ; genAssign
      0081CC CF 00 03         [ 2]  230 	ldw	_miliseconds+2, x
      0081CF 90 CF 00 01      [ 2]  231 	ldw	_miliseconds+0, y
                                    232 ; genLabel
      0081D3                        233 00101$:
                           000062   234 	Smilis$TIM4_UPD_OVF_IRQHandler$49 ==.
                                    235 ;	./src/milis.c: 42: }
                                    236 ; genEndFunction
                           000062   237 	Smilis$TIM4_UPD_OVF_IRQHandler$50 ==.
                           000062   238 	XG$TIM4_UPD_OVF_IRQHandler$0$0 ==.
      0081D3 80               [11]  239 	iret
                           000063   240 	Smilis$TIM4_UPD_OVF_IRQHandler$51 ==.
                                    241 	.area CODE
                                    242 	.area CONST
                                    243 	.area INITIALIZER
                           000000   244 Fmilis$__xinit_miliseconds$0_0$0 == .
      0080C0                        245 __xinit__miliseconds:
      0080C0 00 00 00 00            246 	.byte #0x00, #0x00, #0x00, #0x00	; 0
                                    247 	.area CABS (ABS)
                                    248 
                                    249 	.area .debug_line (NOLOAD)
      000133 00 00 00 FE            250 	.dw	0,Ldebug_line_end-Ldebug_line_start
      000137                        251 Ldebug_line_start:
      000137 00 02                  252 	.dw	2
      000139 00 00 00 6E            253 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      00013D 01                     254 	.db	1
      00013E 01                     255 	.db	1
      00013F FB                     256 	.db	-5
      000140 0F                     257 	.db	15
      000141 0A                     258 	.db	10
      000142 00                     259 	.db	0
      000143 01                     260 	.db	1
      000144 01                     261 	.db	1
      000145 01                     262 	.db	1
      000146 01                     263 	.db	1
      000147 00                     264 	.db	0
      000148 00                     265 	.db	0
      000149 00                     266 	.db	0
      00014A 01                     267 	.db	1
      00014B 43 3A 5C 50 72 6F 67   268 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      000173 00                     269 	.db	0
      000174 43 3A 5C 50 72 6F 67   270 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      000197 00                     271 	.db	0
      000198 00                     272 	.db	0
      000199 2E 2F 73 72 63 2F 6D   273 	.ascii "./src/milis.c"
             69 6C 69 73 2E 63
      0001A6 00                     274 	.db	0
      0001A7 00                     275 	.uleb128	0
      0001A8 00                     276 	.uleb128	0
      0001A9 00                     277 	.uleb128	0
      0001AA 00                     278 	.db	0
      0001AB                        279 Ldebug_line_stmt:
      0001AB 00                     280 	.db	0
      0001AC 05                     281 	.uleb128	5
      0001AD 02                     282 	.db	2
      0001AE 00 00 81 71            283 	.dw	0,(Smilis$milis$0)
      0001B2 03                     284 	.db	3
      0001B3 0C                     285 	.sleb128	12
      0001B4 01                     286 	.db	1
      0001B5 09                     287 	.db	9
      0001B6 00 02                  288 	.dw	Smilis$milis$3-Smilis$milis$0
      0001B8 03                     289 	.db	3
      0001B9 07                     290 	.sleb128	7
      0001BA 01                     291 	.db	1
      0001BB 09                     292 	.db	9
      0001BC 00 08                  293 	.dw	Smilis$milis$7-Smilis$milis$3
      0001BE 03                     294 	.db	3
      0001BF 01                     295 	.sleb128	1
      0001C0 01                     296 	.db	1
      0001C1 09                     297 	.db	9
      0001C2 00 09                  298 	.dw	Smilis$milis$8-Smilis$milis$7
      0001C4 03                     299 	.db	3
      0001C5 01                     300 	.sleb128	1
      0001C6 01                     301 	.db	1
      0001C7 09                     302 	.db	9
      0001C8 00 0A                  303 	.dw	Smilis$milis$14-Smilis$milis$8
      0001CA 03                     304 	.db	3
      0001CB 01                     305 	.sleb128	1
      0001CC 01                     306 	.db	1
      0001CD 09                     307 	.db	9
      0001CE 00 02                  308 	.dw	Smilis$milis$15-Smilis$milis$14
      0001D0 03                     309 	.db	3
      0001D1 01                     310 	.sleb128	1
      0001D2 01                     311 	.db	1
      0001D3 09                     312 	.db	9
      0001D4 00 03                  313 	.dw	1+Smilis$milis$17-Smilis$milis$15
      0001D6 00                     314 	.db	0
      0001D7 01                     315 	.uleb128	1
      0001D8 01                     316 	.db	1
      0001D9 00                     317 	.db	0
      0001DA 05                     318 	.uleb128	5
      0001DB 02                     319 	.db	2
      0001DC 00 00 81 93            320 	.dw	0,(Smilis$init_milis$19)
      0001E0 03                     321 	.db	3
      0001E1 1A                     322 	.sleb128	26
      0001E2 01                     323 	.db	1
      0001E3 09                     324 	.db	9
      0001E4 00 00                  325 	.dw	Smilis$init_milis$21-Smilis$init_milis$19
      0001E6 03                     326 	.db	3
      0001E7 02                     327 	.sleb128	2
      0001E8 01                     328 	.db	1
      0001E9 09                     329 	.db	9
      0001EA 00 08                  330 	.dw	Smilis$init_milis$25-Smilis$init_milis$21
      0001EC 03                     331 	.db	3
      0001ED 01                     332 	.sleb128	1
      0001EE 01                     333 	.db	1
      0001EF 09                     334 	.db	9
      0001F0 00 06                  335 	.dw	Smilis$init_milis$28-Smilis$init_milis$25
      0001F2 03                     336 	.db	3
      0001F3 01                     337 	.sleb128	1
      0001F4 01                     338 	.db	1
      0001F5 09                     339 	.db	9
      0001F6 00 08                  340 	.dw	Smilis$init_milis$32-Smilis$init_milis$28
      0001F8 03                     341 	.db	3
      0001F9 01                     342 	.sleb128	1
      0001FA 01                     343 	.db	1
      0001FB 09                     344 	.db	9
      0001FC 00 08                  345 	.dw	Smilis$init_milis$36-Smilis$init_milis$32
      0001FE 03                     346 	.db	3
      0001FF 01                     347 	.sleb128	1
      000200 01                     348 	.db	1
      000201 09                     349 	.db	9
      000202 00 01                  350 	.dw	Smilis$init_milis$37-Smilis$init_milis$36
      000204 03                     351 	.db	3
      000205 01                     352 	.sleb128	1
      000206 01                     353 	.db	1
      000207 09                     354 	.db	9
      000208 00 06                  355 	.dw	Smilis$init_milis$40-Smilis$init_milis$37
      00020A 03                     356 	.db	3
      00020B 01                     357 	.sleb128	1
      00020C 01                     358 	.db	1
      00020D 09                     359 	.db	9
      00020E 00 01                  360 	.dw	1+Smilis$init_milis$41-Smilis$init_milis$40
      000210 00                     361 	.db	0
      000211 01                     362 	.uleb128	1
      000212 01                     363 	.db	1
      000213 00                     364 	.db	0
      000214 05                     365 	.uleb128	5
      000215 02                     366 	.db	2
      000216 00 00 81 B9            367 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$43)
      00021A 03                     368 	.db	3
      00021B 25                     369 	.sleb128	37
      00021C 01                     370 	.db	1
      00021D 09                     371 	.db	9
      00021E 00 01                  372 	.dw	Smilis$TIM4_UPD_OVF_IRQHandler$45-Smilis$TIM4_UPD_OVF_IRQHandler$43
      000220 03                     373 	.db	3
      000221 02                     374 	.sleb128	2
      000222 01                     375 	.db	1
      000223 09                     376 	.db	9
      000224 00 06                  377 	.dw	Smilis$TIM4_UPD_OVF_IRQHandler$48-Smilis$TIM4_UPD_OVF_IRQHandler$45
      000226 03                     378 	.db	3
      000227 01                     379 	.sleb128	1
      000228 01                     380 	.db	1
      000229 09                     381 	.db	9
      00022A 00 13                  382 	.dw	Smilis$TIM4_UPD_OVF_IRQHandler$49-Smilis$TIM4_UPD_OVF_IRQHandler$48
      00022C 03                     383 	.db	3
      00022D 01                     384 	.sleb128	1
      00022E 01                     385 	.db	1
      00022F 09                     386 	.db	9
      000230 00 01                  387 	.dw	1+Smilis$TIM4_UPD_OVF_IRQHandler$50-Smilis$TIM4_UPD_OVF_IRQHandler$49
      000232 00                     388 	.db	0
      000233 01                     389 	.uleb128	1
      000234 01                     390 	.db	1
      000235                        391 Ldebug_line_end:
                                    392 
                                    393 	.area .debug_loc (NOLOAD)
      0001FC                        394 Ldebug_loc_start:
      0001FC 00 00 81 C0            395 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$47)
      000200 00 00 81 D4            396 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$51)
      000204 00 02                  397 	.dw	2
      000206 78                     398 	.db	120
      000207 01                     399 	.sleb128	1
      000208 00 00 81 BC            400 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$46)
      00020C 00 00 81 C0            401 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$47)
      000210 00 02                  402 	.dw	2
      000212 78                     403 	.db	120
      000213 02                     404 	.sleb128	2
      000214 00 00 81 BA            405 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$44)
      000218 00 00 81 BC            406 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$46)
      00021C 00 02                  407 	.dw	2
      00021E 78                     408 	.db	120
      00021F 01                     409 	.sleb128	1
      000220 00 00 00 00            410 	.dw	0,0
      000224 00 00 00 00            411 	.dw	0,0
      000228 00 00 81 B8            412 	.dw	0,(Smilis$init_milis$39)
      00022C 00 00 81 B9            413 	.dw	0,(Smilis$init_milis$42)
      000230 00 02                  414 	.dw	2
      000232 78                     415 	.db	120
      000233 01                     416 	.sleb128	1
      000234 00 00 81 B4            417 	.dw	0,(Smilis$init_milis$38)
      000238 00 00 81 B8            418 	.dw	0,(Smilis$init_milis$39)
      00023C 00 02                  419 	.dw	2
      00023E 78                     420 	.db	120
      00023F 02                     421 	.sleb128	2
      000240 00 00 81 B1            422 	.dw	0,(Smilis$init_milis$35)
      000244 00 00 81 B4            423 	.dw	0,(Smilis$init_milis$38)
      000248 00 02                  424 	.dw	2
      00024A 78                     425 	.db	120
      00024B 01                     426 	.sleb128	1
      00024C 00 00 81 AD            427 	.dw	0,(Smilis$init_milis$34)
      000250 00 00 81 B1            428 	.dw	0,(Smilis$init_milis$35)
      000254 00 02                  429 	.dw	2
      000256 78                     430 	.db	120
      000257 03                     431 	.sleb128	3
      000258 00 00 81 AB            432 	.dw	0,(Smilis$init_milis$33)
      00025C 00 00 81 AD            433 	.dw	0,(Smilis$init_milis$34)
      000260 00 02                  434 	.dw	2
      000262 78                     435 	.db	120
      000263 02                     436 	.sleb128	2
      000264 00 00 81 A9            437 	.dw	0,(Smilis$init_milis$31)
      000268 00 00 81 AB            438 	.dw	0,(Smilis$init_milis$33)
      00026C 00 02                  439 	.dw	2
      00026E 78                     440 	.db	120
      00026F 01                     441 	.sleb128	1
      000270 00 00 81 A5            442 	.dw	0,(Smilis$init_milis$30)
      000274 00 00 81 A9            443 	.dw	0,(Smilis$init_milis$31)
      000278 00 02                  444 	.dw	2
      00027A 78                     445 	.db	120
      00027B 03                     446 	.sleb128	3
      00027C 00 00 81 A3            447 	.dw	0,(Smilis$init_milis$29)
      000280 00 00 81 A5            448 	.dw	0,(Smilis$init_milis$30)
      000284 00 02                  449 	.dw	2
      000286 78                     450 	.db	120
      000287 02                     451 	.sleb128	2
      000288 00 00 81 A1            452 	.dw	0,(Smilis$init_milis$27)
      00028C 00 00 81 A3            453 	.dw	0,(Smilis$init_milis$29)
      000290 00 02                  454 	.dw	2
      000292 78                     455 	.db	120
      000293 01                     456 	.sleb128	1
      000294 00 00 81 9D            457 	.dw	0,(Smilis$init_milis$26)
      000298 00 00 81 A1            458 	.dw	0,(Smilis$init_milis$27)
      00029C 00 02                  459 	.dw	2
      00029E 78                     460 	.db	120
      00029F 02                     461 	.sleb128	2
      0002A0 00 00 81 9B            462 	.dw	0,(Smilis$init_milis$24)
      0002A4 00 00 81 9D            463 	.dw	0,(Smilis$init_milis$26)
      0002A8 00 02                  464 	.dw	2
      0002AA 78                     465 	.db	120
      0002AB 01                     466 	.sleb128	1
      0002AC 00 00 81 97            467 	.dw	0,(Smilis$init_milis$23)
      0002B0 00 00 81 9B            468 	.dw	0,(Smilis$init_milis$24)
      0002B4 00 02                  469 	.dw	2
      0002B6 78                     470 	.db	120
      0002B7 03                     471 	.sleb128	3
      0002B8 00 00 81 95            472 	.dw	0,(Smilis$init_milis$22)
      0002BC 00 00 81 97            473 	.dw	0,(Smilis$init_milis$23)
      0002C0 00 02                  474 	.dw	2
      0002C2 78                     475 	.db	120
      0002C3 02                     476 	.sleb128	2
      0002C4 00 00 81 93            477 	.dw	0,(Smilis$init_milis$20)
      0002C8 00 00 81 95            478 	.dw	0,(Smilis$init_milis$22)
      0002CC 00 02                  479 	.dw	2
      0002CE 78                     480 	.db	120
      0002CF 01                     481 	.sleb128	1
      0002D0 00 00 00 00            482 	.dw	0,0
      0002D4 00 00 00 00            483 	.dw	0,0
      0002D8 00 00 81 92            484 	.dw	0,(Smilis$milis$16)
      0002DC 00 00 81 93            485 	.dw	0,(Smilis$milis$18)
      0002E0 00 02                  486 	.dw	2
      0002E2 78                     487 	.db	120
      0002E3 01                     488 	.sleb128	1
      0002E4 00 00 81 8E            489 	.dw	0,(Smilis$milis$13)
      0002E8 00 00 81 92            490 	.dw	0,(Smilis$milis$16)
      0002EC 00 02                  491 	.dw	2
      0002EE 78                     492 	.db	120
      0002EF 05                     493 	.sleb128	5
      0002F0 00 00 81 8D            494 	.dw	0,(Smilis$milis$12)
      0002F4 00 00 81 8E            495 	.dw	0,(Smilis$milis$13)
      0002F8 00 02                  496 	.dw	2
      0002FA 78                     497 	.db	120
      0002FB 07                     498 	.sleb128	7
      0002FC 00 00 81 89            499 	.dw	0,(Smilis$milis$11)
      000300 00 00 81 8D            500 	.dw	0,(Smilis$milis$12)
      000304 00 02                  501 	.dw	2
      000306 78                     502 	.db	120
      000307 09                     503 	.sleb128	9
      000308 00 00 81 87            504 	.dw	0,(Smilis$milis$10)
      00030C 00 00 81 89            505 	.dw	0,(Smilis$milis$11)
      000310 00 02                  506 	.dw	2
      000312 78                     507 	.db	120
      000313 08                     508 	.sleb128	8
      000314 00 00 81 85            509 	.dw	0,(Smilis$milis$9)
      000318 00 00 81 87            510 	.dw	0,(Smilis$milis$10)
      00031C 00 02                  511 	.dw	2
      00031E 78                     512 	.db	120
      00031F 07                     513 	.sleb128	7
      000320 00 00 81 7B            514 	.dw	0,(Smilis$milis$6)
      000324 00 00 81 85            515 	.dw	0,(Smilis$milis$9)
      000328 00 02                  516 	.dw	2
      00032A 78                     517 	.db	120
      00032B 05                     518 	.sleb128	5
      00032C 00 00 81 77            519 	.dw	0,(Smilis$milis$5)
      000330 00 00 81 7B            520 	.dw	0,(Smilis$milis$6)
      000334 00 02                  521 	.dw	2
      000336 78                     522 	.db	120
      000337 07                     523 	.sleb128	7
      000338 00 00 81 75            524 	.dw	0,(Smilis$milis$4)
      00033C 00 00 81 77            525 	.dw	0,(Smilis$milis$5)
      000340 00 02                  526 	.dw	2
      000342 78                     527 	.db	120
      000343 06                     528 	.sleb128	6
      000344 00 00 81 73            529 	.dw	0,(Smilis$milis$2)
      000348 00 00 81 75            530 	.dw	0,(Smilis$milis$4)
      00034C 00 02                  531 	.dw	2
      00034E 78                     532 	.db	120
      00034F 05                     533 	.sleb128	5
      000350 00 00 81 71            534 	.dw	0,(Smilis$milis$1)
      000354 00 00 81 73            535 	.dw	0,(Smilis$milis$2)
      000358 00 02                  536 	.dw	2
      00035A 78                     537 	.db	120
      00035B 01                     538 	.sleb128	1
      00035C 00 00 00 00            539 	.dw	0,0
      000360 00 00 00 00            540 	.dw	0,0
                                    541 
                                    542 	.area .debug_abbrev (NOLOAD)
      00007A                        543 Ldebug_abbrev:
      00007A 07                     544 	.uleb128	7
      00007B 35                     545 	.uleb128	53
      00007C 00                     546 	.db	0
      00007D 49                     547 	.uleb128	73
      00007E 13                     548 	.uleb128	19
      00007F 00                     549 	.uleb128	0
      000080 00                     550 	.uleb128	0
      000081 08                     551 	.uleb128	8
      000082 34                     552 	.uleb128	52
      000083 00                     553 	.db	0
      000084 02                     554 	.uleb128	2
      000085 0A                     555 	.uleb128	10
      000086 03                     556 	.uleb128	3
      000087 08                     557 	.uleb128	8
      000088 3F                     558 	.uleb128	63
      000089 0C                     559 	.uleb128	12
      00008A 49                     560 	.uleb128	73
      00008B 13                     561 	.uleb128	19
      00008C 00                     562 	.uleb128	0
      00008D 00                     563 	.uleb128	0
      00008E 04                     564 	.uleb128	4
      00008F 34                     565 	.uleb128	52
      000090 00                     566 	.db	0
      000091 02                     567 	.uleb128	2
      000092 0A                     568 	.uleb128	10
      000093 03                     569 	.uleb128	3
      000094 08                     570 	.uleb128	8
      000095 49                     571 	.uleb128	73
      000096 13                     572 	.uleb128	19
      000097 00                     573 	.uleb128	0
      000098 00                     574 	.uleb128	0
      000099 03                     575 	.uleb128	3
      00009A 2E                     576 	.uleb128	46
      00009B 01                     577 	.db	1
      00009C 01                     578 	.uleb128	1
      00009D 13                     579 	.uleb128	19
      00009E 03                     580 	.uleb128	3
      00009F 08                     581 	.uleb128	8
      0000A0 11                     582 	.uleb128	17
      0000A1 01                     583 	.uleb128	1
      0000A2 12                     584 	.uleb128	18
      0000A3 01                     585 	.uleb128	1
      0000A4 3F                     586 	.uleb128	63
      0000A5 0C                     587 	.uleb128	12
      0000A6 40                     588 	.uleb128	64
      0000A7 06                     589 	.uleb128	6
      0000A8 49                     590 	.uleb128	73
      0000A9 13                     591 	.uleb128	19
      0000AA 00                     592 	.uleb128	0
      0000AB 00                     593 	.uleb128	0
      0000AC 01                     594 	.uleb128	1
      0000AD 11                     595 	.uleb128	17
      0000AE 01                     596 	.db	1
      0000AF 03                     597 	.uleb128	3
      0000B0 08                     598 	.uleb128	8
      0000B1 10                     599 	.uleb128	16
      0000B2 06                     600 	.uleb128	6
      0000B3 13                     601 	.uleb128	19
      0000B4 0B                     602 	.uleb128	11
      0000B5 25                     603 	.uleb128	37
      0000B6 08                     604 	.uleb128	8
      0000B7 00                     605 	.uleb128	0
      0000B8 00                     606 	.uleb128	0
      0000B9 05                     607 	.uleb128	5
      0000BA 2E                     608 	.uleb128	46
      0000BB 00                     609 	.db	0
      0000BC 03                     610 	.uleb128	3
      0000BD 08                     611 	.uleb128	8
      0000BE 11                     612 	.uleb128	17
      0000BF 01                     613 	.uleb128	1
      0000C0 12                     614 	.uleb128	18
      0000C1 01                     615 	.uleb128	1
      0000C2 3F                     616 	.uleb128	63
      0000C3 0C                     617 	.uleb128	12
      0000C4 40                     618 	.uleb128	64
      0000C5 06                     619 	.uleb128	6
      0000C6 00                     620 	.uleb128	0
      0000C7 00                     621 	.uleb128	0
      0000C8 02                     622 	.uleb128	2
      0000C9 24                     623 	.uleb128	36
      0000CA 00                     624 	.db	0
      0000CB 03                     625 	.uleb128	3
      0000CC 08                     626 	.uleb128	8
      0000CD 0B                     627 	.uleb128	11
      0000CE 0B                     628 	.uleb128	11
      0000CF 3E                     629 	.uleb128	62
      0000D0 0B                     630 	.uleb128	11
      0000D1 00                     631 	.uleb128	0
      0000D2 00                     632 	.uleb128	0
      0000D3 06                     633 	.uleb128	6
      0000D4 2E                     634 	.uleb128	46
      0000D5 00                     635 	.db	0
      0000D6 03                     636 	.uleb128	3
      0000D7 08                     637 	.uleb128	8
      0000D8 11                     638 	.uleb128	17
      0000D9 01                     639 	.uleb128	1
      0000DA 12                     640 	.uleb128	18
      0000DB 01                     641 	.uleb128	1
      0000DC 36                     642 	.uleb128	54
      0000DD 0B                     643 	.uleb128	11
      0000DE 3F                     644 	.uleb128	63
      0000DF 0C                     645 	.uleb128	12
      0000E0 40                     646 	.uleb128	64
      0000E1 06                     647 	.uleb128	6
      0000E2 00                     648 	.uleb128	0
      0000E3 00                     649 	.uleb128	0
      0000E4 00                     650 	.uleb128	0
                                    651 
                                    652 	.area .debug_info (NOLOAD)
      000130 00 00 00 DB            653 	.dw	0,Ldebug_info_end-Ldebug_info_start
      000134                        654 Ldebug_info_start:
      000134 00 02                  655 	.dw	2
      000136 00 00 00 7A            656 	.dw	0,(Ldebug_abbrev)
      00013A 04                     657 	.db	4
      00013B 01                     658 	.uleb128	1
      00013C 2E 2F 73 72 63 2F 6D   659 	.ascii "./src/milis.c"
             69 6C 69 73 2E 63
      000149 00                     660 	.db	0
      00014A 00 00 01 33            661 	.dw	0,(Ldebug_line_start+-4)
      00014E 01                     662 	.db	1
      00014F 53 44 43 43 20 76 65   663 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      000168 00                     664 	.db	0
      000169 02                     665 	.uleb128	2
      00016A 75 6E 73 69 67 6E 65   666 	.ascii "unsigned long"
             64 20 6C 6F 6E 67
      000177 00                     667 	.db	0
      000178 04                     668 	.db	4
      000179 07                     669 	.db	7
      00017A 03                     670 	.uleb128	3
      00017B 00 00 00 7F            671 	.dw	0,127
      00017F 6D 69 6C 69 73         672 	.ascii "milis"
      000184 00                     673 	.db	0
      000185 00 00 81 71            674 	.dw	0,(_milis)
      000189 00 00 81 93            675 	.dw	0,(XG$milis$0$0+1)
      00018D 01                     676 	.db	1
      00018E 00 00 02 D8            677 	.dw	0,(Ldebug_loc_start+220)
      000192 00 00 00 39            678 	.dw	0,57
      000196 04                     679 	.uleb128	4
      000197 0E                     680 	.db	14
      000198 91                     681 	.db	145
      000199 7C                     682 	.sleb128	-4
      00019A 93                     683 	.db	147
      00019B 01                     684 	.uleb128	1
      00019C 91                     685 	.db	145
      00019D 7D                     686 	.sleb128	-3
      00019E 93                     687 	.db	147
      00019F 01                     688 	.uleb128	1
      0001A0 52                     689 	.db	82
      0001A1 93                     690 	.db	147
      0001A2 01                     691 	.uleb128	1
      0001A3 51                     692 	.db	81
      0001A4 93                     693 	.db	147
      0001A5 01                     694 	.uleb128	1
      0001A6 74 6D 70               695 	.ascii "tmp"
      0001A9 00                     696 	.db	0
      0001AA 00 00 00 39            697 	.dw	0,57
      0001AE 00                     698 	.uleb128	0
      0001AF 05                     699 	.uleb128	5
      0001B0 69 6E 69 74 5F 6D 69   700 	.ascii "init_milis"
             6C 69 73
      0001BA 00                     701 	.db	0
      0001BB 00 00 81 93            702 	.dw	0,(_init_milis)
      0001BF 00 00 81 B9            703 	.dw	0,(XG$init_milis$0$0+1)
      0001C3 01                     704 	.db	1
      0001C4 00 00 02 28            705 	.dw	0,(Ldebug_loc_start+44)
      0001C8 06                     706 	.uleb128	6
      0001C9 54 49 4D 34 5F 55 50   707 	.ascii "TIM4_UPD_OVF_IRQHandler"
             44 5F 4F 56 46 5F 49
             52 51 48 61 6E 64 6C
             65 72
      0001E0 00                     708 	.db	0
      0001E1 00 00 81 B9            709 	.dw	0,(_TIM4_UPD_OVF_IRQHandler)
      0001E5 00 00 81 D4            710 	.dw	0,(XG$TIM4_UPD_OVF_IRQHandler$0$0+1)
      0001E9 03                     711 	.db	3
      0001EA 01                     712 	.db	1
      0001EB 00 00 01 FC            713 	.dw	0,(Ldebug_loc_start)
      0001EF 07                     714 	.uleb128	7
      0001F0 00 00 00 39            715 	.dw	0,57
      0001F4 08                     716 	.uleb128	8
      0001F5 05                     717 	.db	5
      0001F6 03                     718 	.db	3
      0001F7 00 00 00 01            719 	.dw	0,(_miliseconds)
      0001FB 6D 69 6C 69 73 65 63   720 	.ascii "miliseconds"
             6F 6E 64 73
      000206 00                     721 	.db	0
      000207 01                     722 	.db	1
      000208 00 00 00 BF            723 	.dw	0,191
      00020C 00                     724 	.uleb128	0
      00020D 00                     725 	.uleb128	0
      00020E 00                     726 	.uleb128	0
      00020F                        727 Ldebug_info_end:
                                    728 
                                    729 	.area .debug_pubnames (NOLOAD)
      000025 00 00 00 53            730 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      000029                        731 Ldebug_pubnames_start:
      000029 00 02                  732 	.dw	2
      00002B 00 00 01 30            733 	.dw	0,(Ldebug_info_start-4)
      00002F 00 00 00 DF            734 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      000033 00 00 00 4A            735 	.dw	0,74
      000037 6D 69 6C 69 73         736 	.ascii "milis"
      00003C 00                     737 	.db	0
      00003D 00 00 00 7F            738 	.dw	0,127
      000041 69 6E 69 74 5F 6D 69   739 	.ascii "init_milis"
             6C 69 73
      00004B 00                     740 	.db	0
      00004C 00 00 00 98            741 	.dw	0,152
      000050 54 49 4D 34 5F 55 50   742 	.ascii "TIM4_UPD_OVF_IRQHandler"
             44 5F 4F 56 46 5F 49
             52 51 48 61 6E 64 6C
             65 72
      000067 00                     743 	.db	0
      000068 00 00 00 C4            744 	.dw	0,196
      00006C 6D 69 6C 69 73 65 63   745 	.ascii "miliseconds"
             6F 6E 64 73
      000077 00                     746 	.db	0
      000078 00 00 00 00            747 	.dw	0,0
      00007C                        748 Ldebug_pubnames_end:
                                    749 
                                    750 	.area .debug_frame (NOLOAD)
      000163 00 00                  751 	.dw	0
      000165 00 0E                  752 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      000167                        753 Ldebug_CIE0_start:
      000167 FF FF                  754 	.dw	0xffff
      000169 FF FF                  755 	.dw	0xffff
      00016B 01                     756 	.db	1
      00016C 00                     757 	.db	0
      00016D 01                     758 	.uleb128	1
      00016E 7F                     759 	.sleb128	-1
      00016F 09                     760 	.db	9
      000170 0C                     761 	.db	12
      000171 08                     762 	.uleb128	8
      000172 09                     763 	.uleb128	9
      000173 89                     764 	.db	137
      000174 01                     765 	.uleb128	1
      000175                        766 Ldebug_CIE0_end:
      000175 00 00 00 21            767 	.dw	0,33
      000179 00 00 01 63            768 	.dw	0,(Ldebug_CIE0_start-4)
      00017D 00 00 81 BA            769 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$44)	;initial loc
      000181 00 00 00 1A            770 	.dw	0,Smilis$TIM4_UPD_OVF_IRQHandler$51-Smilis$TIM4_UPD_OVF_IRQHandler$44
      000185 01                     771 	.db	1
      000186 00 00 81 BA            772 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$44)
      00018A 0E                     773 	.db	14
      00018B 09                     774 	.uleb128	9
      00018C 01                     775 	.db	1
      00018D 00 00 81 BC            776 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$46)
      000191 0E                     777 	.db	14
      000192 0A                     778 	.uleb128	10
      000193 01                     779 	.db	1
      000194 00 00 81 C0            780 	.dw	0,(Smilis$TIM4_UPD_OVF_IRQHandler$47)
      000198 0E                     781 	.db	14
      000199 09                     782 	.uleb128	9
                                    783 
                                    784 	.area .debug_frame (NOLOAD)
      00019A 00 00                  785 	.dw	0
      00019C 00 0E                  786 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      00019E                        787 Ldebug_CIE1_start:
      00019E FF FF                  788 	.dw	0xffff
      0001A0 FF FF                  789 	.dw	0xffff
      0001A2 01                     790 	.db	1
      0001A3 00                     791 	.db	0
      0001A4 01                     792 	.uleb128	1
      0001A5 7F                     793 	.sleb128	-1
      0001A6 09                     794 	.db	9
      0001A7 0C                     795 	.db	12
      0001A8 08                     796 	.uleb128	8
      0001A9 02                     797 	.uleb128	2
      0001AA 89                     798 	.db	137
      0001AB 01                     799 	.uleb128	1
      0001AC                        800 Ldebug_CIE1_end:
      0001AC 00 00 00 6E            801 	.dw	0,110
      0001B0 00 00 01 9A            802 	.dw	0,(Ldebug_CIE1_start-4)
      0001B4 00 00 81 93            803 	.dw	0,(Smilis$init_milis$20)	;initial loc
      0001B8 00 00 00 26            804 	.dw	0,Smilis$init_milis$42-Smilis$init_milis$20
      0001BC 01                     805 	.db	1
      0001BD 00 00 81 93            806 	.dw	0,(Smilis$init_milis$20)
      0001C1 0E                     807 	.db	14
      0001C2 02                     808 	.uleb128	2
      0001C3 01                     809 	.db	1
      0001C4 00 00 81 95            810 	.dw	0,(Smilis$init_milis$22)
      0001C8 0E                     811 	.db	14
      0001C9 03                     812 	.uleb128	3
      0001CA 01                     813 	.db	1
      0001CB 00 00 81 97            814 	.dw	0,(Smilis$init_milis$23)
      0001CF 0E                     815 	.db	14
      0001D0 04                     816 	.uleb128	4
      0001D1 01                     817 	.db	1
      0001D2 00 00 81 9B            818 	.dw	0,(Smilis$init_milis$24)
      0001D6 0E                     819 	.db	14
      0001D7 02                     820 	.uleb128	2
      0001D8 01                     821 	.db	1
      0001D9 00 00 81 9D            822 	.dw	0,(Smilis$init_milis$26)
      0001DD 0E                     823 	.db	14
      0001DE 03                     824 	.uleb128	3
      0001DF 01                     825 	.db	1
      0001E0 00 00 81 A1            826 	.dw	0,(Smilis$init_milis$27)
      0001E4 0E                     827 	.db	14
      0001E5 02                     828 	.uleb128	2
      0001E6 01                     829 	.db	1
      0001E7 00 00 81 A3            830 	.dw	0,(Smilis$init_milis$29)
      0001EB 0E                     831 	.db	14
      0001EC 03                     832 	.uleb128	3
      0001ED 01                     833 	.db	1
      0001EE 00 00 81 A5            834 	.dw	0,(Smilis$init_milis$30)
      0001F2 0E                     835 	.db	14
      0001F3 04                     836 	.uleb128	4
      0001F4 01                     837 	.db	1
      0001F5 00 00 81 A9            838 	.dw	0,(Smilis$init_milis$31)
      0001F9 0E                     839 	.db	14
      0001FA 02                     840 	.uleb128	2
      0001FB 01                     841 	.db	1
      0001FC 00 00 81 AB            842 	.dw	0,(Smilis$init_milis$33)
      000200 0E                     843 	.db	14
      000201 03                     844 	.uleb128	3
      000202 01                     845 	.db	1
      000203 00 00 81 AD            846 	.dw	0,(Smilis$init_milis$34)
      000207 0E                     847 	.db	14
      000208 04                     848 	.uleb128	4
      000209 01                     849 	.db	1
      00020A 00 00 81 B1            850 	.dw	0,(Smilis$init_milis$35)
      00020E 0E                     851 	.db	14
      00020F 02                     852 	.uleb128	2
      000210 01                     853 	.db	1
      000211 00 00 81 B4            854 	.dw	0,(Smilis$init_milis$38)
      000215 0E                     855 	.db	14
      000216 03                     856 	.uleb128	3
      000217 01                     857 	.db	1
      000218 00 00 81 B8            858 	.dw	0,(Smilis$init_milis$39)
      00021C 0E                     859 	.db	14
      00021D 02                     860 	.uleb128	2
                                    861 
                                    862 	.area .debug_frame (NOLOAD)
      00021E 00 00                  863 	.dw	0
      000220 00 0E                  864 	.dw	Ldebug_CIE2_end-Ldebug_CIE2_start
      000222                        865 Ldebug_CIE2_start:
      000222 FF FF                  866 	.dw	0xffff
      000224 FF FF                  867 	.dw	0xffff
      000226 01                     868 	.db	1
      000227 00                     869 	.db	0
      000228 01                     870 	.uleb128	1
      000229 7F                     871 	.sleb128	-1
      00022A 09                     872 	.db	9
      00022B 0C                     873 	.db	12
      00022C 08                     874 	.uleb128	8
      00022D 02                     875 	.uleb128	2
      00022E 89                     876 	.db	137
      00022F 01                     877 	.uleb128	1
      000230                        878 Ldebug_CIE2_end:
      000230 00 00 00 59            879 	.dw	0,89
      000234 00 00 02 1E            880 	.dw	0,(Ldebug_CIE2_start-4)
      000238 00 00 81 71            881 	.dw	0,(Smilis$milis$1)	;initial loc
      00023C 00 00 00 22            882 	.dw	0,Smilis$milis$18-Smilis$milis$1
      000240 01                     883 	.db	1
      000241 00 00 81 71            884 	.dw	0,(Smilis$milis$1)
      000245 0E                     885 	.db	14
      000246 02                     886 	.uleb128	2
      000247 01                     887 	.db	1
      000248 00 00 81 73            888 	.dw	0,(Smilis$milis$2)
      00024C 0E                     889 	.db	14
      00024D 06                     890 	.uleb128	6
      00024E 01                     891 	.db	1
      00024F 00 00 81 75            892 	.dw	0,(Smilis$milis$4)
      000253 0E                     893 	.db	14
      000254 07                     894 	.uleb128	7
      000255 01                     895 	.db	1
      000256 00 00 81 77            896 	.dw	0,(Smilis$milis$5)
      00025A 0E                     897 	.db	14
      00025B 08                     898 	.uleb128	8
      00025C 01                     899 	.db	1
      00025D 00 00 81 7B            900 	.dw	0,(Smilis$milis$6)
      000261 0E                     901 	.db	14
      000262 06                     902 	.uleb128	6
      000263 01                     903 	.db	1
      000264 00 00 81 85            904 	.dw	0,(Smilis$milis$9)
      000268 0E                     905 	.db	14
      000269 08                     906 	.uleb128	8
      00026A 01                     907 	.db	1
      00026B 00 00 81 87            908 	.dw	0,(Smilis$milis$10)
      00026F 0E                     909 	.db	14
      000270 09                     910 	.uleb128	9
      000271 01                     911 	.db	1
      000272 00 00 81 89            912 	.dw	0,(Smilis$milis$11)
      000276 0E                     913 	.db	14
      000277 0A                     914 	.uleb128	10
      000278 01                     915 	.db	1
      000279 00 00 81 8D            916 	.dw	0,(Smilis$milis$12)
      00027D 0E                     917 	.db	14
      00027E 08                     918 	.uleb128	8
      00027F 01                     919 	.db	1
      000280 00 00 81 8E            920 	.dw	0,(Smilis$milis$13)
      000284 0E                     921 	.db	14
      000285 06                     922 	.uleb128	6
      000286 01                     923 	.db	1
      000287 00 00 81 92            924 	.dw	0,(Smilis$milis$16)
      00028B 0E                     925 	.db	14
      00028C 02                     926 	.uleb128	2
