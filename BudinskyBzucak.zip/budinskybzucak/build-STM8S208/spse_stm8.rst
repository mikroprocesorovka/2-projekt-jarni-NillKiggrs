                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module spse_stm8
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ADC2_GetConversionValue
                                     12 	.globl _ADC_get
                                     13 	.globl _ADC2_Select_Channel
                                     14 	.globl _ADC2_AlignConfig
                                     15 	.globl _ADC2_Startup_Wait
                                     16 ;--------------------------------------------------------
                                     17 ; ram data
                                     18 ;--------------------------------------------------------
                                     19 	.area DATA
                                     20 ;--------------------------------------------------------
                                     21 ; ram data
                                     22 ;--------------------------------------------------------
                                     23 	.area INITIALIZED
                                     24 ;--------------------------------------------------------
                                     25 ; absolute external ram data
                                     26 ;--------------------------------------------------------
                                     27 	.area DABS (ABS)
                                     28 
                                     29 ; default segment ordering for linker
                                     30 	.area HOME
                                     31 	.area GSINIT
                                     32 	.area GSFINAL
                                     33 	.area CONST
                                     34 	.area INITIALIZER
                                     35 	.area CODE
                                     36 
                                     37 ;--------------------------------------------------------
                                     38 ; global & static initialisations
                                     39 ;--------------------------------------------------------
                                     40 	.area HOME
                                     41 	.area GSINIT
                                     42 	.area GSFINAL
                                     43 	.area GSINIT
                                     44 ;--------------------------------------------------------
                                     45 ; Home
                                     46 ;--------------------------------------------------------
                                     47 	.area HOME
                                     48 	.area HOME
                                     49 ;--------------------------------------------------------
                                     50 ; code
                                     51 ;--------------------------------------------------------
                                     52 	.area CODE
                           000000    53 	Sspse_stm8$_delay_cycl$0 ==.
                                     54 ;	inc/delay.h: 14: static @inline void _delay_cycl( unsigned short __ticks )
                                     55 ; genLabel
                                     56 ;	-----------------------------------------
                                     57 ;	 function _delay_cycl
                                     58 ;	-----------------------------------------
                                     59 ;	Register assignment is optimal.
                                     60 ;	Stack space usage: 0 bytes.
      0081D4                         61 __delay_cycl:
                           000000    62 	Sspse_stm8$_delay_cycl$1 ==.
                           000000    63 	Sspse_stm8$_delay_cycl$2 ==.
                                     64 ;	inc/delay.h: 25: __asm__("nop\n nop\n"); 
                                     65 ;	genInline
      0081D4 9D               [ 1]   66 	nop
      0081D5 9D               [ 1]   67 	nop
                           000002    68 	Sspse_stm8$_delay_cycl$3 ==.
                                     69 ;	inc/delay.h: 26: do { 		// ASM: ldw X, #tick; lab$: decw X; tnzw X; jrne lab$
                                     70 ; genAssign
      0081D6 1E 03            [ 2]   71 	ldw	x, (0x03, sp)
                                     72 ; genLabel
      0081D8                         73 00101$:
                           000004    74 	Sspse_stm8$_delay_cycl$4 ==.
                           000004    75 	Sspse_stm8$_delay_cycl$5 ==.
                                     76 ;	inc/delay.h: 27: __ticks--;//      2c;                 1c;     2c    ; 1/2c   
                                     77 ; genMinus
      0081D8 5A               [ 2]   78 	decw	x
                           000005    79 	Sspse_stm8$_delay_cycl$6 ==.
                           000005    80 	Sspse_stm8$_delay_cycl$7 ==.
                                     81 ;	inc/delay.h: 28: } while ( __ticks );
                                     82 ; genIfx
      0081D9 5D               [ 2]   83 	tnzw	x
      0081DA 27 03            [ 1]   84 	jreq	00117$
      0081DC CC 81 D8         [ 2]   85 	jp	00101$
      0081DF                         86 00117$:
                           00000B    87 	Sspse_stm8$_delay_cycl$8 ==.
                                     88 ;	inc/delay.h: 29: __asm__("nop\n");
                                     89 ;	genInline
      0081DF 9D               [ 1]   90 	nop
                                     91 ; genLabel
      0081E0                         92 00104$:
                           00000C    93 	Sspse_stm8$_delay_cycl$9 ==.
                                     94 ;	inc/delay.h: 39: }
                                     95 ; genEndFunction
                           00000C    96 	Sspse_stm8$_delay_cycl$10 ==.
                           00000C    97 	XFspse_stm8$_delay_cycl$0$0 ==.
      0081E0 81               [ 4]   98 	ret
                           00000D    99 	Sspse_stm8$_delay_cycl$11 ==.
                           00000D   100 	Sspse_stm8$_delay_us$12 ==.
                                    101 ;	inc/delay.h: 41: static @inline void _delay_us( const unsigned short __us ){
                                    102 ; genLabel
                                    103 ;	-----------------------------------------
                                    104 ;	 function _delay_us
                                    105 ;	-----------------------------------------
                                    106 ;	Register assignment might be sub-optimal.
                                    107 ;	Stack space usage: 0 bytes.
      0081E1                        108 __delay_us:
                           00000D   109 	Sspse_stm8$_delay_us$13 ==.
                           00000D   110 	Sspse_stm8$_delay_us$14 ==.
                                    111 ;	inc/delay.h: 42: _delay_cycl( (unsigned short)( T_COUNT(__us) ));
                                    112 ; genCast
                                    113 ; genAssign
      0081E1 16 03            [ 2]  114 	ldw	y, (0x03, sp)
      0081E3 5F               [ 1]  115 	clrw	x
                                    116 ; genIPush
      0081E4 90 89            [ 2]  117 	pushw	y
                           000012   118 	Sspse_stm8$_delay_us$15 ==.
      0081E6 89               [ 2]  119 	pushw	x
                           000013   120 	Sspse_stm8$_delay_us$16 ==.
                                    121 ; genIPush
      0081E7 4B 00            [ 1]  122 	push	#0x00
                           000015   123 	Sspse_stm8$_delay_us$17 ==.
      0081E9 4B 24            [ 1]  124 	push	#0x24
                           000017   125 	Sspse_stm8$_delay_us$18 ==.
      0081EB 4B F4            [ 1]  126 	push	#0xf4
                           000019   127 	Sspse_stm8$_delay_us$19 ==.
      0081ED 4B 00            [ 1]  128 	push	#0x00
                           00001B   129 	Sspse_stm8$_delay_us$20 ==.
                                    130 ; genCall
      0081EF CD A4 CA         [ 4]  131 	call	__mullong
      0081F2 5B 08            [ 2]  132 	addw	sp, #8
                           000020   133 	Sspse_stm8$_delay_us$21 ==.
                           000020   134 	Sspse_stm8$_delay_us$22 ==.
                                    135 ; genCast
                                    136 ; genAssign
                                    137 ; genIPush
      0081F4 4B 40            [ 1]  138 	push	#0x40
                           000022   139 	Sspse_stm8$_delay_us$23 ==.
      0081F6 4B 42            [ 1]  140 	push	#0x42
                           000024   141 	Sspse_stm8$_delay_us$24 ==.
      0081F8 4B 0F            [ 1]  142 	push	#0x0f
                           000026   143 	Sspse_stm8$_delay_us$25 ==.
      0081FA 4B 00            [ 1]  144 	push	#0x00
                           000028   145 	Sspse_stm8$_delay_us$26 ==.
                                    146 ; genIPush
      0081FC 89               [ 2]  147 	pushw	x
                           000029   148 	Sspse_stm8$_delay_us$27 ==.
      0081FD 90 89            [ 2]  149 	pushw	y
                           00002B   150 	Sspse_stm8$_delay_us$28 ==.
                                    151 ; genCall
      0081FF CD A4 4C         [ 4]  152 	call	__divulong
      008202 5B 08            [ 2]  153 	addw	sp, #8
                           000030   154 	Sspse_stm8$_delay_us$29 ==.
                           000030   155 	Sspse_stm8$_delay_us$30 ==.
                                    156 ; genRightShiftLiteral
      008204 90 54            [ 2]  157 	srlw	y
      008206 56               [ 2]  158 	rrcw	x
      008207 90 54            [ 2]  159 	srlw	y
      008209 56               [ 2]  160 	rrcw	x
      00820A 90 54            [ 2]  161 	srlw	y
      00820C 56               [ 2]  162 	rrcw	x
                                    163 ; genCast
                                    164 ; genAssign
                           000039   165 	Sspse_stm8$_delay_us$31 ==.
                                    166 ; genPlus
      00820D 5C               [ 1]  167 	incw	x
                                    168 ; genAssign
                                    169 ; genAssign
                           00003A   170 	Sspse_stm8$_delay_us$32 ==.
                                    171 ; genAssign
                           00003A   172 	Sspse_stm8$_delay_us$33 ==.
                                    173 ;	inc/delay.h: 25: __asm__("nop\n nop\n"); 
                                    174 ;	genInline
      00820E 9D               [ 1]  175 	nop
      00820F 9D               [ 1]  176 	nop
                           00003C   177 	Sspse_stm8$_delay_us$34 ==.
                           00003C   178 	Sspse_stm8$_delay_us$35 ==.
                                    179 ;	inc/delay.h: 26: do { 		// ASM: ldw X, #tick; lab$: decw X; tnzw X; jrne lab$
                                    180 ; genAssign
                                    181 ; genLabel
      008210                        182 00101$:
                           00003C   183 	Sspse_stm8$_delay_us$36 ==.
                                    184 ;	inc/delay.h: 27: __ticks--;//      2c;                 1c;     2c    ; 1/2c   
                                    185 ; genMinus
      008210 5A               [ 2]  186 	decw	x
                           00003D   187 	Sspse_stm8$_delay_us$37 ==.
                                    188 ;	inc/delay.h: 28: } while ( __ticks );
                                    189 ; genIfx
      008211 5D               [ 2]  190 	tnzw	x
      008212 27 03            [ 1]  191 	jreq	00118$
      008214 CC 82 10         [ 2]  192 	jp	00101$
      008217                        193 00118$:
                                    194 ;	inc/delay.h: 29: __asm__("nop\n");
                                    195 ;	genInline
      008217 9D               [ 1]  196 	nop
                           000044   197 	Sspse_stm8$_delay_us$38 ==.
                           000044   198 	Sspse_stm8$_delay_us$39 ==.
                                    199 ;	inc/delay.h: 42: _delay_cycl( (unsigned short)( T_COUNT(__us) ));
                                    200 ; genLabel
      008218                        201 00105$:
                           000044   202 	Sspse_stm8$_delay_us$40 ==.
                                    203 ;	inc/delay.h: 43: }
                                    204 ; genEndFunction
                           000044   205 	Sspse_stm8$_delay_us$41 ==.
                           000044   206 	XFspse_stm8$_delay_us$0$0 ==.
      008218 81               [ 4]  207 	ret
                           000045   208 	Sspse_stm8$_delay_us$42 ==.
                           000045   209 	Sspse_stm8$ADC_get$43 ==.
                                    210 ;	./src/spse_stm8.c: 10: uint16_t ADC_get(ADC2_Channel_TypeDef ADC2_Channel){
                                    211 ; genLabel
                                    212 ;	-----------------------------------------
                                    213 ;	 function ADC_get
                                    214 ;	-----------------------------------------
                                    215 ;	Register assignment is optimal.
                                    216 ;	Stack space usage: 0 bytes.
      008219                        217 _ADC_get:
                           000045   218 	Sspse_stm8$ADC_get$44 ==.
                           000045   219 	Sspse_stm8$ADC_get$45 ==.
                                    220 ;	./src/spse_stm8.c: 11: ADC2_Select_Channel(ADC2_Channel); // vybere kan�l / nastavuje analogov� multiplexer
                                    221 ; genIPush
      008219 7B 03            [ 1]  222 	ld	a, (0x03, sp)
      00821B 88               [ 1]  223 	push	a
                           000048   224 	Sspse_stm8$ADC_get$46 ==.
                                    225 ; genCall
      00821C CD 82 3D         [ 4]  226 	call	_ADC2_Select_Channel
      00821F 84               [ 1]  227 	pop	a
                           00004C   228 	Sspse_stm8$ADC_get$47 ==.
                           00004C   229 	Sspse_stm8$ADC_get$48 ==.
                                    230 ;	./src/spse_stm8.c: 12: ADC2->CR1 |= ADC2_CR1_ADON; // Start Conversion (ADON must be SET before => ADC must be enabled !)
                                    231 ; genPointerGet
      008220 C6 54 01         [ 1]  232 	ld	a, 0x5401
                                    233 ; genOr
      008223 AA 01            [ 1]  234 	or	a, #0x01
                                    235 ; genPointerSet
      008225 C7 54 01         [ 1]  236 	ld	0x5401, a
                           000054   237 	Sspse_stm8$ADC_get$49 ==.
                                    238 ;	./src/spse_stm8.c: 13: while(!(ADC2->CSR & ADC2_CSR_EOC)); // �ek� na dokon�en� p�evodu (End Of Conversion)
                                    239 ; genLabel
      008228                        240 00101$:
                                    241 ; genPointerGet
      008228 C6 54 00         [ 1]  242 	ld	a, 0x5400
                                    243 ; genAnd
      00822B 4D               [ 1]  244 	tnz	a
      00822C 2B 03            [ 1]  245 	jrmi	00116$
      00822E CC 82 28         [ 2]  246 	jp	00101$
      008231                        247 00116$:
                                    248 ; skipping generated iCode
                           00005D   249 	Sspse_stm8$ADC_get$50 ==.
                                    250 ;	./src/spse_stm8.c: 14: ADC2->CSR &=~ADC2_CSR_EOC; // ma�e vlajku 
                                    251 ; genPointerGet
      008231 C6 54 00         [ 1]  252 	ld	a, 0x5400
                                    253 ; genAnd
      008234 A4 7F            [ 1]  254 	and	a, #0x7f
                                    255 ; genPointerSet
      008236 C7 54 00         [ 1]  256 	ld	0x5400, a
                           000065   257 	Sspse_stm8$ADC_get$51 ==.
                                    258 ;	./src/spse_stm8.c: 15: return ADC2_GetConversionValue(); // vrac� v�sledek
                                    259 ; genCall
      008239 CC 9E 12         [ 2]  260 	jp	_ADC2_GetConversionValue
                                    261 ; genReturn
                                    262 ; genLabel
      00823C                        263 00104$:
                           000068   264 	Sspse_stm8$ADC_get$52 ==.
                                    265 ;	./src/spse_stm8.c: 16: }
                                    266 ; genEndFunction
                           000068   267 	Sspse_stm8$ADC_get$53 ==.
                           000068   268 	XG$ADC_get$0$0 ==.
      00823C 81               [ 4]  269 	ret
                           000069   270 	Sspse_stm8$ADC_get$54 ==.
                           000069   271 	Sspse_stm8$ADC2_Select_Channel$55 ==.
                                    272 ;	./src/spse_stm8.c: 21: void ADC2_Select_Channel(ADC2_Channel_TypeDef ADC2_Channel){
                                    273 ; genLabel
                                    274 ;	-----------------------------------------
                                    275 ;	 function ADC2_Select_Channel
                                    276 ;	-----------------------------------------
                                    277 ;	Register assignment is optimal.
                                    278 ;	Stack space usage: 1 bytes.
      00823D                        279 _ADC2_Select_Channel:
                           000069   280 	Sspse_stm8$ADC2_Select_Channel$56 ==.
      00823D 88               [ 1]  281 	push	a
                           00006A   282 	Sspse_stm8$ADC2_Select_Channel$57 ==.
                           00006A   283 	Sspse_stm8$ADC2_Select_Channel$58 ==.
                                    284 ;	./src/spse_stm8.c: 22: uint8_t tmp = (ADC2->CSR) & (~ADC2_CSR_CH);
                                    285 ; genPointerGet
      00823E C6 54 00         [ 1]  286 	ld	a, 0x5400
                                    287 ; genAnd
      008241 A4 F0            [ 1]  288 	and	a, #0xf0
      008243 6B 01            [ 1]  289 	ld	(0x01, sp), a
                           000071   290 	Sspse_stm8$ADC2_Select_Channel$59 ==.
                                    291 ;	./src/spse_stm8.c: 23: tmp |= ADC2_Channel | ADC2_CSR_EOC;
                                    292 ; genOr
      008245 7B 04            [ 1]  293 	ld	a, (0x04, sp)
      008247 AA 80            [ 1]  294 	or	a, #0x80
                                    295 ; genOr
      008249 1A 01            [ 1]  296 	or	a, (0x01, sp)
                                    297 ; genAssign
                           000077   298 	Sspse_stm8$ADC2_Select_Channel$60 ==.
                                    299 ;	./src/spse_stm8.c: 24: ADC2->CSR = tmp;
                                    300 ; genPointerSet
      00824B C7 54 00         [ 1]  301 	ld	0x5400, a
                                    302 ; genLabel
      00824E                        303 00101$:
                           00007A   304 	Sspse_stm8$ADC2_Select_Channel$61 ==.
                                    305 ;	./src/spse_stm8.c: 25: }
                                    306 ; genEndFunction
      00824E 84               [ 1]  307 	pop	a
                           00007B   308 	Sspse_stm8$ADC2_Select_Channel$62 ==.
                           00007B   309 	Sspse_stm8$ADC2_Select_Channel$63 ==.
                           00007B   310 	XG$ADC2_Select_Channel$0$0 ==.
      00824F 81               [ 4]  311 	ret
                           00007C   312 	Sspse_stm8$ADC2_Select_Channel$64 ==.
                           00007C   313 	Sspse_stm8$ADC2_AlignConfig$65 ==.
                                    314 ;	./src/spse_stm8.c: 30: void ADC2_AlignConfig(ADC2_Align_TypeDef ADC2_Align){
                                    315 ; genLabel
                                    316 ;	-----------------------------------------
                                    317 ;	 function ADC2_AlignConfig
                                    318 ;	-----------------------------------------
                                    319 ;	Register assignment is optimal.
                                    320 ;	Stack space usage: 0 bytes.
      008250                        321 _ADC2_AlignConfig:
                           00007C   322 	Sspse_stm8$ADC2_AlignConfig$66 ==.
                           00007C   323 	Sspse_stm8$ADC2_AlignConfig$67 ==.
                                    324 ;	./src/spse_stm8.c: 32: ADC2->CR2 |= (uint8_t)(ADC2_Align);
                                    325 ; genPointerGet
      008250 C6 54 02         [ 1]  326 	ld	a, 0x5402
                           00007F   327 	Sspse_stm8$ADC2_AlignConfig$68 ==.
                                    328 ;	./src/spse_stm8.c: 31: if(ADC2_Align){
                                    329 ; genIfx
      008253 0D 03            [ 1]  330 	tnz	(0x03, sp)
      008255 26 03            [ 1]  331 	jrne	00111$
      008257 CC 82 62         [ 2]  332 	jp	00102$
      00825A                        333 00111$:
                           000086   334 	Sspse_stm8$ADC2_AlignConfig$69 ==.
                           000086   335 	Sspse_stm8$ADC2_AlignConfig$70 ==.
                                    336 ;	./src/spse_stm8.c: 32: ADC2->CR2 |= (uint8_t)(ADC2_Align);
                                    337 ; genOr
      00825A 1A 03            [ 1]  338 	or	a, (0x03, sp)
                                    339 ; genPointerSet
      00825C C7 54 02         [ 1]  340 	ld	0x5402, a
                           00008B   341 	Sspse_stm8$ADC2_AlignConfig$71 ==.
                                    342 ; genGoto
      00825F CC 82 67         [ 2]  343 	jp	00104$
                                    344 ; genLabel
      008262                        345 00102$:
                           00008E   346 	Sspse_stm8$ADC2_AlignConfig$72 ==.
                           00008E   347 	Sspse_stm8$ADC2_AlignConfig$73 ==.
                                    348 ;	./src/spse_stm8.c: 34: ADC2->CR2 &= (uint8_t)(~ADC2_CR2_ALIGN);
                                    349 ; genAnd
      008262 A4 F7            [ 1]  350 	and	a, #0xf7
                                    351 ; genPointerSet
      008264 C7 54 02         [ 1]  352 	ld	0x5402, a
                           000093   353 	Sspse_stm8$ADC2_AlignConfig$74 ==.
                                    354 ; genLabel
      008267                        355 00104$:
                           000093   356 	Sspse_stm8$ADC2_AlignConfig$75 ==.
                                    357 ;	./src/spse_stm8.c: 36: }
                                    358 ; genEndFunction
                           000093   359 	Sspse_stm8$ADC2_AlignConfig$76 ==.
                           000093   360 	XG$ADC2_AlignConfig$0$0 ==.
      008267 81               [ 4]  361 	ret
                           000094   362 	Sspse_stm8$ADC2_AlignConfig$77 ==.
                           000094   363 	Sspse_stm8$ADC2_Startup_Wait$78 ==.
                                    364 ;	./src/spse_stm8.c: 40: void ADC2_Startup_Wait(void){
                                    365 ; genLabel
                                    366 ;	-----------------------------------------
                                    367 ;	 function ADC2_Startup_Wait
                                    368 ;	-----------------------------------------
                                    369 ;	Register assignment is optimal.
                                    370 ;	Stack space usage: 0 bytes.
      008268                        371 _ADC2_Startup_Wait:
                           000094   372 	Sspse_stm8$ADC2_Startup_Wait$79 ==.
                           000094   373 	Sspse_stm8$ADC2_Startup_Wait$80 ==.
                                    374 ;	inc/delay.h: 42: _delay_cycl( (unsigned short)( T_COUNT(__us) ));
                                    375 ; genAssign
      008268 AE 00 0F         [ 2]  376 	ldw	x, #0x000f
                           000097   377 	Sspse_stm8$ADC2_Startup_Wait$81 ==.
                                    378 ;	inc/delay.h: 25: __asm__("nop\n nop\n"); 
                                    379 ;	genInline
      00826B 9D               [ 1]  380 	nop
      00826C 9D               [ 1]  381 	nop
                           000099   382 	Sspse_stm8$ADC2_Startup_Wait$82 ==.
                           000099   383 	Sspse_stm8$ADC2_Startup_Wait$83 ==.
                                    384 ;	inc/delay.h: 26: do { 		// ASM: ldw X, #tick; lab$: decw X; tnzw X; jrne lab$
                                    385 ; genAssign
                                    386 ; genLabel
      00826D                        387 00101$:
                           000099   388 	Sspse_stm8$ADC2_Startup_Wait$84 ==.
                                    389 ;	inc/delay.h: 27: __ticks--;//      2c;                 1c;     2c    ; 1/2c   
                                    390 ; genMinus
      00826D 5A               [ 2]  391 	decw	x
                           00009A   392 	Sspse_stm8$ADC2_Startup_Wait$85 ==.
                                    393 ;	inc/delay.h: 28: } while ( __ticks );
                                    394 ; genIfx
      00826E 5D               [ 2]  395 	tnzw	x
      00826F 27 03            [ 1]  396 	jreq	00119$
      008271 CC 82 6D         [ 2]  397 	jp	00101$
      008274                        398 00119$:
                                    399 ;	inc/delay.h: 29: __asm__("nop\n");
                                    400 ;	genInline
      008274 9D               [ 1]  401 	nop
                           0000A1   402 	Sspse_stm8$ADC2_Startup_Wait$86 ==.
                           0000A1   403 	Sspse_stm8$ADC2_Startup_Wait$87 ==.
                                    404 ;	./src/spse_stm8.c: 41: _delay_us(ADC_TSTAB);
                                    405 ; genLabel
      008275                        406 00106$:
                           0000A1   407 	Sspse_stm8$ADC2_Startup_Wait$88 ==.
                                    408 ;	./src/spse_stm8.c: 42: }
                                    409 ; genEndFunction
                           0000A1   410 	Sspse_stm8$ADC2_Startup_Wait$89 ==.
                           0000A1   411 	XG$ADC2_Startup_Wait$0$0 ==.
      008275 81               [ 4]  412 	ret
                           0000A2   413 	Sspse_stm8$ADC2_Startup_Wait$90 ==.
                                    414 	.area CODE
                                    415 	.area CONST
                                    416 	.area INITIALIZER
                                    417 	.area CABS (ABS)
                                    418 
                                    419 	.area .debug_line (NOLOAD)
      000235 00 00 01 95            420 	.dw	0,Ldebug_line_end-Ldebug_line_start
      000239                        421 Ldebug_line_start:
      000239 00 02                  422 	.dw	2
      00023B 00 00 00 81            423 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      00023F 01                     424 	.db	1
      000240 01                     425 	.db	1
      000241 FB                     426 	.db	-5
      000242 0F                     427 	.db	15
      000243 0A                     428 	.db	10
      000244 00                     429 	.db	0
      000245 01                     430 	.db	1
      000246 01                     431 	.db	1
      000247 01                     432 	.db	1
      000248 01                     433 	.db	1
      000249 00                     434 	.db	0
      00024A 00                     435 	.db	0
      00024B 00                     436 	.db	0
      00024C 01                     437 	.db	1
      00024D 43 3A 5C 50 72 6F 67   438 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      000275 00                     439 	.db	0
      000276 43 3A 5C 50 72 6F 67   440 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      000299 00                     441 	.db	0
      00029A 00                     442 	.db	0
      00029B 69 6E 63 2F 64 65 6C   443 	.ascii "inc/delay.h"
             61 79 2E 68
      0002A6 00                     444 	.db	0
      0002A7 00                     445 	.uleb128	0
      0002A8 00                     446 	.uleb128	0
      0002A9 00                     447 	.uleb128	0
      0002AA 2E 2F 73 72 63 2F 73   448 	.ascii "./src/spse_stm8.c"
             70 73 65 5F 73 74 6D
             38 2E 63
      0002BB 00                     449 	.db	0
      0002BC 00                     450 	.uleb128	0
      0002BD 00                     451 	.uleb128	0
      0002BE 00                     452 	.uleb128	0
      0002BF 00                     453 	.db	0
      0002C0                        454 Ldebug_line_stmt:
      0002C0 00                     455 	.db	0
      0002C1 05                     456 	.uleb128	5
      0002C2 02                     457 	.db	2
      0002C3 00 00 81 D4            458 	.dw	0,(Sspse_stm8$_delay_cycl$0)
      0002C7 03                     459 	.db	3
      0002C8 0D                     460 	.sleb128	13
      0002C9 01                     461 	.db	1
      0002CA 09                     462 	.db	9
      0002CB 00 00                  463 	.dw	Sspse_stm8$_delay_cycl$2-Sspse_stm8$_delay_cycl$0
      0002CD 03                     464 	.db	3
      0002CE 0B                     465 	.sleb128	11
      0002CF 01                     466 	.db	1
      0002D0 09                     467 	.db	9
      0002D1 00 02                  468 	.dw	Sspse_stm8$_delay_cycl$3-Sspse_stm8$_delay_cycl$2
      0002D3 03                     469 	.db	3
      0002D4 01                     470 	.sleb128	1
      0002D5 01                     471 	.db	1
      0002D6 09                     472 	.db	9
      0002D7 00 02                  473 	.dw	Sspse_stm8$_delay_cycl$5-Sspse_stm8$_delay_cycl$3
      0002D9 03                     474 	.db	3
      0002DA 01                     475 	.sleb128	1
      0002DB 01                     476 	.db	1
      0002DC 09                     477 	.db	9
      0002DD 00 01                  478 	.dw	Sspse_stm8$_delay_cycl$7-Sspse_stm8$_delay_cycl$5
      0002DF 03                     479 	.db	3
      0002E0 01                     480 	.sleb128	1
      0002E1 01                     481 	.db	1
      0002E2 09                     482 	.db	9
      0002E3 00 06                  483 	.dw	Sspse_stm8$_delay_cycl$8-Sspse_stm8$_delay_cycl$7
      0002E5 03                     484 	.db	3
      0002E6 01                     485 	.sleb128	1
      0002E7 01                     486 	.db	1
      0002E8 09                     487 	.db	9
      0002E9 00 01                  488 	.dw	Sspse_stm8$_delay_cycl$9-Sspse_stm8$_delay_cycl$8
      0002EB 03                     489 	.db	3
      0002EC 0A                     490 	.sleb128	10
      0002ED 01                     491 	.db	1
      0002EE 09                     492 	.db	9
      0002EF 00 01                  493 	.dw	1+Sspse_stm8$_delay_cycl$10-Sspse_stm8$_delay_cycl$9
      0002F1 00                     494 	.db	0
      0002F2 01                     495 	.uleb128	1
      0002F3 01                     496 	.db	1
      0002F4 00                     497 	.db	0
      0002F5 05                     498 	.uleb128	5
      0002F6 02                     499 	.db	2
      0002F7 00 00 81 E1            500 	.dw	0,(Sspse_stm8$_delay_us$12)
      0002FB 03                     501 	.db	3
      0002FC 28                     502 	.sleb128	40
      0002FD 01                     503 	.db	1
      0002FE 09                     504 	.db	9
      0002FF 00 2F                  505 	.dw	Sspse_stm8$_delay_us$35-Sspse_stm8$_delay_us$12
      000301 03                     506 	.db	3
      000302 71                     507 	.sleb128	-15
      000303 01                     508 	.db	1
      000304 09                     509 	.db	9
      000305 00 08                  510 	.dw	Sspse_stm8$_delay_us$39-Sspse_stm8$_delay_us$35
      000307 03                     511 	.db	3
      000308 10                     512 	.sleb128	16
      000309 01                     513 	.db	1
      00030A 09                     514 	.db	9
      00030B 00 00                  515 	.dw	Sspse_stm8$_delay_us$40-Sspse_stm8$_delay_us$39
      00030D 03                     516 	.db	3
      00030E 01                     517 	.sleb128	1
      00030F 01                     518 	.db	1
      000310 09                     519 	.db	9
      000311 00 01                  520 	.dw	1+Sspse_stm8$_delay_us$41-Sspse_stm8$_delay_us$40
      000313 00                     521 	.db	0
      000314 01                     522 	.uleb128	1
      000315 01                     523 	.db	1
      000316 04                     524 	.db	4
      000317 02                     525 	.uleb128	2
      000318 00                     526 	.db	0
      000319 05                     527 	.uleb128	5
      00031A 02                     528 	.db	2
      00031B 00 00 82 19            529 	.dw	0,(Sspse_stm8$ADC_get$43)
      00031F 03                     530 	.db	3
      000320 09                     531 	.sleb128	9
      000321 01                     532 	.db	1
      000322 09                     533 	.db	9
      000323 00 00                  534 	.dw	Sspse_stm8$ADC_get$45-Sspse_stm8$ADC_get$43
      000325 03                     535 	.db	3
      000326 01                     536 	.sleb128	1
      000327 01                     537 	.db	1
      000328 09                     538 	.db	9
      000329 00 07                  539 	.dw	Sspse_stm8$ADC_get$48-Sspse_stm8$ADC_get$45
      00032B 03                     540 	.db	3
      00032C 01                     541 	.sleb128	1
      00032D 01                     542 	.db	1
      00032E 09                     543 	.db	9
      00032F 00 08                  544 	.dw	Sspse_stm8$ADC_get$49-Sspse_stm8$ADC_get$48
      000331 03                     545 	.db	3
      000332 01                     546 	.sleb128	1
      000333 01                     547 	.db	1
      000334 09                     548 	.db	9
      000335 00 09                  549 	.dw	Sspse_stm8$ADC_get$50-Sspse_stm8$ADC_get$49
      000337 03                     550 	.db	3
      000338 01                     551 	.sleb128	1
      000339 01                     552 	.db	1
      00033A 09                     553 	.db	9
      00033B 00 08                  554 	.dw	Sspse_stm8$ADC_get$51-Sspse_stm8$ADC_get$50
      00033D 03                     555 	.db	3
      00033E 01                     556 	.sleb128	1
      00033F 01                     557 	.db	1
      000340 09                     558 	.db	9
      000341 00 03                  559 	.dw	Sspse_stm8$ADC_get$52-Sspse_stm8$ADC_get$51
      000343 03                     560 	.db	3
      000344 01                     561 	.sleb128	1
      000345 01                     562 	.db	1
      000346 09                     563 	.db	9
      000347 00 01                  564 	.dw	1+Sspse_stm8$ADC_get$53-Sspse_stm8$ADC_get$52
      000349 00                     565 	.db	0
      00034A 01                     566 	.uleb128	1
      00034B 01                     567 	.db	1
      00034C 04                     568 	.db	4
      00034D 02                     569 	.uleb128	2
      00034E 00                     570 	.db	0
      00034F 05                     571 	.uleb128	5
      000350 02                     572 	.db	2
      000351 00 00 82 3D            573 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$55)
      000355 03                     574 	.db	3
      000356 14                     575 	.sleb128	20
      000357 01                     576 	.db	1
      000358 09                     577 	.db	9
      000359 00 01                  578 	.dw	Sspse_stm8$ADC2_Select_Channel$58-Sspse_stm8$ADC2_Select_Channel$55
      00035B 03                     579 	.db	3
      00035C 01                     580 	.sleb128	1
      00035D 01                     581 	.db	1
      00035E 09                     582 	.db	9
      00035F 00 07                  583 	.dw	Sspse_stm8$ADC2_Select_Channel$59-Sspse_stm8$ADC2_Select_Channel$58
      000361 03                     584 	.db	3
      000362 01                     585 	.sleb128	1
      000363 01                     586 	.db	1
      000364 09                     587 	.db	9
      000365 00 06                  588 	.dw	Sspse_stm8$ADC2_Select_Channel$60-Sspse_stm8$ADC2_Select_Channel$59
      000367 03                     589 	.db	3
      000368 01                     590 	.sleb128	1
      000369 01                     591 	.db	1
      00036A 09                     592 	.db	9
      00036B 00 03                  593 	.dw	Sspse_stm8$ADC2_Select_Channel$61-Sspse_stm8$ADC2_Select_Channel$60
      00036D 03                     594 	.db	3
      00036E 01                     595 	.sleb128	1
      00036F 01                     596 	.db	1
      000370 09                     597 	.db	9
      000371 00 02                  598 	.dw	1+Sspse_stm8$ADC2_Select_Channel$63-Sspse_stm8$ADC2_Select_Channel$61
      000373 00                     599 	.db	0
      000374 01                     600 	.uleb128	1
      000375 01                     601 	.db	1
      000376 04                     602 	.db	4
      000377 02                     603 	.uleb128	2
      000378 00                     604 	.db	0
      000379 05                     605 	.uleb128	5
      00037A 02                     606 	.db	2
      00037B 00 00 82 50            607 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$65)
      00037F 03                     608 	.db	3
      000380 1D                     609 	.sleb128	29
      000381 01                     610 	.db	1
      000382 09                     611 	.db	9
      000383 00 00                  612 	.dw	Sspse_stm8$ADC2_AlignConfig$67-Sspse_stm8$ADC2_AlignConfig$65
      000385 03                     613 	.db	3
      000386 02                     614 	.sleb128	2
      000387 01                     615 	.db	1
      000388 09                     616 	.db	9
      000389 00 03                  617 	.dw	Sspse_stm8$ADC2_AlignConfig$68-Sspse_stm8$ADC2_AlignConfig$67
      00038B 03                     618 	.db	3
      00038C 7F                     619 	.sleb128	-1
      00038D 01                     620 	.db	1
      00038E 09                     621 	.db	9
      00038F 00 07                  622 	.dw	Sspse_stm8$ADC2_AlignConfig$70-Sspse_stm8$ADC2_AlignConfig$68
      000391 03                     623 	.db	3
      000392 01                     624 	.sleb128	1
      000393 01                     625 	.db	1
      000394 09                     626 	.db	9
      000395 00 08                  627 	.dw	Sspse_stm8$ADC2_AlignConfig$73-Sspse_stm8$ADC2_AlignConfig$70
      000397 03                     628 	.db	3
      000398 02                     629 	.sleb128	2
      000399 01                     630 	.db	1
      00039A 09                     631 	.db	9
      00039B 00 05                  632 	.dw	Sspse_stm8$ADC2_AlignConfig$75-Sspse_stm8$ADC2_AlignConfig$73
      00039D 03                     633 	.db	3
      00039E 02                     634 	.sleb128	2
      00039F 01                     635 	.db	1
      0003A0 09                     636 	.db	9
      0003A1 00 01                  637 	.dw	1+Sspse_stm8$ADC2_AlignConfig$76-Sspse_stm8$ADC2_AlignConfig$75
      0003A3 00                     638 	.db	0
      0003A4 01                     639 	.uleb128	1
      0003A5 01                     640 	.db	1
      0003A6 04                     641 	.db	4
      0003A7 02                     642 	.uleb128	2
      0003A8 00                     643 	.db	0
      0003A9 05                     644 	.uleb128	5
      0003AA 02                     645 	.db	2
      0003AB 00 00 82 68            646 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$78)
      0003AF 03                     647 	.db	3
      0003B0 27                     648 	.sleb128	39
      0003B1 01                     649 	.db	1
      0003B2 04                     650 	.db	4
      0003B3 01                     651 	.uleb128	1
      0003B4 09                     652 	.db	9
      0003B5 00 05                  653 	.dw	Sspse_stm8$ADC2_Startup_Wait$83-Sspse_stm8$ADC2_Startup_Wait$78
      0003B7 03                     654 	.db	3
      0003B8 72                     655 	.sleb128	-14
      0003B9 01                     656 	.db	1
      0003BA 04                     657 	.db	4
      0003BB 02                     658 	.uleb128	2
      0003BC 09                     659 	.db	9
      0003BD 00 08                  660 	.dw	Sspse_stm8$ADC2_Startup_Wait$87-Sspse_stm8$ADC2_Startup_Wait$83
      0003BF 03                     661 	.db	3
      0003C0 0F                     662 	.sleb128	15
      0003C1 01                     663 	.db	1
      0003C2 09                     664 	.db	9
      0003C3 00 00                  665 	.dw	Sspse_stm8$ADC2_Startup_Wait$88-Sspse_stm8$ADC2_Startup_Wait$87
      0003C5 03                     666 	.db	3
      0003C6 01                     667 	.sleb128	1
      0003C7 01                     668 	.db	1
      0003C8 09                     669 	.db	9
      0003C9 00 01                  670 	.dw	1+Sspse_stm8$ADC2_Startup_Wait$89-Sspse_stm8$ADC2_Startup_Wait$88
      0003CB 00                     671 	.db	0
      0003CC 01                     672 	.uleb128	1
      0003CD 01                     673 	.db	1
      0003CE                        674 Ldebug_line_end:
                                    675 
                                    676 	.area .debug_loc (NOLOAD)
      000364                        677 Ldebug_loc_start:
      000364 00 00 82 68            678 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$79)
      000368 00 00 82 76            679 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$90)
      00036C 00 02                  680 	.dw	2
      00036E 78                     681 	.db	120
      00036F 01                     682 	.sleb128	1
      000370 00 00 00 00            683 	.dw	0,0
      000374 00 00 00 00            684 	.dw	0,0
      000378 00 00 82 50            685 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$66)
      00037C 00 00 82 68            686 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$77)
      000380 00 02                  687 	.dw	2
      000382 78                     688 	.db	120
      000383 01                     689 	.sleb128	1
      000384 00 00 00 00            690 	.dw	0,0
      000388 00 00 00 00            691 	.dw	0,0
      00038C 00 00 82 4F            692 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$62)
      000390 00 00 82 50            693 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$64)
      000394 00 02                  694 	.dw	2
      000396 78                     695 	.db	120
      000397 01                     696 	.sleb128	1
      000398 00 00 82 3E            697 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$57)
      00039C 00 00 82 4F            698 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$62)
      0003A0 00 02                  699 	.dw	2
      0003A2 78                     700 	.db	120
      0003A3 02                     701 	.sleb128	2
      0003A4 00 00 82 3D            702 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$56)
      0003A8 00 00 82 3E            703 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$57)
      0003AC 00 02                  704 	.dw	2
      0003AE 78                     705 	.db	120
      0003AF 01                     706 	.sleb128	1
      0003B0 00 00 00 00            707 	.dw	0,0
      0003B4 00 00 00 00            708 	.dw	0,0
      0003B8 00 00 82 20            709 	.dw	0,(Sspse_stm8$ADC_get$47)
      0003BC 00 00 82 3D            710 	.dw	0,(Sspse_stm8$ADC_get$54)
      0003C0 00 02                  711 	.dw	2
      0003C2 78                     712 	.db	120
      0003C3 01                     713 	.sleb128	1
      0003C4 00 00 82 1C            714 	.dw	0,(Sspse_stm8$ADC_get$46)
      0003C8 00 00 82 20            715 	.dw	0,(Sspse_stm8$ADC_get$47)
      0003CC 00 02                  716 	.dw	2
      0003CE 78                     717 	.db	120
      0003CF 02                     718 	.sleb128	2
      0003D0 00 00 82 19            719 	.dw	0,(Sspse_stm8$ADC_get$44)
      0003D4 00 00 82 1C            720 	.dw	0,(Sspse_stm8$ADC_get$46)
      0003D8 00 02                  721 	.dw	2
      0003DA 78                     722 	.db	120
      0003DB 01                     723 	.sleb128	1
      0003DC 00 00 00 00            724 	.dw	0,0
      0003E0 00 00 00 00            725 	.dw	0,0
      0003E4 00 00 82 04            726 	.dw	0,(Sspse_stm8$_delay_us$29)
      0003E8 00 00 82 19            727 	.dw	0,(Sspse_stm8$_delay_us$42)
      0003EC 00 02                  728 	.dw	2
      0003EE 78                     729 	.db	120
      0003EF 01                     730 	.sleb128	1
      0003F0 00 00 81 FF            731 	.dw	0,(Sspse_stm8$_delay_us$28)
      0003F4 00 00 82 04            732 	.dw	0,(Sspse_stm8$_delay_us$29)
      0003F8 00 02                  733 	.dw	2
      0003FA 78                     734 	.db	120
      0003FB 09                     735 	.sleb128	9
      0003FC 00 00 81 FD            736 	.dw	0,(Sspse_stm8$_delay_us$27)
      000400 00 00 81 FF            737 	.dw	0,(Sspse_stm8$_delay_us$28)
      000404 00 02                  738 	.dw	2
      000406 78                     739 	.db	120
      000407 07                     740 	.sleb128	7
      000408 00 00 81 FC            741 	.dw	0,(Sspse_stm8$_delay_us$26)
      00040C 00 00 81 FD            742 	.dw	0,(Sspse_stm8$_delay_us$27)
      000410 00 02                  743 	.dw	2
      000412 78                     744 	.db	120
      000413 05                     745 	.sleb128	5
      000414 00 00 81 FA            746 	.dw	0,(Sspse_stm8$_delay_us$25)
      000418 00 00 81 FC            747 	.dw	0,(Sspse_stm8$_delay_us$26)
      00041C 00 02                  748 	.dw	2
      00041E 78                     749 	.db	120
      00041F 04                     750 	.sleb128	4
      000420 00 00 81 F8            751 	.dw	0,(Sspse_stm8$_delay_us$24)
      000424 00 00 81 FA            752 	.dw	0,(Sspse_stm8$_delay_us$25)
      000428 00 02                  753 	.dw	2
      00042A 78                     754 	.db	120
      00042B 03                     755 	.sleb128	3
      00042C 00 00 81 F6            756 	.dw	0,(Sspse_stm8$_delay_us$23)
      000430 00 00 81 F8            757 	.dw	0,(Sspse_stm8$_delay_us$24)
      000434 00 02                  758 	.dw	2
      000436 78                     759 	.db	120
      000437 02                     760 	.sleb128	2
      000438 00 00 81 F4            761 	.dw	0,(Sspse_stm8$_delay_us$21)
      00043C 00 00 81 F6            762 	.dw	0,(Sspse_stm8$_delay_us$23)
      000440 00 02                  763 	.dw	2
      000442 78                     764 	.db	120
      000443 01                     765 	.sleb128	1
      000444 00 00 81 EF            766 	.dw	0,(Sspse_stm8$_delay_us$20)
      000448 00 00 81 F4            767 	.dw	0,(Sspse_stm8$_delay_us$21)
      00044C 00 02                  768 	.dw	2
      00044E 78                     769 	.db	120
      00044F 09                     770 	.sleb128	9
      000450 00 00 81 ED            771 	.dw	0,(Sspse_stm8$_delay_us$19)
      000454 00 00 81 EF            772 	.dw	0,(Sspse_stm8$_delay_us$20)
      000458 00 02                  773 	.dw	2
      00045A 78                     774 	.db	120
      00045B 08                     775 	.sleb128	8
      00045C 00 00 81 EB            776 	.dw	0,(Sspse_stm8$_delay_us$18)
      000460 00 00 81 ED            777 	.dw	0,(Sspse_stm8$_delay_us$19)
      000464 00 02                  778 	.dw	2
      000466 78                     779 	.db	120
      000467 07                     780 	.sleb128	7
      000468 00 00 81 E9            781 	.dw	0,(Sspse_stm8$_delay_us$17)
      00046C 00 00 81 EB            782 	.dw	0,(Sspse_stm8$_delay_us$18)
      000470 00 02                  783 	.dw	2
      000472 78                     784 	.db	120
      000473 06                     785 	.sleb128	6
      000474 00 00 81 E7            786 	.dw	0,(Sspse_stm8$_delay_us$16)
      000478 00 00 81 E9            787 	.dw	0,(Sspse_stm8$_delay_us$17)
      00047C 00 02                  788 	.dw	2
      00047E 78                     789 	.db	120
      00047F 05                     790 	.sleb128	5
      000480 00 00 81 E6            791 	.dw	0,(Sspse_stm8$_delay_us$15)
      000484 00 00 81 E7            792 	.dw	0,(Sspse_stm8$_delay_us$16)
      000488 00 02                  793 	.dw	2
      00048A 78                     794 	.db	120
      00048B 03                     795 	.sleb128	3
      00048C 00 00 81 E1            796 	.dw	0,(Sspse_stm8$_delay_us$13)
      000490 00 00 81 E6            797 	.dw	0,(Sspse_stm8$_delay_us$15)
      000494 00 02                  798 	.dw	2
      000496 78                     799 	.db	120
      000497 01                     800 	.sleb128	1
      000498 00 00 00 00            801 	.dw	0,0
      00049C 00 00 00 00            802 	.dw	0,0
      0004A0 00 00 81 D4            803 	.dw	0,(Sspse_stm8$_delay_cycl$1)
      0004A4 00 00 81 E1            804 	.dw	0,(Sspse_stm8$_delay_cycl$11)
      0004A8 00 02                  805 	.dw	2
      0004AA 78                     806 	.db	120
      0004AB 01                     807 	.sleb128	1
      0004AC 00 00 00 00            808 	.dw	0,0
      0004B0 00 00 00 00            809 	.dw	0,0
                                    810 
                                    811 	.area .debug_abbrev (NOLOAD)
      0000E5                        812 Ldebug_abbrev:
      0000E5 0D                     813 	.uleb128	13
      0000E6 0B                     814 	.uleb128	11
      0000E7 01                     815 	.db	1
      0000E8 00                     816 	.uleb128	0
      0000E9 00                     817 	.uleb128	0
      0000EA 03                     818 	.uleb128	3
      0000EB 05                     819 	.uleb128	5
      0000EC 00                     820 	.db	0
      0000ED 02                     821 	.uleb128	2
      0000EE 0A                     822 	.uleb128	10
      0000EF 03                     823 	.uleb128	3
      0000F0 08                     824 	.uleb128	8
      0000F1 49                     825 	.uleb128	73
      0000F2 13                     826 	.uleb128	19
      0000F3 00                     827 	.uleb128	0
      0000F4 00                     828 	.uleb128	0
      0000F5 02                     829 	.uleb128	2
      0000F6 2E                     830 	.uleb128	46
      0000F7 01                     831 	.db	1
      0000F8 01                     832 	.uleb128	1
      0000F9 13                     833 	.uleb128	19
      0000FA 03                     834 	.uleb128	3
      0000FB 08                     835 	.uleb128	8
      0000FC 11                     836 	.uleb128	17
      0000FD 01                     837 	.uleb128	1
      0000FE 12                     838 	.uleb128	18
      0000FF 01                     839 	.uleb128	1
      000100 3F                     840 	.uleb128	63
      000101 0C                     841 	.uleb128	12
      000102 40                     842 	.uleb128	64
      000103 06                     843 	.uleb128	6
      000104 00                     844 	.uleb128	0
      000105 00                     845 	.uleb128	0
      000106 0A                     846 	.uleb128	10
      000107 34                     847 	.uleb128	52
      000108 00                     848 	.db	0
      000109 02                     849 	.uleb128	2
      00010A 0A                     850 	.uleb128	10
      00010B 03                     851 	.uleb128	3
      00010C 08                     852 	.uleb128	8
      00010D 49                     853 	.uleb128	73
      00010E 13                     854 	.uleb128	19
      00010F 00                     855 	.uleb128	0
      000110 00                     856 	.uleb128	0
      000111 0B                     857 	.uleb128	11
      000112 2E                     858 	.uleb128	46
      000113 01                     859 	.db	1
      000114 01                     860 	.uleb128	1
      000115 13                     861 	.uleb128	19
      000116 03                     862 	.uleb128	3
      000117 08                     863 	.uleb128	8
      000118 11                     864 	.uleb128	17
      000119 01                     865 	.uleb128	1
      00011A 12                     866 	.uleb128	18
      00011B 01                     867 	.uleb128	1
      00011C 3F                     868 	.uleb128	63
      00011D 0C                     869 	.uleb128	12
      00011E 40                     870 	.uleb128	64
      00011F 06                     871 	.uleb128	6
      000120 49                     872 	.uleb128	73
      000121 13                     873 	.uleb128	19
      000122 00                     874 	.uleb128	0
      000123 00                     875 	.uleb128	0
      000124 0E                     876 	.uleb128	14
      000125 0B                     877 	.uleb128	11
      000126 01                     878 	.db	1
      000127 01                     879 	.uleb128	1
      000128 13                     880 	.uleb128	19
      000129 00                     881 	.uleb128	0
      00012A 00                     882 	.uleb128	0
      00012B 06                     883 	.uleb128	6
      00012C 26                     884 	.uleb128	38
      00012D 00                     885 	.db	0
      00012E 49                     886 	.uleb128	73
      00012F 13                     887 	.uleb128	19
      000130 00                     888 	.uleb128	0
      000131 00                     889 	.uleb128	0
      000132 01                     890 	.uleb128	1
      000133 11                     891 	.uleb128	17
      000134 01                     892 	.db	1
      000135 03                     893 	.uleb128	3
      000136 08                     894 	.uleb128	8
      000137 10                     895 	.uleb128	16
      000138 06                     896 	.uleb128	6
      000139 13                     897 	.uleb128	19
      00013A 0B                     898 	.uleb128	11
      00013B 25                     899 	.uleb128	37
      00013C 08                     900 	.uleb128	8
      00013D 00                     901 	.uleb128	0
      00013E 00                     902 	.uleb128	0
      00013F 04                     903 	.uleb128	4
      000140 0B                     904 	.uleb128	11
      000141 00                     905 	.db	0
      000142 11                     906 	.uleb128	17
      000143 01                     907 	.uleb128	1
      000144 12                     908 	.uleb128	18
      000145 01                     909 	.uleb128	1
      000146 00                     910 	.uleb128	0
      000147 00                     911 	.uleb128	0
      000148 07                     912 	.uleb128	7
      000149 0B                     913 	.uleb128	11
      00014A 01                     914 	.db	1
      00014B 11                     915 	.uleb128	17
      00014C 01                     916 	.uleb128	1
      00014D 12                     917 	.uleb128	18
      00014E 01                     918 	.uleb128	1
      00014F 00                     919 	.uleb128	0
      000150 00                     920 	.uleb128	0
      000151 08                     921 	.uleb128	8
      000152 0B                     922 	.uleb128	11
      000153 01                     923 	.db	1
      000154 01                     924 	.uleb128	1
      000155 13                     925 	.uleb128	19
      000156 11                     926 	.uleb128	17
      000157 01                     927 	.uleb128	1
      000158 00                     928 	.uleb128	0
      000159 00                     929 	.uleb128	0
      00015A 0C                     930 	.uleb128	12
      00015B 2E                     931 	.uleb128	46
      00015C 01                     932 	.db	1
      00015D 03                     933 	.uleb128	3
      00015E 08                     934 	.uleb128	8
      00015F 11                     935 	.uleb128	17
      000160 01                     936 	.uleb128	1
      000161 12                     937 	.uleb128	18
      000162 01                     938 	.uleb128	1
      000163 3F                     939 	.uleb128	63
      000164 0C                     940 	.uleb128	12
      000165 40                     941 	.uleb128	64
      000166 06                     942 	.uleb128	6
      000167 00                     943 	.uleb128	0
      000168 00                     944 	.uleb128	0
      000169 09                     945 	.uleb128	9
      00016A 0B                     946 	.uleb128	11
      00016B 01                     947 	.db	1
      00016C 01                     948 	.uleb128	1
      00016D 13                     949 	.uleb128	19
      00016E 11                     950 	.uleb128	17
      00016F 01                     951 	.uleb128	1
      000170 12                     952 	.uleb128	18
      000171 01                     953 	.uleb128	1
      000172 00                     954 	.uleb128	0
      000173 00                     955 	.uleb128	0
      000174 05                     956 	.uleb128	5
      000175 24                     957 	.uleb128	36
      000176 00                     958 	.db	0
      000177 03                     959 	.uleb128	3
      000178 08                     960 	.uleb128	8
      000179 0B                     961 	.uleb128	11
      00017A 0B                     962 	.uleb128	11
      00017B 3E                     963 	.uleb128	62
      00017C 0B                     964 	.uleb128	11
      00017D 00                     965 	.uleb128	0
      00017E 00                     966 	.uleb128	0
      00017F 00                     967 	.uleb128	0
                                    968 
                                    969 	.area .debug_info (NOLOAD)
      00020F 00 00 02 7D            970 	.dw	0,Ldebug_info_end-Ldebug_info_start
      000213                        971 Ldebug_info_start:
      000213 00 02                  972 	.dw	2
      000215 00 00 00 E5            973 	.dw	0,(Ldebug_abbrev)
      000219 04                     974 	.db	4
      00021A 01                     975 	.uleb128	1
      00021B 2E 2F 73 72 63 2F 73   976 	.ascii "./src/spse_stm8.c"
             70 73 65 5F 73 74 6D
             38 2E 63
      00022C 00                     977 	.db	0
      00022D 00 00 02 35            978 	.dw	0,(Ldebug_line_start+-4)
      000231 01                     979 	.db	1
      000232 53 44 43 43 20 76 65   980 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      00024B 00                     981 	.db	0
      00024C 02                     982 	.uleb128	2
      00024D 00 00 00 75            983 	.dw	0,117
      000251 5F 64 65 6C 61 79 5F   984 	.ascii "_delay_cycl"
             63 79 63 6C
      00025C 00                     985 	.db	0
      00025D 00 00 81 D4            986 	.dw	0,(__delay_cycl)
      000261 00 00 81 E1            987 	.dw	0,(XFspse_stm8$_delay_cycl$0$0+1)
      000265 00                     988 	.db	0
      000266 00 00 04 A0            989 	.dw	0,(Ldebug_loc_start+316)
      00026A 03                     990 	.uleb128	3
      00026B 02                     991 	.db	2
      00026C 91                     992 	.db	145
      00026D 02                     993 	.sleb128	2
      00026E 5F 5F 74 69 63 6B 73   994 	.ascii "__ticks"
      000275 00                     995 	.db	0
      000276 00 00 00 75            996 	.dw	0,117
      00027A 04                     997 	.uleb128	4
      00027B 00 00 81 D8            998 	.dw	0,(Sspse_stm8$_delay_cycl$4)
      00027F 00 00 81 D9            999 	.dw	0,(Sspse_stm8$_delay_cycl$6)
      000283 00                    1000 	.uleb128	0
      000284 05                    1001 	.uleb128	5
      000285 75 6E 73 69 67 6E 65  1002 	.ascii "unsigned int"
             64 20 69 6E 74
      000291 00                    1003 	.db	0
      000292 02                    1004 	.db	2
      000293 07                    1005 	.db	7
      000294 02                    1006 	.uleb128	2
      000295 00 00 01 0C           1007 	.dw	0,268
      000299 5F 64 65 6C 61 79 5F  1008 	.ascii "_delay_us"
             75 73
      0002A2 00                    1009 	.db	0
      0002A3 00 00 81 E1           1010 	.dw	0,(__delay_us)
      0002A7 00 00 82 19           1011 	.dw	0,(XFspse_stm8$_delay_us$0$0+1)
      0002AB 00                    1012 	.db	0
      0002AC 00 00 03 E4           1013 	.dw	0,(Ldebug_loc_start+128)
      0002B0 06                    1014 	.uleb128	6
      0002B1 00 00 00 75           1015 	.dw	0,117
      0002B5 03                    1016 	.uleb128	3
      0002B6 02                    1017 	.db	2
      0002B7 91                    1018 	.db	145
      0002B8 02                    1019 	.sleb128	2
      0002B9 5F 5F 75 73           1020 	.ascii "__us"
      0002BD 00                    1021 	.db	0
      0002BE 00 00 00 A1           1022 	.dw	0,161
      0002C2 07                    1023 	.uleb128	7
      0002C3 00 00 81 E1           1024 	.dw	0,(Sspse_stm8$_delay_us$14)
      0002C7 00 00 82 0D           1025 	.dw	0,(Sspse_stm8$_delay_us$31)
      0002CB 08                    1026 	.uleb128	8
      0002CC 00 00 00 F1           1027 	.dw	0,241
      0002D0 00 00 82 0E           1028 	.dw	0,(Sspse_stm8$_delay_us$32)
      0002D4 09                    1029 	.uleb128	9
      0002D5 00 00 00 DC           1030 	.dw	0,220
      0002D9 00 00 82 0E           1031 	.dw	0,(Sspse_stm8$_delay_us$33)
      0002DD 00 00 82 18           1032 	.dw	0,(Sspse_stm8$_delay_us$38)
      0002E1 04                    1033 	.uleb128	4
      0002E2 00 00 82 10           1034 	.dw	0,(Sspse_stm8$_delay_us$36)
      0002E6 00 00 82 11           1035 	.dw	0,(Sspse_stm8$_delay_us$37)
      0002EA 00                    1036 	.uleb128	0
      0002EB 0A                    1037 	.uleb128	10
      0002EC 06                    1038 	.db	6
      0002ED 52                    1039 	.db	82
      0002EE 93                    1040 	.db	147
      0002EF 01                    1041 	.uleb128	1
      0002F0 51                    1042 	.db	81
      0002F1 93                    1043 	.db	147
      0002F2 01                    1044 	.uleb128	1
      0002F3 5F 5F 74 69 63 6B 73  1045 	.ascii "__ticks"
      0002FA 00                    1046 	.db	0
      0002FB 00 00 00 75           1047 	.dw	0,117
      0002FF 00                    1048 	.uleb128	0
      000300 0A                    1049 	.uleb128	10
      000301 06                    1050 	.db	6
      000302 52                    1051 	.db	82
      000303 93                    1052 	.db	147
      000304 01                    1053 	.uleb128	1
      000305 51                    1054 	.db	81
      000306 93                    1055 	.db	147
      000307 01                    1056 	.uleb128	1
      000308 5F 5F 31 33 31 30 37  1057 	.ascii "__1310720010"
             32 30 30 31 30
      000314 00                    1058 	.db	0
      000315 00 00 00 75           1059 	.dw	0,117
      000319 00                    1060 	.uleb128	0
      00031A 00                    1061 	.uleb128	0
      00031B 0B                    1062 	.uleb128	11
      00031C 00 00 01 40           1063 	.dw	0,320
      000320 41 44 43 5F 67 65 74  1064 	.ascii "ADC_get"
      000327 00                    1065 	.db	0
      000328 00 00 82 19           1066 	.dw	0,(_ADC_get)
      00032C 00 00 82 3D           1067 	.dw	0,(XG$ADC_get$0$0+1)
      000330 01                    1068 	.db	1
      000331 00 00 03 B8           1069 	.dw	0,(Ldebug_loc_start+84)
      000335 00 00 00 75           1070 	.dw	0,117
      000339 03                    1071 	.uleb128	3
      00033A 02                    1072 	.db	2
      00033B 91                    1073 	.db	145
      00033C 02                    1074 	.sleb128	2
      00033D 41 44 43 32 5F 43 68  1075 	.ascii "ADC2_Channel"
             61 6E 6E 65 6C
      000349 00                    1076 	.db	0
      00034A 00 00 01 40           1077 	.dw	0,320
      00034E 00                    1078 	.uleb128	0
      00034F 05                    1079 	.uleb128	5
      000350 75 6E 73 69 67 6E 65  1080 	.ascii "unsigned char"
             64 20 63 68 61 72
      00035D 00                    1081 	.db	0
      00035E 01                    1082 	.db	1
      00035F 08                    1083 	.db	8
      000360 02                    1084 	.uleb128	2
      000361 00 00 01 98           1085 	.dw	0,408
      000365 41 44 43 32 5F 53 65  1086 	.ascii "ADC2_Select_Channel"
             6C 65 63 74 5F 43 68
             61 6E 6E 65 6C
      000378 00                    1087 	.db	0
      000379 00 00 82 3D           1088 	.dw	0,(_ADC2_Select_Channel)
      00037D 00 00 82 50           1089 	.dw	0,(XG$ADC2_Select_Channel$0$0+1)
      000381 01                    1090 	.db	1
      000382 00 00 03 8C           1091 	.dw	0,(Ldebug_loc_start+40)
      000386 03                    1092 	.uleb128	3
      000387 02                    1093 	.db	2
      000388 91                    1094 	.db	145
      000389 02                    1095 	.sleb128	2
      00038A 41 44 43 32 5F 43 68  1096 	.ascii "ADC2_Channel"
             61 6E 6E 65 6C
      000396 00                    1097 	.db	0
      000397 00 00 01 40           1098 	.dw	0,320
      00039B 0A                    1099 	.uleb128	10
      00039C 01                    1100 	.db	1
      00039D 50                    1101 	.db	80
      00039E 74 6D 70              1102 	.ascii "tmp"
      0003A1 00                    1103 	.db	0
      0003A2 00 00 01 40           1104 	.dw	0,320
      0003A6 00                    1105 	.uleb128	0
      0003A7 02                    1106 	.uleb128	2
      0003A8 00 00 01 E1           1107 	.dw	0,481
      0003AC 41 44 43 32 5F 41 6C  1108 	.ascii "ADC2_AlignConfig"
             69 67 6E 43 6F 6E 66
             69 67
      0003BC 00                    1109 	.db	0
      0003BD 00 00 82 50           1110 	.dw	0,(_ADC2_AlignConfig)
      0003C1 00 00 82 68           1111 	.dw	0,(XG$ADC2_AlignConfig$0$0+1)
      0003C5 01                    1112 	.db	1
      0003C6 00 00 03 78           1113 	.dw	0,(Ldebug_loc_start+20)
      0003CA 03                    1114 	.uleb128	3
      0003CB 02                    1115 	.db	2
      0003CC 91                    1116 	.db	145
      0003CD 02                    1117 	.sleb128	2
      0003CE 41 44 43 32 5F 41 6C  1118 	.ascii "ADC2_Align"
             69 67 6E
      0003D8 00                    1119 	.db	0
      0003D9 00 00 01 40           1120 	.dw	0,320
      0003DD 04                    1121 	.uleb128	4
      0003DE 00 00 82 5A           1122 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$69)
      0003E2 00 00 82 5F           1123 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$71)
      0003E6 04                    1124 	.uleb128	4
      0003E7 00 00 82 62           1125 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$72)
      0003EB 00 00 82 67           1126 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$74)
      0003EF 00                    1127 	.uleb128	0
      0003F0 0C                    1128 	.uleb128	12
      0003F1 41 44 43 32 5F 53 74  1129 	.ascii "ADC2_Startup_Wait"
             61 72 74 75 70 5F 57
             61 69 74
      000402 00                    1130 	.db	0
      000403 00 00 82 68           1131 	.dw	0,(_ADC2_Startup_Wait)
      000407 00 00 82 76           1132 	.dw	0,(XG$ADC2_Startup_Wait$0$0+1)
      00040B 01                    1133 	.db	1
      00040C 00 00 03 64           1134 	.dw	0,(Ldebug_loc_start)
      000410 0D                    1135 	.uleb128	13
      000411 0E                    1136 	.uleb128	14
      000412 00 00 02 67           1137 	.dw	0,615
      000416 0E                    1138 	.uleb128	14
      000417 00 00 02 59           1139 	.dw	0,601
      00041B 0D                    1140 	.uleb128	13
      00041C 08                    1141 	.uleb128	8
      00041D 00 00 02 42           1142 	.dw	0,578
      000421 00 00 82 68           1143 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$80)
      000425 09                    1144 	.uleb128	9
      000426 00 00 02 2D           1145 	.dw	0,557
      00042A 00 00 82 6B           1146 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$81)
      00042E 00 00 82 75           1147 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$86)
      000432 04                    1148 	.uleb128	4
      000433 00 00 82 6D           1149 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$84)
      000437 00 00 82 6E           1150 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$85)
      00043B 00                    1151 	.uleb128	0
      00043C 0A                    1152 	.uleb128	10
      00043D 06                    1153 	.db	6
      00043E 52                    1154 	.db	82
      00043F 93                    1155 	.db	147
      000440 01                    1156 	.uleb128	1
      000441 51                    1157 	.db	81
      000442 93                    1158 	.db	147
      000443 01                    1159 	.uleb128	1
      000444 5F 5F 74 69 63 6B 73  1160 	.ascii "__ticks"
      00044B 00                    1161 	.db	0
      00044C 00 00 00 75           1162 	.dw	0,117
      000450 00                    1163 	.uleb128	0
      000451 0A                    1164 	.uleb128	10
      000452 02                    1165 	.db	2
      000453 91                    1166 	.db	145
      000454 00                    1167 	.sleb128	0
      000455 5F 5F 31 33 31 30 37  1168 	.ascii "__1310720010"
             32 30 30 31 30
      000461 00                    1169 	.db	0
      000462 00 00 00 75           1170 	.dw	0,117
      000466 00                    1171 	.uleb128	0
      000467 00                    1172 	.uleb128	0
      000468 0A                    1173 	.uleb128	10
      000469 02                    1174 	.db	2
      00046A 91                    1175 	.db	145
      00046B 00                    1176 	.sleb128	0
      00046C 5F 5F 75 73           1177 	.ascii "__us"
      000470 00                    1178 	.db	0
      000471 00 00 00 A1           1179 	.dw	0,161
      000475 00                    1180 	.uleb128	0
      000476 0A                    1181 	.uleb128	10
      000477 02                    1182 	.db	2
      000478 91                    1183 	.db	145
      000479 00                    1184 	.sleb128	0
      00047A 5F 5F 31 33 31 30 37  1185 	.ascii "__1310720012"
             32 30 30 31 32
      000486 00                    1186 	.db	0
      000487 00 00 00 A1           1187 	.dw	0,161
      00048B 00                    1188 	.uleb128	0
      00048C 00                    1189 	.uleb128	0
      00048D 00                    1190 	.uleb128	0
      00048E 00                    1191 	.uleb128	0
      00048F 00                    1192 	.uleb128	0
      000490                       1193 Ldebug_info_end:
                                   1194 
                                   1195 	.area .debug_pubnames (NOLOAD)
      00007C 00 00 00 5D           1196 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      000080                       1197 Ldebug_pubnames_start:
      000080 00 02                 1198 	.dw	2
      000082 00 00 02 0F           1199 	.dw	0,(Ldebug_info_start-4)
      000086 00 00 02 81           1200 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      00008A 00 00 01 0C           1201 	.dw	0,268
      00008E 41 44 43 5F 67 65 74  1202 	.ascii "ADC_get"
      000095 00                    1203 	.db	0
      000096 00 00 01 51           1204 	.dw	0,337
      00009A 41 44 43 32 5F 53 65  1205 	.ascii "ADC2_Select_Channel"
             6C 65 63 74 5F 43 68
             61 6E 6E 65 6C
      0000AD 00                    1206 	.db	0
      0000AE 00 00 01 98           1207 	.dw	0,408
      0000B2 41 44 43 32 5F 41 6C  1208 	.ascii "ADC2_AlignConfig"
             69 67 6E 43 6F 6E 66
             69 67
      0000C2 00                    1209 	.db	0
      0000C3 00 00 01 E1           1210 	.dw	0,481
      0000C7 41 44 43 32 5F 53 74  1211 	.ascii "ADC2_Startup_Wait"
             61 72 74 75 70 5F 57
             61 69 74
      0000D8 00                    1212 	.db	0
      0000D9 00 00 00 00           1213 	.dw	0,0
      0000DD                       1214 Ldebug_pubnames_end:
                                   1215 
                                   1216 	.area .debug_frame (NOLOAD)
      00028D 00 00                 1217 	.dw	0
      00028F 00 0E                 1218 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      000291                       1219 Ldebug_CIE0_start:
      000291 FF FF                 1220 	.dw	0xffff
      000293 FF FF                 1221 	.dw	0xffff
      000295 01                    1222 	.db	1
      000296 00                    1223 	.db	0
      000297 01                    1224 	.uleb128	1
      000298 7F                    1225 	.sleb128	-1
      000299 09                    1226 	.db	9
      00029A 0C                    1227 	.db	12
      00029B 08                    1228 	.uleb128	8
      00029C 02                    1229 	.uleb128	2
      00029D 89                    1230 	.db	137
      00029E 01                    1231 	.uleb128	1
      00029F                       1232 Ldebug_CIE0_end:
      00029F 00 00 00 13           1233 	.dw	0,19
      0002A3 00 00 02 8D           1234 	.dw	0,(Ldebug_CIE0_start-4)
      0002A7 00 00 82 68           1235 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$79)	;initial loc
      0002AB 00 00 00 0E           1236 	.dw	0,Sspse_stm8$ADC2_Startup_Wait$90-Sspse_stm8$ADC2_Startup_Wait$79
      0002AF 01                    1237 	.db	1
      0002B0 00 00 82 68           1238 	.dw	0,(Sspse_stm8$ADC2_Startup_Wait$79)
      0002B4 0E                    1239 	.db	14
      0002B5 02                    1240 	.uleb128	2
                                   1241 
                                   1242 	.area .debug_frame (NOLOAD)
      0002B6 00 00                 1243 	.dw	0
      0002B8 00 0E                 1244 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      0002BA                       1245 Ldebug_CIE1_start:
      0002BA FF FF                 1246 	.dw	0xffff
      0002BC FF FF                 1247 	.dw	0xffff
      0002BE 01                    1248 	.db	1
      0002BF 00                    1249 	.db	0
      0002C0 01                    1250 	.uleb128	1
      0002C1 7F                    1251 	.sleb128	-1
      0002C2 09                    1252 	.db	9
      0002C3 0C                    1253 	.db	12
      0002C4 08                    1254 	.uleb128	8
      0002C5 02                    1255 	.uleb128	2
      0002C6 89                    1256 	.db	137
      0002C7 01                    1257 	.uleb128	1
      0002C8                       1258 Ldebug_CIE1_end:
      0002C8 00 00 00 13           1259 	.dw	0,19
      0002CC 00 00 02 B6           1260 	.dw	0,(Ldebug_CIE1_start-4)
      0002D0 00 00 82 50           1261 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$66)	;initial loc
      0002D4 00 00 00 18           1262 	.dw	0,Sspse_stm8$ADC2_AlignConfig$77-Sspse_stm8$ADC2_AlignConfig$66
      0002D8 01                    1263 	.db	1
      0002D9 00 00 82 50           1264 	.dw	0,(Sspse_stm8$ADC2_AlignConfig$66)
      0002DD 0E                    1265 	.db	14
      0002DE 02                    1266 	.uleb128	2
                                   1267 
                                   1268 	.area .debug_frame (NOLOAD)
      0002DF 00 00                 1269 	.dw	0
      0002E1 00 0E                 1270 	.dw	Ldebug_CIE2_end-Ldebug_CIE2_start
      0002E3                       1271 Ldebug_CIE2_start:
      0002E3 FF FF                 1272 	.dw	0xffff
      0002E5 FF FF                 1273 	.dw	0xffff
      0002E7 01                    1274 	.db	1
      0002E8 00                    1275 	.db	0
      0002E9 01                    1276 	.uleb128	1
      0002EA 7F                    1277 	.sleb128	-1
      0002EB 09                    1278 	.db	9
      0002EC 0C                    1279 	.db	12
      0002ED 08                    1280 	.uleb128	8
      0002EE 02                    1281 	.uleb128	2
      0002EF 89                    1282 	.db	137
      0002F0 01                    1283 	.uleb128	1
      0002F1                       1284 Ldebug_CIE2_end:
      0002F1 00 00 00 21           1285 	.dw	0,33
      0002F5 00 00 02 DF           1286 	.dw	0,(Ldebug_CIE2_start-4)
      0002F9 00 00 82 3D           1287 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$56)	;initial loc
      0002FD 00 00 00 13           1288 	.dw	0,Sspse_stm8$ADC2_Select_Channel$64-Sspse_stm8$ADC2_Select_Channel$56
      000301 01                    1289 	.db	1
      000302 00 00 82 3D           1290 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$56)
      000306 0E                    1291 	.db	14
      000307 02                    1292 	.uleb128	2
      000308 01                    1293 	.db	1
      000309 00 00 82 3E           1294 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$57)
      00030D 0E                    1295 	.db	14
      00030E 03                    1296 	.uleb128	3
      00030F 01                    1297 	.db	1
      000310 00 00 82 4F           1298 	.dw	0,(Sspse_stm8$ADC2_Select_Channel$62)
      000314 0E                    1299 	.db	14
      000315 02                    1300 	.uleb128	2
                                   1301 
                                   1302 	.area .debug_frame (NOLOAD)
      000316 00 00                 1303 	.dw	0
      000318 00 0E                 1304 	.dw	Ldebug_CIE3_end-Ldebug_CIE3_start
      00031A                       1305 Ldebug_CIE3_start:
      00031A FF FF                 1306 	.dw	0xffff
      00031C FF FF                 1307 	.dw	0xffff
      00031E 01                    1308 	.db	1
      00031F 00                    1309 	.db	0
      000320 01                    1310 	.uleb128	1
      000321 7F                    1311 	.sleb128	-1
      000322 09                    1312 	.db	9
      000323 0C                    1313 	.db	12
      000324 08                    1314 	.uleb128	8
      000325 02                    1315 	.uleb128	2
      000326 89                    1316 	.db	137
      000327 01                    1317 	.uleb128	1
      000328                       1318 Ldebug_CIE3_end:
      000328 00 00 00 21           1319 	.dw	0,33
      00032C 00 00 03 16           1320 	.dw	0,(Ldebug_CIE3_start-4)
      000330 00 00 82 19           1321 	.dw	0,(Sspse_stm8$ADC_get$44)	;initial loc
      000334 00 00 00 24           1322 	.dw	0,Sspse_stm8$ADC_get$54-Sspse_stm8$ADC_get$44
      000338 01                    1323 	.db	1
      000339 00 00 82 19           1324 	.dw	0,(Sspse_stm8$ADC_get$44)
      00033D 0E                    1325 	.db	14
      00033E 02                    1326 	.uleb128	2
      00033F 01                    1327 	.db	1
      000340 00 00 82 1C           1328 	.dw	0,(Sspse_stm8$ADC_get$46)
      000344 0E                    1329 	.db	14
      000345 03                    1330 	.uleb128	3
      000346 01                    1331 	.db	1
      000347 00 00 82 20           1332 	.dw	0,(Sspse_stm8$ADC_get$47)
      00034B 0E                    1333 	.db	14
      00034C 02                    1334 	.uleb128	2
                                   1335 
                                   1336 	.area .debug_frame (NOLOAD)
      00034D 00 00                 1337 	.dw	0
      00034F 00 0E                 1338 	.dw	Ldebug_CIE4_end-Ldebug_CIE4_start
      000351                       1339 Ldebug_CIE4_start:
      000351 FF FF                 1340 	.dw	0xffff
      000353 FF FF                 1341 	.dw	0xffff
      000355 01                    1342 	.db	1
      000356 00                    1343 	.db	0
      000357 01                    1344 	.uleb128	1
      000358 7F                    1345 	.sleb128	-1
      000359 09                    1346 	.db	9
      00035A 0C                    1347 	.db	12
      00035B 08                    1348 	.uleb128	8
      00035C 02                    1349 	.uleb128	2
      00035D 89                    1350 	.db	137
      00035E 01                    1351 	.uleb128	1
      00035F                       1352 Ldebug_CIE4_end:
      00035F 00 00 00 75           1353 	.dw	0,117
      000363 00 00 03 4D           1354 	.dw	0,(Ldebug_CIE4_start-4)
      000367 00 00 81 E1           1355 	.dw	0,(Sspse_stm8$_delay_us$13)	;initial loc
      00036B 00 00 00 38           1356 	.dw	0,Sspse_stm8$_delay_us$42-Sspse_stm8$_delay_us$13
      00036F 01                    1357 	.db	1
      000370 00 00 81 E1           1358 	.dw	0,(Sspse_stm8$_delay_us$13)
      000374 0E                    1359 	.db	14
      000375 02                    1360 	.uleb128	2
      000376 01                    1361 	.db	1
      000377 00 00 81 E6           1362 	.dw	0,(Sspse_stm8$_delay_us$15)
      00037B 0E                    1363 	.db	14
      00037C 04                    1364 	.uleb128	4
      00037D 01                    1365 	.db	1
      00037E 00 00 81 E7           1366 	.dw	0,(Sspse_stm8$_delay_us$16)
      000382 0E                    1367 	.db	14
      000383 06                    1368 	.uleb128	6
      000384 01                    1369 	.db	1
      000385 00 00 81 E9           1370 	.dw	0,(Sspse_stm8$_delay_us$17)
      000389 0E                    1371 	.db	14
      00038A 07                    1372 	.uleb128	7
      00038B 01                    1373 	.db	1
      00038C 00 00 81 EB           1374 	.dw	0,(Sspse_stm8$_delay_us$18)
      000390 0E                    1375 	.db	14
      000391 08                    1376 	.uleb128	8
      000392 01                    1377 	.db	1
      000393 00 00 81 ED           1378 	.dw	0,(Sspse_stm8$_delay_us$19)
      000397 0E                    1379 	.db	14
      000398 09                    1380 	.uleb128	9
      000399 01                    1381 	.db	1
      00039A 00 00 81 EF           1382 	.dw	0,(Sspse_stm8$_delay_us$20)
      00039E 0E                    1383 	.db	14
      00039F 0A                    1384 	.uleb128	10
      0003A0 01                    1385 	.db	1
      0003A1 00 00 81 F4           1386 	.dw	0,(Sspse_stm8$_delay_us$21)
      0003A5 0E                    1387 	.db	14
      0003A6 02                    1388 	.uleb128	2
      0003A7 01                    1389 	.db	1
      0003A8 00 00 81 F6           1390 	.dw	0,(Sspse_stm8$_delay_us$23)
      0003AC 0E                    1391 	.db	14
      0003AD 03                    1392 	.uleb128	3
      0003AE 01                    1393 	.db	1
      0003AF 00 00 81 F8           1394 	.dw	0,(Sspse_stm8$_delay_us$24)
      0003B3 0E                    1395 	.db	14
      0003B4 04                    1396 	.uleb128	4
      0003B5 01                    1397 	.db	1
      0003B6 00 00 81 FA           1398 	.dw	0,(Sspse_stm8$_delay_us$25)
      0003BA 0E                    1399 	.db	14
      0003BB 05                    1400 	.uleb128	5
      0003BC 01                    1401 	.db	1
      0003BD 00 00 81 FC           1402 	.dw	0,(Sspse_stm8$_delay_us$26)
      0003C1 0E                    1403 	.db	14
      0003C2 06                    1404 	.uleb128	6
      0003C3 01                    1405 	.db	1
      0003C4 00 00 81 FD           1406 	.dw	0,(Sspse_stm8$_delay_us$27)
      0003C8 0E                    1407 	.db	14
      0003C9 08                    1408 	.uleb128	8
      0003CA 01                    1409 	.db	1
      0003CB 00 00 81 FF           1410 	.dw	0,(Sspse_stm8$_delay_us$28)
      0003CF 0E                    1411 	.db	14
      0003D0 0A                    1412 	.uleb128	10
      0003D1 01                    1413 	.db	1
      0003D2 00 00 82 04           1414 	.dw	0,(Sspse_stm8$_delay_us$29)
      0003D6 0E                    1415 	.db	14
      0003D7 02                    1416 	.uleb128	2
                                   1417 
                                   1418 	.area .debug_frame (NOLOAD)
      0003D8 00 00                 1419 	.dw	0
      0003DA 00 0E                 1420 	.dw	Ldebug_CIE5_end-Ldebug_CIE5_start
      0003DC                       1421 Ldebug_CIE5_start:
      0003DC FF FF                 1422 	.dw	0xffff
      0003DE FF FF                 1423 	.dw	0xffff
      0003E0 01                    1424 	.db	1
      0003E1 00                    1425 	.db	0
      0003E2 01                    1426 	.uleb128	1
      0003E3 7F                    1427 	.sleb128	-1
      0003E4 09                    1428 	.db	9
      0003E5 0C                    1429 	.db	12
      0003E6 08                    1430 	.uleb128	8
      0003E7 02                    1431 	.uleb128	2
      0003E8 89                    1432 	.db	137
      0003E9 01                    1433 	.uleb128	1
      0003EA                       1434 Ldebug_CIE5_end:
      0003EA 00 00 00 13           1435 	.dw	0,19
      0003EE 00 00 03 D8           1436 	.dw	0,(Ldebug_CIE5_start-4)
      0003F2 00 00 81 D4           1437 	.dw	0,(Sspse_stm8$_delay_cycl$1)	;initial loc
      0003F6 00 00 00 0D           1438 	.dw	0,Sspse_stm8$_delay_cycl$11-Sspse_stm8$_delay_cycl$1
      0003FA 01                    1439 	.db	1
      0003FB 00 00 81 D4           1440 	.dw	0,(Sspse_stm8$_delay_cycl$1)
      0003FF 0E                    1441 	.db	14
      000400 02                    1442 	.uleb128	2
