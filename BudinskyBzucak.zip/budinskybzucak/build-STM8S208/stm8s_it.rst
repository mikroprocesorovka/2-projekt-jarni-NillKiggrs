                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module stm8s_it
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _TRAP_IRQHandler
                                     12 	.globl _TLI_IRQHandler
                                     13 	.globl _AWU_IRQHandler
                                     14 	.globl _CLK_IRQHandler
                                     15 	.globl _EXTI_PORTA_IRQHandler
                                     16 	.globl _EXTI_PORTB_IRQHandler
                                     17 	.globl _EXTI_PORTC_IRQHandler
                                     18 	.globl _EXTI_PORTD_IRQHandler
                                     19 	.globl _EXTI_PORTE_IRQHandler
                                     20 	.globl _CAN_RX_IRQHandler
                                     21 	.globl _CAN_TX_IRQHandler
                                     22 	.globl _SPI_IRQHandler
                                     23 	.globl _TIM1_UPD_OVF_TRG_BRK_IRQHandler
                                     24 	.globl _TIM1_CAP_COM_IRQHandler
                                     25 	.globl _TIM2_UPD_OVF_BRK_IRQHandler
                                     26 	.globl _TIM2_CAP_COM_IRQHandler
                                     27 	.globl _TIM3_UPD_OVF_BRK_IRQHandler
                                     28 	.globl _TIM3_CAP_COM_IRQHandler
                                     29 	.globl _UART1_TX_IRQHandler
                                     30 	.globl _UART1_RX_IRQHandler
                                     31 	.globl _I2C_IRQHandler
                                     32 	.globl _UART3_TX_IRQHandler
                                     33 	.globl _UART3_RX_IRQHandler
                                     34 	.globl _ADC2_IRQHandler
                                     35 	.globl _EEPROM_EEC_IRQHandler
                                     36 ;--------------------------------------------------------
                                     37 ; ram data
                                     38 ;--------------------------------------------------------
                                     39 	.area DATA
                                     40 ;--------------------------------------------------------
                                     41 ; ram data
                                     42 ;--------------------------------------------------------
                                     43 	.area INITIALIZED
                                     44 ;--------------------------------------------------------
                                     45 ; absolute external ram data
                                     46 ;--------------------------------------------------------
                                     47 	.area DABS (ABS)
                                     48 
                                     49 ; default segment ordering for linker
                                     50 	.area HOME
                                     51 	.area GSINIT
                                     52 	.area GSFINAL
                                     53 	.area CONST
                                     54 	.area INITIALIZER
                                     55 	.area CODE
                                     56 
                                     57 ;--------------------------------------------------------
                                     58 ; global & static initialisations
                                     59 ;--------------------------------------------------------
                                     60 	.area HOME
                                     61 	.area GSINIT
                                     62 	.area GSFINAL
                                     63 	.area GSINIT
                                     64 ;--------------------------------------------------------
                                     65 ; Home
                                     66 ;--------------------------------------------------------
                                     67 	.area HOME
                                     68 	.area HOME
                                     69 ;--------------------------------------------------------
                                     70 ; code
                                     71 ;--------------------------------------------------------
                                     72 	.area CODE
                           000000    73 	Sstm8s_it$TRAP_IRQHandler$0 ==.
                                     74 ;	./src/stm8s_it.c: 63: INTERRUPT_HANDLER_TRAP(TRAP_IRQHandler)
                                     75 ; genLabel
                                     76 ;	-----------------------------------------
                                     77 ;	 function TRAP_IRQHandler
                                     78 ;	-----------------------------------------
                                     79 ;	Register assignment is optimal.
                                     80 ;	Stack space usage: 0 bytes.
      00875B                         81 _TRAP_IRQHandler:
                           000000    82 	Sstm8s_it$TRAP_IRQHandler$1 ==.
                           000000    83 	Sstm8s_it$TRAP_IRQHandler$2 ==.
                                     84 ;	./src/stm8s_it.c: 68: }
                                     85 ; genLabel
      00875B                         86 00101$:
                                     87 ; genEndFunction
                           000000    88 	Sstm8s_it$TRAP_IRQHandler$3 ==.
                           000000    89 	XG$TRAP_IRQHandler$0$0 ==.
      00875B 80               [11]   90 	iret
                           000001    91 	Sstm8s_it$TRAP_IRQHandler$4 ==.
                           000001    92 	Sstm8s_it$TLI_IRQHandler$5 ==.
                                     93 ;	./src/stm8s_it.c: 74: INTERRUPT_HANDLER(TLI_IRQHandler, 0)
                                     94 ; genLabel
                                     95 ;	-----------------------------------------
                                     96 ;	 function TLI_IRQHandler
                                     97 ;	-----------------------------------------
                                     98 ;	Register assignment is optimal.
                                     99 ;	Stack space usage: 0 bytes.
      00875C                        100 _TLI_IRQHandler:
                           000001   101 	Sstm8s_it$TLI_IRQHandler$6 ==.
                           000001   102 	Sstm8s_it$TLI_IRQHandler$7 ==.
                                    103 ;	./src/stm8s_it.c: 79: }
                                    104 ; genLabel
      00875C                        105 00101$:
                                    106 ; genEndFunction
                           000001   107 	Sstm8s_it$TLI_IRQHandler$8 ==.
                           000001   108 	XG$TLI_IRQHandler$0$0 ==.
      00875C 80               [11]  109 	iret
                           000002   110 	Sstm8s_it$TLI_IRQHandler$9 ==.
                           000002   111 	Sstm8s_it$AWU_IRQHandler$10 ==.
                                    112 ;	./src/stm8s_it.c: 86: INTERRUPT_HANDLER(AWU_IRQHandler, 1)
                                    113 ; genLabel
                                    114 ;	-----------------------------------------
                                    115 ;	 function AWU_IRQHandler
                                    116 ;	-----------------------------------------
                                    117 ;	Register assignment is optimal.
                                    118 ;	Stack space usage: 0 bytes.
      00875D                        119 _AWU_IRQHandler:
                           000002   120 	Sstm8s_it$AWU_IRQHandler$11 ==.
                           000002   121 	Sstm8s_it$AWU_IRQHandler$12 ==.
                                    122 ;	./src/stm8s_it.c: 91: }
                                    123 ; genLabel
      00875D                        124 00101$:
                                    125 ; genEndFunction
                           000002   126 	Sstm8s_it$AWU_IRQHandler$13 ==.
                           000002   127 	XG$AWU_IRQHandler$0$0 ==.
      00875D 80               [11]  128 	iret
                           000003   129 	Sstm8s_it$AWU_IRQHandler$14 ==.
                           000003   130 	Sstm8s_it$CLK_IRQHandler$15 ==.
                                    131 ;	./src/stm8s_it.c: 98: INTERRUPT_HANDLER(CLK_IRQHandler, 2)
                                    132 ; genLabel
                                    133 ;	-----------------------------------------
                                    134 ;	 function CLK_IRQHandler
                                    135 ;	-----------------------------------------
                                    136 ;	Register assignment is optimal.
                                    137 ;	Stack space usage: 0 bytes.
      00875E                        138 _CLK_IRQHandler:
                           000003   139 	Sstm8s_it$CLK_IRQHandler$16 ==.
                           000003   140 	Sstm8s_it$CLK_IRQHandler$17 ==.
                                    141 ;	./src/stm8s_it.c: 103: }
                                    142 ; genLabel
      00875E                        143 00101$:
                                    144 ; genEndFunction
                           000003   145 	Sstm8s_it$CLK_IRQHandler$18 ==.
                           000003   146 	XG$CLK_IRQHandler$0$0 ==.
      00875E 80               [11]  147 	iret
                           000004   148 	Sstm8s_it$CLK_IRQHandler$19 ==.
                           000004   149 	Sstm8s_it$EXTI_PORTA_IRQHandler$20 ==.
                                    150 ;	./src/stm8s_it.c: 110: INTERRUPT_HANDLER(EXTI_PORTA_IRQHandler, 3)
                                    151 ; genLabel
                                    152 ;	-----------------------------------------
                                    153 ;	 function EXTI_PORTA_IRQHandler
                                    154 ;	-----------------------------------------
                                    155 ;	Register assignment is optimal.
                                    156 ;	Stack space usage: 0 bytes.
      00875F                        157 _EXTI_PORTA_IRQHandler:
                           000004   158 	Sstm8s_it$EXTI_PORTA_IRQHandler$21 ==.
                           000004   159 	Sstm8s_it$EXTI_PORTA_IRQHandler$22 ==.
                                    160 ;	./src/stm8s_it.c: 115: }
                                    161 ; genLabel
      00875F                        162 00101$:
                                    163 ; genEndFunction
                           000004   164 	Sstm8s_it$EXTI_PORTA_IRQHandler$23 ==.
                           000004   165 	XG$EXTI_PORTA_IRQHandler$0$0 ==.
      00875F 80               [11]  166 	iret
                           000005   167 	Sstm8s_it$EXTI_PORTA_IRQHandler$24 ==.
                           000005   168 	Sstm8s_it$EXTI_PORTB_IRQHandler$25 ==.
                                    169 ;	./src/stm8s_it.c: 122: INTERRUPT_HANDLER(EXTI_PORTB_IRQHandler, 4)
                                    170 ; genLabel
                                    171 ;	-----------------------------------------
                                    172 ;	 function EXTI_PORTB_IRQHandler
                                    173 ;	-----------------------------------------
                                    174 ;	Register assignment is optimal.
                                    175 ;	Stack space usage: 0 bytes.
      008760                        176 _EXTI_PORTB_IRQHandler:
                           000005   177 	Sstm8s_it$EXTI_PORTB_IRQHandler$26 ==.
                           000005   178 	Sstm8s_it$EXTI_PORTB_IRQHandler$27 ==.
                                    179 ;	./src/stm8s_it.c: 127: }
                                    180 ; genLabel
      008760                        181 00101$:
                                    182 ; genEndFunction
                           000005   183 	Sstm8s_it$EXTI_PORTB_IRQHandler$28 ==.
                           000005   184 	XG$EXTI_PORTB_IRQHandler$0$0 ==.
      008760 80               [11]  185 	iret
                           000006   186 	Sstm8s_it$EXTI_PORTB_IRQHandler$29 ==.
                           000006   187 	Sstm8s_it$EXTI_PORTC_IRQHandler$30 ==.
                                    188 ;	./src/stm8s_it.c: 134: INTERRUPT_HANDLER(EXTI_PORTC_IRQHandler, 5)
                                    189 ; genLabel
                                    190 ;	-----------------------------------------
                                    191 ;	 function EXTI_PORTC_IRQHandler
                                    192 ;	-----------------------------------------
                                    193 ;	Register assignment is optimal.
                                    194 ;	Stack space usage: 0 bytes.
      008761                        195 _EXTI_PORTC_IRQHandler:
                           000006   196 	Sstm8s_it$EXTI_PORTC_IRQHandler$31 ==.
                           000006   197 	Sstm8s_it$EXTI_PORTC_IRQHandler$32 ==.
                                    198 ;	./src/stm8s_it.c: 139: }
                                    199 ; genLabel
      008761                        200 00101$:
                                    201 ; genEndFunction
                           000006   202 	Sstm8s_it$EXTI_PORTC_IRQHandler$33 ==.
                           000006   203 	XG$EXTI_PORTC_IRQHandler$0$0 ==.
      008761 80               [11]  204 	iret
                           000007   205 	Sstm8s_it$EXTI_PORTC_IRQHandler$34 ==.
                           000007   206 	Sstm8s_it$EXTI_PORTD_IRQHandler$35 ==.
                                    207 ;	./src/stm8s_it.c: 146: INTERRUPT_HANDLER(EXTI_PORTD_IRQHandler, 6)
                                    208 ; genLabel
                                    209 ;	-----------------------------------------
                                    210 ;	 function EXTI_PORTD_IRQHandler
                                    211 ;	-----------------------------------------
                                    212 ;	Register assignment is optimal.
                                    213 ;	Stack space usage: 0 bytes.
      008762                        214 _EXTI_PORTD_IRQHandler:
                           000007   215 	Sstm8s_it$EXTI_PORTD_IRQHandler$36 ==.
                           000007   216 	Sstm8s_it$EXTI_PORTD_IRQHandler$37 ==.
                                    217 ;	./src/stm8s_it.c: 151: }
                                    218 ; genLabel
      008762                        219 00101$:
                                    220 ; genEndFunction
                           000007   221 	Sstm8s_it$EXTI_PORTD_IRQHandler$38 ==.
                           000007   222 	XG$EXTI_PORTD_IRQHandler$0$0 ==.
      008762 80               [11]  223 	iret
                           000008   224 	Sstm8s_it$EXTI_PORTD_IRQHandler$39 ==.
                           000008   225 	Sstm8s_it$EXTI_PORTE_IRQHandler$40 ==.
                                    226 ;	./src/stm8s_it.c: 158: INTERRUPT_HANDLER(EXTI_PORTE_IRQHandler, 7)
                                    227 ; genLabel
                                    228 ;	-----------------------------------------
                                    229 ;	 function EXTI_PORTE_IRQHandler
                                    230 ;	-----------------------------------------
                                    231 ;	Register assignment is optimal.
                                    232 ;	Stack space usage: 0 bytes.
      008763                        233 _EXTI_PORTE_IRQHandler:
                           000008   234 	Sstm8s_it$EXTI_PORTE_IRQHandler$41 ==.
                           000008   235 	Sstm8s_it$EXTI_PORTE_IRQHandler$42 ==.
                                    236 ;	./src/stm8s_it.c: 163: }
                                    237 ; genLabel
      008763                        238 00101$:
                                    239 ; genEndFunction
                           000008   240 	Sstm8s_it$EXTI_PORTE_IRQHandler$43 ==.
                           000008   241 	XG$EXTI_PORTE_IRQHandler$0$0 ==.
      008763 80               [11]  242 	iret
                           000009   243 	Sstm8s_it$EXTI_PORTE_IRQHandler$44 ==.
                           000009   244 	Sstm8s_it$CAN_RX_IRQHandler$45 ==.
                                    245 ;	./src/stm8s_it.c: 184: INTERRUPT_HANDLER(CAN_RX_IRQHandler, 8)
                                    246 ; genLabel
                                    247 ;	-----------------------------------------
                                    248 ;	 function CAN_RX_IRQHandler
                                    249 ;	-----------------------------------------
                                    250 ;	Register assignment is optimal.
                                    251 ;	Stack space usage: 0 bytes.
      008764                        252 _CAN_RX_IRQHandler:
                           000009   253 	Sstm8s_it$CAN_RX_IRQHandler$46 ==.
                           000009   254 	Sstm8s_it$CAN_RX_IRQHandler$47 ==.
                                    255 ;	./src/stm8s_it.c: 189: }
                                    256 ; genLabel
      008764                        257 00101$:
                                    258 ; genEndFunction
                           000009   259 	Sstm8s_it$CAN_RX_IRQHandler$48 ==.
                           000009   260 	XG$CAN_RX_IRQHandler$0$0 ==.
      008764 80               [11]  261 	iret
                           00000A   262 	Sstm8s_it$CAN_RX_IRQHandler$49 ==.
                           00000A   263 	Sstm8s_it$CAN_TX_IRQHandler$50 ==.
                                    264 ;	./src/stm8s_it.c: 196: INTERRUPT_HANDLER(CAN_TX_IRQHandler, 9)
                                    265 ; genLabel
                                    266 ;	-----------------------------------------
                                    267 ;	 function CAN_TX_IRQHandler
                                    268 ;	-----------------------------------------
                                    269 ;	Register assignment is optimal.
                                    270 ;	Stack space usage: 0 bytes.
      008765                        271 _CAN_TX_IRQHandler:
                           00000A   272 	Sstm8s_it$CAN_TX_IRQHandler$51 ==.
                           00000A   273 	Sstm8s_it$CAN_TX_IRQHandler$52 ==.
                                    274 ;	./src/stm8s_it.c: 201: }
                                    275 ; genLabel
      008765                        276 00101$:
                                    277 ; genEndFunction
                           00000A   278 	Sstm8s_it$CAN_TX_IRQHandler$53 ==.
                           00000A   279 	XG$CAN_TX_IRQHandler$0$0 ==.
      008765 80               [11]  280 	iret
                           00000B   281 	Sstm8s_it$CAN_TX_IRQHandler$54 ==.
                           00000B   282 	Sstm8s_it$SPI_IRQHandler$55 ==.
                                    283 ;	./src/stm8s_it.c: 209: INTERRUPT_HANDLER(SPI_IRQHandler, 10)
                                    284 ; genLabel
                                    285 ;	-----------------------------------------
                                    286 ;	 function SPI_IRQHandler
                                    287 ;	-----------------------------------------
                                    288 ;	Register assignment is optimal.
                                    289 ;	Stack space usage: 0 bytes.
      008766                        290 _SPI_IRQHandler:
                           00000B   291 	Sstm8s_it$SPI_IRQHandler$56 ==.
                           00000B   292 	Sstm8s_it$SPI_IRQHandler$57 ==.
                                    293 ;	./src/stm8s_it.c: 214: }
                                    294 ; genLabel
      008766                        295 00101$:
                                    296 ; genEndFunction
                           00000B   297 	Sstm8s_it$SPI_IRQHandler$58 ==.
                           00000B   298 	XG$SPI_IRQHandler$0$0 ==.
      008766 80               [11]  299 	iret
                           00000C   300 	Sstm8s_it$SPI_IRQHandler$59 ==.
                           00000C   301 	Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$60 ==.
                                    302 ;	./src/stm8s_it.c: 221: INTERRUPT_HANDLER(TIM1_UPD_OVF_TRG_BRK_IRQHandler, 11)
                                    303 ; genLabel
                                    304 ;	-----------------------------------------
                                    305 ;	 function TIM1_UPD_OVF_TRG_BRK_IRQHandler
                                    306 ;	-----------------------------------------
                                    307 ;	Register assignment is optimal.
                                    308 ;	Stack space usage: 0 bytes.
      008767                        309 _TIM1_UPD_OVF_TRG_BRK_IRQHandler:
                           00000C   310 	Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$61 ==.
                           00000C   311 	Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$62 ==.
                                    312 ;	./src/stm8s_it.c: 226: }
                                    313 ; genLabel
      008767                        314 00101$:
                                    315 ; genEndFunction
                           00000C   316 	Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$63 ==.
                           00000C   317 	XG$TIM1_UPD_OVF_TRG_BRK_IRQHandler$0$0 ==.
      008767 80               [11]  318 	iret
                           00000D   319 	Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$64 ==.
                           00000D   320 	Sstm8s_it$TIM1_CAP_COM_IRQHandler$65 ==.
                                    321 ;	./src/stm8s_it.c: 233: INTERRUPT_HANDLER(TIM1_CAP_COM_IRQHandler, 12)
                                    322 ; genLabel
                                    323 ;	-----------------------------------------
                                    324 ;	 function TIM1_CAP_COM_IRQHandler
                                    325 ;	-----------------------------------------
                                    326 ;	Register assignment is optimal.
                                    327 ;	Stack space usage: 0 bytes.
      008768                        328 _TIM1_CAP_COM_IRQHandler:
                           00000D   329 	Sstm8s_it$TIM1_CAP_COM_IRQHandler$66 ==.
                           00000D   330 	Sstm8s_it$TIM1_CAP_COM_IRQHandler$67 ==.
                                    331 ;	./src/stm8s_it.c: 238: }
                                    332 ; genLabel
      008768                        333 00101$:
                                    334 ; genEndFunction
                           00000D   335 	Sstm8s_it$TIM1_CAP_COM_IRQHandler$68 ==.
                           00000D   336 	XG$TIM1_CAP_COM_IRQHandler$0$0 ==.
      008768 80               [11]  337 	iret
                           00000E   338 	Sstm8s_it$TIM1_CAP_COM_IRQHandler$69 ==.
                           00000E   339 	Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$70 ==.
                                    340 ;	./src/stm8s_it.c: 270: INTERRUPT_HANDLER(TIM2_UPD_OVF_BRK_IRQHandler, 13)
                                    341 ; genLabel
                                    342 ;	-----------------------------------------
                                    343 ;	 function TIM2_UPD_OVF_BRK_IRQHandler
                                    344 ;	-----------------------------------------
                                    345 ;	Register assignment is optimal.
                                    346 ;	Stack space usage: 0 bytes.
      008769                        347 _TIM2_UPD_OVF_BRK_IRQHandler:
                           00000E   348 	Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$71 ==.
                           00000E   349 	Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$72 ==.
                                    350 ;	./src/stm8s_it.c: 275: }
                                    351 ; genLabel
      008769                        352 00101$:
                                    353 ; genEndFunction
                           00000E   354 	Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$73 ==.
                           00000E   355 	XG$TIM2_UPD_OVF_BRK_IRQHandler$0$0 ==.
      008769 80               [11]  356 	iret
                           00000F   357 	Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$74 ==.
                           00000F   358 	Sstm8s_it$TIM2_CAP_COM_IRQHandler$75 ==.
                                    359 ;	./src/stm8s_it.c: 282: INTERRUPT_HANDLER(TIM2_CAP_COM_IRQHandler, 14)
                                    360 ; genLabel
                                    361 ;	-----------------------------------------
                                    362 ;	 function TIM2_CAP_COM_IRQHandler
                                    363 ;	-----------------------------------------
                                    364 ;	Register assignment is optimal.
                                    365 ;	Stack space usage: 0 bytes.
      00876A                        366 _TIM2_CAP_COM_IRQHandler:
                           00000F   367 	Sstm8s_it$TIM2_CAP_COM_IRQHandler$76 ==.
                           00000F   368 	Sstm8s_it$TIM2_CAP_COM_IRQHandler$77 ==.
                                    369 ;	./src/stm8s_it.c: 287: }
                                    370 ; genLabel
      00876A                        371 00101$:
                                    372 ; genEndFunction
                           00000F   373 	Sstm8s_it$TIM2_CAP_COM_IRQHandler$78 ==.
                           00000F   374 	XG$TIM2_CAP_COM_IRQHandler$0$0 ==.
      00876A 80               [11]  375 	iret
                           000010   376 	Sstm8s_it$TIM2_CAP_COM_IRQHandler$79 ==.
                           000010   377 	Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$80 ==.
                                    378 ;	./src/stm8s_it.c: 297: INTERRUPT_HANDLER(TIM3_UPD_OVF_BRK_IRQHandler, 15)
                                    379 ; genLabel
                                    380 ;	-----------------------------------------
                                    381 ;	 function TIM3_UPD_OVF_BRK_IRQHandler
                                    382 ;	-----------------------------------------
                                    383 ;	Register assignment is optimal.
                                    384 ;	Stack space usage: 0 bytes.
      00876B                        385 _TIM3_UPD_OVF_BRK_IRQHandler:
                           000010   386 	Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$81 ==.
                           000010   387 	Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$82 ==.
                                    388 ;	./src/stm8s_it.c: 302: }
                                    389 ; genLabel
      00876B                        390 00101$:
                                    391 ; genEndFunction
                           000010   392 	Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$83 ==.
                           000010   393 	XG$TIM3_UPD_OVF_BRK_IRQHandler$0$0 ==.
      00876B 80               [11]  394 	iret
                           000011   395 	Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$84 ==.
                           000011   396 	Sstm8s_it$TIM3_CAP_COM_IRQHandler$85 ==.
                                    397 ;	./src/stm8s_it.c: 309: INTERRUPT_HANDLER(TIM3_CAP_COM_IRQHandler, 16)
                                    398 ; genLabel
                                    399 ;	-----------------------------------------
                                    400 ;	 function TIM3_CAP_COM_IRQHandler
                                    401 ;	-----------------------------------------
                                    402 ;	Register assignment is optimal.
                                    403 ;	Stack space usage: 0 bytes.
      00876C                        404 _TIM3_CAP_COM_IRQHandler:
                           000011   405 	Sstm8s_it$TIM3_CAP_COM_IRQHandler$86 ==.
                           000011   406 	Sstm8s_it$TIM3_CAP_COM_IRQHandler$87 ==.
                                    407 ;	./src/stm8s_it.c: 314: }
                                    408 ; genLabel
      00876C                        409 00101$:
                                    410 ; genEndFunction
                           000011   411 	Sstm8s_it$TIM3_CAP_COM_IRQHandler$88 ==.
                           000011   412 	XG$TIM3_CAP_COM_IRQHandler$0$0 ==.
      00876C 80               [11]  413 	iret
                           000012   414 	Sstm8s_it$TIM3_CAP_COM_IRQHandler$89 ==.
                           000012   415 	Sstm8s_it$UART1_TX_IRQHandler$90 ==.
                                    416 ;	./src/stm8s_it.c: 324: INTERRUPT_HANDLER(UART1_TX_IRQHandler, 17)
                                    417 ; genLabel
                                    418 ;	-----------------------------------------
                                    419 ;	 function UART1_TX_IRQHandler
                                    420 ;	-----------------------------------------
                                    421 ;	Register assignment is optimal.
                                    422 ;	Stack space usage: 0 bytes.
      00876D                        423 _UART1_TX_IRQHandler:
                           000012   424 	Sstm8s_it$UART1_TX_IRQHandler$91 ==.
                           000012   425 	Sstm8s_it$UART1_TX_IRQHandler$92 ==.
                                    426 ;	./src/stm8s_it.c: 329: }
                                    427 ; genLabel
      00876D                        428 00101$:
                                    429 ; genEndFunction
                           000012   430 	Sstm8s_it$UART1_TX_IRQHandler$93 ==.
                           000012   431 	XG$UART1_TX_IRQHandler$0$0 ==.
      00876D 80               [11]  432 	iret
                           000013   433 	Sstm8s_it$UART1_TX_IRQHandler$94 ==.
                           000013   434 	Sstm8s_it$UART1_RX_IRQHandler$95 ==.
                                    435 ;	./src/stm8s_it.c: 336: INTERRUPT_HANDLER(UART1_RX_IRQHandler, 18)
                                    436 ; genLabel
                                    437 ;	-----------------------------------------
                                    438 ;	 function UART1_RX_IRQHandler
                                    439 ;	-----------------------------------------
                                    440 ;	Register assignment is optimal.
                                    441 ;	Stack space usage: 0 bytes.
      00876E                        442 _UART1_RX_IRQHandler:
                           000013   443 	Sstm8s_it$UART1_RX_IRQHandler$96 ==.
                           000013   444 	Sstm8s_it$UART1_RX_IRQHandler$97 ==.
                                    445 ;	./src/stm8s_it.c: 341: }
                                    446 ; genLabel
      00876E                        447 00101$:
                                    448 ; genEndFunction
                           000013   449 	Sstm8s_it$UART1_RX_IRQHandler$98 ==.
                           000013   450 	XG$UART1_RX_IRQHandler$0$0 ==.
      00876E 80               [11]  451 	iret
                           000014   452 	Sstm8s_it$UART1_RX_IRQHandler$99 ==.
                           000014   453 	Sstm8s_it$I2C_IRQHandler$100 ==.
                                    454 ;	./src/stm8s_it.c: 349: INTERRUPT_HANDLER(I2C_IRQHandler, 19)
                                    455 ; genLabel
                                    456 ;	-----------------------------------------
                                    457 ;	 function I2C_IRQHandler
                                    458 ;	-----------------------------------------
                                    459 ;	Register assignment is optimal.
                                    460 ;	Stack space usage: 0 bytes.
      00876F                        461 _I2C_IRQHandler:
                           000014   462 	Sstm8s_it$I2C_IRQHandler$101 ==.
                           000014   463 	Sstm8s_it$I2C_IRQHandler$102 ==.
                                    464 ;	./src/stm8s_it.c: 354: }
                                    465 ; genLabel
      00876F                        466 00101$:
                                    467 ; genEndFunction
                           000014   468 	Sstm8s_it$I2C_IRQHandler$103 ==.
                           000014   469 	XG$I2C_IRQHandler$0$0 ==.
      00876F 80               [11]  470 	iret
                           000015   471 	Sstm8s_it$I2C_IRQHandler$104 ==.
                           000015   472 	Sstm8s_it$UART3_TX_IRQHandler$105 ==.
                                    473 ;	./src/stm8s_it.c: 388: INTERRUPT_HANDLER(UART3_TX_IRQHandler, 20)
                                    474 ; genLabel
                                    475 ;	-----------------------------------------
                                    476 ;	 function UART3_TX_IRQHandler
                                    477 ;	-----------------------------------------
                                    478 ;	Register assignment is optimal.
                                    479 ;	Stack space usage: 0 bytes.
      008770                        480 _UART3_TX_IRQHandler:
                           000015   481 	Sstm8s_it$UART3_TX_IRQHandler$106 ==.
                           000015   482 	Sstm8s_it$UART3_TX_IRQHandler$107 ==.
                                    483 ;	./src/stm8s_it.c: 393: }
                                    484 ; genLabel
      008770                        485 00101$:
                                    486 ; genEndFunction
                           000015   487 	Sstm8s_it$UART3_TX_IRQHandler$108 ==.
                           000015   488 	XG$UART3_TX_IRQHandler$0$0 ==.
      008770 80               [11]  489 	iret
                           000016   490 	Sstm8s_it$UART3_TX_IRQHandler$109 ==.
                           000016   491 	Sstm8s_it$UART3_RX_IRQHandler$110 ==.
                                    492 ;	./src/stm8s_it.c: 400: INTERRUPT_HANDLER(UART3_RX_IRQHandler, 21)
                                    493 ; genLabel
                                    494 ;	-----------------------------------------
                                    495 ;	 function UART3_RX_IRQHandler
                                    496 ;	-----------------------------------------
                                    497 ;	Register assignment is optimal.
                                    498 ;	Stack space usage: 0 bytes.
      008771                        499 _UART3_RX_IRQHandler:
                           000016   500 	Sstm8s_it$UART3_RX_IRQHandler$111 ==.
                           000016   501 	Sstm8s_it$UART3_RX_IRQHandler$112 ==.
                                    502 ;	./src/stm8s_it.c: 405: }
                                    503 ; genLabel
      008771                        504 00101$:
                                    505 ; genEndFunction
                           000016   506 	Sstm8s_it$UART3_RX_IRQHandler$113 ==.
                           000016   507 	XG$UART3_RX_IRQHandler$0$0 ==.
      008771 80               [11]  508 	iret
                           000017   509 	Sstm8s_it$UART3_RX_IRQHandler$114 ==.
                           000017   510 	Sstm8s_it$ADC2_IRQHandler$115 ==.
                                    511 ;	./src/stm8s_it.c: 414: INTERRUPT_HANDLER(ADC2_IRQHandler, 22)
                                    512 ; genLabel
                                    513 ;	-----------------------------------------
                                    514 ;	 function ADC2_IRQHandler
                                    515 ;	-----------------------------------------
                                    516 ;	Register assignment is optimal.
                                    517 ;	Stack space usage: 0 bytes.
      008772                        518 _ADC2_IRQHandler:
                           000017   519 	Sstm8s_it$ADC2_IRQHandler$116 ==.
                           000017   520 	Sstm8s_it$ADC2_IRQHandler$117 ==.
                                    521 ;	./src/stm8s_it.c: 420: return;
                                    522 ; genReturn
                                    523 ; genLabel
      008772                        524 00101$:
                           000017   525 	Sstm8s_it$ADC2_IRQHandler$118 ==.
                                    526 ;	./src/stm8s_it.c: 422: }
                                    527 ; genEndFunction
                           000017   528 	Sstm8s_it$ADC2_IRQHandler$119 ==.
                           000017   529 	XG$ADC2_IRQHandler$0$0 ==.
      008772 80               [11]  530 	iret
                           000018   531 	Sstm8s_it$ADC2_IRQHandler$120 ==.
                           000018   532 	Sstm8s_it$EEPROM_EEC_IRQHandler$121 ==.
                                    533 ;	./src/stm8s_it.c: 471: INTERRUPT_HANDLER(EEPROM_EEC_IRQHandler, 24)
                                    534 ; genLabel
                                    535 ;	-----------------------------------------
                                    536 ;	 function EEPROM_EEC_IRQHandler
                                    537 ;	-----------------------------------------
                                    538 ;	Register assignment is optimal.
                                    539 ;	Stack space usage: 0 bytes.
      008773                        540 _EEPROM_EEC_IRQHandler:
                           000018   541 	Sstm8s_it$EEPROM_EEC_IRQHandler$122 ==.
                           000018   542 	Sstm8s_it$EEPROM_EEC_IRQHandler$123 ==.
                                    543 ;	./src/stm8s_it.c: 476: }
                                    544 ; genLabel
      008773                        545 00101$:
                                    546 ; genEndFunction
                           000018   547 	Sstm8s_it$EEPROM_EEC_IRQHandler$124 ==.
                           000018   548 	XG$EEPROM_EEC_IRQHandler$0$0 ==.
      008773 80               [11]  549 	iret
                           000019   550 	Sstm8s_it$EEPROM_EEC_IRQHandler$125 ==.
                                    551 	.area CODE
                                    552 	.area CONST
                                    553 	.area INITIALIZER
                                    554 	.area CABS (ABS)
                                    555 
                                    556 	.area .debug_line (NOLOAD)
      000949 00 00 02 BB            557 	.dw	0,Ldebug_line_end-Ldebug_line_start
      00094D                        558 Ldebug_line_start:
      00094D 00 02                  559 	.dw	2
      00094F 00 00 00 71            560 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      000953 01                     561 	.db	1
      000954 01                     562 	.db	1
      000955 FB                     563 	.db	-5
      000956 0F                     564 	.db	15
      000957 0A                     565 	.db	10
      000958 00                     566 	.db	0
      000959 01                     567 	.db	1
      00095A 01                     568 	.db	1
      00095B 01                     569 	.db	1
      00095C 01                     570 	.db	1
      00095D 00                     571 	.db	0
      00095E 00                     572 	.db	0
      00095F 00                     573 	.db	0
      000960 01                     574 	.db	1
      000961 43 3A 5C 50 72 6F 67   575 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      000989 00                     576 	.db	0
      00098A 43 3A 5C 50 72 6F 67   577 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      0009AD 00                     578 	.db	0
      0009AE 00                     579 	.db	0
      0009AF 2E 2F 73 72 63 2F 73   580 	.ascii "./src/stm8s_it.c"
             74 6D 38 73 5F 69 74
             2E 63
      0009BF 00                     581 	.db	0
      0009C0 00                     582 	.uleb128	0
      0009C1 00                     583 	.uleb128	0
      0009C2 00                     584 	.uleb128	0
      0009C3 00                     585 	.db	0
      0009C4                        586 Ldebug_line_stmt:
      0009C4 00                     587 	.db	0
      0009C5 05                     588 	.uleb128	5
      0009C6 02                     589 	.db	2
      0009C7 00 00 87 5B            590 	.dw	0,(Sstm8s_it$TRAP_IRQHandler$0)
      0009CB 03                     591 	.db	3
      0009CC 3E                     592 	.sleb128	62
      0009CD 01                     593 	.db	1
      0009CE 09                     594 	.db	9
      0009CF 00 00                  595 	.dw	Sstm8s_it$TRAP_IRQHandler$2-Sstm8s_it$TRAP_IRQHandler$0
      0009D1 03                     596 	.db	3
      0009D2 05                     597 	.sleb128	5
      0009D3 01                     598 	.db	1
      0009D4 09                     599 	.db	9
      0009D5 00 01                  600 	.dw	1+Sstm8s_it$TRAP_IRQHandler$3-Sstm8s_it$TRAP_IRQHandler$2
      0009D7 00                     601 	.db	0
      0009D8 01                     602 	.uleb128	1
      0009D9 01                     603 	.db	1
      0009DA 00                     604 	.db	0
      0009DB 05                     605 	.uleb128	5
      0009DC 02                     606 	.db	2
      0009DD 00 00 87 5C            607 	.dw	0,(Sstm8s_it$TLI_IRQHandler$5)
      0009E1 03                     608 	.db	3
      0009E2 C9 00                  609 	.sleb128	73
      0009E4 01                     610 	.db	1
      0009E5 09                     611 	.db	9
      0009E6 00 00                  612 	.dw	Sstm8s_it$TLI_IRQHandler$7-Sstm8s_it$TLI_IRQHandler$5
      0009E8 03                     613 	.db	3
      0009E9 05                     614 	.sleb128	5
      0009EA 01                     615 	.db	1
      0009EB 09                     616 	.db	9
      0009EC 00 01                  617 	.dw	1+Sstm8s_it$TLI_IRQHandler$8-Sstm8s_it$TLI_IRQHandler$7
      0009EE 00                     618 	.db	0
      0009EF 01                     619 	.uleb128	1
      0009F0 01                     620 	.db	1
      0009F1 00                     621 	.db	0
      0009F2 05                     622 	.uleb128	5
      0009F3 02                     623 	.db	2
      0009F4 00 00 87 5D            624 	.dw	0,(Sstm8s_it$AWU_IRQHandler$10)
      0009F8 03                     625 	.db	3
      0009F9 D5 00                  626 	.sleb128	85
      0009FB 01                     627 	.db	1
      0009FC 09                     628 	.db	9
      0009FD 00 00                  629 	.dw	Sstm8s_it$AWU_IRQHandler$12-Sstm8s_it$AWU_IRQHandler$10
      0009FF 03                     630 	.db	3
      000A00 05                     631 	.sleb128	5
      000A01 01                     632 	.db	1
      000A02 09                     633 	.db	9
      000A03 00 01                  634 	.dw	1+Sstm8s_it$AWU_IRQHandler$13-Sstm8s_it$AWU_IRQHandler$12
      000A05 00                     635 	.db	0
      000A06 01                     636 	.uleb128	1
      000A07 01                     637 	.db	1
      000A08 00                     638 	.db	0
      000A09 05                     639 	.uleb128	5
      000A0A 02                     640 	.db	2
      000A0B 00 00 87 5E            641 	.dw	0,(Sstm8s_it$CLK_IRQHandler$15)
      000A0F 03                     642 	.db	3
      000A10 E1 00                  643 	.sleb128	97
      000A12 01                     644 	.db	1
      000A13 09                     645 	.db	9
      000A14 00 00                  646 	.dw	Sstm8s_it$CLK_IRQHandler$17-Sstm8s_it$CLK_IRQHandler$15
      000A16 03                     647 	.db	3
      000A17 05                     648 	.sleb128	5
      000A18 01                     649 	.db	1
      000A19 09                     650 	.db	9
      000A1A 00 01                  651 	.dw	1+Sstm8s_it$CLK_IRQHandler$18-Sstm8s_it$CLK_IRQHandler$17
      000A1C 00                     652 	.db	0
      000A1D 01                     653 	.uleb128	1
      000A1E 01                     654 	.db	1
      000A1F 00                     655 	.db	0
      000A20 05                     656 	.uleb128	5
      000A21 02                     657 	.db	2
      000A22 00 00 87 5F            658 	.dw	0,(Sstm8s_it$EXTI_PORTA_IRQHandler$20)
      000A26 03                     659 	.db	3
      000A27 ED 00                  660 	.sleb128	109
      000A29 01                     661 	.db	1
      000A2A 09                     662 	.db	9
      000A2B 00 00                  663 	.dw	Sstm8s_it$EXTI_PORTA_IRQHandler$22-Sstm8s_it$EXTI_PORTA_IRQHandler$20
      000A2D 03                     664 	.db	3
      000A2E 05                     665 	.sleb128	5
      000A2F 01                     666 	.db	1
      000A30 09                     667 	.db	9
      000A31 00 01                  668 	.dw	1+Sstm8s_it$EXTI_PORTA_IRQHandler$23-Sstm8s_it$EXTI_PORTA_IRQHandler$22
      000A33 00                     669 	.db	0
      000A34 01                     670 	.uleb128	1
      000A35 01                     671 	.db	1
      000A36 00                     672 	.db	0
      000A37 05                     673 	.uleb128	5
      000A38 02                     674 	.db	2
      000A39 00 00 87 60            675 	.dw	0,(Sstm8s_it$EXTI_PORTB_IRQHandler$25)
      000A3D 03                     676 	.db	3
      000A3E F9 00                  677 	.sleb128	121
      000A40 01                     678 	.db	1
      000A41 09                     679 	.db	9
      000A42 00 00                  680 	.dw	Sstm8s_it$EXTI_PORTB_IRQHandler$27-Sstm8s_it$EXTI_PORTB_IRQHandler$25
      000A44 03                     681 	.db	3
      000A45 05                     682 	.sleb128	5
      000A46 01                     683 	.db	1
      000A47 09                     684 	.db	9
      000A48 00 01                  685 	.dw	1+Sstm8s_it$EXTI_PORTB_IRQHandler$28-Sstm8s_it$EXTI_PORTB_IRQHandler$27
      000A4A 00                     686 	.db	0
      000A4B 01                     687 	.uleb128	1
      000A4C 01                     688 	.db	1
      000A4D 00                     689 	.db	0
      000A4E 05                     690 	.uleb128	5
      000A4F 02                     691 	.db	2
      000A50 00 00 87 61            692 	.dw	0,(Sstm8s_it$EXTI_PORTC_IRQHandler$30)
      000A54 03                     693 	.db	3
      000A55 85 01                  694 	.sleb128	133
      000A57 01                     695 	.db	1
      000A58 09                     696 	.db	9
      000A59 00 00                  697 	.dw	Sstm8s_it$EXTI_PORTC_IRQHandler$32-Sstm8s_it$EXTI_PORTC_IRQHandler$30
      000A5B 03                     698 	.db	3
      000A5C 05                     699 	.sleb128	5
      000A5D 01                     700 	.db	1
      000A5E 09                     701 	.db	9
      000A5F 00 01                  702 	.dw	1+Sstm8s_it$EXTI_PORTC_IRQHandler$33-Sstm8s_it$EXTI_PORTC_IRQHandler$32
      000A61 00                     703 	.db	0
      000A62 01                     704 	.uleb128	1
      000A63 01                     705 	.db	1
      000A64 00                     706 	.db	0
      000A65 05                     707 	.uleb128	5
      000A66 02                     708 	.db	2
      000A67 00 00 87 62            709 	.dw	0,(Sstm8s_it$EXTI_PORTD_IRQHandler$35)
      000A6B 03                     710 	.db	3
      000A6C 91 01                  711 	.sleb128	145
      000A6E 01                     712 	.db	1
      000A6F 09                     713 	.db	9
      000A70 00 00                  714 	.dw	Sstm8s_it$EXTI_PORTD_IRQHandler$37-Sstm8s_it$EXTI_PORTD_IRQHandler$35
      000A72 03                     715 	.db	3
      000A73 05                     716 	.sleb128	5
      000A74 01                     717 	.db	1
      000A75 09                     718 	.db	9
      000A76 00 01                  719 	.dw	1+Sstm8s_it$EXTI_PORTD_IRQHandler$38-Sstm8s_it$EXTI_PORTD_IRQHandler$37
      000A78 00                     720 	.db	0
      000A79 01                     721 	.uleb128	1
      000A7A 01                     722 	.db	1
      000A7B 00                     723 	.db	0
      000A7C 05                     724 	.uleb128	5
      000A7D 02                     725 	.db	2
      000A7E 00 00 87 63            726 	.dw	0,(Sstm8s_it$EXTI_PORTE_IRQHandler$40)
      000A82 03                     727 	.db	3
      000A83 9D 01                  728 	.sleb128	157
      000A85 01                     729 	.db	1
      000A86 09                     730 	.db	9
      000A87 00 00                  731 	.dw	Sstm8s_it$EXTI_PORTE_IRQHandler$42-Sstm8s_it$EXTI_PORTE_IRQHandler$40
      000A89 03                     732 	.db	3
      000A8A 05                     733 	.sleb128	5
      000A8B 01                     734 	.db	1
      000A8C 09                     735 	.db	9
      000A8D 00 01                  736 	.dw	1+Sstm8s_it$EXTI_PORTE_IRQHandler$43-Sstm8s_it$EXTI_PORTE_IRQHandler$42
      000A8F 00                     737 	.db	0
      000A90 01                     738 	.uleb128	1
      000A91 01                     739 	.db	1
      000A92 00                     740 	.db	0
      000A93 05                     741 	.uleb128	5
      000A94 02                     742 	.db	2
      000A95 00 00 87 64            743 	.dw	0,(Sstm8s_it$CAN_RX_IRQHandler$45)
      000A99 03                     744 	.db	3
      000A9A B7 01                  745 	.sleb128	183
      000A9C 01                     746 	.db	1
      000A9D 09                     747 	.db	9
      000A9E 00 00                  748 	.dw	Sstm8s_it$CAN_RX_IRQHandler$47-Sstm8s_it$CAN_RX_IRQHandler$45
      000AA0 03                     749 	.db	3
      000AA1 05                     750 	.sleb128	5
      000AA2 01                     751 	.db	1
      000AA3 09                     752 	.db	9
      000AA4 00 01                  753 	.dw	1+Sstm8s_it$CAN_RX_IRQHandler$48-Sstm8s_it$CAN_RX_IRQHandler$47
      000AA6 00                     754 	.db	0
      000AA7 01                     755 	.uleb128	1
      000AA8 01                     756 	.db	1
      000AA9 00                     757 	.db	0
      000AAA 05                     758 	.uleb128	5
      000AAB 02                     759 	.db	2
      000AAC 00 00 87 65            760 	.dw	0,(Sstm8s_it$CAN_TX_IRQHandler$50)
      000AB0 03                     761 	.db	3
      000AB1 C3 01                  762 	.sleb128	195
      000AB3 01                     763 	.db	1
      000AB4 09                     764 	.db	9
      000AB5 00 00                  765 	.dw	Sstm8s_it$CAN_TX_IRQHandler$52-Sstm8s_it$CAN_TX_IRQHandler$50
      000AB7 03                     766 	.db	3
      000AB8 05                     767 	.sleb128	5
      000AB9 01                     768 	.db	1
      000ABA 09                     769 	.db	9
      000ABB 00 01                  770 	.dw	1+Sstm8s_it$CAN_TX_IRQHandler$53-Sstm8s_it$CAN_TX_IRQHandler$52
      000ABD 00                     771 	.db	0
      000ABE 01                     772 	.uleb128	1
      000ABF 01                     773 	.db	1
      000AC0 00                     774 	.db	0
      000AC1 05                     775 	.uleb128	5
      000AC2 02                     776 	.db	2
      000AC3 00 00 87 66            777 	.dw	0,(Sstm8s_it$SPI_IRQHandler$55)
      000AC7 03                     778 	.db	3
      000AC8 D0 01                  779 	.sleb128	208
      000ACA 01                     780 	.db	1
      000ACB 09                     781 	.db	9
      000ACC 00 00                  782 	.dw	Sstm8s_it$SPI_IRQHandler$57-Sstm8s_it$SPI_IRQHandler$55
      000ACE 03                     783 	.db	3
      000ACF 05                     784 	.sleb128	5
      000AD0 01                     785 	.db	1
      000AD1 09                     786 	.db	9
      000AD2 00 01                  787 	.dw	1+Sstm8s_it$SPI_IRQHandler$58-Sstm8s_it$SPI_IRQHandler$57
      000AD4 00                     788 	.db	0
      000AD5 01                     789 	.uleb128	1
      000AD6 01                     790 	.db	1
      000AD7 00                     791 	.db	0
      000AD8 05                     792 	.uleb128	5
      000AD9 02                     793 	.db	2
      000ADA 00 00 87 67            794 	.dw	0,(Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$60)
      000ADE 03                     795 	.db	3
      000ADF DC 01                  796 	.sleb128	220
      000AE1 01                     797 	.db	1
      000AE2 09                     798 	.db	9
      000AE3 00 00                  799 	.dw	Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$62-Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$60
      000AE5 03                     800 	.db	3
      000AE6 05                     801 	.sleb128	5
      000AE7 01                     802 	.db	1
      000AE8 09                     803 	.db	9
      000AE9 00 01                  804 	.dw	1+Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$63-Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$62
      000AEB 00                     805 	.db	0
      000AEC 01                     806 	.uleb128	1
      000AED 01                     807 	.db	1
      000AEE 00                     808 	.db	0
      000AEF 05                     809 	.uleb128	5
      000AF0 02                     810 	.db	2
      000AF1 00 00 87 68            811 	.dw	0,(Sstm8s_it$TIM1_CAP_COM_IRQHandler$65)
      000AF5 03                     812 	.db	3
      000AF6 E8 01                  813 	.sleb128	232
      000AF8 01                     814 	.db	1
      000AF9 09                     815 	.db	9
      000AFA 00 00                  816 	.dw	Sstm8s_it$TIM1_CAP_COM_IRQHandler$67-Sstm8s_it$TIM1_CAP_COM_IRQHandler$65
      000AFC 03                     817 	.db	3
      000AFD 05                     818 	.sleb128	5
      000AFE 01                     819 	.db	1
      000AFF 09                     820 	.db	9
      000B00 00 01                  821 	.dw	1+Sstm8s_it$TIM1_CAP_COM_IRQHandler$68-Sstm8s_it$TIM1_CAP_COM_IRQHandler$67
      000B02 00                     822 	.db	0
      000B03 01                     823 	.uleb128	1
      000B04 01                     824 	.db	1
      000B05 00                     825 	.db	0
      000B06 05                     826 	.uleb128	5
      000B07 02                     827 	.db	2
      000B08 00 00 87 69            828 	.dw	0,(Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$70)
      000B0C 03                     829 	.db	3
      000B0D 8D 02                  830 	.sleb128	269
      000B0F 01                     831 	.db	1
      000B10 09                     832 	.db	9
      000B11 00 00                  833 	.dw	Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$72-Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$70
      000B13 03                     834 	.db	3
      000B14 05                     835 	.sleb128	5
      000B15 01                     836 	.db	1
      000B16 09                     837 	.db	9
      000B17 00 01                  838 	.dw	1+Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$73-Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$72
      000B19 00                     839 	.db	0
      000B1A 01                     840 	.uleb128	1
      000B1B 01                     841 	.db	1
      000B1C 00                     842 	.db	0
      000B1D 05                     843 	.uleb128	5
      000B1E 02                     844 	.db	2
      000B1F 00 00 87 6A            845 	.dw	0,(Sstm8s_it$TIM2_CAP_COM_IRQHandler$75)
      000B23 03                     846 	.db	3
      000B24 99 02                  847 	.sleb128	281
      000B26 01                     848 	.db	1
      000B27 09                     849 	.db	9
      000B28 00 00                  850 	.dw	Sstm8s_it$TIM2_CAP_COM_IRQHandler$77-Sstm8s_it$TIM2_CAP_COM_IRQHandler$75
      000B2A 03                     851 	.db	3
      000B2B 05                     852 	.sleb128	5
      000B2C 01                     853 	.db	1
      000B2D 09                     854 	.db	9
      000B2E 00 01                  855 	.dw	1+Sstm8s_it$TIM2_CAP_COM_IRQHandler$78-Sstm8s_it$TIM2_CAP_COM_IRQHandler$77
      000B30 00                     856 	.db	0
      000B31 01                     857 	.uleb128	1
      000B32 01                     858 	.db	1
      000B33 00                     859 	.db	0
      000B34 05                     860 	.uleb128	5
      000B35 02                     861 	.db	2
      000B36 00 00 87 6B            862 	.dw	0,(Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$80)
      000B3A 03                     863 	.db	3
      000B3B A8 02                  864 	.sleb128	296
      000B3D 01                     865 	.db	1
      000B3E 09                     866 	.db	9
      000B3F 00 00                  867 	.dw	Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$82-Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$80
      000B41 03                     868 	.db	3
      000B42 05                     869 	.sleb128	5
      000B43 01                     870 	.db	1
      000B44 09                     871 	.db	9
      000B45 00 01                  872 	.dw	1+Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$83-Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$82
      000B47 00                     873 	.db	0
      000B48 01                     874 	.uleb128	1
      000B49 01                     875 	.db	1
      000B4A 00                     876 	.db	0
      000B4B 05                     877 	.uleb128	5
      000B4C 02                     878 	.db	2
      000B4D 00 00 87 6C            879 	.dw	0,(Sstm8s_it$TIM3_CAP_COM_IRQHandler$85)
      000B51 03                     880 	.db	3
      000B52 B4 02                  881 	.sleb128	308
      000B54 01                     882 	.db	1
      000B55 09                     883 	.db	9
      000B56 00 00                  884 	.dw	Sstm8s_it$TIM3_CAP_COM_IRQHandler$87-Sstm8s_it$TIM3_CAP_COM_IRQHandler$85
      000B58 03                     885 	.db	3
      000B59 05                     886 	.sleb128	5
      000B5A 01                     887 	.db	1
      000B5B 09                     888 	.db	9
      000B5C 00 01                  889 	.dw	1+Sstm8s_it$TIM3_CAP_COM_IRQHandler$88-Sstm8s_it$TIM3_CAP_COM_IRQHandler$87
      000B5E 00                     890 	.db	0
      000B5F 01                     891 	.uleb128	1
      000B60 01                     892 	.db	1
      000B61 00                     893 	.db	0
      000B62 05                     894 	.uleb128	5
      000B63 02                     895 	.db	2
      000B64 00 00 87 6D            896 	.dw	0,(Sstm8s_it$UART1_TX_IRQHandler$90)
      000B68 03                     897 	.db	3
      000B69 C3 02                  898 	.sleb128	323
      000B6B 01                     899 	.db	1
      000B6C 09                     900 	.db	9
      000B6D 00 00                  901 	.dw	Sstm8s_it$UART1_TX_IRQHandler$92-Sstm8s_it$UART1_TX_IRQHandler$90
      000B6F 03                     902 	.db	3
      000B70 05                     903 	.sleb128	5
      000B71 01                     904 	.db	1
      000B72 09                     905 	.db	9
      000B73 00 01                  906 	.dw	1+Sstm8s_it$UART1_TX_IRQHandler$93-Sstm8s_it$UART1_TX_IRQHandler$92
      000B75 00                     907 	.db	0
      000B76 01                     908 	.uleb128	1
      000B77 01                     909 	.db	1
      000B78 00                     910 	.db	0
      000B79 05                     911 	.uleb128	5
      000B7A 02                     912 	.db	2
      000B7B 00 00 87 6E            913 	.dw	0,(Sstm8s_it$UART1_RX_IRQHandler$95)
      000B7F 03                     914 	.db	3
      000B80 CF 02                  915 	.sleb128	335
      000B82 01                     916 	.db	1
      000B83 09                     917 	.db	9
      000B84 00 00                  918 	.dw	Sstm8s_it$UART1_RX_IRQHandler$97-Sstm8s_it$UART1_RX_IRQHandler$95
      000B86 03                     919 	.db	3
      000B87 05                     920 	.sleb128	5
      000B88 01                     921 	.db	1
      000B89 09                     922 	.db	9
      000B8A 00 01                  923 	.dw	1+Sstm8s_it$UART1_RX_IRQHandler$98-Sstm8s_it$UART1_RX_IRQHandler$97
      000B8C 00                     924 	.db	0
      000B8D 01                     925 	.uleb128	1
      000B8E 01                     926 	.db	1
      000B8F 00                     927 	.db	0
      000B90 05                     928 	.uleb128	5
      000B91 02                     929 	.db	2
      000B92 00 00 87 6F            930 	.dw	0,(Sstm8s_it$I2C_IRQHandler$100)
      000B96 03                     931 	.db	3
      000B97 DC 02                  932 	.sleb128	348
      000B99 01                     933 	.db	1
      000B9A 09                     934 	.db	9
      000B9B 00 00                  935 	.dw	Sstm8s_it$I2C_IRQHandler$102-Sstm8s_it$I2C_IRQHandler$100
      000B9D 03                     936 	.db	3
      000B9E 05                     937 	.sleb128	5
      000B9F 01                     938 	.db	1
      000BA0 09                     939 	.db	9
      000BA1 00 01                  940 	.dw	1+Sstm8s_it$I2C_IRQHandler$103-Sstm8s_it$I2C_IRQHandler$102
      000BA3 00                     941 	.db	0
      000BA4 01                     942 	.uleb128	1
      000BA5 01                     943 	.db	1
      000BA6 00                     944 	.db	0
      000BA7 05                     945 	.uleb128	5
      000BA8 02                     946 	.db	2
      000BA9 00 00 87 70            947 	.dw	0,(Sstm8s_it$UART3_TX_IRQHandler$105)
      000BAD 03                     948 	.db	3
      000BAE 83 03                  949 	.sleb128	387
      000BB0 01                     950 	.db	1
      000BB1 09                     951 	.db	9
      000BB2 00 00                  952 	.dw	Sstm8s_it$UART3_TX_IRQHandler$107-Sstm8s_it$UART3_TX_IRQHandler$105
      000BB4 03                     953 	.db	3
      000BB5 05                     954 	.sleb128	5
      000BB6 01                     955 	.db	1
      000BB7 09                     956 	.db	9
      000BB8 00 01                  957 	.dw	1+Sstm8s_it$UART3_TX_IRQHandler$108-Sstm8s_it$UART3_TX_IRQHandler$107
      000BBA 00                     958 	.db	0
      000BBB 01                     959 	.uleb128	1
      000BBC 01                     960 	.db	1
      000BBD 00                     961 	.db	0
      000BBE 05                     962 	.uleb128	5
      000BBF 02                     963 	.db	2
      000BC0 00 00 87 71            964 	.dw	0,(Sstm8s_it$UART3_RX_IRQHandler$110)
      000BC4 03                     965 	.db	3
      000BC5 8F 03                  966 	.sleb128	399
      000BC7 01                     967 	.db	1
      000BC8 09                     968 	.db	9
      000BC9 00 00                  969 	.dw	Sstm8s_it$UART3_RX_IRQHandler$112-Sstm8s_it$UART3_RX_IRQHandler$110
      000BCB 03                     970 	.db	3
      000BCC 05                     971 	.sleb128	5
      000BCD 01                     972 	.db	1
      000BCE 09                     973 	.db	9
      000BCF 00 01                  974 	.dw	1+Sstm8s_it$UART3_RX_IRQHandler$113-Sstm8s_it$UART3_RX_IRQHandler$112
      000BD1 00                     975 	.db	0
      000BD2 01                     976 	.uleb128	1
      000BD3 01                     977 	.db	1
      000BD4 00                     978 	.db	0
      000BD5 05                     979 	.uleb128	5
      000BD6 02                     980 	.db	2
      000BD7 00 00 87 72            981 	.dw	0,(Sstm8s_it$ADC2_IRQHandler$115)
      000BDB 03                     982 	.db	3
      000BDC 9D 03                  983 	.sleb128	413
      000BDE 01                     984 	.db	1
      000BDF 09                     985 	.db	9
      000BE0 00 00                  986 	.dw	Sstm8s_it$ADC2_IRQHandler$117-Sstm8s_it$ADC2_IRQHandler$115
      000BE2 03                     987 	.db	3
      000BE3 06                     988 	.sleb128	6
      000BE4 01                     989 	.db	1
      000BE5 09                     990 	.db	9
      000BE6 00 00                  991 	.dw	Sstm8s_it$ADC2_IRQHandler$118-Sstm8s_it$ADC2_IRQHandler$117
      000BE8 03                     992 	.db	3
      000BE9 02                     993 	.sleb128	2
      000BEA 01                     994 	.db	1
      000BEB 09                     995 	.db	9
      000BEC 00 01                  996 	.dw	1+Sstm8s_it$ADC2_IRQHandler$119-Sstm8s_it$ADC2_IRQHandler$118
      000BEE 00                     997 	.db	0
      000BEF 01                     998 	.uleb128	1
      000BF0 01                     999 	.db	1
      000BF1 00                    1000 	.db	0
      000BF2 05                    1001 	.uleb128	5
      000BF3 02                    1002 	.db	2
      000BF4 00 00 87 73           1003 	.dw	0,(Sstm8s_it$EEPROM_EEC_IRQHandler$121)
      000BF8 03                    1004 	.db	3
      000BF9 D6 03                 1005 	.sleb128	470
      000BFB 01                    1006 	.db	1
      000BFC 09                    1007 	.db	9
      000BFD 00 00                 1008 	.dw	Sstm8s_it$EEPROM_EEC_IRQHandler$123-Sstm8s_it$EEPROM_EEC_IRQHandler$121
      000BFF 03                    1009 	.db	3
      000C00 05                    1010 	.sleb128	5
      000C01 01                    1011 	.db	1
      000C02 09                    1012 	.db	9
      000C03 00 01                 1013 	.dw	1+Sstm8s_it$EEPROM_EEC_IRQHandler$124-Sstm8s_it$EEPROM_EEC_IRQHandler$123
      000C05 00                    1014 	.db	0
      000C06 01                    1015 	.uleb128	1
      000C07 01                    1016 	.db	1
      000C08                       1017 Ldebug_line_end:
                                   1018 
                                   1019 	.area .debug_loc (NOLOAD)
      0012FC                       1020 Ldebug_loc_start:
      0012FC 00 00 87 73           1021 	.dw	0,(Sstm8s_it$EEPROM_EEC_IRQHandler$122)
      001300 00 00 87 74           1022 	.dw	0,(Sstm8s_it$EEPROM_EEC_IRQHandler$125)
      001304 00 02                 1023 	.dw	2
      001306 78                    1024 	.db	120
      001307 01                    1025 	.sleb128	1
      001308 00 00 00 00           1026 	.dw	0,0
      00130C 00 00 00 00           1027 	.dw	0,0
      001310 00 00 87 72           1028 	.dw	0,(Sstm8s_it$ADC2_IRQHandler$116)
      001314 00 00 87 73           1029 	.dw	0,(Sstm8s_it$ADC2_IRQHandler$120)
      001318 00 02                 1030 	.dw	2
      00131A 78                    1031 	.db	120
      00131B 01                    1032 	.sleb128	1
      00131C 00 00 00 00           1033 	.dw	0,0
      001320 00 00 00 00           1034 	.dw	0,0
      001324 00 00 87 71           1035 	.dw	0,(Sstm8s_it$UART3_RX_IRQHandler$111)
      001328 00 00 87 72           1036 	.dw	0,(Sstm8s_it$UART3_RX_IRQHandler$114)
      00132C 00 02                 1037 	.dw	2
      00132E 78                    1038 	.db	120
      00132F 01                    1039 	.sleb128	1
      001330 00 00 00 00           1040 	.dw	0,0
      001334 00 00 00 00           1041 	.dw	0,0
      001338 00 00 87 70           1042 	.dw	0,(Sstm8s_it$UART3_TX_IRQHandler$106)
      00133C 00 00 87 71           1043 	.dw	0,(Sstm8s_it$UART3_TX_IRQHandler$109)
      001340 00 02                 1044 	.dw	2
      001342 78                    1045 	.db	120
      001343 01                    1046 	.sleb128	1
      001344 00 00 00 00           1047 	.dw	0,0
      001348 00 00 00 00           1048 	.dw	0,0
      00134C 00 00 87 6F           1049 	.dw	0,(Sstm8s_it$I2C_IRQHandler$101)
      001350 00 00 87 70           1050 	.dw	0,(Sstm8s_it$I2C_IRQHandler$104)
      001354 00 02                 1051 	.dw	2
      001356 78                    1052 	.db	120
      001357 01                    1053 	.sleb128	1
      001358 00 00 00 00           1054 	.dw	0,0
      00135C 00 00 00 00           1055 	.dw	0,0
      001360 00 00 87 6E           1056 	.dw	0,(Sstm8s_it$UART1_RX_IRQHandler$96)
      001364 00 00 87 6F           1057 	.dw	0,(Sstm8s_it$UART1_RX_IRQHandler$99)
      001368 00 02                 1058 	.dw	2
      00136A 78                    1059 	.db	120
      00136B 01                    1060 	.sleb128	1
      00136C 00 00 00 00           1061 	.dw	0,0
      001370 00 00 00 00           1062 	.dw	0,0
      001374 00 00 87 6D           1063 	.dw	0,(Sstm8s_it$UART1_TX_IRQHandler$91)
      001378 00 00 87 6E           1064 	.dw	0,(Sstm8s_it$UART1_TX_IRQHandler$94)
      00137C 00 02                 1065 	.dw	2
      00137E 78                    1066 	.db	120
      00137F 01                    1067 	.sleb128	1
      001380 00 00 00 00           1068 	.dw	0,0
      001384 00 00 00 00           1069 	.dw	0,0
      001388 00 00 87 6C           1070 	.dw	0,(Sstm8s_it$TIM3_CAP_COM_IRQHandler$86)
      00138C 00 00 87 6D           1071 	.dw	0,(Sstm8s_it$TIM3_CAP_COM_IRQHandler$89)
      001390 00 02                 1072 	.dw	2
      001392 78                    1073 	.db	120
      001393 01                    1074 	.sleb128	1
      001394 00 00 00 00           1075 	.dw	0,0
      001398 00 00 00 00           1076 	.dw	0,0
      00139C 00 00 87 6B           1077 	.dw	0,(Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$81)
      0013A0 00 00 87 6C           1078 	.dw	0,(Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$84)
      0013A4 00 02                 1079 	.dw	2
      0013A6 78                    1080 	.db	120
      0013A7 01                    1081 	.sleb128	1
      0013A8 00 00 00 00           1082 	.dw	0,0
      0013AC 00 00 00 00           1083 	.dw	0,0
      0013B0 00 00 87 6A           1084 	.dw	0,(Sstm8s_it$TIM2_CAP_COM_IRQHandler$76)
      0013B4 00 00 87 6B           1085 	.dw	0,(Sstm8s_it$TIM2_CAP_COM_IRQHandler$79)
      0013B8 00 02                 1086 	.dw	2
      0013BA 78                    1087 	.db	120
      0013BB 01                    1088 	.sleb128	1
      0013BC 00 00 00 00           1089 	.dw	0,0
      0013C0 00 00 00 00           1090 	.dw	0,0
      0013C4 00 00 87 69           1091 	.dw	0,(Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$71)
      0013C8 00 00 87 6A           1092 	.dw	0,(Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$74)
      0013CC 00 02                 1093 	.dw	2
      0013CE 78                    1094 	.db	120
      0013CF 01                    1095 	.sleb128	1
      0013D0 00 00 00 00           1096 	.dw	0,0
      0013D4 00 00 00 00           1097 	.dw	0,0
      0013D8 00 00 87 68           1098 	.dw	0,(Sstm8s_it$TIM1_CAP_COM_IRQHandler$66)
      0013DC 00 00 87 69           1099 	.dw	0,(Sstm8s_it$TIM1_CAP_COM_IRQHandler$69)
      0013E0 00 02                 1100 	.dw	2
      0013E2 78                    1101 	.db	120
      0013E3 01                    1102 	.sleb128	1
      0013E4 00 00 00 00           1103 	.dw	0,0
      0013E8 00 00 00 00           1104 	.dw	0,0
      0013EC 00 00 87 67           1105 	.dw	0,(Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$61)
      0013F0 00 00 87 68           1106 	.dw	0,(Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$64)
      0013F4 00 02                 1107 	.dw	2
      0013F6 78                    1108 	.db	120
      0013F7 01                    1109 	.sleb128	1
      0013F8 00 00 00 00           1110 	.dw	0,0
      0013FC 00 00 00 00           1111 	.dw	0,0
      001400 00 00 87 66           1112 	.dw	0,(Sstm8s_it$SPI_IRQHandler$56)
      001404 00 00 87 67           1113 	.dw	0,(Sstm8s_it$SPI_IRQHandler$59)
      001408 00 02                 1114 	.dw	2
      00140A 78                    1115 	.db	120
      00140B 01                    1116 	.sleb128	1
      00140C 00 00 00 00           1117 	.dw	0,0
      001410 00 00 00 00           1118 	.dw	0,0
      001414 00 00 87 65           1119 	.dw	0,(Sstm8s_it$CAN_TX_IRQHandler$51)
      001418 00 00 87 66           1120 	.dw	0,(Sstm8s_it$CAN_TX_IRQHandler$54)
      00141C 00 02                 1121 	.dw	2
      00141E 78                    1122 	.db	120
      00141F 01                    1123 	.sleb128	1
      001420 00 00 00 00           1124 	.dw	0,0
      001424 00 00 00 00           1125 	.dw	0,0
      001428 00 00 87 64           1126 	.dw	0,(Sstm8s_it$CAN_RX_IRQHandler$46)
      00142C 00 00 87 65           1127 	.dw	0,(Sstm8s_it$CAN_RX_IRQHandler$49)
      001430 00 02                 1128 	.dw	2
      001432 78                    1129 	.db	120
      001433 01                    1130 	.sleb128	1
      001434 00 00 00 00           1131 	.dw	0,0
      001438 00 00 00 00           1132 	.dw	0,0
      00143C 00 00 87 63           1133 	.dw	0,(Sstm8s_it$EXTI_PORTE_IRQHandler$41)
      001440 00 00 87 64           1134 	.dw	0,(Sstm8s_it$EXTI_PORTE_IRQHandler$44)
      001444 00 02                 1135 	.dw	2
      001446 78                    1136 	.db	120
      001447 01                    1137 	.sleb128	1
      001448 00 00 00 00           1138 	.dw	0,0
      00144C 00 00 00 00           1139 	.dw	0,0
      001450 00 00 87 62           1140 	.dw	0,(Sstm8s_it$EXTI_PORTD_IRQHandler$36)
      001454 00 00 87 63           1141 	.dw	0,(Sstm8s_it$EXTI_PORTD_IRQHandler$39)
      001458 00 02                 1142 	.dw	2
      00145A 78                    1143 	.db	120
      00145B 01                    1144 	.sleb128	1
      00145C 00 00 00 00           1145 	.dw	0,0
      001460 00 00 00 00           1146 	.dw	0,0
      001464 00 00 87 61           1147 	.dw	0,(Sstm8s_it$EXTI_PORTC_IRQHandler$31)
      001468 00 00 87 62           1148 	.dw	0,(Sstm8s_it$EXTI_PORTC_IRQHandler$34)
      00146C 00 02                 1149 	.dw	2
      00146E 78                    1150 	.db	120
      00146F 01                    1151 	.sleb128	1
      001470 00 00 00 00           1152 	.dw	0,0
      001474 00 00 00 00           1153 	.dw	0,0
      001478 00 00 87 60           1154 	.dw	0,(Sstm8s_it$EXTI_PORTB_IRQHandler$26)
      00147C 00 00 87 61           1155 	.dw	0,(Sstm8s_it$EXTI_PORTB_IRQHandler$29)
      001480 00 02                 1156 	.dw	2
      001482 78                    1157 	.db	120
      001483 01                    1158 	.sleb128	1
      001484 00 00 00 00           1159 	.dw	0,0
      001488 00 00 00 00           1160 	.dw	0,0
      00148C 00 00 87 5F           1161 	.dw	0,(Sstm8s_it$EXTI_PORTA_IRQHandler$21)
      001490 00 00 87 60           1162 	.dw	0,(Sstm8s_it$EXTI_PORTA_IRQHandler$24)
      001494 00 02                 1163 	.dw	2
      001496 78                    1164 	.db	120
      001497 01                    1165 	.sleb128	1
      001498 00 00 00 00           1166 	.dw	0,0
      00149C 00 00 00 00           1167 	.dw	0,0
      0014A0 00 00 87 5E           1168 	.dw	0,(Sstm8s_it$CLK_IRQHandler$16)
      0014A4 00 00 87 5F           1169 	.dw	0,(Sstm8s_it$CLK_IRQHandler$19)
      0014A8 00 02                 1170 	.dw	2
      0014AA 78                    1171 	.db	120
      0014AB 01                    1172 	.sleb128	1
      0014AC 00 00 00 00           1173 	.dw	0,0
      0014B0 00 00 00 00           1174 	.dw	0,0
      0014B4 00 00 87 5D           1175 	.dw	0,(Sstm8s_it$AWU_IRQHandler$11)
      0014B8 00 00 87 5E           1176 	.dw	0,(Sstm8s_it$AWU_IRQHandler$14)
      0014BC 00 02                 1177 	.dw	2
      0014BE 78                    1178 	.db	120
      0014BF 01                    1179 	.sleb128	1
      0014C0 00 00 00 00           1180 	.dw	0,0
      0014C4 00 00 00 00           1181 	.dw	0,0
      0014C8 00 00 87 5C           1182 	.dw	0,(Sstm8s_it$TLI_IRQHandler$6)
      0014CC 00 00 87 5D           1183 	.dw	0,(Sstm8s_it$TLI_IRQHandler$9)
      0014D0 00 02                 1184 	.dw	2
      0014D2 78                    1185 	.db	120
      0014D3 01                    1186 	.sleb128	1
      0014D4 00 00 00 00           1187 	.dw	0,0
      0014D8 00 00 00 00           1188 	.dw	0,0
      0014DC 00 00 87 5B           1189 	.dw	0,(Sstm8s_it$TRAP_IRQHandler$1)
      0014E0 00 00 87 5C           1190 	.dw	0,(Sstm8s_it$TRAP_IRQHandler$4)
      0014E4 00 02                 1191 	.dw	2
      0014E6 78                    1192 	.db	120
      0014E7 01                    1193 	.sleb128	1
      0014E8 00 00 00 00           1194 	.dw	0,0
      0014EC 00 00 00 00           1195 	.dw	0,0
                                   1196 
                                   1197 	.area .debug_abbrev (NOLOAD)
      000235                       1198 Ldebug_abbrev:
      000235 01                    1199 	.uleb128	1
      000236 11                    1200 	.uleb128	17
      000237 01                    1201 	.db	1
      000238 03                    1202 	.uleb128	3
      000239 08                    1203 	.uleb128	8
      00023A 10                    1204 	.uleb128	16
      00023B 06                    1205 	.uleb128	6
      00023C 13                    1206 	.uleb128	19
      00023D 0B                    1207 	.uleb128	11
      00023E 25                    1208 	.uleb128	37
      00023F 08                    1209 	.uleb128	8
      000240 00                    1210 	.uleb128	0
      000241 00                    1211 	.uleb128	0
      000242 02                    1212 	.uleb128	2
      000243 2E                    1213 	.uleb128	46
      000244 00                    1214 	.db	0
      000245 03                    1215 	.uleb128	3
      000246 08                    1216 	.uleb128	8
      000247 11                    1217 	.uleb128	17
      000248 01                    1218 	.uleb128	1
      000249 12                    1219 	.uleb128	18
      00024A 01                    1220 	.uleb128	1
      00024B 36                    1221 	.uleb128	54
      00024C 0B                    1222 	.uleb128	11
      00024D 3F                    1223 	.uleb128	63
      00024E 0C                    1224 	.uleb128	12
      00024F 40                    1225 	.uleb128	64
      000250 06                    1226 	.uleb128	6
      000251 00                    1227 	.uleb128	0
      000252 00                    1228 	.uleb128	0
      000253 00                    1229 	.uleb128	0
                                   1230 
                                   1231 	.area .debug_info (NOLOAD)
      000F8E 00 00 03 B5           1232 	.dw	0,Ldebug_info_end-Ldebug_info_start
      000F92                       1233 Ldebug_info_start:
      000F92 00 02                 1234 	.dw	2
      000F94 00 00 02 35           1235 	.dw	0,(Ldebug_abbrev)
      000F98 04                    1236 	.db	4
      000F99 01                    1237 	.uleb128	1
      000F9A 2E 2F 73 72 63 2F 73  1238 	.ascii "./src/stm8s_it.c"
             74 6D 38 73 5F 69 74
             2E 63
      000FAA 00                    1239 	.db	0
      000FAB 00 00 09 49           1240 	.dw	0,(Ldebug_line_start+-4)
      000FAF 01                    1241 	.db	1
      000FB0 53 44 43 43 20 76 65  1242 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      000FC9 00                    1243 	.db	0
      000FCA 02                    1244 	.uleb128	2
      000FCB 54 52 41 50 5F 49 52  1245 	.ascii "TRAP_IRQHandler"
             51 48 61 6E 64 6C 65
             72
      000FDA 00                    1246 	.db	0
      000FDB 00 00 87 5B           1247 	.dw	0,(_TRAP_IRQHandler)
      000FDF 00 00 87 5C           1248 	.dw	0,(XG$TRAP_IRQHandler$0$0+1)
      000FE3 03                    1249 	.db	3
      000FE4 01                    1250 	.db	1
      000FE5 00 00 14 DC           1251 	.dw	0,(Ldebug_loc_start+480)
      000FE9 02                    1252 	.uleb128	2
      000FEA 54 4C 49 5F 49 52 51  1253 	.ascii "TLI_IRQHandler"
             48 61 6E 64 6C 65 72
      000FF8 00                    1254 	.db	0
      000FF9 00 00 87 5C           1255 	.dw	0,(_TLI_IRQHandler)
      000FFD 00 00 87 5D           1256 	.dw	0,(XG$TLI_IRQHandler$0$0+1)
      001001 03                    1257 	.db	3
      001002 01                    1258 	.db	1
      001003 00 00 14 C8           1259 	.dw	0,(Ldebug_loc_start+460)
      001007 02                    1260 	.uleb128	2
      001008 41 57 55 5F 49 52 51  1261 	.ascii "AWU_IRQHandler"
             48 61 6E 64 6C 65 72
      001016 00                    1262 	.db	0
      001017 00 00 87 5D           1263 	.dw	0,(_AWU_IRQHandler)
      00101B 00 00 87 5E           1264 	.dw	0,(XG$AWU_IRQHandler$0$0+1)
      00101F 03                    1265 	.db	3
      001020 01                    1266 	.db	1
      001021 00 00 14 B4           1267 	.dw	0,(Ldebug_loc_start+440)
      001025 02                    1268 	.uleb128	2
      001026 43 4C 4B 5F 49 52 51  1269 	.ascii "CLK_IRQHandler"
             48 61 6E 64 6C 65 72
      001034 00                    1270 	.db	0
      001035 00 00 87 5E           1271 	.dw	0,(_CLK_IRQHandler)
      001039 00 00 87 5F           1272 	.dw	0,(XG$CLK_IRQHandler$0$0+1)
      00103D 03                    1273 	.db	3
      00103E 01                    1274 	.db	1
      00103F 00 00 14 A0           1275 	.dw	0,(Ldebug_loc_start+420)
      001043 02                    1276 	.uleb128	2
      001044 45 58 54 49 5F 50 4F  1277 	.ascii "EXTI_PORTA_IRQHandler"
             52 54 41 5F 49 52 51
             48 61 6E 64 6C 65 72
      001059 00                    1278 	.db	0
      00105A 00 00 87 5F           1279 	.dw	0,(_EXTI_PORTA_IRQHandler)
      00105E 00 00 87 60           1280 	.dw	0,(XG$EXTI_PORTA_IRQHandler$0$0+1)
      001062 03                    1281 	.db	3
      001063 01                    1282 	.db	1
      001064 00 00 14 8C           1283 	.dw	0,(Ldebug_loc_start+400)
      001068 02                    1284 	.uleb128	2
      001069 45 58 54 49 5F 50 4F  1285 	.ascii "EXTI_PORTB_IRQHandler"
             52 54 42 5F 49 52 51
             48 61 6E 64 6C 65 72
      00107E 00                    1286 	.db	0
      00107F 00 00 87 60           1287 	.dw	0,(_EXTI_PORTB_IRQHandler)
      001083 00 00 87 61           1288 	.dw	0,(XG$EXTI_PORTB_IRQHandler$0$0+1)
      001087 03                    1289 	.db	3
      001088 01                    1290 	.db	1
      001089 00 00 14 78           1291 	.dw	0,(Ldebug_loc_start+380)
      00108D 02                    1292 	.uleb128	2
      00108E 45 58 54 49 5F 50 4F  1293 	.ascii "EXTI_PORTC_IRQHandler"
             52 54 43 5F 49 52 51
             48 61 6E 64 6C 65 72
      0010A3 00                    1294 	.db	0
      0010A4 00 00 87 61           1295 	.dw	0,(_EXTI_PORTC_IRQHandler)
      0010A8 00 00 87 62           1296 	.dw	0,(XG$EXTI_PORTC_IRQHandler$0$0+1)
      0010AC 03                    1297 	.db	3
      0010AD 01                    1298 	.db	1
      0010AE 00 00 14 64           1299 	.dw	0,(Ldebug_loc_start+360)
      0010B2 02                    1300 	.uleb128	2
      0010B3 45 58 54 49 5F 50 4F  1301 	.ascii "EXTI_PORTD_IRQHandler"
             52 54 44 5F 49 52 51
             48 61 6E 64 6C 65 72
      0010C8 00                    1302 	.db	0
      0010C9 00 00 87 62           1303 	.dw	0,(_EXTI_PORTD_IRQHandler)
      0010CD 00 00 87 63           1304 	.dw	0,(XG$EXTI_PORTD_IRQHandler$0$0+1)
      0010D1 03                    1305 	.db	3
      0010D2 01                    1306 	.db	1
      0010D3 00 00 14 50           1307 	.dw	0,(Ldebug_loc_start+340)
      0010D7 02                    1308 	.uleb128	2
      0010D8 45 58 54 49 5F 50 4F  1309 	.ascii "EXTI_PORTE_IRQHandler"
             52 54 45 5F 49 52 51
             48 61 6E 64 6C 65 72
      0010ED 00                    1310 	.db	0
      0010EE 00 00 87 63           1311 	.dw	0,(_EXTI_PORTE_IRQHandler)
      0010F2 00 00 87 64           1312 	.dw	0,(XG$EXTI_PORTE_IRQHandler$0$0+1)
      0010F6 03                    1313 	.db	3
      0010F7 01                    1314 	.db	1
      0010F8 00 00 14 3C           1315 	.dw	0,(Ldebug_loc_start+320)
      0010FC 02                    1316 	.uleb128	2
      0010FD 43 41 4E 5F 52 58 5F  1317 	.ascii "CAN_RX_IRQHandler"
             49 52 51 48 61 6E 64
             6C 65 72
      00110E 00                    1318 	.db	0
      00110F 00 00 87 64           1319 	.dw	0,(_CAN_RX_IRQHandler)
      001113 00 00 87 65           1320 	.dw	0,(XG$CAN_RX_IRQHandler$0$0+1)
      001117 03                    1321 	.db	3
      001118 01                    1322 	.db	1
      001119 00 00 14 28           1323 	.dw	0,(Ldebug_loc_start+300)
      00111D 02                    1324 	.uleb128	2
      00111E 43 41 4E 5F 54 58 5F  1325 	.ascii "CAN_TX_IRQHandler"
             49 52 51 48 61 6E 64
             6C 65 72
      00112F 00                    1326 	.db	0
      001130 00 00 87 65           1327 	.dw	0,(_CAN_TX_IRQHandler)
      001134 00 00 87 66           1328 	.dw	0,(XG$CAN_TX_IRQHandler$0$0+1)
      001138 03                    1329 	.db	3
      001139 01                    1330 	.db	1
      00113A 00 00 14 14           1331 	.dw	0,(Ldebug_loc_start+280)
      00113E 02                    1332 	.uleb128	2
      00113F 53 50 49 5F 49 52 51  1333 	.ascii "SPI_IRQHandler"
             48 61 6E 64 6C 65 72
      00114D 00                    1334 	.db	0
      00114E 00 00 87 66           1335 	.dw	0,(_SPI_IRQHandler)
      001152 00 00 87 67           1336 	.dw	0,(XG$SPI_IRQHandler$0$0+1)
      001156 03                    1337 	.db	3
      001157 01                    1338 	.db	1
      001158 00 00 14 00           1339 	.dw	0,(Ldebug_loc_start+260)
      00115C 02                    1340 	.uleb128	2
      00115D 54 49 4D 31 5F 55 50  1341 	.ascii "TIM1_UPD_OVF_TRG_BRK_IRQHandler"
             44 5F 4F 56 46 5F 54
             52 47 5F 42 52 4B 5F
             49 52 51 48 61 6E 64
             6C 65 72
      00117C 00                    1342 	.db	0
      00117D 00 00 87 67           1343 	.dw	0,(_TIM1_UPD_OVF_TRG_BRK_IRQHandler)
      001181 00 00 87 68           1344 	.dw	0,(XG$TIM1_UPD_OVF_TRG_BRK_IRQHandler$0$0+1)
      001185 03                    1345 	.db	3
      001186 01                    1346 	.db	1
      001187 00 00 13 EC           1347 	.dw	0,(Ldebug_loc_start+240)
      00118B 02                    1348 	.uleb128	2
      00118C 54 49 4D 31 5F 43 41  1349 	.ascii "TIM1_CAP_COM_IRQHandler"
             50 5F 43 4F 4D 5F 49
             52 51 48 61 6E 64 6C
             65 72
      0011A3 00                    1350 	.db	0
      0011A4 00 00 87 68           1351 	.dw	0,(_TIM1_CAP_COM_IRQHandler)
      0011A8 00 00 87 69           1352 	.dw	0,(XG$TIM1_CAP_COM_IRQHandler$0$0+1)
      0011AC 03                    1353 	.db	3
      0011AD 01                    1354 	.db	1
      0011AE 00 00 13 D8           1355 	.dw	0,(Ldebug_loc_start+220)
      0011B2 02                    1356 	.uleb128	2
      0011B3 54 49 4D 32 5F 55 50  1357 	.ascii "TIM2_UPD_OVF_BRK_IRQHandler"
             44 5F 4F 56 46 5F 42
             52 4B 5F 49 52 51 48
             61 6E 64 6C 65 72
      0011CE 00                    1358 	.db	0
      0011CF 00 00 87 69           1359 	.dw	0,(_TIM2_UPD_OVF_BRK_IRQHandler)
      0011D3 00 00 87 6A           1360 	.dw	0,(XG$TIM2_UPD_OVF_BRK_IRQHandler$0$0+1)
      0011D7 03                    1361 	.db	3
      0011D8 01                    1362 	.db	1
      0011D9 00 00 13 C4           1363 	.dw	0,(Ldebug_loc_start+200)
      0011DD 02                    1364 	.uleb128	2
      0011DE 54 49 4D 32 5F 43 41  1365 	.ascii "TIM2_CAP_COM_IRQHandler"
             50 5F 43 4F 4D 5F 49
             52 51 48 61 6E 64 6C
             65 72
      0011F5 00                    1366 	.db	0
      0011F6 00 00 87 6A           1367 	.dw	0,(_TIM2_CAP_COM_IRQHandler)
      0011FA 00 00 87 6B           1368 	.dw	0,(XG$TIM2_CAP_COM_IRQHandler$0$0+1)
      0011FE 03                    1369 	.db	3
      0011FF 01                    1370 	.db	1
      001200 00 00 13 B0           1371 	.dw	0,(Ldebug_loc_start+180)
      001204 02                    1372 	.uleb128	2
      001205 54 49 4D 33 5F 55 50  1373 	.ascii "TIM3_UPD_OVF_BRK_IRQHandler"
             44 5F 4F 56 46 5F 42
             52 4B 5F 49 52 51 48
             61 6E 64 6C 65 72
      001220 00                    1374 	.db	0
      001221 00 00 87 6B           1375 	.dw	0,(_TIM3_UPD_OVF_BRK_IRQHandler)
      001225 00 00 87 6C           1376 	.dw	0,(XG$TIM3_UPD_OVF_BRK_IRQHandler$0$0+1)
      001229 03                    1377 	.db	3
      00122A 01                    1378 	.db	1
      00122B 00 00 13 9C           1379 	.dw	0,(Ldebug_loc_start+160)
      00122F 02                    1380 	.uleb128	2
      001230 54 49 4D 33 5F 43 41  1381 	.ascii "TIM3_CAP_COM_IRQHandler"
             50 5F 43 4F 4D 5F 49
             52 51 48 61 6E 64 6C
             65 72
      001247 00                    1382 	.db	0
      001248 00 00 87 6C           1383 	.dw	0,(_TIM3_CAP_COM_IRQHandler)
      00124C 00 00 87 6D           1384 	.dw	0,(XG$TIM3_CAP_COM_IRQHandler$0$0+1)
      001250 03                    1385 	.db	3
      001251 01                    1386 	.db	1
      001252 00 00 13 88           1387 	.dw	0,(Ldebug_loc_start+140)
      001256 02                    1388 	.uleb128	2
      001257 55 41 52 54 31 5F 54  1389 	.ascii "UART1_TX_IRQHandler"
             58 5F 49 52 51 48 61
             6E 64 6C 65 72
      00126A 00                    1390 	.db	0
      00126B 00 00 87 6D           1391 	.dw	0,(_UART1_TX_IRQHandler)
      00126F 00 00 87 6E           1392 	.dw	0,(XG$UART1_TX_IRQHandler$0$0+1)
      001273 03                    1393 	.db	3
      001274 01                    1394 	.db	1
      001275 00 00 13 74           1395 	.dw	0,(Ldebug_loc_start+120)
      001279 02                    1396 	.uleb128	2
      00127A 55 41 52 54 31 5F 52  1397 	.ascii "UART1_RX_IRQHandler"
             58 5F 49 52 51 48 61
             6E 64 6C 65 72
      00128D 00                    1398 	.db	0
      00128E 00 00 87 6E           1399 	.dw	0,(_UART1_RX_IRQHandler)
      001292 00 00 87 6F           1400 	.dw	0,(XG$UART1_RX_IRQHandler$0$0+1)
      001296 03                    1401 	.db	3
      001297 01                    1402 	.db	1
      001298 00 00 13 60           1403 	.dw	0,(Ldebug_loc_start+100)
      00129C 02                    1404 	.uleb128	2
      00129D 49 32 43 5F 49 52 51  1405 	.ascii "I2C_IRQHandler"
             48 61 6E 64 6C 65 72
      0012AB 00                    1406 	.db	0
      0012AC 00 00 87 6F           1407 	.dw	0,(_I2C_IRQHandler)
      0012B0 00 00 87 70           1408 	.dw	0,(XG$I2C_IRQHandler$0$0+1)
      0012B4 03                    1409 	.db	3
      0012B5 01                    1410 	.db	1
      0012B6 00 00 13 4C           1411 	.dw	0,(Ldebug_loc_start+80)
      0012BA 02                    1412 	.uleb128	2
      0012BB 55 41 52 54 33 5F 54  1413 	.ascii "UART3_TX_IRQHandler"
             58 5F 49 52 51 48 61
             6E 64 6C 65 72
      0012CE 00                    1414 	.db	0
      0012CF 00 00 87 70           1415 	.dw	0,(_UART3_TX_IRQHandler)
      0012D3 00 00 87 71           1416 	.dw	0,(XG$UART3_TX_IRQHandler$0$0+1)
      0012D7 03                    1417 	.db	3
      0012D8 01                    1418 	.db	1
      0012D9 00 00 13 38           1419 	.dw	0,(Ldebug_loc_start+60)
      0012DD 02                    1420 	.uleb128	2
      0012DE 55 41 52 54 33 5F 52  1421 	.ascii "UART3_RX_IRQHandler"
             58 5F 49 52 51 48 61
             6E 64 6C 65 72
      0012F1 00                    1422 	.db	0
      0012F2 00 00 87 71           1423 	.dw	0,(_UART3_RX_IRQHandler)
      0012F6 00 00 87 72           1424 	.dw	0,(XG$UART3_RX_IRQHandler$0$0+1)
      0012FA 03                    1425 	.db	3
      0012FB 01                    1426 	.db	1
      0012FC 00 00 13 24           1427 	.dw	0,(Ldebug_loc_start+40)
      001300 02                    1428 	.uleb128	2
      001301 41 44 43 32 5F 49 52  1429 	.ascii "ADC2_IRQHandler"
             51 48 61 6E 64 6C 65
             72
      001310 00                    1430 	.db	0
      001311 00 00 87 72           1431 	.dw	0,(_ADC2_IRQHandler)
      001315 00 00 87 73           1432 	.dw	0,(XG$ADC2_IRQHandler$0$0+1)
      001319 03                    1433 	.db	3
      00131A 01                    1434 	.db	1
      00131B 00 00 13 10           1435 	.dw	0,(Ldebug_loc_start+20)
      00131F 02                    1436 	.uleb128	2
      001320 45 45 50 52 4F 4D 5F  1437 	.ascii "EEPROM_EEC_IRQHandler"
             45 45 43 5F 49 52 51
             48 61 6E 64 6C 65 72
      001335 00                    1438 	.db	0
      001336 00 00 87 73           1439 	.dw	0,(_EEPROM_EEC_IRQHandler)
      00133A 00 00 87 74           1440 	.dw	0,(XG$EEPROM_EEC_IRQHandler$0$0+1)
      00133E 03                    1441 	.db	3
      00133F 01                    1442 	.db	1
      001340 00 00 12 FC           1443 	.dw	0,(Ldebug_loc_start)
      001344 00                    1444 	.uleb128	0
      001345 00                    1445 	.uleb128	0
      001346 00                    1446 	.uleb128	0
      001347                       1447 Ldebug_info_end:
                                   1448 
                                   1449 	.area .debug_pubnames (NOLOAD)
      000207 00 00 02 75           1450 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      00020B                       1451 Ldebug_pubnames_start:
      00020B 00 02                 1452 	.dw	2
      00020D 00 00 0F 8E           1453 	.dw	0,(Ldebug_info_start-4)
      000211 00 00 03 B9           1454 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      000215 00 00 00 3C           1455 	.dw	0,60
      000219 54 52 41 50 5F 49 52  1456 	.ascii "TRAP_IRQHandler"
             51 48 61 6E 64 6C 65
             72
      000228 00                    1457 	.db	0
      000229 00 00 00 5B           1458 	.dw	0,91
      00022D 54 4C 49 5F 49 52 51  1459 	.ascii "TLI_IRQHandler"
             48 61 6E 64 6C 65 72
      00023B 00                    1460 	.db	0
      00023C 00 00 00 79           1461 	.dw	0,121
      000240 41 57 55 5F 49 52 51  1462 	.ascii "AWU_IRQHandler"
             48 61 6E 64 6C 65 72
      00024E 00                    1463 	.db	0
      00024F 00 00 00 97           1464 	.dw	0,151
      000253 43 4C 4B 5F 49 52 51  1465 	.ascii "CLK_IRQHandler"
             48 61 6E 64 6C 65 72
      000261 00                    1466 	.db	0
      000262 00 00 00 B5           1467 	.dw	0,181
      000266 45 58 54 49 5F 50 4F  1468 	.ascii "EXTI_PORTA_IRQHandler"
             52 54 41 5F 49 52 51
             48 61 6E 64 6C 65 72
      00027B 00                    1469 	.db	0
      00027C 00 00 00 DA           1470 	.dw	0,218
      000280 45 58 54 49 5F 50 4F  1471 	.ascii "EXTI_PORTB_IRQHandler"
             52 54 42 5F 49 52 51
             48 61 6E 64 6C 65 72
      000295 00                    1472 	.db	0
      000296 00 00 00 FF           1473 	.dw	0,255
      00029A 45 58 54 49 5F 50 4F  1474 	.ascii "EXTI_PORTC_IRQHandler"
             52 54 43 5F 49 52 51
             48 61 6E 64 6C 65 72
      0002AF 00                    1475 	.db	0
      0002B0 00 00 01 24           1476 	.dw	0,292
      0002B4 45 58 54 49 5F 50 4F  1477 	.ascii "EXTI_PORTD_IRQHandler"
             52 54 44 5F 49 52 51
             48 61 6E 64 6C 65 72
      0002C9 00                    1478 	.db	0
      0002CA 00 00 01 49           1479 	.dw	0,329
      0002CE 45 58 54 49 5F 50 4F  1480 	.ascii "EXTI_PORTE_IRQHandler"
             52 54 45 5F 49 52 51
             48 61 6E 64 6C 65 72
      0002E3 00                    1481 	.db	0
      0002E4 00 00 01 6E           1482 	.dw	0,366
      0002E8 43 41 4E 5F 52 58 5F  1483 	.ascii "CAN_RX_IRQHandler"
             49 52 51 48 61 6E 64
             6C 65 72
      0002F9 00                    1484 	.db	0
      0002FA 00 00 01 8F           1485 	.dw	0,399
      0002FE 43 41 4E 5F 54 58 5F  1486 	.ascii "CAN_TX_IRQHandler"
             49 52 51 48 61 6E 64
             6C 65 72
      00030F 00                    1487 	.db	0
      000310 00 00 01 B0           1488 	.dw	0,432
      000314 53 50 49 5F 49 52 51  1489 	.ascii "SPI_IRQHandler"
             48 61 6E 64 6C 65 72
      000322 00                    1490 	.db	0
      000323 00 00 01 CE           1491 	.dw	0,462
      000327 54 49 4D 31 5F 55 50  1492 	.ascii "TIM1_UPD_OVF_TRG_BRK_IRQHandler"
             44 5F 4F 56 46 5F 54
             52 47 5F 42 52 4B 5F
             49 52 51 48 61 6E 64
             6C 65 72
      000346 00                    1493 	.db	0
      000347 00 00 01 FD           1494 	.dw	0,509
      00034B 54 49 4D 31 5F 43 41  1495 	.ascii "TIM1_CAP_COM_IRQHandler"
             50 5F 43 4F 4D 5F 49
             52 51 48 61 6E 64 6C
             65 72
      000362 00                    1496 	.db	0
      000363 00 00 02 24           1497 	.dw	0,548
      000367 54 49 4D 32 5F 55 50  1498 	.ascii "TIM2_UPD_OVF_BRK_IRQHandler"
             44 5F 4F 56 46 5F 42
             52 4B 5F 49 52 51 48
             61 6E 64 6C 65 72
      000382 00                    1499 	.db	0
      000383 00 00 02 4F           1500 	.dw	0,591
      000387 54 49 4D 32 5F 43 41  1501 	.ascii "TIM2_CAP_COM_IRQHandler"
             50 5F 43 4F 4D 5F 49
             52 51 48 61 6E 64 6C
             65 72
      00039E 00                    1502 	.db	0
      00039F 00 00 02 76           1503 	.dw	0,630
      0003A3 54 49 4D 33 5F 55 50  1504 	.ascii "TIM3_UPD_OVF_BRK_IRQHandler"
             44 5F 4F 56 46 5F 42
             52 4B 5F 49 52 51 48
             61 6E 64 6C 65 72
      0003BE 00                    1505 	.db	0
      0003BF 00 00 02 A1           1506 	.dw	0,673
      0003C3 54 49 4D 33 5F 43 41  1507 	.ascii "TIM3_CAP_COM_IRQHandler"
             50 5F 43 4F 4D 5F 49
             52 51 48 61 6E 64 6C
             65 72
      0003DA 00                    1508 	.db	0
      0003DB 00 00 02 C8           1509 	.dw	0,712
      0003DF 55 41 52 54 31 5F 54  1510 	.ascii "UART1_TX_IRQHandler"
             58 5F 49 52 51 48 61
             6E 64 6C 65 72
      0003F2 00                    1511 	.db	0
      0003F3 00 00 02 EB           1512 	.dw	0,747
      0003F7 55 41 52 54 31 5F 52  1513 	.ascii "UART1_RX_IRQHandler"
             58 5F 49 52 51 48 61
             6E 64 6C 65 72
      00040A 00                    1514 	.db	0
      00040B 00 00 03 0E           1515 	.dw	0,782
      00040F 49 32 43 5F 49 52 51  1516 	.ascii "I2C_IRQHandler"
             48 61 6E 64 6C 65 72
      00041D 00                    1517 	.db	0
      00041E 00 00 03 2C           1518 	.dw	0,812
      000422 55 41 52 54 33 5F 54  1519 	.ascii "UART3_TX_IRQHandler"
             58 5F 49 52 51 48 61
             6E 64 6C 65 72
      000435 00                    1520 	.db	0
      000436 00 00 03 4F           1521 	.dw	0,847
      00043A 55 41 52 54 33 5F 52  1522 	.ascii "UART3_RX_IRQHandler"
             58 5F 49 52 51 48 61
             6E 64 6C 65 72
      00044D 00                    1523 	.db	0
      00044E 00 00 03 72           1524 	.dw	0,882
      000452 41 44 43 32 5F 49 52  1525 	.ascii "ADC2_IRQHandler"
             51 48 61 6E 64 6C 65
             72
      000461 00                    1526 	.db	0
      000462 00 00 03 91           1527 	.dw	0,913
      000466 45 45 50 52 4F 4D 5F  1528 	.ascii "EEPROM_EEC_IRQHandler"
             45 45 43 5F 49 52 51
             48 61 6E 64 6C 65 72
      00047B 00                    1529 	.db	0
      00047C 00 00 00 00           1530 	.dw	0,0
      000480                       1531 Ldebug_pubnames_end:
                                   1532 
                                   1533 	.area .debug_frame (NOLOAD)
      000E83 00 00                 1534 	.dw	0
      000E85 00 0E                 1535 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      000E87                       1536 Ldebug_CIE0_start:
      000E87 FF FF                 1537 	.dw	0xffff
      000E89 FF FF                 1538 	.dw	0xffff
      000E8B 01                    1539 	.db	1
      000E8C 00                    1540 	.db	0
      000E8D 01                    1541 	.uleb128	1
      000E8E 7F                    1542 	.sleb128	-1
      000E8F 09                    1543 	.db	9
      000E90 0C                    1544 	.db	12
      000E91 08                    1545 	.uleb128	8
      000E92 09                    1546 	.uleb128	9
      000E93 89                    1547 	.db	137
      000E94 01                    1548 	.uleb128	1
      000E95                       1549 Ldebug_CIE0_end:
      000E95 00 00 00 13           1550 	.dw	0,19
      000E99 00 00 0E 83           1551 	.dw	0,(Ldebug_CIE0_start-4)
      000E9D 00 00 87 73           1552 	.dw	0,(Sstm8s_it$EEPROM_EEC_IRQHandler$122)	;initial loc
      000EA1 00 00 00 01           1553 	.dw	0,Sstm8s_it$EEPROM_EEC_IRQHandler$125-Sstm8s_it$EEPROM_EEC_IRQHandler$122
      000EA5 01                    1554 	.db	1
      000EA6 00 00 87 73           1555 	.dw	0,(Sstm8s_it$EEPROM_EEC_IRQHandler$122)
      000EAA 0E                    1556 	.db	14
      000EAB 09                    1557 	.uleb128	9
                                   1558 
                                   1559 	.area .debug_frame (NOLOAD)
      000EAC 00 00                 1560 	.dw	0
      000EAE 00 0E                 1561 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      000EB0                       1562 Ldebug_CIE1_start:
      000EB0 FF FF                 1563 	.dw	0xffff
      000EB2 FF FF                 1564 	.dw	0xffff
      000EB4 01                    1565 	.db	1
      000EB5 00                    1566 	.db	0
      000EB6 01                    1567 	.uleb128	1
      000EB7 7F                    1568 	.sleb128	-1
      000EB8 09                    1569 	.db	9
      000EB9 0C                    1570 	.db	12
      000EBA 08                    1571 	.uleb128	8
      000EBB 09                    1572 	.uleb128	9
      000EBC 89                    1573 	.db	137
      000EBD 01                    1574 	.uleb128	1
      000EBE                       1575 Ldebug_CIE1_end:
      000EBE 00 00 00 13           1576 	.dw	0,19
      000EC2 00 00 0E AC           1577 	.dw	0,(Ldebug_CIE1_start-4)
      000EC6 00 00 87 72           1578 	.dw	0,(Sstm8s_it$ADC2_IRQHandler$116)	;initial loc
      000ECA 00 00 00 01           1579 	.dw	0,Sstm8s_it$ADC2_IRQHandler$120-Sstm8s_it$ADC2_IRQHandler$116
      000ECE 01                    1580 	.db	1
      000ECF 00 00 87 72           1581 	.dw	0,(Sstm8s_it$ADC2_IRQHandler$116)
      000ED3 0E                    1582 	.db	14
      000ED4 09                    1583 	.uleb128	9
                                   1584 
                                   1585 	.area .debug_frame (NOLOAD)
      000ED5 00 00                 1586 	.dw	0
      000ED7 00 0E                 1587 	.dw	Ldebug_CIE2_end-Ldebug_CIE2_start
      000ED9                       1588 Ldebug_CIE2_start:
      000ED9 FF FF                 1589 	.dw	0xffff
      000EDB FF FF                 1590 	.dw	0xffff
      000EDD 01                    1591 	.db	1
      000EDE 00                    1592 	.db	0
      000EDF 01                    1593 	.uleb128	1
      000EE0 7F                    1594 	.sleb128	-1
      000EE1 09                    1595 	.db	9
      000EE2 0C                    1596 	.db	12
      000EE3 08                    1597 	.uleb128	8
      000EE4 09                    1598 	.uleb128	9
      000EE5 89                    1599 	.db	137
      000EE6 01                    1600 	.uleb128	1
      000EE7                       1601 Ldebug_CIE2_end:
      000EE7 00 00 00 13           1602 	.dw	0,19
      000EEB 00 00 0E D5           1603 	.dw	0,(Ldebug_CIE2_start-4)
      000EEF 00 00 87 71           1604 	.dw	0,(Sstm8s_it$UART3_RX_IRQHandler$111)	;initial loc
      000EF3 00 00 00 01           1605 	.dw	0,Sstm8s_it$UART3_RX_IRQHandler$114-Sstm8s_it$UART3_RX_IRQHandler$111
      000EF7 01                    1606 	.db	1
      000EF8 00 00 87 71           1607 	.dw	0,(Sstm8s_it$UART3_RX_IRQHandler$111)
      000EFC 0E                    1608 	.db	14
      000EFD 09                    1609 	.uleb128	9
                                   1610 
                                   1611 	.area .debug_frame (NOLOAD)
      000EFE 00 00                 1612 	.dw	0
      000F00 00 0E                 1613 	.dw	Ldebug_CIE3_end-Ldebug_CIE3_start
      000F02                       1614 Ldebug_CIE3_start:
      000F02 FF FF                 1615 	.dw	0xffff
      000F04 FF FF                 1616 	.dw	0xffff
      000F06 01                    1617 	.db	1
      000F07 00                    1618 	.db	0
      000F08 01                    1619 	.uleb128	1
      000F09 7F                    1620 	.sleb128	-1
      000F0A 09                    1621 	.db	9
      000F0B 0C                    1622 	.db	12
      000F0C 08                    1623 	.uleb128	8
      000F0D 09                    1624 	.uleb128	9
      000F0E 89                    1625 	.db	137
      000F0F 01                    1626 	.uleb128	1
      000F10                       1627 Ldebug_CIE3_end:
      000F10 00 00 00 13           1628 	.dw	0,19
      000F14 00 00 0E FE           1629 	.dw	0,(Ldebug_CIE3_start-4)
      000F18 00 00 87 70           1630 	.dw	0,(Sstm8s_it$UART3_TX_IRQHandler$106)	;initial loc
      000F1C 00 00 00 01           1631 	.dw	0,Sstm8s_it$UART3_TX_IRQHandler$109-Sstm8s_it$UART3_TX_IRQHandler$106
      000F20 01                    1632 	.db	1
      000F21 00 00 87 70           1633 	.dw	0,(Sstm8s_it$UART3_TX_IRQHandler$106)
      000F25 0E                    1634 	.db	14
      000F26 09                    1635 	.uleb128	9
                                   1636 
                                   1637 	.area .debug_frame (NOLOAD)
      000F27 00 00                 1638 	.dw	0
      000F29 00 0E                 1639 	.dw	Ldebug_CIE4_end-Ldebug_CIE4_start
      000F2B                       1640 Ldebug_CIE4_start:
      000F2B FF FF                 1641 	.dw	0xffff
      000F2D FF FF                 1642 	.dw	0xffff
      000F2F 01                    1643 	.db	1
      000F30 00                    1644 	.db	0
      000F31 01                    1645 	.uleb128	1
      000F32 7F                    1646 	.sleb128	-1
      000F33 09                    1647 	.db	9
      000F34 0C                    1648 	.db	12
      000F35 08                    1649 	.uleb128	8
      000F36 09                    1650 	.uleb128	9
      000F37 89                    1651 	.db	137
      000F38 01                    1652 	.uleb128	1
      000F39                       1653 Ldebug_CIE4_end:
      000F39 00 00 00 13           1654 	.dw	0,19
      000F3D 00 00 0F 27           1655 	.dw	0,(Ldebug_CIE4_start-4)
      000F41 00 00 87 6F           1656 	.dw	0,(Sstm8s_it$I2C_IRQHandler$101)	;initial loc
      000F45 00 00 00 01           1657 	.dw	0,Sstm8s_it$I2C_IRQHandler$104-Sstm8s_it$I2C_IRQHandler$101
      000F49 01                    1658 	.db	1
      000F4A 00 00 87 6F           1659 	.dw	0,(Sstm8s_it$I2C_IRQHandler$101)
      000F4E 0E                    1660 	.db	14
      000F4F 09                    1661 	.uleb128	9
                                   1662 
                                   1663 	.area .debug_frame (NOLOAD)
      000F50 00 00                 1664 	.dw	0
      000F52 00 0E                 1665 	.dw	Ldebug_CIE5_end-Ldebug_CIE5_start
      000F54                       1666 Ldebug_CIE5_start:
      000F54 FF FF                 1667 	.dw	0xffff
      000F56 FF FF                 1668 	.dw	0xffff
      000F58 01                    1669 	.db	1
      000F59 00                    1670 	.db	0
      000F5A 01                    1671 	.uleb128	1
      000F5B 7F                    1672 	.sleb128	-1
      000F5C 09                    1673 	.db	9
      000F5D 0C                    1674 	.db	12
      000F5E 08                    1675 	.uleb128	8
      000F5F 09                    1676 	.uleb128	9
      000F60 89                    1677 	.db	137
      000F61 01                    1678 	.uleb128	1
      000F62                       1679 Ldebug_CIE5_end:
      000F62 00 00 00 13           1680 	.dw	0,19
      000F66 00 00 0F 50           1681 	.dw	0,(Ldebug_CIE5_start-4)
      000F6A 00 00 87 6E           1682 	.dw	0,(Sstm8s_it$UART1_RX_IRQHandler$96)	;initial loc
      000F6E 00 00 00 01           1683 	.dw	0,Sstm8s_it$UART1_RX_IRQHandler$99-Sstm8s_it$UART1_RX_IRQHandler$96
      000F72 01                    1684 	.db	1
      000F73 00 00 87 6E           1685 	.dw	0,(Sstm8s_it$UART1_RX_IRQHandler$96)
      000F77 0E                    1686 	.db	14
      000F78 09                    1687 	.uleb128	9
                                   1688 
                                   1689 	.area .debug_frame (NOLOAD)
      000F79 00 00                 1690 	.dw	0
      000F7B 00 0E                 1691 	.dw	Ldebug_CIE6_end-Ldebug_CIE6_start
      000F7D                       1692 Ldebug_CIE6_start:
      000F7D FF FF                 1693 	.dw	0xffff
      000F7F FF FF                 1694 	.dw	0xffff
      000F81 01                    1695 	.db	1
      000F82 00                    1696 	.db	0
      000F83 01                    1697 	.uleb128	1
      000F84 7F                    1698 	.sleb128	-1
      000F85 09                    1699 	.db	9
      000F86 0C                    1700 	.db	12
      000F87 08                    1701 	.uleb128	8
      000F88 09                    1702 	.uleb128	9
      000F89 89                    1703 	.db	137
      000F8A 01                    1704 	.uleb128	1
      000F8B                       1705 Ldebug_CIE6_end:
      000F8B 00 00 00 13           1706 	.dw	0,19
      000F8F 00 00 0F 79           1707 	.dw	0,(Ldebug_CIE6_start-4)
      000F93 00 00 87 6D           1708 	.dw	0,(Sstm8s_it$UART1_TX_IRQHandler$91)	;initial loc
      000F97 00 00 00 01           1709 	.dw	0,Sstm8s_it$UART1_TX_IRQHandler$94-Sstm8s_it$UART1_TX_IRQHandler$91
      000F9B 01                    1710 	.db	1
      000F9C 00 00 87 6D           1711 	.dw	0,(Sstm8s_it$UART1_TX_IRQHandler$91)
      000FA0 0E                    1712 	.db	14
      000FA1 09                    1713 	.uleb128	9
                                   1714 
                                   1715 	.area .debug_frame (NOLOAD)
      000FA2 00 00                 1716 	.dw	0
      000FA4 00 0E                 1717 	.dw	Ldebug_CIE7_end-Ldebug_CIE7_start
      000FA6                       1718 Ldebug_CIE7_start:
      000FA6 FF FF                 1719 	.dw	0xffff
      000FA8 FF FF                 1720 	.dw	0xffff
      000FAA 01                    1721 	.db	1
      000FAB 00                    1722 	.db	0
      000FAC 01                    1723 	.uleb128	1
      000FAD 7F                    1724 	.sleb128	-1
      000FAE 09                    1725 	.db	9
      000FAF 0C                    1726 	.db	12
      000FB0 08                    1727 	.uleb128	8
      000FB1 09                    1728 	.uleb128	9
      000FB2 89                    1729 	.db	137
      000FB3 01                    1730 	.uleb128	1
      000FB4                       1731 Ldebug_CIE7_end:
      000FB4 00 00 00 13           1732 	.dw	0,19
      000FB8 00 00 0F A2           1733 	.dw	0,(Ldebug_CIE7_start-4)
      000FBC 00 00 87 6C           1734 	.dw	0,(Sstm8s_it$TIM3_CAP_COM_IRQHandler$86)	;initial loc
      000FC0 00 00 00 01           1735 	.dw	0,Sstm8s_it$TIM3_CAP_COM_IRQHandler$89-Sstm8s_it$TIM3_CAP_COM_IRQHandler$86
      000FC4 01                    1736 	.db	1
      000FC5 00 00 87 6C           1737 	.dw	0,(Sstm8s_it$TIM3_CAP_COM_IRQHandler$86)
      000FC9 0E                    1738 	.db	14
      000FCA 09                    1739 	.uleb128	9
                                   1740 
                                   1741 	.area .debug_frame (NOLOAD)
      000FCB 00 00                 1742 	.dw	0
      000FCD 00 0E                 1743 	.dw	Ldebug_CIE8_end-Ldebug_CIE8_start
      000FCF                       1744 Ldebug_CIE8_start:
      000FCF FF FF                 1745 	.dw	0xffff
      000FD1 FF FF                 1746 	.dw	0xffff
      000FD3 01                    1747 	.db	1
      000FD4 00                    1748 	.db	0
      000FD5 01                    1749 	.uleb128	1
      000FD6 7F                    1750 	.sleb128	-1
      000FD7 09                    1751 	.db	9
      000FD8 0C                    1752 	.db	12
      000FD9 08                    1753 	.uleb128	8
      000FDA 09                    1754 	.uleb128	9
      000FDB 89                    1755 	.db	137
      000FDC 01                    1756 	.uleb128	1
      000FDD                       1757 Ldebug_CIE8_end:
      000FDD 00 00 00 13           1758 	.dw	0,19
      000FE1 00 00 0F CB           1759 	.dw	0,(Ldebug_CIE8_start-4)
      000FE5 00 00 87 6B           1760 	.dw	0,(Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$81)	;initial loc
      000FE9 00 00 00 01           1761 	.dw	0,Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$84-Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$81
      000FED 01                    1762 	.db	1
      000FEE 00 00 87 6B           1763 	.dw	0,(Sstm8s_it$TIM3_UPD_OVF_BRK_IRQHandler$81)
      000FF2 0E                    1764 	.db	14
      000FF3 09                    1765 	.uleb128	9
                                   1766 
                                   1767 	.area .debug_frame (NOLOAD)
      000FF4 00 00                 1768 	.dw	0
      000FF6 00 0E                 1769 	.dw	Ldebug_CIE9_end-Ldebug_CIE9_start
      000FF8                       1770 Ldebug_CIE9_start:
      000FF8 FF FF                 1771 	.dw	0xffff
      000FFA FF FF                 1772 	.dw	0xffff
      000FFC 01                    1773 	.db	1
      000FFD 00                    1774 	.db	0
      000FFE 01                    1775 	.uleb128	1
      000FFF 7F                    1776 	.sleb128	-1
      001000 09                    1777 	.db	9
      001001 0C                    1778 	.db	12
      001002 08                    1779 	.uleb128	8
      001003 09                    1780 	.uleb128	9
      001004 89                    1781 	.db	137
      001005 01                    1782 	.uleb128	1
      001006                       1783 Ldebug_CIE9_end:
      001006 00 00 00 13           1784 	.dw	0,19
      00100A 00 00 0F F4           1785 	.dw	0,(Ldebug_CIE9_start-4)
      00100E 00 00 87 6A           1786 	.dw	0,(Sstm8s_it$TIM2_CAP_COM_IRQHandler$76)	;initial loc
      001012 00 00 00 01           1787 	.dw	0,Sstm8s_it$TIM2_CAP_COM_IRQHandler$79-Sstm8s_it$TIM2_CAP_COM_IRQHandler$76
      001016 01                    1788 	.db	1
      001017 00 00 87 6A           1789 	.dw	0,(Sstm8s_it$TIM2_CAP_COM_IRQHandler$76)
      00101B 0E                    1790 	.db	14
      00101C 09                    1791 	.uleb128	9
                                   1792 
                                   1793 	.area .debug_frame (NOLOAD)
      00101D 00 00                 1794 	.dw	0
      00101F 00 0E                 1795 	.dw	Ldebug_CIE10_end-Ldebug_CIE10_start
      001021                       1796 Ldebug_CIE10_start:
      001021 FF FF                 1797 	.dw	0xffff
      001023 FF FF                 1798 	.dw	0xffff
      001025 01                    1799 	.db	1
      001026 00                    1800 	.db	0
      001027 01                    1801 	.uleb128	1
      001028 7F                    1802 	.sleb128	-1
      001029 09                    1803 	.db	9
      00102A 0C                    1804 	.db	12
      00102B 08                    1805 	.uleb128	8
      00102C 09                    1806 	.uleb128	9
      00102D 89                    1807 	.db	137
      00102E 01                    1808 	.uleb128	1
      00102F                       1809 Ldebug_CIE10_end:
      00102F 00 00 00 13           1810 	.dw	0,19
      001033 00 00 10 1D           1811 	.dw	0,(Ldebug_CIE10_start-4)
      001037 00 00 87 69           1812 	.dw	0,(Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$71)	;initial loc
      00103B 00 00 00 01           1813 	.dw	0,Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$74-Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$71
      00103F 01                    1814 	.db	1
      001040 00 00 87 69           1815 	.dw	0,(Sstm8s_it$TIM2_UPD_OVF_BRK_IRQHandler$71)
      001044 0E                    1816 	.db	14
      001045 09                    1817 	.uleb128	9
                                   1818 
                                   1819 	.area .debug_frame (NOLOAD)
      001046 00 00                 1820 	.dw	0
      001048 00 0E                 1821 	.dw	Ldebug_CIE11_end-Ldebug_CIE11_start
      00104A                       1822 Ldebug_CIE11_start:
      00104A FF FF                 1823 	.dw	0xffff
      00104C FF FF                 1824 	.dw	0xffff
      00104E 01                    1825 	.db	1
      00104F 00                    1826 	.db	0
      001050 01                    1827 	.uleb128	1
      001051 7F                    1828 	.sleb128	-1
      001052 09                    1829 	.db	9
      001053 0C                    1830 	.db	12
      001054 08                    1831 	.uleb128	8
      001055 09                    1832 	.uleb128	9
      001056 89                    1833 	.db	137
      001057 01                    1834 	.uleb128	1
      001058                       1835 Ldebug_CIE11_end:
      001058 00 00 00 13           1836 	.dw	0,19
      00105C 00 00 10 46           1837 	.dw	0,(Ldebug_CIE11_start-4)
      001060 00 00 87 68           1838 	.dw	0,(Sstm8s_it$TIM1_CAP_COM_IRQHandler$66)	;initial loc
      001064 00 00 00 01           1839 	.dw	0,Sstm8s_it$TIM1_CAP_COM_IRQHandler$69-Sstm8s_it$TIM1_CAP_COM_IRQHandler$66
      001068 01                    1840 	.db	1
      001069 00 00 87 68           1841 	.dw	0,(Sstm8s_it$TIM1_CAP_COM_IRQHandler$66)
      00106D 0E                    1842 	.db	14
      00106E 09                    1843 	.uleb128	9
                                   1844 
                                   1845 	.area .debug_frame (NOLOAD)
      00106F 00 00                 1846 	.dw	0
      001071 00 0E                 1847 	.dw	Ldebug_CIE12_end-Ldebug_CIE12_start
      001073                       1848 Ldebug_CIE12_start:
      001073 FF FF                 1849 	.dw	0xffff
      001075 FF FF                 1850 	.dw	0xffff
      001077 01                    1851 	.db	1
      001078 00                    1852 	.db	0
      001079 01                    1853 	.uleb128	1
      00107A 7F                    1854 	.sleb128	-1
      00107B 09                    1855 	.db	9
      00107C 0C                    1856 	.db	12
      00107D 08                    1857 	.uleb128	8
      00107E 09                    1858 	.uleb128	9
      00107F 89                    1859 	.db	137
      001080 01                    1860 	.uleb128	1
      001081                       1861 Ldebug_CIE12_end:
      001081 00 00 00 13           1862 	.dw	0,19
      001085 00 00 10 6F           1863 	.dw	0,(Ldebug_CIE12_start-4)
      001089 00 00 87 67           1864 	.dw	0,(Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$61)	;initial loc
      00108D 00 00 00 01           1865 	.dw	0,Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$64-Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$61
      001091 01                    1866 	.db	1
      001092 00 00 87 67           1867 	.dw	0,(Sstm8s_it$TIM1_UPD_OVF_TRG_BRK_IRQHandler$61)
      001096 0E                    1868 	.db	14
      001097 09                    1869 	.uleb128	9
                                   1870 
                                   1871 	.area .debug_frame (NOLOAD)
      001098 00 00                 1872 	.dw	0
      00109A 00 0E                 1873 	.dw	Ldebug_CIE13_end-Ldebug_CIE13_start
      00109C                       1874 Ldebug_CIE13_start:
      00109C FF FF                 1875 	.dw	0xffff
      00109E FF FF                 1876 	.dw	0xffff
      0010A0 01                    1877 	.db	1
      0010A1 00                    1878 	.db	0
      0010A2 01                    1879 	.uleb128	1
      0010A3 7F                    1880 	.sleb128	-1
      0010A4 09                    1881 	.db	9
      0010A5 0C                    1882 	.db	12
      0010A6 08                    1883 	.uleb128	8
      0010A7 09                    1884 	.uleb128	9
      0010A8 89                    1885 	.db	137
      0010A9 01                    1886 	.uleb128	1
      0010AA                       1887 Ldebug_CIE13_end:
      0010AA 00 00 00 13           1888 	.dw	0,19
      0010AE 00 00 10 98           1889 	.dw	0,(Ldebug_CIE13_start-4)
      0010B2 00 00 87 66           1890 	.dw	0,(Sstm8s_it$SPI_IRQHandler$56)	;initial loc
      0010B6 00 00 00 01           1891 	.dw	0,Sstm8s_it$SPI_IRQHandler$59-Sstm8s_it$SPI_IRQHandler$56
      0010BA 01                    1892 	.db	1
      0010BB 00 00 87 66           1893 	.dw	0,(Sstm8s_it$SPI_IRQHandler$56)
      0010BF 0E                    1894 	.db	14
      0010C0 09                    1895 	.uleb128	9
                                   1896 
                                   1897 	.area .debug_frame (NOLOAD)
      0010C1 00 00                 1898 	.dw	0
      0010C3 00 0E                 1899 	.dw	Ldebug_CIE14_end-Ldebug_CIE14_start
      0010C5                       1900 Ldebug_CIE14_start:
      0010C5 FF FF                 1901 	.dw	0xffff
      0010C7 FF FF                 1902 	.dw	0xffff
      0010C9 01                    1903 	.db	1
      0010CA 00                    1904 	.db	0
      0010CB 01                    1905 	.uleb128	1
      0010CC 7F                    1906 	.sleb128	-1
      0010CD 09                    1907 	.db	9
      0010CE 0C                    1908 	.db	12
      0010CF 08                    1909 	.uleb128	8
      0010D0 09                    1910 	.uleb128	9
      0010D1 89                    1911 	.db	137
      0010D2 01                    1912 	.uleb128	1
      0010D3                       1913 Ldebug_CIE14_end:
      0010D3 00 00 00 13           1914 	.dw	0,19
      0010D7 00 00 10 C1           1915 	.dw	0,(Ldebug_CIE14_start-4)
      0010DB 00 00 87 65           1916 	.dw	0,(Sstm8s_it$CAN_TX_IRQHandler$51)	;initial loc
      0010DF 00 00 00 01           1917 	.dw	0,Sstm8s_it$CAN_TX_IRQHandler$54-Sstm8s_it$CAN_TX_IRQHandler$51
      0010E3 01                    1918 	.db	1
      0010E4 00 00 87 65           1919 	.dw	0,(Sstm8s_it$CAN_TX_IRQHandler$51)
      0010E8 0E                    1920 	.db	14
      0010E9 09                    1921 	.uleb128	9
                                   1922 
                                   1923 	.area .debug_frame (NOLOAD)
      0010EA 00 00                 1924 	.dw	0
      0010EC 00 0E                 1925 	.dw	Ldebug_CIE15_end-Ldebug_CIE15_start
      0010EE                       1926 Ldebug_CIE15_start:
      0010EE FF FF                 1927 	.dw	0xffff
      0010F0 FF FF                 1928 	.dw	0xffff
      0010F2 01                    1929 	.db	1
      0010F3 00                    1930 	.db	0
      0010F4 01                    1931 	.uleb128	1
      0010F5 7F                    1932 	.sleb128	-1
      0010F6 09                    1933 	.db	9
      0010F7 0C                    1934 	.db	12
      0010F8 08                    1935 	.uleb128	8
      0010F9 09                    1936 	.uleb128	9
      0010FA 89                    1937 	.db	137
      0010FB 01                    1938 	.uleb128	1
      0010FC                       1939 Ldebug_CIE15_end:
      0010FC 00 00 00 13           1940 	.dw	0,19
      001100 00 00 10 EA           1941 	.dw	0,(Ldebug_CIE15_start-4)
      001104 00 00 87 64           1942 	.dw	0,(Sstm8s_it$CAN_RX_IRQHandler$46)	;initial loc
      001108 00 00 00 01           1943 	.dw	0,Sstm8s_it$CAN_RX_IRQHandler$49-Sstm8s_it$CAN_RX_IRQHandler$46
      00110C 01                    1944 	.db	1
      00110D 00 00 87 64           1945 	.dw	0,(Sstm8s_it$CAN_RX_IRQHandler$46)
      001111 0E                    1946 	.db	14
      001112 09                    1947 	.uleb128	9
                                   1948 
                                   1949 	.area .debug_frame (NOLOAD)
      001113 00 00                 1950 	.dw	0
      001115 00 0E                 1951 	.dw	Ldebug_CIE16_end-Ldebug_CIE16_start
      001117                       1952 Ldebug_CIE16_start:
      001117 FF FF                 1953 	.dw	0xffff
      001119 FF FF                 1954 	.dw	0xffff
      00111B 01                    1955 	.db	1
      00111C 00                    1956 	.db	0
      00111D 01                    1957 	.uleb128	1
      00111E 7F                    1958 	.sleb128	-1
      00111F 09                    1959 	.db	9
      001120 0C                    1960 	.db	12
      001121 08                    1961 	.uleb128	8
      001122 09                    1962 	.uleb128	9
      001123 89                    1963 	.db	137
      001124 01                    1964 	.uleb128	1
      001125                       1965 Ldebug_CIE16_end:
      001125 00 00 00 13           1966 	.dw	0,19
      001129 00 00 11 13           1967 	.dw	0,(Ldebug_CIE16_start-4)
      00112D 00 00 87 63           1968 	.dw	0,(Sstm8s_it$EXTI_PORTE_IRQHandler$41)	;initial loc
      001131 00 00 00 01           1969 	.dw	0,Sstm8s_it$EXTI_PORTE_IRQHandler$44-Sstm8s_it$EXTI_PORTE_IRQHandler$41
      001135 01                    1970 	.db	1
      001136 00 00 87 63           1971 	.dw	0,(Sstm8s_it$EXTI_PORTE_IRQHandler$41)
      00113A 0E                    1972 	.db	14
      00113B 09                    1973 	.uleb128	9
                                   1974 
                                   1975 	.area .debug_frame (NOLOAD)
      00113C 00 00                 1976 	.dw	0
      00113E 00 0E                 1977 	.dw	Ldebug_CIE17_end-Ldebug_CIE17_start
      001140                       1978 Ldebug_CIE17_start:
      001140 FF FF                 1979 	.dw	0xffff
      001142 FF FF                 1980 	.dw	0xffff
      001144 01                    1981 	.db	1
      001145 00                    1982 	.db	0
      001146 01                    1983 	.uleb128	1
      001147 7F                    1984 	.sleb128	-1
      001148 09                    1985 	.db	9
      001149 0C                    1986 	.db	12
      00114A 08                    1987 	.uleb128	8
      00114B 09                    1988 	.uleb128	9
      00114C 89                    1989 	.db	137
      00114D 01                    1990 	.uleb128	1
      00114E                       1991 Ldebug_CIE17_end:
      00114E 00 00 00 13           1992 	.dw	0,19
      001152 00 00 11 3C           1993 	.dw	0,(Ldebug_CIE17_start-4)
      001156 00 00 87 62           1994 	.dw	0,(Sstm8s_it$EXTI_PORTD_IRQHandler$36)	;initial loc
      00115A 00 00 00 01           1995 	.dw	0,Sstm8s_it$EXTI_PORTD_IRQHandler$39-Sstm8s_it$EXTI_PORTD_IRQHandler$36
      00115E 01                    1996 	.db	1
      00115F 00 00 87 62           1997 	.dw	0,(Sstm8s_it$EXTI_PORTD_IRQHandler$36)
      001163 0E                    1998 	.db	14
      001164 09                    1999 	.uleb128	9
                                   2000 
                                   2001 	.area .debug_frame (NOLOAD)
      001165 00 00                 2002 	.dw	0
      001167 00 0E                 2003 	.dw	Ldebug_CIE18_end-Ldebug_CIE18_start
      001169                       2004 Ldebug_CIE18_start:
      001169 FF FF                 2005 	.dw	0xffff
      00116B FF FF                 2006 	.dw	0xffff
      00116D 01                    2007 	.db	1
      00116E 00                    2008 	.db	0
      00116F 01                    2009 	.uleb128	1
      001170 7F                    2010 	.sleb128	-1
      001171 09                    2011 	.db	9
      001172 0C                    2012 	.db	12
      001173 08                    2013 	.uleb128	8
      001174 09                    2014 	.uleb128	9
      001175 89                    2015 	.db	137
      001176 01                    2016 	.uleb128	1
      001177                       2017 Ldebug_CIE18_end:
      001177 00 00 00 13           2018 	.dw	0,19
      00117B 00 00 11 65           2019 	.dw	0,(Ldebug_CIE18_start-4)
      00117F 00 00 87 61           2020 	.dw	0,(Sstm8s_it$EXTI_PORTC_IRQHandler$31)	;initial loc
      001183 00 00 00 01           2021 	.dw	0,Sstm8s_it$EXTI_PORTC_IRQHandler$34-Sstm8s_it$EXTI_PORTC_IRQHandler$31
      001187 01                    2022 	.db	1
      001188 00 00 87 61           2023 	.dw	0,(Sstm8s_it$EXTI_PORTC_IRQHandler$31)
      00118C 0E                    2024 	.db	14
      00118D 09                    2025 	.uleb128	9
                                   2026 
                                   2027 	.area .debug_frame (NOLOAD)
      00118E 00 00                 2028 	.dw	0
      001190 00 0E                 2029 	.dw	Ldebug_CIE19_end-Ldebug_CIE19_start
      001192                       2030 Ldebug_CIE19_start:
      001192 FF FF                 2031 	.dw	0xffff
      001194 FF FF                 2032 	.dw	0xffff
      001196 01                    2033 	.db	1
      001197 00                    2034 	.db	0
      001198 01                    2035 	.uleb128	1
      001199 7F                    2036 	.sleb128	-1
      00119A 09                    2037 	.db	9
      00119B 0C                    2038 	.db	12
      00119C 08                    2039 	.uleb128	8
      00119D 09                    2040 	.uleb128	9
      00119E 89                    2041 	.db	137
      00119F 01                    2042 	.uleb128	1
      0011A0                       2043 Ldebug_CIE19_end:
      0011A0 00 00 00 13           2044 	.dw	0,19
      0011A4 00 00 11 8E           2045 	.dw	0,(Ldebug_CIE19_start-4)
      0011A8 00 00 87 60           2046 	.dw	0,(Sstm8s_it$EXTI_PORTB_IRQHandler$26)	;initial loc
      0011AC 00 00 00 01           2047 	.dw	0,Sstm8s_it$EXTI_PORTB_IRQHandler$29-Sstm8s_it$EXTI_PORTB_IRQHandler$26
      0011B0 01                    2048 	.db	1
      0011B1 00 00 87 60           2049 	.dw	0,(Sstm8s_it$EXTI_PORTB_IRQHandler$26)
      0011B5 0E                    2050 	.db	14
      0011B6 09                    2051 	.uleb128	9
                                   2052 
                                   2053 	.area .debug_frame (NOLOAD)
      0011B7 00 00                 2054 	.dw	0
      0011B9 00 0E                 2055 	.dw	Ldebug_CIE20_end-Ldebug_CIE20_start
      0011BB                       2056 Ldebug_CIE20_start:
      0011BB FF FF                 2057 	.dw	0xffff
      0011BD FF FF                 2058 	.dw	0xffff
      0011BF 01                    2059 	.db	1
      0011C0 00                    2060 	.db	0
      0011C1 01                    2061 	.uleb128	1
      0011C2 7F                    2062 	.sleb128	-1
      0011C3 09                    2063 	.db	9
      0011C4 0C                    2064 	.db	12
      0011C5 08                    2065 	.uleb128	8
      0011C6 09                    2066 	.uleb128	9
      0011C7 89                    2067 	.db	137
      0011C8 01                    2068 	.uleb128	1
      0011C9                       2069 Ldebug_CIE20_end:
      0011C9 00 00 00 13           2070 	.dw	0,19
      0011CD 00 00 11 B7           2071 	.dw	0,(Ldebug_CIE20_start-4)
      0011D1 00 00 87 5F           2072 	.dw	0,(Sstm8s_it$EXTI_PORTA_IRQHandler$21)	;initial loc
      0011D5 00 00 00 01           2073 	.dw	0,Sstm8s_it$EXTI_PORTA_IRQHandler$24-Sstm8s_it$EXTI_PORTA_IRQHandler$21
      0011D9 01                    2074 	.db	1
      0011DA 00 00 87 5F           2075 	.dw	0,(Sstm8s_it$EXTI_PORTA_IRQHandler$21)
      0011DE 0E                    2076 	.db	14
      0011DF 09                    2077 	.uleb128	9
                                   2078 
                                   2079 	.area .debug_frame (NOLOAD)
      0011E0 00 00                 2080 	.dw	0
      0011E2 00 0E                 2081 	.dw	Ldebug_CIE21_end-Ldebug_CIE21_start
      0011E4                       2082 Ldebug_CIE21_start:
      0011E4 FF FF                 2083 	.dw	0xffff
      0011E6 FF FF                 2084 	.dw	0xffff
      0011E8 01                    2085 	.db	1
      0011E9 00                    2086 	.db	0
      0011EA 01                    2087 	.uleb128	1
      0011EB 7F                    2088 	.sleb128	-1
      0011EC 09                    2089 	.db	9
      0011ED 0C                    2090 	.db	12
      0011EE 08                    2091 	.uleb128	8
      0011EF 09                    2092 	.uleb128	9
      0011F0 89                    2093 	.db	137
      0011F1 01                    2094 	.uleb128	1
      0011F2                       2095 Ldebug_CIE21_end:
      0011F2 00 00 00 13           2096 	.dw	0,19
      0011F6 00 00 11 E0           2097 	.dw	0,(Ldebug_CIE21_start-4)
      0011FA 00 00 87 5E           2098 	.dw	0,(Sstm8s_it$CLK_IRQHandler$16)	;initial loc
      0011FE 00 00 00 01           2099 	.dw	0,Sstm8s_it$CLK_IRQHandler$19-Sstm8s_it$CLK_IRQHandler$16
      001202 01                    2100 	.db	1
      001203 00 00 87 5E           2101 	.dw	0,(Sstm8s_it$CLK_IRQHandler$16)
      001207 0E                    2102 	.db	14
      001208 09                    2103 	.uleb128	9
                                   2104 
                                   2105 	.area .debug_frame (NOLOAD)
      001209 00 00                 2106 	.dw	0
      00120B 00 0E                 2107 	.dw	Ldebug_CIE22_end-Ldebug_CIE22_start
      00120D                       2108 Ldebug_CIE22_start:
      00120D FF FF                 2109 	.dw	0xffff
      00120F FF FF                 2110 	.dw	0xffff
      001211 01                    2111 	.db	1
      001212 00                    2112 	.db	0
      001213 01                    2113 	.uleb128	1
      001214 7F                    2114 	.sleb128	-1
      001215 09                    2115 	.db	9
      001216 0C                    2116 	.db	12
      001217 08                    2117 	.uleb128	8
      001218 09                    2118 	.uleb128	9
      001219 89                    2119 	.db	137
      00121A 01                    2120 	.uleb128	1
      00121B                       2121 Ldebug_CIE22_end:
      00121B 00 00 00 13           2122 	.dw	0,19
      00121F 00 00 12 09           2123 	.dw	0,(Ldebug_CIE22_start-4)
      001223 00 00 87 5D           2124 	.dw	0,(Sstm8s_it$AWU_IRQHandler$11)	;initial loc
      001227 00 00 00 01           2125 	.dw	0,Sstm8s_it$AWU_IRQHandler$14-Sstm8s_it$AWU_IRQHandler$11
      00122B 01                    2126 	.db	1
      00122C 00 00 87 5D           2127 	.dw	0,(Sstm8s_it$AWU_IRQHandler$11)
      001230 0E                    2128 	.db	14
      001231 09                    2129 	.uleb128	9
                                   2130 
                                   2131 	.area .debug_frame (NOLOAD)
      001232 00 00                 2132 	.dw	0
      001234 00 0E                 2133 	.dw	Ldebug_CIE23_end-Ldebug_CIE23_start
      001236                       2134 Ldebug_CIE23_start:
      001236 FF FF                 2135 	.dw	0xffff
      001238 FF FF                 2136 	.dw	0xffff
      00123A 01                    2137 	.db	1
      00123B 00                    2138 	.db	0
      00123C 01                    2139 	.uleb128	1
      00123D 7F                    2140 	.sleb128	-1
      00123E 09                    2141 	.db	9
      00123F 0C                    2142 	.db	12
      001240 08                    2143 	.uleb128	8
      001241 09                    2144 	.uleb128	9
      001242 89                    2145 	.db	137
      001243 01                    2146 	.uleb128	1
      001244                       2147 Ldebug_CIE23_end:
      001244 00 00 00 13           2148 	.dw	0,19
      001248 00 00 12 32           2149 	.dw	0,(Ldebug_CIE23_start-4)
      00124C 00 00 87 5C           2150 	.dw	0,(Sstm8s_it$TLI_IRQHandler$6)	;initial loc
      001250 00 00 00 01           2151 	.dw	0,Sstm8s_it$TLI_IRQHandler$9-Sstm8s_it$TLI_IRQHandler$6
      001254 01                    2152 	.db	1
      001255 00 00 87 5C           2153 	.dw	0,(Sstm8s_it$TLI_IRQHandler$6)
      001259 0E                    2154 	.db	14
      00125A 09                    2155 	.uleb128	9
                                   2156 
                                   2157 	.area .debug_frame (NOLOAD)
      00125B 00 00                 2158 	.dw	0
      00125D 00 0E                 2159 	.dw	Ldebug_CIE24_end-Ldebug_CIE24_start
      00125F                       2160 Ldebug_CIE24_start:
      00125F FF FF                 2161 	.dw	0xffff
      001261 FF FF                 2162 	.dw	0xffff
      001263 01                    2163 	.db	1
      001264 00                    2164 	.db	0
      001265 01                    2165 	.uleb128	1
      001266 7F                    2166 	.sleb128	-1
      001267 09                    2167 	.db	9
      001268 0C                    2168 	.db	12
      001269 08                    2169 	.uleb128	8
      00126A 09                    2170 	.uleb128	9
      00126B 89                    2171 	.db	137
      00126C 01                    2172 	.uleb128	1
      00126D                       2173 Ldebug_CIE24_end:
      00126D 00 00 00 13           2174 	.dw	0,19
      001271 00 00 12 5B           2175 	.dw	0,(Ldebug_CIE24_start-4)
      001275 00 00 87 5B           2176 	.dw	0,(Sstm8s_it$TRAP_IRQHandler$1)	;initial loc
      001279 00 00 00 01           2177 	.dw	0,Sstm8s_it$TRAP_IRQHandler$4-Sstm8s_it$TRAP_IRQHandler$1
      00127D 01                    2178 	.db	1
      00127E 00 00 87 5B           2179 	.dw	0,(Sstm8s_it$TRAP_IRQHandler$1)
      001282 0E                    2180 	.db	14
      001283 09                    2181 	.uleb128	9
