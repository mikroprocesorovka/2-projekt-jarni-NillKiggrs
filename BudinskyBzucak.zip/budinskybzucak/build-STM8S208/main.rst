                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module main
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _main
                                     12 	.globl _setup
                                     13 	.globl _init_uart1
                                     14 	.globl _puts
                                     15 	.globl _init_milis
                                     16 	.globl _TIM2_SetCompare1
                                     17 	.globl _TIM2_OC1PreloadConfig
                                     18 	.globl _TIM2_Cmd
                                     19 	.globl _TIM2_OC1Init
                                     20 	.globl _TIM2_TimeBaseInit
                                     21 	.globl _GPIO_ReadInputPin
                                     22 	.globl _GPIO_Init
                                     23 	.globl _CLK_HSIPrescalerConfig
                                     24 ;--------------------------------------------------------
                                     25 ; ram data
                                     26 ;--------------------------------------------------------
                                     27 	.area DATA
                                     28 ;--------------------------------------------------------
                                     29 ; ram data
                                     30 ;--------------------------------------------------------
                                     31 	.area INITIALIZED
                                     32 ;--------------------------------------------------------
                                     33 ; Stack segment in internal ram 
                                     34 ;--------------------------------------------------------
                                     35 	.area	SSEG
      000005                         36 __start__stack:
      000005                         37 	.ds	1
                                     38 
                                     39 ;--------------------------------------------------------
                                     40 ; absolute external ram data
                                     41 ;--------------------------------------------------------
                                     42 	.area DABS (ABS)
                                     43 
                                     44 ; default segment ordering for linker
                                     45 	.area HOME
                                     46 	.area GSINIT
                                     47 	.area GSFINAL
                                     48 	.area CONST
                                     49 	.area INITIALIZER
                                     50 	.area CODE
                                     51 
                                     52 ;--------------------------------------------------------
                                     53 ; interrupt vector 
                                     54 ;--------------------------------------------------------
                                     55 	.area HOME
      008000                         56 __interrupt_vect:
      008000 82 00 80 6F             57 	int s_GSINIT ; reset
      008004 82 00 87 5B             58 	int _TRAP_IRQHandler ; trap
      008008 82 00 87 5C             59 	int _TLI_IRQHandler ; int0
      00800C 82 00 87 5D             60 	int _AWU_IRQHandler ; int1
      008010 82 00 87 5E             61 	int _CLK_IRQHandler ; int2
      008014 82 00 87 5F             62 	int _EXTI_PORTA_IRQHandler ; int3
      008018 82 00 87 60             63 	int _EXTI_PORTB_IRQHandler ; int4
      00801C 82 00 87 61             64 	int _EXTI_PORTC_IRQHandler ; int5
      008020 82 00 87 62             65 	int _EXTI_PORTD_IRQHandler ; int6
      008024 82 00 87 63             66 	int _EXTI_PORTE_IRQHandler ; int7
      008028 82 00 87 64             67 	int _CAN_RX_IRQHandler ; int8
      00802C 82 00 87 65             68 	int _CAN_TX_IRQHandler ; int9
      008030 82 00 87 66             69 	int _SPI_IRQHandler ; int10
      008034 82 00 87 67             70 	int _TIM1_UPD_OVF_TRG_BRK_IRQHandler ; int11
      008038 82 00 87 68             71 	int _TIM1_CAP_COM_IRQHandler ; int12
      00803C 82 00 87 69             72 	int _TIM2_UPD_OVF_BRK_IRQHandler ; int13
      008040 82 00 87 6A             73 	int _TIM2_CAP_COM_IRQHandler ; int14
      008044 82 00 87 6B             74 	int _TIM3_UPD_OVF_BRK_IRQHandler ; int15
      008048 82 00 87 6C             75 	int _TIM3_CAP_COM_IRQHandler ; int16
      00804C 82 00 87 6D             76 	int _UART1_TX_IRQHandler ; int17
      008050 82 00 87 6E             77 	int _UART1_RX_IRQHandler ; int18
      008054 82 00 87 6F             78 	int _I2C_IRQHandler ; int19
      008058 82 00 87 70             79 	int _UART3_TX_IRQHandler ; int20
      00805C 82 00 87 71             80 	int _UART3_RX_IRQHandler ; int21
      008060 82 00 87 72             81 	int _ADC2_IRQHandler ; int22
      008064 82 00 81 B9             82 	int _TIM4_UPD_OVF_IRQHandler ; int23
      008068 82 00 87 73             83 	int _EEPROM_EEC_IRQHandler ; int24
                                     84 ;--------------------------------------------------------
                                     85 ; global & static initialisations
                                     86 ;--------------------------------------------------------
                                     87 	.area HOME
                                     88 	.area GSINIT
                                     89 	.area GSFINAL
                                     90 	.area GSINIT
      00806F                         91 __sdcc_init_data:
                                     92 ; stm8_genXINIT() start
      00806F AE 00 00         [ 2]   93 	ldw x, #l_DATA
      008072 27 07            [ 1]   94 	jreq	00002$
      008074                         95 00001$:
      008074 72 4F 00 00      [ 1]   96 	clr (s_DATA - 1, x)
      008078 5A               [ 2]   97 	decw x
      008079 26 F9            [ 1]   98 	jrne	00001$
      00807B                         99 00002$:
      00807B AE 00 04         [ 2]  100 	ldw	x, #l_INITIALIZER
      00807E 27 09            [ 1]  101 	jreq	00004$
      008080                        102 00003$:
      008080 D6 80 BF         [ 1]  103 	ld	a, (s_INITIALIZER - 1, x)
      008083 D7 00 00         [ 1]  104 	ld	(s_INITIALIZED - 1, x), a
      008086 5A               [ 2]  105 	decw	x
      008087 26 F7            [ 1]  106 	jrne	00003$
      008089                        107 00004$:
                                    108 ; stm8_genXINIT() end
                                    109 	.area GSFINAL
      008089 CC 80 6C         [ 2]  110 	jp	__sdcc_program_startup
                                    111 ;--------------------------------------------------------
                                    112 ; Home
                                    113 ;--------------------------------------------------------
                                    114 	.area HOME
                                    115 	.area HOME
      00806C                        116 __sdcc_program_startup:
      00806C CC 81 04         [ 2]  117 	jp	_main
                                    118 ;	return from main will return to caller
                                    119 ;--------------------------------------------------------
                                    120 ; code
                                    121 ;--------------------------------------------------------
                                    122 	.area CODE
                           000000   123 	Smain$setup$0 ==.
                                    124 ;	./src/main.c: 16: void setup(void)
                                    125 ; genLabel
                                    126 ;	-----------------------------------------
                                    127 ;	 function setup
                                    128 ;	-----------------------------------------
                                    129 ;	Register assignment is optimal.
                                    130 ;	Stack space usage: 0 bytes.
      0080C4                        131 _setup:
                           000000   132 	Smain$setup$1 ==.
                           000000   133 	Smain$setup$2 ==.
                                    134 ;	./src/main.c: 18: CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);      // taktovani MCU na 16MHz
                                    135 ; genIPush
      0080C4 4B 00            [ 1]  136 	push	#0x00
                           000002   137 	Smain$setup$3 ==.
                                    138 ; genCall
      0080C6 CD 92 91         [ 4]  139 	call	_CLK_HSIPrescalerConfig
      0080C9 84               [ 1]  140 	pop	a
                           000006   141 	Smain$setup$4 ==.
                           000006   142 	Smain$setup$5 ==.
                                    143 ;	./src/main.c: 19: GPIO_Init(BTN_PORT, BTN_PIN, GPIO_MODE_IN_FL_NO_IT);
                                    144 ; genIPush
      0080CA 4B 00            [ 1]  145 	push	#0x00
                           000008   146 	Smain$setup$6 ==.
                                    147 ; genIPush
      0080CC 4B 10            [ 1]  148 	push	#0x10
                           00000A   149 	Smain$setup$7 ==.
                                    150 ; genIPush
      0080CE 4B 14            [ 1]  151 	push	#0x14
                           00000C   152 	Smain$setup$8 ==.
      0080D0 4B 50            [ 1]  153 	push	#0x50
                           00000E   154 	Smain$setup$9 ==.
                                    155 ; genCall
      0080D2 CD 8F 7C         [ 4]  156 	call	_GPIO_Init
      0080D5 5B 04            [ 2]  157 	addw	sp, #4
                           000013   158 	Smain$setup$10 ==.
                           000013   159 	Smain$setup$11 ==.
                                    160 ;	./src/main.c: 21: init_milis();
                                    161 ; genCall
      0080D7 CD 81 93         [ 4]  162 	call	_init_milis
                           000016   163 	Smain$setup$12 ==.
                                    164 ;	./src/main.c: 22: init_uart1();
                                    165 ; genCall
      0080DA CD 8F 1C         [ 4]  166 	call	_init_uart1
                           000019   167 	Smain$setup$13 ==.
                                    168 ;	./src/main.c: 24: TIM2_TimeBaseInit(TIM2_PRESCALER_4, 7000 - 1 ); 
                                    169 ; genIPush
      0080DD 4B 57            [ 1]  170 	push	#0x57
                           00001B   171 	Smain$setup$14 ==.
      0080DF 4B 1B            [ 1]  172 	push	#0x1b
                           00001D   173 	Smain$setup$15 ==.
                                    174 ; genIPush
      0080E1 4B 02            [ 1]  175 	push	#0x02
                           00001F   176 	Smain$setup$16 ==.
                                    177 ; genCall
      0080E3 CD 9E D1         [ 4]  178 	call	_TIM2_TimeBaseInit
      0080E6 5B 03            [ 2]  179 	addw	sp, #3
                           000024   180 	Smain$setup$17 ==.
                           000024   181 	Smain$setup$18 ==.
                                    182 ;	./src/main.c: 25: TIM2_OC1Init(TIM2_OCMODE_PWM1,TIM2_OUTPUTSTATE_ENABLE,3000,TIM2_OCPOLARITY_HIGH);// inicializujeme kanál 1 (TM2_CH1)
                                    183 ; genIPush
      0080E8 4B 00            [ 1]  184 	push	#0x00
                           000026   185 	Smain$setup$19 ==.
                                    186 ; genIPush
      0080EA 4B B8            [ 1]  187 	push	#0xb8
                           000028   188 	Smain$setup$20 ==.
      0080EC 4B 0B            [ 1]  189 	push	#0x0b
                           00002A   190 	Smain$setup$21 ==.
                                    191 ; genIPush
      0080EE 4B 11            [ 1]  192 	push	#0x11
                           00002C   193 	Smain$setup$22 ==.
                                    194 ; genIPush
      0080F0 4B 60            [ 1]  195 	push	#0x60
                           00002E   196 	Smain$setup$23 ==.
                                    197 ; genCall
      0080F2 CD 9E E3         [ 4]  198 	call	_TIM2_OC1Init
      0080F5 5B 05            [ 2]  199 	addw	sp, #5
                           000033   200 	Smain$setup$24 ==.
                           000033   201 	Smain$setup$25 ==.
                                    202 ;	./src/main.c: 26: TIM2_OC1PreloadConfig(ENABLE);
                                    203 ; genIPush
      0080F7 4B 01            [ 1]  204 	push	#0x01
                           000035   205 	Smain$setup$26 ==.
                                    206 ; genCall
      0080F9 CD A1 2D         [ 4]  207 	call	_TIM2_OC1PreloadConfig
      0080FC 84               [ 1]  208 	pop	a
                           000039   209 	Smain$setup$27 ==.
                           000039   210 	Smain$setup$28 ==.
                                    211 ;	./src/main.c: 27: TIM2_Cmd(ENABLE);
                                    212 ; genIPush
      0080FD 4B 01            [ 1]  213 	push	#0x01
                           00003B   214 	Smain$setup$29 ==.
                                    215 ; genCall
      0080FF CD A0 66         [ 4]  216 	call	_TIM2_Cmd
      008102 84               [ 1]  217 	pop	a
                           00003F   218 	Smain$setup$30 ==.
                                    219 ; genLabel
      008103                        220 00101$:
                           00003F   221 	Smain$setup$31 ==.
                                    222 ;	./src/main.c: 29: }
                                    223 ; genEndFunction
                           00003F   224 	Smain$setup$32 ==.
                           00003F   225 	XG$setup$0$0 ==.
      008103 81               [ 4]  226 	ret
                           000040   227 	Smain$setup$33 ==.
                           000040   228 	Smain$main$34 ==.
                                    229 ;	./src/main.c: 31: int main(void)
                                    230 ; genLabel
                                    231 ;	-----------------------------------------
                                    232 ;	 function main
                                    233 ;	-----------------------------------------
                                    234 ;	Register assignment might be sub-optimal.
                                    235 ;	Stack space usage: 3 bytes.
      008104                        236 _main:
                           000040   237 	Smain$main$35 ==.
      008104 52 03            [ 2]  238 	sub	sp, #3
                           000042   239 	Smain$main$36 ==.
                           000042   240 	Smain$main$37 ==.
                                    241 ;	./src/main.c: 35: uint8_t minuly_stav = 0;
                                    242 ; genAssign
      008106 0F 01            [ 1]  243 	clr	(0x01, sp)
                           000044   244 	Smain$main$38 ==.
                                    245 ;	./src/main.c: 36: uint8_t stav_bzucaku = 0;
                                    246 ; genAssign
      008108 0F 02            [ 1]  247 	clr	(0x02, sp)
                           000046   248 	Smain$main$39 ==.
                                    249 ;	./src/main.c: 39: setup();
                                    250 ; genCall
      00810A CD 80 C4         [ 4]  251 	call	_setup
                           000049   252 	Smain$main$40 ==.
                                    253 ;	./src/main.c: 41: while (1) {
                                    254 ; genLabel
      00810D                        255 00111$:
                           000049   256 	Smain$main$41 ==.
                           000049   257 	Smain$main$42 ==.
                                    258 ;	./src/main.c: 45: if (BTN_PUSH){
                                    259 ; genIPush
      00810D 4B 10            [ 1]  260 	push	#0x10
                           00004B   261 	Smain$main$43 ==.
                                    262 ; genIPush
      00810F 4B 14            [ 1]  263 	push	#0x14
                           00004D   264 	Smain$main$44 ==.
      008111 4B 50            [ 1]  265 	push	#0x50
                           00004F   266 	Smain$main$45 ==.
                                    267 ; genCall
      008113 CD 90 2E         [ 4]  268 	call	_GPIO_ReadInputPin
      008116 5B 03            [ 2]  269 	addw	sp, #3
                           000054   270 	Smain$main$46 ==.
                                    271 ; genIfx
      008118 4D               [ 1]  272 	tnz	a
      008119 27 03            [ 1]  273 	jreq	00140$
      00811B CC 81 25         [ 2]  274 	jp	00102$
      00811E                        275 00140$:
                           00005A   276 	Smain$main$47 ==.
                           00005A   277 	Smain$main$48 ==.
                                    278 ;	./src/main.c: 46: aktual_stav = 1;
                                    279 ; genAssign
      00811E A6 01            [ 1]  280 	ld	a, #0x01
      008120 6B 03            [ 1]  281 	ld	(0x03, sp), a
                           00005E   282 	Smain$main$49 ==.
                                    283 ; genGoto
      008122 CC 81 27         [ 2]  284 	jp	00103$
                                    285 ; genLabel
      008125                        286 00102$:
                           000061   287 	Smain$main$50 ==.
                           000061   288 	Smain$main$51 ==.
                                    289 ;	./src/main.c: 49: aktual_stav = 0;
                                    290 ; genAssign
      008125 0F 03            [ 1]  291 	clr	(0x03, sp)
                           000063   292 	Smain$main$52 ==.
                                    293 ; genLabel
      008127                        294 00103$:
                           000063   295 	Smain$main$53 ==.
                                    296 ;	./src/main.c: 52: if (aktual_stav == 1 && minuly_stav == 0){
                                    297 ; genCmpEQorNE
      008127 7B 03            [ 1]  298 	ld	a, (0x03, sp)
      008129 4A               [ 1]  299 	dec	a
      00812A 26 03            [ 1]  300 	jrne	00142$
      00812C CC 81 32         [ 2]  301 	jp	00143$
      00812F                        302 00142$:
      00812F CC 81 67         [ 2]  303 	jp	00108$
      008132                        304 00143$:
                           00006E   305 	Smain$main$54 ==.
                                    306 ; skipping generated iCode
                                    307 ; genIfx
      008132 0D 01            [ 1]  308 	tnz	(0x01, sp)
      008134 27 03            [ 1]  309 	jreq	00144$
      008136 CC 81 67         [ 2]  310 	jp	00108$
      008139                        311 00144$:
                           000075   312 	Smain$main$55 ==.
                           000075   313 	Smain$main$56 ==.
                                    314 ;	./src/main.c: 53: if (stav_bzucaku == 0){
                                    315 ; genIfx
      008139 0D 02            [ 1]  316 	tnz	(0x02, sp)
      00813B 27 03            [ 1]  317 	jreq	00145$
      00813D CC 81 57         [ 2]  318 	jp	00105$
      008140                        319 00145$:
                           00007C   320 	Smain$main$57 ==.
                           00007C   321 	Smain$main$58 ==.
                                    322 ;	./src/main.c: 54: TIM2_SetCompare1(4000);
                                    323 ; genIPush
      008140 4B A0            [ 1]  324 	push	#0xa0
                           00007E   325 	Smain$main$59 ==.
      008142 4B 0F            [ 1]  326 	push	#0x0f
                           000080   327 	Smain$main$60 ==.
                                    328 ; genCall
      008144 CD A2 89         [ 4]  329 	call	_TIM2_SetCompare1
      008147 85               [ 2]  330 	popw	x
                           000084   331 	Smain$main$61 ==.
                           000084   332 	Smain$main$62 ==.
                                    333 ;	./src/main.c: 55: stav_bzucaku = 1;
                                    334 ; genAssign
      008148 A6 01            [ 1]  335 	ld	a, #0x01
      00814A 6B 02            [ 1]  336 	ld	(0x02, sp), a
                           000088   337 	Smain$main$63 ==.
                                    338 ;	./src/main.c: 56: printf("Bzučák je zaplý\r\n");
                                    339 ; skipping iCode since result will be rematerialized
                                    340 ; skipping iCode since result will be rematerialized
                                    341 ; genIPush
      00814C 4B 8C            [ 1]  342 	push	#<(___str_1+0)
                           00008A   343 	Smain$main$64 ==.
      00814E 4B 80            [ 1]  344 	push	#((___str_1+0) >> 8)
                           00008C   345 	Smain$main$65 ==.
                                    346 ; genCall
      008150 CD A4 A6         [ 4]  347 	call	_puts
      008153 85               [ 2]  348 	popw	x
                           000090   349 	Smain$main$66 ==.
                           000090   350 	Smain$main$67 ==.
                                    351 ; genGoto
      008154 CC 81 67         [ 2]  352 	jp	00108$
                                    353 ; genLabel
      008157                        354 00105$:
                           000093   355 	Smain$main$68 ==.
                           000093   356 	Smain$main$69 ==.
                                    357 ;	./src/main.c: 59: TIM2_SetCompare1(0);
                                    358 ; genIPush
      008157 5F               [ 1]  359 	clrw	x
      008158 89               [ 2]  360 	pushw	x
                           000095   361 	Smain$main$70 ==.
                                    362 ; genCall
      008159 CD A2 89         [ 4]  363 	call	_TIM2_SetCompare1
      00815C 85               [ 2]  364 	popw	x
                           000099   365 	Smain$main$71 ==.
                           000099   366 	Smain$main$72 ==.
                                    367 ;	./src/main.c: 60: stav_bzucaku = 0;
                                    368 ; genAssign
      00815D 0F 02            [ 1]  369 	clr	(0x02, sp)
                           00009B   370 	Smain$main$73 ==.
                                    371 ;	./src/main.c: 61: printf("Bzučák je vyplý\r\n");
                                    372 ; skipping iCode since result will be rematerialized
                                    373 ; skipping iCode since result will be rematerialized
                                    374 ; genIPush
      00815F 4B A0            [ 1]  375 	push	#<(___str_3+0)
                           00009D   376 	Smain$main$74 ==.
      008161 4B 80            [ 1]  377 	push	#((___str_3+0) >> 8)
                           00009F   378 	Smain$main$75 ==.
                                    379 ; genCall
      008163 CD A4 A6         [ 4]  380 	call	_puts
      008166 85               [ 2]  381 	popw	x
                           0000A3   382 	Smain$main$76 ==.
                           0000A3   383 	Smain$main$77 ==.
                                    384 ; genLabel
      008167                        385 00108$:
                           0000A3   386 	Smain$main$78 ==.
                                    387 ;	./src/main.c: 65: minuly_stav = aktual_stav;
                                    388 ; genAssign
      008167 7B 03            [ 1]  389 	ld	a, (0x03, sp)
      008169 6B 01            [ 1]  390 	ld	(0x01, sp), a
                           0000A7   391 	Smain$main$79 ==.
                                    392 ; genGoto
      00816B CC 81 0D         [ 2]  393 	jp	00111$
                                    394 ; genLabel
      00816E                        395 00113$:
                           0000AA   396 	Smain$main$80 ==.
                                    397 ;	./src/main.c: 70: }
                                    398 ; genEndFunction
      00816E 5B 03            [ 2]  399 	addw	sp, #3
                           0000AC   400 	Smain$main$81 ==.
                           0000AC   401 	Smain$main$82 ==.
                           0000AC   402 	XG$main$0$0 ==.
      008170 81               [ 4]  403 	ret
                           0000AD   404 	Smain$main$83 ==.
                                    405 	.area CODE
                                    406 	.area CONST
                           000000   407 Fmain$__str_1$0_0$0 == .
                                    408 	.area CONST
      00808C                        409 ___str_1:
      00808C 42 7A 75               410 	.ascii "Bzu"
      00808F C4                     411 	.db 0xc4
      008090 8D                     412 	.db 0x8d
      008091 C3                     413 	.db 0xc3
      008092 A1                     414 	.db 0xa1
      008093 6B 20 6A 65 20 7A 61   415 	.ascii "k je zapl"
             70 6C
      00809C C3                     416 	.db 0xc3
      00809D BD                     417 	.db 0xbd
      00809E 0D                     418 	.db 0x0d
      00809F 00                     419 	.db 0x00
                                    420 	.area CODE
                           0000AD   421 Fmain$__str_3$0_0$0 == .
                                    422 	.area CONST
      0080A0                        423 ___str_3:
      0080A0 42 7A 75               424 	.ascii "Bzu"
      0080A3 C4                     425 	.db 0xc4
      0080A4 8D                     426 	.db 0x8d
      0080A5 C3                     427 	.db 0xc3
      0080A6 A1                     428 	.db 0xa1
      0080A7 6B 20 6A 65 20 76 79   429 	.ascii "k je vypl"
             70 6C
      0080B0 C3                     430 	.db 0xc3
      0080B1 BD                     431 	.db 0xbd
      0080B2 0D                     432 	.db 0x0d
      0080B3 00                     433 	.db 0x00
                                    434 	.area CODE
                                    435 	.area INITIALIZER
                                    436 	.area CABS (ABS)
                                    437 
                                    438 	.area .debug_line (NOLOAD)
      000000 00 00 01 2F            439 	.dw	0,Ldebug_line_end-Ldebug_line_start
      000004                        440 Ldebug_line_start:
      000004 00 02                  441 	.dw	2
      000006 00 00 00 6D            442 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      00000A 01                     443 	.db	1
      00000B 01                     444 	.db	1
      00000C FB                     445 	.db	-5
      00000D 0F                     446 	.db	15
      00000E 0A                     447 	.db	10
      00000F 00                     448 	.db	0
      000010 01                     449 	.db	1
      000011 01                     450 	.db	1
      000012 01                     451 	.db	1
      000013 01                     452 	.db	1
      000014 00                     453 	.db	0
      000015 00                     454 	.db	0
      000016 00                     455 	.db	0
      000017 01                     456 	.db	1
      000018 43 3A 5C 50 72 6F 67   457 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      000040 00                     458 	.db	0
      000041 43 3A 5C 50 72 6F 67   459 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      000064 00                     460 	.db	0
      000065 00                     461 	.db	0
      000066 2E 2F 73 72 63 2F 6D   462 	.ascii "./src/main.c"
             61 69 6E 2E 63
      000072 00                     463 	.db	0
      000073 00                     464 	.uleb128	0
      000074 00                     465 	.uleb128	0
      000075 00                     466 	.uleb128	0
      000076 00                     467 	.db	0
      000077                        468 Ldebug_line_stmt:
      000077 00                     469 	.db	0
      000078 05                     470 	.uleb128	5
      000079 02                     471 	.db	2
      00007A 00 00 80 C4            472 	.dw	0,(Smain$setup$0)
      00007E 03                     473 	.db	3
      00007F 0F                     474 	.sleb128	15
      000080 01                     475 	.db	1
      000081 09                     476 	.db	9
      000082 00 00                  477 	.dw	Smain$setup$2-Smain$setup$0
      000084 03                     478 	.db	3
      000085 02                     479 	.sleb128	2
      000086 01                     480 	.db	1
      000087 09                     481 	.db	9
      000088 00 06                  482 	.dw	Smain$setup$5-Smain$setup$2
      00008A 03                     483 	.db	3
      00008B 01                     484 	.sleb128	1
      00008C 01                     485 	.db	1
      00008D 09                     486 	.db	9
      00008E 00 0D                  487 	.dw	Smain$setup$11-Smain$setup$5
      000090 03                     488 	.db	3
      000091 02                     489 	.sleb128	2
      000092 01                     490 	.db	1
      000093 09                     491 	.db	9
      000094 00 03                  492 	.dw	Smain$setup$12-Smain$setup$11
      000096 03                     493 	.db	3
      000097 01                     494 	.sleb128	1
      000098 01                     495 	.db	1
      000099 09                     496 	.db	9
      00009A 00 03                  497 	.dw	Smain$setup$13-Smain$setup$12
      00009C 03                     498 	.db	3
      00009D 02                     499 	.sleb128	2
      00009E 01                     500 	.db	1
      00009F 09                     501 	.db	9
      0000A0 00 0B                  502 	.dw	Smain$setup$18-Smain$setup$13
      0000A2 03                     503 	.db	3
      0000A3 01                     504 	.sleb128	1
      0000A4 01                     505 	.db	1
      0000A5 09                     506 	.db	9
      0000A6 00 0F                  507 	.dw	Smain$setup$25-Smain$setup$18
      0000A8 03                     508 	.db	3
      0000A9 01                     509 	.sleb128	1
      0000AA 01                     510 	.db	1
      0000AB 09                     511 	.db	9
      0000AC 00 06                  512 	.dw	Smain$setup$28-Smain$setup$25
      0000AE 03                     513 	.db	3
      0000AF 01                     514 	.sleb128	1
      0000B0 01                     515 	.db	1
      0000B1 09                     516 	.db	9
      0000B2 00 06                  517 	.dw	Smain$setup$31-Smain$setup$28
      0000B4 03                     518 	.db	3
      0000B5 02                     519 	.sleb128	2
      0000B6 01                     520 	.db	1
      0000B7 09                     521 	.db	9
      0000B8 00 01                  522 	.dw	1+Smain$setup$32-Smain$setup$31
      0000BA 00                     523 	.db	0
      0000BB 01                     524 	.uleb128	1
      0000BC 01                     525 	.db	1
      0000BD 00                     526 	.db	0
      0000BE 05                     527 	.uleb128	5
      0000BF 02                     528 	.db	2
      0000C0 00 00 81 04            529 	.dw	0,(Smain$main$34)
      0000C4 03                     530 	.db	3
      0000C5 1E                     531 	.sleb128	30
      0000C6 01                     532 	.db	1
      0000C7 09                     533 	.db	9
      0000C8 00 02                  534 	.dw	Smain$main$37-Smain$main$34
      0000CA 03                     535 	.db	3
      0000CB 04                     536 	.sleb128	4
      0000CC 01                     537 	.db	1
      0000CD 09                     538 	.db	9
      0000CE 00 02                  539 	.dw	Smain$main$38-Smain$main$37
      0000D0 03                     540 	.db	3
      0000D1 01                     541 	.sleb128	1
      0000D2 01                     542 	.db	1
      0000D3 09                     543 	.db	9
      0000D4 00 02                  544 	.dw	Smain$main$39-Smain$main$38
      0000D6 03                     545 	.db	3
      0000D7 03                     546 	.sleb128	3
      0000D8 01                     547 	.db	1
      0000D9 09                     548 	.db	9
      0000DA 00 03                  549 	.dw	Smain$main$40-Smain$main$39
      0000DC 03                     550 	.db	3
      0000DD 02                     551 	.sleb128	2
      0000DE 01                     552 	.db	1
      0000DF 09                     553 	.db	9
      0000E0 00 00                  554 	.dw	Smain$main$42-Smain$main$40
      0000E2 03                     555 	.db	3
      0000E3 04                     556 	.sleb128	4
      0000E4 01                     557 	.db	1
      0000E5 09                     558 	.db	9
      0000E6 00 11                  559 	.dw	Smain$main$48-Smain$main$42
      0000E8 03                     560 	.db	3
      0000E9 01                     561 	.sleb128	1
      0000EA 01                     562 	.db	1
      0000EB 09                     563 	.db	9
      0000EC 00 07                  564 	.dw	Smain$main$51-Smain$main$48
      0000EE 03                     565 	.db	3
      0000EF 03                     566 	.sleb128	3
      0000F0 01                     567 	.db	1
      0000F1 09                     568 	.db	9
      0000F2 00 02                  569 	.dw	Smain$main$53-Smain$main$51
      0000F4 03                     570 	.db	3
      0000F5 03                     571 	.sleb128	3
      0000F6 01                     572 	.db	1
      0000F7 09                     573 	.db	9
      0000F8 00 12                  574 	.dw	Smain$main$56-Smain$main$53
      0000FA 03                     575 	.db	3
      0000FB 01                     576 	.sleb128	1
      0000FC 01                     577 	.db	1
      0000FD 09                     578 	.db	9
      0000FE 00 07                  579 	.dw	Smain$main$58-Smain$main$56
      000100 03                     580 	.db	3
      000101 01                     581 	.sleb128	1
      000102 01                     582 	.db	1
      000103 09                     583 	.db	9
      000104 00 08                  584 	.dw	Smain$main$62-Smain$main$58
      000106 03                     585 	.db	3
      000107 01                     586 	.sleb128	1
      000108 01                     587 	.db	1
      000109 09                     588 	.db	9
      00010A 00 04                  589 	.dw	Smain$main$63-Smain$main$62
      00010C 03                     590 	.db	3
      00010D 01                     591 	.sleb128	1
      00010E 01                     592 	.db	1
      00010F 09                     593 	.db	9
      000110 00 0B                  594 	.dw	Smain$main$69-Smain$main$63
      000112 03                     595 	.db	3
      000113 03                     596 	.sleb128	3
      000114 01                     597 	.db	1
      000115 09                     598 	.db	9
      000116 00 06                  599 	.dw	Smain$main$72-Smain$main$69
      000118 03                     600 	.db	3
      000119 01                     601 	.sleb128	1
      00011A 01                     602 	.db	1
      00011B 09                     603 	.db	9
      00011C 00 02                  604 	.dw	Smain$main$73-Smain$main$72
      00011E 03                     605 	.db	3
      00011F 01                     606 	.sleb128	1
      000120 01                     607 	.db	1
      000121 09                     608 	.db	9
      000122 00 08                  609 	.dw	Smain$main$78-Smain$main$73
      000124 03                     610 	.db	3
      000125 04                     611 	.sleb128	4
      000126 01                     612 	.db	1
      000127 09                     613 	.db	9
      000128 00 07                  614 	.dw	Smain$main$80-Smain$main$78
      00012A 03                     615 	.db	3
      00012B 05                     616 	.sleb128	5
      00012C 01                     617 	.db	1
      00012D 09                     618 	.db	9
      00012E 00 03                  619 	.dw	1+Smain$main$82-Smain$main$80
      000130 00                     620 	.db	0
      000131 01                     621 	.uleb128	1
      000132 01                     622 	.db	1
      000133                        623 Ldebug_line_end:
                                    624 
                                    625 	.area .debug_loc (NOLOAD)
      000000                        626 Ldebug_loc_start:
      000000 00 00 81 70            627 	.dw	0,(Smain$main$81)
      000004 00 00 81 71            628 	.dw	0,(Smain$main$83)
      000008 00 02                  629 	.dw	2
      00000A 78                     630 	.db	120
      00000B 01                     631 	.sleb128	1
      00000C 00 00 81 67            632 	.dw	0,(Smain$main$76)
      000010 00 00 81 70            633 	.dw	0,(Smain$main$81)
      000014 00 02                  634 	.dw	2
      000016 78                     635 	.db	120
      000017 04                     636 	.sleb128	4
      000018 00 00 81 63            637 	.dw	0,(Smain$main$75)
      00001C 00 00 81 67            638 	.dw	0,(Smain$main$76)
      000020 00 02                  639 	.dw	2
      000022 78                     640 	.db	120
      000023 06                     641 	.sleb128	6
      000024 00 00 81 61            642 	.dw	0,(Smain$main$74)
      000028 00 00 81 63            643 	.dw	0,(Smain$main$75)
      00002C 00 02                  644 	.dw	2
      00002E 78                     645 	.db	120
      00002F 05                     646 	.sleb128	5
      000030 00 00 81 5D            647 	.dw	0,(Smain$main$71)
      000034 00 00 81 61            648 	.dw	0,(Smain$main$74)
      000038 00 02                  649 	.dw	2
      00003A 78                     650 	.db	120
      00003B 04                     651 	.sleb128	4
      00003C 00 00 81 59            652 	.dw	0,(Smain$main$70)
      000040 00 00 81 5D            653 	.dw	0,(Smain$main$71)
      000044 00 02                  654 	.dw	2
      000046 78                     655 	.db	120
      000047 06                     656 	.sleb128	6
      000048 00 00 81 54            657 	.dw	0,(Smain$main$66)
      00004C 00 00 81 59            658 	.dw	0,(Smain$main$70)
      000050 00 02                  659 	.dw	2
      000052 78                     660 	.db	120
      000053 04                     661 	.sleb128	4
      000054 00 00 81 50            662 	.dw	0,(Smain$main$65)
      000058 00 00 81 54            663 	.dw	0,(Smain$main$66)
      00005C 00 02                  664 	.dw	2
      00005E 78                     665 	.db	120
      00005F 06                     666 	.sleb128	6
      000060 00 00 81 4E            667 	.dw	0,(Smain$main$64)
      000064 00 00 81 50            668 	.dw	0,(Smain$main$65)
      000068 00 02                  669 	.dw	2
      00006A 78                     670 	.db	120
      00006B 05                     671 	.sleb128	5
      00006C 00 00 81 48            672 	.dw	0,(Smain$main$61)
      000070 00 00 81 4E            673 	.dw	0,(Smain$main$64)
      000074 00 02                  674 	.dw	2
      000076 78                     675 	.db	120
      000077 04                     676 	.sleb128	4
      000078 00 00 81 44            677 	.dw	0,(Smain$main$60)
      00007C 00 00 81 48            678 	.dw	0,(Smain$main$61)
      000080 00 02                  679 	.dw	2
      000082 78                     680 	.db	120
      000083 06                     681 	.sleb128	6
      000084 00 00 81 42            682 	.dw	0,(Smain$main$59)
      000088 00 00 81 44            683 	.dw	0,(Smain$main$60)
      00008C 00 02                  684 	.dw	2
      00008E 78                     685 	.db	120
      00008F 05                     686 	.sleb128	5
      000090 00 00 81 32            687 	.dw	0,(Smain$main$54)
      000094 00 00 81 42            688 	.dw	0,(Smain$main$59)
      000098 00 02                  689 	.dw	2
      00009A 78                     690 	.db	120
      00009B 04                     691 	.sleb128	4
      00009C 00 00 81 18            692 	.dw	0,(Smain$main$46)
      0000A0 00 00 81 32            693 	.dw	0,(Smain$main$54)
      0000A4 00 02                  694 	.dw	2
      0000A6 78                     695 	.db	120
      0000A7 04                     696 	.sleb128	4
      0000A8 00 00 81 13            697 	.dw	0,(Smain$main$45)
      0000AC 00 00 81 18            698 	.dw	0,(Smain$main$46)
      0000B0 00 02                  699 	.dw	2
      0000B2 78                     700 	.db	120
      0000B3 07                     701 	.sleb128	7
      0000B4 00 00 81 11            702 	.dw	0,(Smain$main$44)
      0000B8 00 00 81 13            703 	.dw	0,(Smain$main$45)
      0000BC 00 02                  704 	.dw	2
      0000BE 78                     705 	.db	120
      0000BF 06                     706 	.sleb128	6
      0000C0 00 00 81 0F            707 	.dw	0,(Smain$main$43)
      0000C4 00 00 81 11            708 	.dw	0,(Smain$main$44)
      0000C8 00 02                  709 	.dw	2
      0000CA 78                     710 	.db	120
      0000CB 05                     711 	.sleb128	5
      0000CC 00 00 81 06            712 	.dw	0,(Smain$main$36)
      0000D0 00 00 81 0F            713 	.dw	0,(Smain$main$43)
      0000D4 00 02                  714 	.dw	2
      0000D6 78                     715 	.db	120
      0000D7 04                     716 	.sleb128	4
      0000D8 00 00 81 04            717 	.dw	0,(Smain$main$35)
      0000DC 00 00 81 06            718 	.dw	0,(Smain$main$36)
      0000E0 00 02                  719 	.dw	2
      0000E2 78                     720 	.db	120
      0000E3 01                     721 	.sleb128	1
      0000E4 00 00 00 00            722 	.dw	0,0
      0000E8 00 00 00 00            723 	.dw	0,0
      0000EC 00 00 81 03            724 	.dw	0,(Smain$setup$30)
      0000F0 00 00 81 04            725 	.dw	0,(Smain$setup$33)
      0000F4 00 02                  726 	.dw	2
      0000F6 78                     727 	.db	120
      0000F7 01                     728 	.sleb128	1
      0000F8 00 00 80 FF            729 	.dw	0,(Smain$setup$29)
      0000FC 00 00 81 03            730 	.dw	0,(Smain$setup$30)
      000100 00 02                  731 	.dw	2
      000102 78                     732 	.db	120
      000103 02                     733 	.sleb128	2
      000104 00 00 80 FD            734 	.dw	0,(Smain$setup$27)
      000108 00 00 80 FF            735 	.dw	0,(Smain$setup$29)
      00010C 00 02                  736 	.dw	2
      00010E 78                     737 	.db	120
      00010F 01                     738 	.sleb128	1
      000110 00 00 80 F9            739 	.dw	0,(Smain$setup$26)
      000114 00 00 80 FD            740 	.dw	0,(Smain$setup$27)
      000118 00 02                  741 	.dw	2
      00011A 78                     742 	.db	120
      00011B 02                     743 	.sleb128	2
      00011C 00 00 80 F7            744 	.dw	0,(Smain$setup$24)
      000120 00 00 80 F9            745 	.dw	0,(Smain$setup$26)
      000124 00 02                  746 	.dw	2
      000126 78                     747 	.db	120
      000127 01                     748 	.sleb128	1
      000128 00 00 80 F2            749 	.dw	0,(Smain$setup$23)
      00012C 00 00 80 F7            750 	.dw	0,(Smain$setup$24)
      000130 00 02                  751 	.dw	2
      000132 78                     752 	.db	120
      000133 06                     753 	.sleb128	6
      000134 00 00 80 F0            754 	.dw	0,(Smain$setup$22)
      000138 00 00 80 F2            755 	.dw	0,(Smain$setup$23)
      00013C 00 02                  756 	.dw	2
      00013E 78                     757 	.db	120
      00013F 05                     758 	.sleb128	5
      000140 00 00 80 EE            759 	.dw	0,(Smain$setup$21)
      000144 00 00 80 F0            760 	.dw	0,(Smain$setup$22)
      000148 00 02                  761 	.dw	2
      00014A 78                     762 	.db	120
      00014B 04                     763 	.sleb128	4
      00014C 00 00 80 EC            764 	.dw	0,(Smain$setup$20)
      000150 00 00 80 EE            765 	.dw	0,(Smain$setup$21)
      000154 00 02                  766 	.dw	2
      000156 78                     767 	.db	120
      000157 03                     768 	.sleb128	3
      000158 00 00 80 EA            769 	.dw	0,(Smain$setup$19)
      00015C 00 00 80 EC            770 	.dw	0,(Smain$setup$20)
      000160 00 02                  771 	.dw	2
      000162 78                     772 	.db	120
      000163 02                     773 	.sleb128	2
      000164 00 00 80 E8            774 	.dw	0,(Smain$setup$17)
      000168 00 00 80 EA            775 	.dw	0,(Smain$setup$19)
      00016C 00 02                  776 	.dw	2
      00016E 78                     777 	.db	120
      00016F 01                     778 	.sleb128	1
      000170 00 00 80 E3            779 	.dw	0,(Smain$setup$16)
      000174 00 00 80 E8            780 	.dw	0,(Smain$setup$17)
      000178 00 02                  781 	.dw	2
      00017A 78                     782 	.db	120
      00017B 04                     783 	.sleb128	4
      00017C 00 00 80 E1            784 	.dw	0,(Smain$setup$15)
      000180 00 00 80 E3            785 	.dw	0,(Smain$setup$16)
      000184 00 02                  786 	.dw	2
      000186 78                     787 	.db	120
      000187 03                     788 	.sleb128	3
      000188 00 00 80 DF            789 	.dw	0,(Smain$setup$14)
      00018C 00 00 80 E1            790 	.dw	0,(Smain$setup$15)
      000190 00 02                  791 	.dw	2
      000192 78                     792 	.db	120
      000193 02                     793 	.sleb128	2
      000194 00 00 80 D7            794 	.dw	0,(Smain$setup$10)
      000198 00 00 80 DF            795 	.dw	0,(Smain$setup$14)
      00019C 00 02                  796 	.dw	2
      00019E 78                     797 	.db	120
      00019F 01                     798 	.sleb128	1
      0001A0 00 00 80 D2            799 	.dw	0,(Smain$setup$9)
      0001A4 00 00 80 D7            800 	.dw	0,(Smain$setup$10)
      0001A8 00 02                  801 	.dw	2
      0001AA 78                     802 	.db	120
      0001AB 05                     803 	.sleb128	5
      0001AC 00 00 80 D0            804 	.dw	0,(Smain$setup$8)
      0001B0 00 00 80 D2            805 	.dw	0,(Smain$setup$9)
      0001B4 00 02                  806 	.dw	2
      0001B6 78                     807 	.db	120
      0001B7 04                     808 	.sleb128	4
      0001B8 00 00 80 CE            809 	.dw	0,(Smain$setup$7)
      0001BC 00 00 80 D0            810 	.dw	0,(Smain$setup$8)
      0001C0 00 02                  811 	.dw	2
      0001C2 78                     812 	.db	120
      0001C3 03                     813 	.sleb128	3
      0001C4 00 00 80 CC            814 	.dw	0,(Smain$setup$6)
      0001C8 00 00 80 CE            815 	.dw	0,(Smain$setup$7)
      0001CC 00 02                  816 	.dw	2
      0001CE 78                     817 	.db	120
      0001CF 02                     818 	.sleb128	2
      0001D0 00 00 80 CA            819 	.dw	0,(Smain$setup$4)
      0001D4 00 00 80 CC            820 	.dw	0,(Smain$setup$6)
      0001D8 00 02                  821 	.dw	2
      0001DA 78                     822 	.db	120
      0001DB 01                     823 	.sleb128	1
      0001DC 00 00 80 C6            824 	.dw	0,(Smain$setup$3)
      0001E0 00 00 80 CA            825 	.dw	0,(Smain$setup$4)
      0001E4 00 02                  826 	.dw	2
      0001E6 78                     827 	.db	120
      0001E7 02                     828 	.sleb128	2
      0001E8 00 00 80 C4            829 	.dw	0,(Smain$setup$1)
      0001EC 00 00 80 C6            830 	.dw	0,(Smain$setup$3)
      0001F0 00 02                  831 	.dw	2
      0001F2 78                     832 	.db	120
      0001F3 01                     833 	.sleb128	1
      0001F4 00 00 00 00            834 	.dw	0,0
      0001F8 00 00 00 00            835 	.dw	0,0
                                    836 
                                    837 	.area .debug_abbrev (NOLOAD)
      000000                        838 Ldebug_abbrev:
      000000 0A                     839 	.uleb128	10
      000001 01                     840 	.uleb128	1
      000002 01                     841 	.db	1
      000003 01                     842 	.uleb128	1
      000004 13                     843 	.uleb128	19
      000005 0B                     844 	.uleb128	11
      000006 0B                     845 	.uleb128	11
      000007 49                     846 	.uleb128	73
      000008 13                     847 	.uleb128	19
      000009 00                     848 	.uleb128	0
      00000A 00                     849 	.uleb128	0
      00000B 08                     850 	.uleb128	8
      00000C 34                     851 	.uleb128	52
      00000D 00                     852 	.db	0
      00000E 02                     853 	.uleb128	2
      00000F 0A                     854 	.uleb128	10
      000010 03                     855 	.uleb128	3
      000011 08                     856 	.uleb128	8
      000012 49                     857 	.uleb128	73
      000013 13                     858 	.uleb128	19
      000014 00                     859 	.uleb128	0
      000015 00                     860 	.uleb128	0
      000016 04                     861 	.uleb128	4
      000017 2E                     862 	.uleb128	46
      000018 01                     863 	.db	1
      000019 01                     864 	.uleb128	1
      00001A 13                     865 	.uleb128	19
      00001B 03                     866 	.uleb128	3
      00001C 08                     867 	.uleb128	8
      00001D 11                     868 	.uleb128	17
      00001E 01                     869 	.uleb128	1
      00001F 12                     870 	.uleb128	18
      000020 01                     871 	.uleb128	1
      000021 3F                     872 	.uleb128	63
      000022 0C                     873 	.uleb128	12
      000023 40                     874 	.uleb128	64
      000024 06                     875 	.uleb128	6
      000025 49                     876 	.uleb128	73
      000026 13                     877 	.uleb128	19
      000027 00                     878 	.uleb128	0
      000028 00                     879 	.uleb128	0
      000029 09                     880 	.uleb128	9
      00002A 26                     881 	.uleb128	38
      00002B 00                     882 	.db	0
      00002C 49                     883 	.uleb128	73
      00002D 13                     884 	.uleb128	19
      00002E 00                     885 	.uleb128	0
      00002F 00                     886 	.uleb128	0
      000030 07                     887 	.uleb128	7
      000031 0B                     888 	.uleb128	11
      000032 01                     889 	.db	1
      000033 11                     890 	.uleb128	17
      000034 01                     891 	.uleb128	1
      000035 00                     892 	.uleb128	0
      000036 00                     893 	.uleb128	0
      000037 01                     894 	.uleb128	1
      000038 11                     895 	.uleb128	17
      000039 01                     896 	.db	1
      00003A 03                     897 	.uleb128	3
      00003B 08                     898 	.uleb128	8
      00003C 10                     899 	.uleb128	16
      00003D 06                     900 	.uleb128	6
      00003E 13                     901 	.uleb128	19
      00003F 0B                     902 	.uleb128	11
      000040 25                     903 	.uleb128	37
      000041 08                     904 	.uleb128	8
      000042 00                     905 	.uleb128	0
      000043 00                     906 	.uleb128	0
      000044 06                     907 	.uleb128	6
      000045 0B                     908 	.uleb128	11
      000046 00                     909 	.db	0
      000047 11                     910 	.uleb128	17
      000048 01                     911 	.uleb128	1
      000049 12                     912 	.uleb128	18
      00004A 01                     913 	.uleb128	1
      00004B 00                     914 	.uleb128	0
      00004C 00                     915 	.uleb128	0
      00004D 02                     916 	.uleb128	2
      00004E 2E                     917 	.uleb128	46
      00004F 00                     918 	.db	0
      000050 03                     919 	.uleb128	3
      000051 08                     920 	.uleb128	8
      000052 11                     921 	.uleb128	17
      000053 01                     922 	.uleb128	1
      000054 12                     923 	.uleb128	18
      000055 01                     924 	.uleb128	1
      000056 3F                     925 	.uleb128	63
      000057 0C                     926 	.uleb128	12
      000058 40                     927 	.uleb128	64
      000059 06                     928 	.uleb128	6
      00005A 00                     929 	.uleb128	0
      00005B 00                     930 	.uleb128	0
      00005C 05                     931 	.uleb128	5
      00005D 0B                     932 	.uleb128	11
      00005E 01                     933 	.db	1
      00005F 01                     934 	.uleb128	1
      000060 13                     935 	.uleb128	19
      000061 11                     936 	.uleb128	17
      000062 01                     937 	.uleb128	1
      000063 12                     938 	.uleb128	18
      000064 01                     939 	.uleb128	1
      000065 00                     940 	.uleb128	0
      000066 00                     941 	.uleb128	0
      000067 0B                     942 	.uleb128	11
      000068 21                     943 	.uleb128	33
      000069 00                     944 	.db	0
      00006A 2F                     945 	.uleb128	47
      00006B 0B                     946 	.uleb128	11
      00006C 00                     947 	.uleb128	0
      00006D 00                     948 	.uleb128	0
      00006E 03                     949 	.uleb128	3
      00006F 24                     950 	.uleb128	36
      000070 00                     951 	.db	0
      000071 03                     952 	.uleb128	3
      000072 08                     953 	.uleb128	8
      000073 0B                     954 	.uleb128	11
      000074 0B                     955 	.uleb128	11
      000075 3E                     956 	.uleb128	62
      000076 0B                     957 	.uleb128	11
      000077 00                     958 	.uleb128	0
      000078 00                     959 	.uleb128	0
      000079 00                     960 	.uleb128	0
                                    961 
                                    962 	.area .debug_info (NOLOAD)
      000000 00 00 01 2C            963 	.dw	0,Ldebug_info_end-Ldebug_info_start
      000004                        964 Ldebug_info_start:
      000004 00 02                  965 	.dw	2
      000006 00 00 00 00            966 	.dw	0,(Ldebug_abbrev)
      00000A 04                     967 	.db	4
      00000B 01                     968 	.uleb128	1
      00000C 2E 2F 73 72 63 2F 6D   969 	.ascii "./src/main.c"
             61 69 6E 2E 63
      000018 00                     970 	.db	0
      000019 00 00 00 00            971 	.dw	0,(Ldebug_line_start+-4)
      00001D 01                     972 	.db	1
      00001E 53 44 43 43 20 76 65   973 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      000037 00                     974 	.db	0
      000038 02                     975 	.uleb128	2
      000039 73 65 74 75 70         976 	.ascii "setup"
      00003E 00                     977 	.db	0
      00003F 00 00 80 C4            978 	.dw	0,(_setup)
      000043 00 00 81 04            979 	.dw	0,(XG$setup$0$0+1)
      000047 01                     980 	.db	1
      000048 00 00 00 EC            981 	.dw	0,(Ldebug_loc_start+236)
      00004C 03                     982 	.uleb128	3
      00004D 69 6E 74               983 	.ascii "int"
      000050 00                     984 	.db	0
      000051 02                     985 	.db	2
      000052 05                     986 	.db	5
      000053 04                     987 	.uleb128	4
      000054 00 00 00 E4            988 	.dw	0,228
      000058 6D 61 69 6E            989 	.ascii "main"
      00005C 00                     990 	.db	0
      00005D 00 00 81 04            991 	.dw	0,(_main)
      000061 00 00 81 71            992 	.dw	0,(XG$main$0$0+1)
      000065 01                     993 	.db	1
      000066 00 00 00 00            994 	.dw	0,(Ldebug_loc_start)
      00006A 00 00 00 4C            995 	.dw	0,76
      00006E 05                     996 	.uleb128	5
      00006F 00 00 00 A6            997 	.dw	0,166
      000073 00 00 81 0D            998 	.dw	0,(Smain$main$41)
      000077 00 00 81 6B            999 	.dw	0,(Smain$main$79)
      00007B 06                    1000 	.uleb128	6
      00007C 00 00 81 1E           1001 	.dw	0,(Smain$main$47)
      000080 00 00 81 22           1002 	.dw	0,(Smain$main$49)
      000084 06                    1003 	.uleb128	6
      000085 00 00 81 25           1004 	.dw	0,(Smain$main$50)
      000089 00 00 81 27           1005 	.dw	0,(Smain$main$52)
      00008D 07                    1006 	.uleb128	7
      00008E 00 00 81 39           1007 	.dw	0,(Smain$main$55)
      000092 06                    1008 	.uleb128	6
      000093 00 00 81 40           1009 	.dw	0,(Smain$main$57)
      000097 00 00 81 54           1010 	.dw	0,(Smain$main$67)
      00009B 06                    1011 	.uleb128	6
      00009C 00 00 81 57           1012 	.dw	0,(Smain$main$68)
      0000A0 00 00 81 67           1013 	.dw	0,(Smain$main$77)
      0000A4 00                    1014 	.uleb128	0
      0000A5 00                    1015 	.uleb128	0
      0000A6 08                    1016 	.uleb128	8
      0000A7 02                    1017 	.db	2
      0000A8 91                    1018 	.db	145
      0000A9 7F                    1019 	.sleb128	-1
      0000AA 61 6B 74 75 61 6C 5F  1020 	.ascii "aktual_stav"
             73 74 61 76
      0000B5 00                    1021 	.db	0
      0000B6 00 00 00 E4           1022 	.dw	0,228
      0000BA 08                    1023 	.uleb128	8
      0000BB 02                    1024 	.db	2
      0000BC 91                    1025 	.db	145
      0000BD 7D                    1026 	.sleb128	-3
      0000BE 6D 69 6E 75 6C 79 5F  1027 	.ascii "minuly_stav"
             73 74 61 76
      0000C9 00                    1028 	.db	0
      0000CA 00 00 00 E4           1029 	.dw	0,228
      0000CE 08                    1030 	.uleb128	8
      0000CF 02                    1031 	.db	2
      0000D0 91                    1032 	.db	145
      0000D1 7E                    1033 	.sleb128	-2
      0000D2 73 74 61 76 5F 62 7A  1034 	.ascii "stav_bzucaku"
             75 63 61 6B 75
      0000DE 00                    1035 	.db	0
      0000DF 00 00 00 E4           1036 	.dw	0,228
      0000E3 00                    1037 	.uleb128	0
      0000E4 03                    1038 	.uleb128	3
      0000E5 75 6E 73 69 67 6E 65  1039 	.ascii "unsigned char"
             64 20 63 68 61 72
      0000F2 00                    1040 	.db	0
      0000F3 01                    1041 	.db	1
      0000F4 08                    1042 	.db	8
      0000F5 09                    1043 	.uleb128	9
      0000F6 00 00 00 E4           1044 	.dw	0,228
      0000FA 0A                    1045 	.uleb128	10
      0000FB 00 00 01 07           1046 	.dw	0,263
      0000FF 14                    1047 	.db	20
      000100 00 00 00 F5           1048 	.dw	0,245
      000104 0B                    1049 	.uleb128	11
      000105 13                    1050 	.db	19
      000106 00                    1051 	.uleb128	0
      000107 08                    1052 	.uleb128	8
      000108 05                    1053 	.db	5
      000109 03                    1054 	.db	3
      00010A 00 00 80 8C           1055 	.dw	0,(___str_1)
      00010E 5F 5F 73 74 72 5F 31  1056 	.ascii "__str_1"
      000115 00                    1057 	.db	0
      000116 00 00 00 FA           1058 	.dw	0,250
      00011A 08                    1059 	.uleb128	8
      00011B 05                    1060 	.db	5
      00011C 03                    1061 	.db	3
      00011D 00 00 80 A0           1062 	.dw	0,(___str_3)
      000121 5F 5F 73 74 72 5F 33  1063 	.ascii "__str_3"
      000128 00                    1064 	.db	0
      000129 00 00 00 FA           1065 	.dw	0,250
      00012D 00                    1066 	.uleb128	0
      00012E 00                    1067 	.uleb128	0
      00012F 00                    1068 	.uleb128	0
      000130                       1069 Ldebug_info_end:
                                   1070 
                                   1071 	.area .debug_pubnames (NOLOAD)
      000000 00 00 00 21           1072 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      000004                       1073 Ldebug_pubnames_start:
      000004 00 02                 1074 	.dw	2
      000006 00 00 00 00           1075 	.dw	0,(Ldebug_info_start-4)
      00000A 00 00 01 30           1076 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      00000E 00 00 00 38           1077 	.dw	0,56
      000012 73 65 74 75 70        1078 	.ascii "setup"
      000017 00                    1079 	.db	0
      000018 00 00 00 53           1080 	.dw	0,83
      00001C 6D 61 69 6E           1081 	.ascii "main"
      000020 00                    1082 	.db	0
      000021 00 00 00 00           1083 	.dw	0,0
      000025                       1084 Ldebug_pubnames_end:
                                   1085 
                                   1086 	.area .debug_frame (NOLOAD)
      000000 00 00                 1087 	.dw	0
      000002 00 0E                 1088 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      000004                       1089 Ldebug_CIE0_start:
      000004 FF FF                 1090 	.dw	0xffff
      000006 FF FF                 1091 	.dw	0xffff
      000008 01                    1092 	.db	1
      000009 00                    1093 	.db	0
      00000A 01                    1094 	.uleb128	1
      00000B 7F                    1095 	.sleb128	-1
      00000C 09                    1096 	.db	9
      00000D 0C                    1097 	.db	12
      00000E 08                    1098 	.uleb128	8
      00000F 02                    1099 	.uleb128	2
      000010 89                    1100 	.db	137
      000011 01                    1101 	.uleb128	1
      000012                       1102 Ldebug_CIE0_end:
      000012 00 00 00 91           1103 	.dw	0,145
      000016 00 00 00 00           1104 	.dw	0,(Ldebug_CIE0_start-4)
      00001A 00 00 81 04           1105 	.dw	0,(Smain$main$35)	;initial loc
      00001E 00 00 00 6D           1106 	.dw	0,Smain$main$83-Smain$main$35
      000022 01                    1107 	.db	1
      000023 00 00 81 04           1108 	.dw	0,(Smain$main$35)
      000027 0E                    1109 	.db	14
      000028 02                    1110 	.uleb128	2
      000029 01                    1111 	.db	1
      00002A 00 00 81 06           1112 	.dw	0,(Smain$main$36)
      00002E 0E                    1113 	.db	14
      00002F 05                    1114 	.uleb128	5
      000030 01                    1115 	.db	1
      000031 00 00 81 0F           1116 	.dw	0,(Smain$main$43)
      000035 0E                    1117 	.db	14
      000036 06                    1118 	.uleb128	6
      000037 01                    1119 	.db	1
      000038 00 00 81 11           1120 	.dw	0,(Smain$main$44)
      00003C 0E                    1121 	.db	14
      00003D 07                    1122 	.uleb128	7
      00003E 01                    1123 	.db	1
      00003F 00 00 81 13           1124 	.dw	0,(Smain$main$45)
      000043 0E                    1125 	.db	14
      000044 08                    1126 	.uleb128	8
      000045 01                    1127 	.db	1
      000046 00 00 81 18           1128 	.dw	0,(Smain$main$46)
      00004A 0E                    1129 	.db	14
      00004B 05                    1130 	.uleb128	5
      00004C 01                    1131 	.db	1
      00004D 00 00 81 32           1132 	.dw	0,(Smain$main$54)
      000051 0E                    1133 	.db	14
      000052 05                    1134 	.uleb128	5
      000053 01                    1135 	.db	1
      000054 00 00 81 42           1136 	.dw	0,(Smain$main$59)
      000058 0E                    1137 	.db	14
      000059 06                    1138 	.uleb128	6
      00005A 01                    1139 	.db	1
      00005B 00 00 81 44           1140 	.dw	0,(Smain$main$60)
      00005F 0E                    1141 	.db	14
      000060 07                    1142 	.uleb128	7
      000061 01                    1143 	.db	1
      000062 00 00 81 48           1144 	.dw	0,(Smain$main$61)
      000066 0E                    1145 	.db	14
      000067 05                    1146 	.uleb128	5
      000068 01                    1147 	.db	1
      000069 00 00 81 4E           1148 	.dw	0,(Smain$main$64)
      00006D 0E                    1149 	.db	14
      00006E 06                    1150 	.uleb128	6
      00006F 01                    1151 	.db	1
      000070 00 00 81 50           1152 	.dw	0,(Smain$main$65)
      000074 0E                    1153 	.db	14
      000075 07                    1154 	.uleb128	7
      000076 01                    1155 	.db	1
      000077 00 00 81 54           1156 	.dw	0,(Smain$main$66)
      00007B 0E                    1157 	.db	14
      00007C 05                    1158 	.uleb128	5
      00007D 01                    1159 	.db	1
      00007E 00 00 81 59           1160 	.dw	0,(Smain$main$70)
      000082 0E                    1161 	.db	14
      000083 07                    1162 	.uleb128	7
      000084 01                    1163 	.db	1
      000085 00 00 81 5D           1164 	.dw	0,(Smain$main$71)
      000089 0E                    1165 	.db	14
      00008A 05                    1166 	.uleb128	5
      00008B 01                    1167 	.db	1
      00008C 00 00 81 61           1168 	.dw	0,(Smain$main$74)
      000090 0E                    1169 	.db	14
      000091 06                    1170 	.uleb128	6
      000092 01                    1171 	.db	1
      000093 00 00 81 63           1172 	.dw	0,(Smain$main$75)
      000097 0E                    1173 	.db	14
      000098 07                    1174 	.uleb128	7
      000099 01                    1175 	.db	1
      00009A 00 00 81 67           1176 	.dw	0,(Smain$main$76)
      00009E 0E                    1177 	.db	14
      00009F 05                    1178 	.uleb128	5
      0000A0 01                    1179 	.db	1
      0000A1 00 00 81 70           1180 	.dw	0,(Smain$main$81)
      0000A5 0E                    1181 	.db	14
      0000A6 02                    1182 	.uleb128	2
                                   1183 
                                   1184 	.area .debug_frame (NOLOAD)
      0000A7 00 00                 1185 	.dw	0
      0000A9 00 0E                 1186 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      0000AB                       1187 Ldebug_CIE1_start:
      0000AB FF FF                 1188 	.dw	0xffff
      0000AD FF FF                 1189 	.dw	0xffff
      0000AF 01                    1190 	.db	1
      0000B0 00                    1191 	.db	0
      0000B1 01                    1192 	.uleb128	1
      0000B2 7F                    1193 	.sleb128	-1
      0000B3 09                    1194 	.db	9
      0000B4 0C                    1195 	.db	12
      0000B5 08                    1196 	.uleb128	8
      0000B6 02                    1197 	.uleb128	2
      0000B7 89                    1198 	.db	137
      0000B8 01                    1199 	.uleb128	1
      0000B9                       1200 Ldebug_CIE1_end:
      0000B9 00 00 00 A6           1201 	.dw	0,166
      0000BD 00 00 00 A7           1202 	.dw	0,(Ldebug_CIE1_start-4)
      0000C1 00 00 80 C4           1203 	.dw	0,(Smain$setup$1)	;initial loc
      0000C5 00 00 00 40           1204 	.dw	0,Smain$setup$33-Smain$setup$1
      0000C9 01                    1205 	.db	1
      0000CA 00 00 80 C4           1206 	.dw	0,(Smain$setup$1)
      0000CE 0E                    1207 	.db	14
      0000CF 02                    1208 	.uleb128	2
      0000D0 01                    1209 	.db	1
      0000D1 00 00 80 C6           1210 	.dw	0,(Smain$setup$3)
      0000D5 0E                    1211 	.db	14
      0000D6 03                    1212 	.uleb128	3
      0000D7 01                    1213 	.db	1
      0000D8 00 00 80 CA           1214 	.dw	0,(Smain$setup$4)
      0000DC 0E                    1215 	.db	14
      0000DD 02                    1216 	.uleb128	2
      0000DE 01                    1217 	.db	1
      0000DF 00 00 80 CC           1218 	.dw	0,(Smain$setup$6)
      0000E3 0E                    1219 	.db	14
      0000E4 03                    1220 	.uleb128	3
      0000E5 01                    1221 	.db	1
      0000E6 00 00 80 CE           1222 	.dw	0,(Smain$setup$7)
      0000EA 0E                    1223 	.db	14
      0000EB 04                    1224 	.uleb128	4
      0000EC 01                    1225 	.db	1
      0000ED 00 00 80 D0           1226 	.dw	0,(Smain$setup$8)
      0000F1 0E                    1227 	.db	14
      0000F2 05                    1228 	.uleb128	5
      0000F3 01                    1229 	.db	1
      0000F4 00 00 80 D2           1230 	.dw	0,(Smain$setup$9)
      0000F8 0E                    1231 	.db	14
      0000F9 06                    1232 	.uleb128	6
      0000FA 01                    1233 	.db	1
      0000FB 00 00 80 D7           1234 	.dw	0,(Smain$setup$10)
      0000FF 0E                    1235 	.db	14
      000100 02                    1236 	.uleb128	2
      000101 01                    1237 	.db	1
      000102 00 00 80 DF           1238 	.dw	0,(Smain$setup$14)
      000106 0E                    1239 	.db	14
      000107 03                    1240 	.uleb128	3
      000108 01                    1241 	.db	1
      000109 00 00 80 E1           1242 	.dw	0,(Smain$setup$15)
      00010D 0E                    1243 	.db	14
      00010E 04                    1244 	.uleb128	4
      00010F 01                    1245 	.db	1
      000110 00 00 80 E3           1246 	.dw	0,(Smain$setup$16)
      000114 0E                    1247 	.db	14
      000115 05                    1248 	.uleb128	5
      000116 01                    1249 	.db	1
      000117 00 00 80 E8           1250 	.dw	0,(Smain$setup$17)
      00011B 0E                    1251 	.db	14
      00011C 02                    1252 	.uleb128	2
      00011D 01                    1253 	.db	1
      00011E 00 00 80 EA           1254 	.dw	0,(Smain$setup$19)
      000122 0E                    1255 	.db	14
      000123 03                    1256 	.uleb128	3
      000124 01                    1257 	.db	1
      000125 00 00 80 EC           1258 	.dw	0,(Smain$setup$20)
      000129 0E                    1259 	.db	14
      00012A 04                    1260 	.uleb128	4
      00012B 01                    1261 	.db	1
      00012C 00 00 80 EE           1262 	.dw	0,(Smain$setup$21)
      000130 0E                    1263 	.db	14
      000131 05                    1264 	.uleb128	5
      000132 01                    1265 	.db	1
      000133 00 00 80 F0           1266 	.dw	0,(Smain$setup$22)
      000137 0E                    1267 	.db	14
      000138 06                    1268 	.uleb128	6
      000139 01                    1269 	.db	1
      00013A 00 00 80 F2           1270 	.dw	0,(Smain$setup$23)
      00013E 0E                    1271 	.db	14
      00013F 07                    1272 	.uleb128	7
      000140 01                    1273 	.db	1
      000141 00 00 80 F7           1274 	.dw	0,(Smain$setup$24)
      000145 0E                    1275 	.db	14
      000146 02                    1276 	.uleb128	2
      000147 01                    1277 	.db	1
      000148 00 00 80 F9           1278 	.dw	0,(Smain$setup$26)
      00014C 0E                    1279 	.db	14
      00014D 03                    1280 	.uleb128	3
      00014E 01                    1281 	.db	1
      00014F 00 00 80 FD           1282 	.dw	0,(Smain$setup$27)
      000153 0E                    1283 	.db	14
      000154 02                    1284 	.uleb128	2
      000155 01                    1285 	.db	1
      000156 00 00 80 FF           1286 	.dw	0,(Smain$setup$29)
      00015A 0E                    1287 	.db	14
      00015B 03                    1288 	.uleb128	3
      00015C 01                    1289 	.db	1
      00015D 00 00 81 03           1290 	.dw	0,(Smain$setup$30)
      000161 0E                    1291 	.db	14
      000162 02                    1292 	.uleb128	2
