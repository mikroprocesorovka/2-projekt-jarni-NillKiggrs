                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module stm8s_uart1
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _CLK_GetClockFreq
                                     12 	.globl _UART1_DeInit
                                     13 	.globl _UART1_Init
                                     14 	.globl _UART1_Cmd
                                     15 	.globl _UART1_ITConfig
                                     16 	.globl _UART1_HalfDuplexCmd
                                     17 	.globl _UART1_IrDAConfig
                                     18 	.globl _UART1_IrDACmd
                                     19 	.globl _UART1_LINBreakDetectionConfig
                                     20 	.globl _UART1_LINCmd
                                     21 	.globl _UART1_SmartCardCmd
                                     22 	.globl _UART1_SmartCardNACKCmd
                                     23 	.globl _UART1_WakeUpConfig
                                     24 	.globl _UART1_ReceiverWakeUpCmd
                                     25 	.globl _UART1_ReceiveData8
                                     26 	.globl _UART1_ReceiveData9
                                     27 	.globl _UART1_SendData8
                                     28 	.globl _UART1_SendData9
                                     29 	.globl _UART1_SendBreak
                                     30 	.globl _UART1_SetAddress
                                     31 	.globl _UART1_SetGuardTime
                                     32 	.globl _UART1_SetPrescaler
                                     33 	.globl _UART1_GetFlagStatus
                                     34 	.globl _UART1_ClearFlag
                                     35 	.globl _UART1_GetITStatus
                                     36 	.globl _UART1_ClearITPendingBit
                                     37 ;--------------------------------------------------------
                                     38 ; ram data
                                     39 ;--------------------------------------------------------
                                     40 	.area DATA
                                     41 ;--------------------------------------------------------
                                     42 ; ram data
                                     43 ;--------------------------------------------------------
                                     44 	.area INITIALIZED
                                     45 ;--------------------------------------------------------
                                     46 ; absolute external ram data
                                     47 ;--------------------------------------------------------
                                     48 	.area DABS (ABS)
                                     49 
                                     50 ; default segment ordering for linker
                                     51 	.area HOME
                                     52 	.area GSINIT
                                     53 	.area GSFINAL
                                     54 	.area CONST
                                     55 	.area INITIALIZER
                                     56 	.area CODE
                                     57 
                                     58 ;--------------------------------------------------------
                                     59 ; global & static initialisations
                                     60 ;--------------------------------------------------------
                                     61 	.area HOME
                                     62 	.area GSINIT
                                     63 	.area GSFINAL
                                     64 	.area GSINIT
                                     65 ;--------------------------------------------------------
                                     66 ; Home
                                     67 ;--------------------------------------------------------
                                     68 	.area HOME
                                     69 	.area HOME
                                     70 ;--------------------------------------------------------
                                     71 ; code
                                     72 ;--------------------------------------------------------
                                     73 	.area CODE
                           000000    74 	Sstm8s_uart1$UART1_DeInit$0 ==.
                                     75 ;	../SPL/src/stm8s_uart1.c: 53: void UART1_DeInit(void)
                                     76 ; genLabel
                                     77 ;	-----------------------------------------
                                     78 ;	 function UART1_DeInit
                                     79 ;	-----------------------------------------
                                     80 ;	Register assignment is optimal.
                                     81 ;	Stack space usage: 0 bytes.
      00979C                         82 _UART1_DeInit:
                           000000    83 	Sstm8s_uart1$UART1_DeInit$1 ==.
                           000000    84 	Sstm8s_uart1$UART1_DeInit$2 ==.
                                     85 ;	../SPL/src/stm8s_uart1.c: 57: (void)UART1->SR;
                                     86 ; genPointerGet
                                     87 ; Dummy read
      00979C C6 52 30         [ 1]   88 	ld	a, 0x5230
                           000003    89 	Sstm8s_uart1$UART1_DeInit$3 ==.
                                     90 ;	../SPL/src/stm8s_uart1.c: 58: (void)UART1->DR;
                                     91 ; genPointerGet
                                     92 ; Dummy read
      00979F C6 52 31         [ 1]   93 	ld	a, 0x5231
                           000006    94 	Sstm8s_uart1$UART1_DeInit$4 ==.
                                     95 ;	../SPL/src/stm8s_uart1.c: 60: UART1->BRR2 = UART1_BRR2_RESET_VALUE;  /* Set UART1_BRR2 to reset value 0x00 */
                                     96 ; genPointerSet
      0097A2 35 00 52 33      [ 1]   97 	mov	0x5233+0, #0x00
                           00000A    98 	Sstm8s_uart1$UART1_DeInit$5 ==.
                                     99 ;	../SPL/src/stm8s_uart1.c: 61: UART1->BRR1 = UART1_BRR1_RESET_VALUE;  /* Set UART1_BRR1 to reset value 0x00 */
                                    100 ; genPointerSet
      0097A6 35 00 52 32      [ 1]  101 	mov	0x5232+0, #0x00
                           00000E   102 	Sstm8s_uart1$UART1_DeInit$6 ==.
                                    103 ;	../SPL/src/stm8s_uart1.c: 63: UART1->CR1 = UART1_CR1_RESET_VALUE;  /* Set UART1_CR1 to reset value 0x00 */
                                    104 ; genPointerSet
      0097AA 35 00 52 34      [ 1]  105 	mov	0x5234+0, #0x00
                           000012   106 	Sstm8s_uart1$UART1_DeInit$7 ==.
                                    107 ;	../SPL/src/stm8s_uart1.c: 64: UART1->CR2 = UART1_CR2_RESET_VALUE;  /* Set UART1_CR2 to reset value 0x00 */
                                    108 ; genPointerSet
      0097AE 35 00 52 35      [ 1]  109 	mov	0x5235+0, #0x00
                           000016   110 	Sstm8s_uart1$UART1_DeInit$8 ==.
                                    111 ;	../SPL/src/stm8s_uart1.c: 65: UART1->CR3 = UART1_CR3_RESET_VALUE;  /* Set UART1_CR3 to reset value 0x00 */
                                    112 ; genPointerSet
      0097B2 35 00 52 36      [ 1]  113 	mov	0x5236+0, #0x00
                           00001A   114 	Sstm8s_uart1$UART1_DeInit$9 ==.
                                    115 ;	../SPL/src/stm8s_uart1.c: 66: UART1->CR4 = UART1_CR4_RESET_VALUE;  /* Set UART1_CR4 to reset value 0x00 */
                                    116 ; genPointerSet
      0097B6 35 00 52 37      [ 1]  117 	mov	0x5237+0, #0x00
                           00001E   118 	Sstm8s_uart1$UART1_DeInit$10 ==.
                                    119 ;	../SPL/src/stm8s_uart1.c: 67: UART1->CR5 = UART1_CR5_RESET_VALUE;  /* Set UART1_CR5 to reset value 0x00 */
                                    120 ; genPointerSet
      0097BA 35 00 52 38      [ 1]  121 	mov	0x5238+0, #0x00
                           000022   122 	Sstm8s_uart1$UART1_DeInit$11 ==.
                                    123 ;	../SPL/src/stm8s_uart1.c: 69: UART1->GTR = UART1_GTR_RESET_VALUE;
                                    124 ; genPointerSet
      0097BE 35 00 52 39      [ 1]  125 	mov	0x5239+0, #0x00
                           000026   126 	Sstm8s_uart1$UART1_DeInit$12 ==.
                                    127 ;	../SPL/src/stm8s_uart1.c: 70: UART1->PSCR = UART1_PSCR_RESET_VALUE;
                                    128 ; genPointerSet
      0097C2 35 00 52 3A      [ 1]  129 	mov	0x523a+0, #0x00
                                    130 ; genLabel
      0097C6                        131 00101$:
                           00002A   132 	Sstm8s_uart1$UART1_DeInit$13 ==.
                                    133 ;	../SPL/src/stm8s_uart1.c: 71: }
                                    134 ; genEndFunction
                           00002A   135 	Sstm8s_uart1$UART1_DeInit$14 ==.
                           00002A   136 	XG$UART1_DeInit$0$0 ==.
      0097C6 81               [ 4]  137 	ret
                           00002B   138 	Sstm8s_uart1$UART1_DeInit$15 ==.
                           00002B   139 	Sstm8s_uart1$UART1_Init$16 ==.
                                    140 ;	../SPL/src/stm8s_uart1.c: 90: void UART1_Init(uint32_t BaudRate, UART1_WordLength_TypeDef WordLength, 
                                    141 ; genLabel
                                    142 ;	-----------------------------------------
                                    143 ;	 function UART1_Init
                                    144 ;	-----------------------------------------
                                    145 ;	Register assignment might be sub-optimal.
                                    146 ;	Stack space usage: 17 bytes.
      0097C7                        147 _UART1_Init:
                           00002B   148 	Sstm8s_uart1$UART1_Init$17 ==.
      0097C7 52 11            [ 2]  149 	sub	sp, #17
                           00002D   150 	Sstm8s_uart1$UART1_Init$18 ==.
                           00002D   151 	Sstm8s_uart1$UART1_Init$19 ==.
                                    152 ;	../SPL/src/stm8s_uart1.c: 105: UART1->CR1 &= (uint8_t)(~UART1_CR1_M);  
                                    153 ; genPointerGet
      0097C9 C6 52 34         [ 1]  154 	ld	a, 0x5234
                                    155 ; genAnd
      0097CC A4 EF            [ 1]  156 	and	a, #0xef
                                    157 ; genPointerSet
      0097CE C7 52 34         [ 1]  158 	ld	0x5234, a
                           000035   159 	Sstm8s_uart1$UART1_Init$20 ==.
                                    160 ;	../SPL/src/stm8s_uart1.c: 108: UART1->CR1 |= (uint8_t)WordLength;
                                    161 ; genPointerGet
      0097D1 C6 52 34         [ 1]  162 	ld	a, 0x5234
                                    163 ; genOr
      0097D4 1A 18            [ 1]  164 	or	a, (0x18, sp)
                                    165 ; genPointerSet
      0097D6 C7 52 34         [ 1]  166 	ld	0x5234, a
                           00003D   167 	Sstm8s_uart1$UART1_Init$21 ==.
                                    168 ;	../SPL/src/stm8s_uart1.c: 111: UART1->CR3 &= (uint8_t)(~UART1_CR3_STOP);  
                                    169 ; genPointerGet
      0097D9 C6 52 36         [ 1]  170 	ld	a, 0x5236
                                    171 ; genAnd
      0097DC A4 CF            [ 1]  172 	and	a, #0xcf
                                    173 ; genPointerSet
      0097DE C7 52 36         [ 1]  174 	ld	0x5236, a
                           000045   175 	Sstm8s_uart1$UART1_Init$22 ==.
                                    176 ;	../SPL/src/stm8s_uart1.c: 113: UART1->CR3 |= (uint8_t)StopBits;  
                                    177 ; genPointerGet
      0097E1 C6 52 36         [ 1]  178 	ld	a, 0x5236
                                    179 ; genOr
      0097E4 1A 19            [ 1]  180 	or	a, (0x19, sp)
                                    181 ; genPointerSet
      0097E6 C7 52 36         [ 1]  182 	ld	0x5236, a
                           00004D   183 	Sstm8s_uart1$UART1_Init$23 ==.
                                    184 ;	../SPL/src/stm8s_uart1.c: 116: UART1->CR1 &= (uint8_t)(~(UART1_CR1_PCEN | UART1_CR1_PS  ));  
                                    185 ; genPointerGet
      0097E9 C6 52 34         [ 1]  186 	ld	a, 0x5234
                                    187 ; genAnd
      0097EC A4 F9            [ 1]  188 	and	a, #0xf9
                                    189 ; genPointerSet
      0097EE C7 52 34         [ 1]  190 	ld	0x5234, a
                           000055   191 	Sstm8s_uart1$UART1_Init$24 ==.
                                    192 ;	../SPL/src/stm8s_uart1.c: 118: UART1->CR1 |= (uint8_t)Parity;  
                                    193 ; genPointerGet
      0097F1 C6 52 34         [ 1]  194 	ld	a, 0x5234
                                    195 ; genOr
      0097F4 1A 1A            [ 1]  196 	or	a, (0x1a, sp)
                                    197 ; genPointerSet
      0097F6 C7 52 34         [ 1]  198 	ld	0x5234, a
                           00005D   199 	Sstm8s_uart1$UART1_Init$25 ==.
                                    200 ;	../SPL/src/stm8s_uart1.c: 121: UART1->BRR1 &= (uint8_t)(~UART1_BRR1_DIVM);  
                                    201 ; genPointerGet
                                    202 ; Dummy read
      0097F9 C6 52 32         [ 1]  203 	ld	a, 0x5232
                                    204 ; genPointerSet
      0097FC 35 00 52 32      [ 1]  205 	mov	0x5232+0, #0x00
                           000064   206 	Sstm8s_uart1$UART1_Init$26 ==.
                                    207 ;	../SPL/src/stm8s_uart1.c: 123: UART1->BRR2 &= (uint8_t)(~UART1_BRR2_DIVM);  
                                    208 ; genPointerGet
      009800 C6 52 33         [ 1]  209 	ld	a, 0x5233
                                    210 ; genAnd
      009803 A4 0F            [ 1]  211 	and	a, #0x0f
                                    212 ; genPointerSet
      009805 C7 52 33         [ 1]  213 	ld	0x5233, a
                           00006C   214 	Sstm8s_uart1$UART1_Init$27 ==.
                                    215 ;	../SPL/src/stm8s_uart1.c: 125: UART1->BRR2 &= (uint8_t)(~UART1_BRR2_DIVF);  
                                    216 ; genPointerGet
      009808 C6 52 33         [ 1]  217 	ld	a, 0x5233
                                    218 ; genAnd
      00980B A4 F0            [ 1]  219 	and	a, #0xf0
                                    220 ; genPointerSet
      00980D C7 52 33         [ 1]  221 	ld	0x5233, a
                           000074   222 	Sstm8s_uart1$UART1_Init$28 ==.
                                    223 ;	../SPL/src/stm8s_uart1.c: 128: BaudRate_Mantissa    = ((uint32_t)CLK_GetClockFreq() / (BaudRate << 4));
                                    224 ; genCall
      009810 CD 93 7E         [ 4]  225 	call	_CLK_GetClockFreq
      009813 1F 10            [ 2]  226 	ldw	(0x10, sp), x
                                    227 ; genLeftShift
      009815 1E 14            [ 2]  228 	ldw	x, (0x14, sp)
      009817 1F 0A            [ 2]  229 	ldw	(0x0a, sp), x
      009819 1E 16            [ 2]  230 	ldw	x, (0x16, sp)
      00981B A6 04            [ 1]  231 	ld	a, #0x04
      00981D                        232 00127$:
      00981D 58               [ 2]  233 	sllw	x
      00981E 09 0B            [ 1]  234 	rlc	(0x0b, sp)
      009820 09 0A            [ 1]  235 	rlc	(0x0a, sp)
      009822 4A               [ 1]  236 	dec	a
      009823 26 F8            [ 1]  237 	jrne	00127$
      009825                        238 00128$:
      009825 1F 0C            [ 2]  239 	ldw	(0x0c, sp), x
                                    240 ; genIPush
      009827 1E 0C            [ 2]  241 	ldw	x, (0x0c, sp)
      009829 89               [ 2]  242 	pushw	x
                           00008E   243 	Sstm8s_uart1$UART1_Init$29 ==.
      00982A 1E 0C            [ 2]  244 	ldw	x, (0x0c, sp)
      00982C 89               [ 2]  245 	pushw	x
                           000091   246 	Sstm8s_uart1$UART1_Init$30 ==.
                                    247 ; genIPush
      00982D 1E 14            [ 2]  248 	ldw	x, (0x14, sp)
      00982F 89               [ 2]  249 	pushw	x
                           000094   250 	Sstm8s_uart1$UART1_Init$31 ==.
      009830 90 89            [ 2]  251 	pushw	y
                           000096   252 	Sstm8s_uart1$UART1_Init$32 ==.
                                    253 ; genCall
      009832 CD A4 4C         [ 4]  254 	call	__divulong
      009835 5B 08            [ 2]  255 	addw	sp, #8
                           00009B   256 	Sstm8s_uart1$UART1_Init$33 ==.
      009837 1F 10            [ 2]  257 	ldw	(0x10, sp), x
      009839 17 0E            [ 2]  258 	ldw	(0x0e, sp), y
                                    259 ; genAssign
      00983B 16 10            [ 2]  260 	ldw	y, (0x10, sp)
      00983D 17 03            [ 2]  261 	ldw	(0x03, sp), y
      00983F 16 0E            [ 2]  262 	ldw	y, (0x0e, sp)
      009841 17 01            [ 2]  263 	ldw	(0x01, sp), y
                           0000A7   264 	Sstm8s_uart1$UART1_Init$34 ==.
                                    265 ;	../SPL/src/stm8s_uart1.c: 129: BaudRate_Mantissa100 = (((uint32_t)CLK_GetClockFreq() * 100) / (BaudRate << 4));
                                    266 ; genCall
      009843 CD 93 7E         [ 4]  267 	call	_CLK_GetClockFreq
      009846 1F 10            [ 2]  268 	ldw	(0x10, sp), x
      009848 17 0E            [ 2]  269 	ldw	(0x0e, sp), y
                                    270 ; genIPush
      00984A 1E 10            [ 2]  271 	ldw	x, (0x10, sp)
      00984C 89               [ 2]  272 	pushw	x
                           0000B1   273 	Sstm8s_uart1$UART1_Init$35 ==.
      00984D 1E 10            [ 2]  274 	ldw	x, (0x10, sp)
      00984F 89               [ 2]  275 	pushw	x
                           0000B4   276 	Sstm8s_uart1$UART1_Init$36 ==.
                                    277 ; genIPush
      009850 4B 64            [ 1]  278 	push	#0x64
                           0000B6   279 	Sstm8s_uart1$UART1_Init$37 ==.
      009852 5F               [ 1]  280 	clrw	x
      009853 89               [ 2]  281 	pushw	x
                           0000B8   282 	Sstm8s_uart1$UART1_Init$38 ==.
      009854 4B 00            [ 1]  283 	push	#0x00
                           0000BA   284 	Sstm8s_uart1$UART1_Init$39 ==.
                                    285 ; genCall
      009856 CD A4 CA         [ 4]  286 	call	__mullong
      009859 5B 08            [ 2]  287 	addw	sp, #8
                           0000BF   288 	Sstm8s_uart1$UART1_Init$40 ==.
      00985B 1F 10            [ 2]  289 	ldw	(0x10, sp), x
                                    290 ; genIPush
      00985D 1E 0C            [ 2]  291 	ldw	x, (0x0c, sp)
      00985F 89               [ 2]  292 	pushw	x
                           0000C4   293 	Sstm8s_uart1$UART1_Init$41 ==.
      009860 1E 0C            [ 2]  294 	ldw	x, (0x0c, sp)
      009862 89               [ 2]  295 	pushw	x
                           0000C7   296 	Sstm8s_uart1$UART1_Init$42 ==.
                                    297 ; genIPush
      009863 1E 14            [ 2]  298 	ldw	x, (0x14, sp)
      009865 89               [ 2]  299 	pushw	x
                           0000CA   300 	Sstm8s_uart1$UART1_Init$43 ==.
      009866 90 89            [ 2]  301 	pushw	y
                           0000CC   302 	Sstm8s_uart1$UART1_Init$44 ==.
                                    303 ; genCall
      009868 CD A4 4C         [ 4]  304 	call	__divulong
      00986B 5B 08            [ 2]  305 	addw	sp, #8
                           0000D1   306 	Sstm8s_uart1$UART1_Init$45 ==.
                                    307 ; genAssign
      00986D 1F 07            [ 2]  308 	ldw	(0x07, sp), x
      00986F 17 05            [ 2]  309 	ldw	(0x05, sp), y
                           0000D5   310 	Sstm8s_uart1$UART1_Init$46 ==.
                                    311 ;	../SPL/src/stm8s_uart1.c: 131: UART1->BRR2 |= (uint8_t)((uint8_t)(((BaudRate_Mantissa100 - (BaudRate_Mantissa * 100)) << 4) / 100) & (uint8_t)0x0F); 
                                    312 ; genPointerGet
      009871 C6 52 33         [ 1]  313 	ld	a, 0x5233
      009874 6B 09            [ 1]  314 	ld	(0x09, sp), a
                                    315 ; genIPush
      009876 1E 03            [ 2]  316 	ldw	x, (0x03, sp)
      009878 89               [ 2]  317 	pushw	x
                           0000DD   318 	Sstm8s_uart1$UART1_Init$47 ==.
      009879 1E 03            [ 2]  319 	ldw	x, (0x03, sp)
      00987B 89               [ 2]  320 	pushw	x
                           0000E0   321 	Sstm8s_uart1$UART1_Init$48 ==.
                                    322 ; genIPush
      00987C 4B 64            [ 1]  323 	push	#0x64
                           0000E2   324 	Sstm8s_uart1$UART1_Init$49 ==.
      00987E 5F               [ 1]  325 	clrw	x
      00987F 89               [ 2]  326 	pushw	x
                           0000E4   327 	Sstm8s_uart1$UART1_Init$50 ==.
      009880 4B 00            [ 1]  328 	push	#0x00
                           0000E6   329 	Sstm8s_uart1$UART1_Init$51 ==.
                                    330 ; genCall
      009882 CD A4 CA         [ 4]  331 	call	__mullong
      009885 5B 08            [ 2]  332 	addw	sp, #8
                           0000EB   333 	Sstm8s_uart1$UART1_Init$52 ==.
      009887 1F 0C            [ 2]  334 	ldw	(0x0c, sp), x
      009889 17 0A            [ 2]  335 	ldw	(0x0a, sp), y
                                    336 ; genMinus
      00988B 1E 07            [ 2]  337 	ldw	x, (0x07, sp)
      00988D 72 F0 0C         [ 2]  338 	subw	x, (0x0c, sp)
      009890 1F 10            [ 2]  339 	ldw	(0x10, sp), x
      009892 7B 06            [ 1]  340 	ld	a, (0x06, sp)
      009894 12 0B            [ 1]  341 	sbc	a, (0x0b, sp)
      009896 6B 0F            [ 1]  342 	ld	(0x0f, sp), a
      009898 7B 05            [ 1]  343 	ld	a, (0x05, sp)
      00989A 12 0A            [ 1]  344 	sbc	a, (0x0a, sp)
      00989C 6B 0E            [ 1]  345 	ld	(0x0e, sp), a
                                    346 ; genLeftShift
      00989E 1E 10            [ 2]  347 	ldw	x, (0x10, sp)
      0098A0 16 0E            [ 2]  348 	ldw	y, (0x0e, sp)
      0098A2 A6 04            [ 1]  349 	ld	a, #0x04
      0098A4                        350 00129$:
      0098A4 58               [ 2]  351 	sllw	x
      0098A5 90 59            [ 2]  352 	rlcw	y
      0098A7 4A               [ 1]  353 	dec	a
      0098A8 26 FA            [ 1]  354 	jrne	00129$
      0098AA                        355 00130$:
                                    356 ; genIPush
      0098AA 4B 64            [ 1]  357 	push	#0x64
                           000110   358 	Sstm8s_uart1$UART1_Init$53 ==.
      0098AC 4B 00            [ 1]  359 	push	#0x00
                           000112   360 	Sstm8s_uart1$UART1_Init$54 ==.
      0098AE 4B 00            [ 1]  361 	push	#0x00
                           000114   362 	Sstm8s_uart1$UART1_Init$55 ==.
      0098B0 4B 00            [ 1]  363 	push	#0x00
                           000116   364 	Sstm8s_uart1$UART1_Init$56 ==.
                                    365 ; genIPush
      0098B2 89               [ 2]  366 	pushw	x
                           000117   367 	Sstm8s_uart1$UART1_Init$57 ==.
      0098B3 90 89            [ 2]  368 	pushw	y
                           000119   369 	Sstm8s_uart1$UART1_Init$58 ==.
                                    370 ; genCall
      0098B5 CD A4 4C         [ 4]  371 	call	__divulong
      0098B8 5B 08            [ 2]  372 	addw	sp, #8
                           00011E   373 	Sstm8s_uart1$UART1_Init$59 ==.
      0098BA 9F               [ 1]  374 	ld	a, xl
                                    375 ; genCast
                                    376 ; genAssign
                                    377 ; genAnd
      0098BB A4 0F            [ 1]  378 	and	a, #0x0f
                                    379 ; genOr
      0098BD 1A 09            [ 1]  380 	or	a, (0x09, sp)
                                    381 ; genPointerSet
      0098BF C7 52 33         [ 1]  382 	ld	0x5233, a
                           000126   383 	Sstm8s_uart1$UART1_Init$60 ==.
                                    384 ;	../SPL/src/stm8s_uart1.c: 133: UART1->BRR2 |= (uint8_t)((BaudRate_Mantissa >> 4) & (uint8_t)0xF0); 
                                    385 ; genPointerGet
      0098C2 C6 52 33         [ 1]  386 	ld	a, 0x5233
      0098C5 6B 11            [ 1]  387 	ld	(0x11, sp), a
                                    388 ; genCast
                                    389 ; genAssign
      0098C7 1E 03            [ 2]  390 	ldw	x, (0x03, sp)
                                    391 ; genRightShiftLiteral
      0098C9 A6 10            [ 1]  392 	ld	a, #0x10
      0098CB 62               [ 2]  393 	div	x, a
                                    394 ; genCast
                                    395 ; genAssign
      0098CC 9F               [ 1]  396 	ld	a, xl
                                    397 ; genAnd
      0098CD A4 F0            [ 1]  398 	and	a, #0xf0
                                    399 ; genOr
      0098CF 1A 11            [ 1]  400 	or	a, (0x11, sp)
                                    401 ; genPointerSet
      0098D1 C7 52 33         [ 1]  402 	ld	0x5233, a
                           000138   403 	Sstm8s_uart1$UART1_Init$61 ==.
                                    404 ;	../SPL/src/stm8s_uart1.c: 135: UART1->BRR1 |= (uint8_t)BaudRate_Mantissa;           
                                    405 ; genPointerGet
      0098D4 C6 52 32         [ 1]  406 	ld	a, 0x5232
      0098D7 6B 11            [ 1]  407 	ld	(0x11, sp), a
                                    408 ; genCast
                                    409 ; genAssign
      0098D9 7B 04            [ 1]  410 	ld	a, (0x04, sp)
                                    411 ; genOr
      0098DB 1A 11            [ 1]  412 	or	a, (0x11, sp)
                                    413 ; genPointerSet
      0098DD C7 52 32         [ 1]  414 	ld	0x5232, a
                           000144   415 	Sstm8s_uart1$UART1_Init$62 ==.
                                    416 ;	../SPL/src/stm8s_uart1.c: 138: UART1->CR2 &= (uint8_t)~(UART1_CR2_TEN | UART1_CR2_REN); 
                                    417 ; genPointerGet
      0098E0 C6 52 35         [ 1]  418 	ld	a, 0x5235
                                    419 ; genAnd
      0098E3 A4 F3            [ 1]  420 	and	a, #0xf3
                                    421 ; genPointerSet
      0098E5 C7 52 35         [ 1]  422 	ld	0x5235, a
                           00014C   423 	Sstm8s_uart1$UART1_Init$63 ==.
                                    424 ;	../SPL/src/stm8s_uart1.c: 140: UART1->CR3 &= (uint8_t)~(UART1_CR3_CPOL | UART1_CR3_CPHA | UART1_CR3_LBCL); 
                                    425 ; genPointerGet
      0098E8 C6 52 36         [ 1]  426 	ld	a, 0x5236
                                    427 ; genAnd
      0098EB A4 F8            [ 1]  428 	and	a, #0xf8
                                    429 ; genPointerSet
      0098ED C7 52 36         [ 1]  430 	ld	0x5236, a
                           000154   431 	Sstm8s_uart1$UART1_Init$64 ==.
                                    432 ;	../SPL/src/stm8s_uart1.c: 142: UART1->CR3 |= (uint8_t)((uint8_t)SyncMode & (uint8_t)(UART1_CR3_CPOL | 
                                    433 ; genPointerGet
      0098F0 C6 52 36         [ 1]  434 	ld	a, 0x5236
      0098F3 6B 11            [ 1]  435 	ld	(0x11, sp), a
                                    436 ; genAnd
      0098F5 7B 1B            [ 1]  437 	ld	a, (0x1b, sp)
      0098F7 A4 07            [ 1]  438 	and	a, #0x07
                                    439 ; genOr
      0098F9 1A 11            [ 1]  440 	or	a, (0x11, sp)
                                    441 ; genPointerSet
      0098FB C7 52 36         [ 1]  442 	ld	0x5236, a
                           000162   443 	Sstm8s_uart1$UART1_Init$65 ==.
                                    444 ;	../SPL/src/stm8s_uart1.c: 138: UART1->CR2 &= (uint8_t)~(UART1_CR2_TEN | UART1_CR2_REN); 
                                    445 ; genPointerGet
      0098FE C6 52 35         [ 1]  446 	ld	a, 0x5235
                           000165   447 	Sstm8s_uart1$UART1_Init$66 ==.
                                    448 ;	../SPL/src/stm8s_uart1.c: 145: if ((uint8_t)(Mode & UART1_MODE_TX_ENABLE))
                                    449 ; genAnd
      009901 88               [ 1]  450 	push	a
                           000166   451 	Sstm8s_uart1$UART1_Init$67 ==.
      009902 7B 1D            [ 1]  452 	ld	a, (0x1d, sp)
      009904 A5 04            [ 1]  453 	bcp	a, #0x04
      009906 84               [ 1]  454 	pop	a
                           00016B   455 	Sstm8s_uart1$UART1_Init$68 ==.
      009907 26 03            [ 1]  456 	jrne	00131$
      009909 CC 99 14         [ 2]  457 	jp	00102$
      00990C                        458 00131$:
                                    459 ; skipping generated iCode
                           000170   460 	Sstm8s_uart1$UART1_Init$69 ==.
                           000170   461 	Sstm8s_uart1$UART1_Init$70 ==.
                                    462 ;	../SPL/src/stm8s_uart1.c: 148: UART1->CR2 |= (uint8_t)UART1_CR2_TEN;  
                                    463 ; genOr
      00990C AA 08            [ 1]  464 	or	a, #0x08
                                    465 ; genPointerSet
      00990E C7 52 35         [ 1]  466 	ld	0x5235, a
                           000175   467 	Sstm8s_uart1$UART1_Init$71 ==.
                                    468 ; genGoto
      009911 CC 99 19         [ 2]  469 	jp	00103$
                                    470 ; genLabel
      009914                        471 00102$:
                           000178   472 	Sstm8s_uart1$UART1_Init$72 ==.
                           000178   473 	Sstm8s_uart1$UART1_Init$73 ==.
                                    474 ;	../SPL/src/stm8s_uart1.c: 153: UART1->CR2 &= (uint8_t)(~UART1_CR2_TEN);  
                                    475 ; genAnd
      009914 A4 F7            [ 1]  476 	and	a, #0xf7
                                    477 ; genPointerSet
      009916 C7 52 35         [ 1]  478 	ld	0x5235, a
                           00017D   479 	Sstm8s_uart1$UART1_Init$74 ==.
                                    480 ; genLabel
      009919                        481 00103$:
                           00017D   482 	Sstm8s_uart1$UART1_Init$75 ==.
                                    483 ;	../SPL/src/stm8s_uart1.c: 138: UART1->CR2 &= (uint8_t)~(UART1_CR2_TEN | UART1_CR2_REN); 
                                    484 ; genPointerGet
      009919 C6 52 35         [ 1]  485 	ld	a, 0x5235
                           000180   486 	Sstm8s_uart1$UART1_Init$76 ==.
                                    487 ;	../SPL/src/stm8s_uart1.c: 155: if ((uint8_t)(Mode & UART1_MODE_RX_ENABLE))
                                    488 ; genAnd
      00991C 88               [ 1]  489 	push	a
                           000181   490 	Sstm8s_uart1$UART1_Init$77 ==.
      00991D 7B 1D            [ 1]  491 	ld	a, (0x1d, sp)
      00991F A5 08            [ 1]  492 	bcp	a, #0x08
      009921 84               [ 1]  493 	pop	a
                           000186   494 	Sstm8s_uart1$UART1_Init$78 ==.
      009922 26 03            [ 1]  495 	jrne	00132$
      009924 CC 99 2F         [ 2]  496 	jp	00105$
      009927                        497 00132$:
                                    498 ; skipping generated iCode
                           00018B   499 	Sstm8s_uart1$UART1_Init$79 ==.
                           00018B   500 	Sstm8s_uart1$UART1_Init$80 ==.
                                    501 ;	../SPL/src/stm8s_uart1.c: 158: UART1->CR2 |= (uint8_t)UART1_CR2_REN;  
                                    502 ; genOr
      009927 AA 04            [ 1]  503 	or	a, #0x04
                                    504 ; genPointerSet
      009929 C7 52 35         [ 1]  505 	ld	0x5235, a
                           000190   506 	Sstm8s_uart1$UART1_Init$81 ==.
                                    507 ; genGoto
      00992C CC 99 34         [ 2]  508 	jp	00106$
                                    509 ; genLabel
      00992F                        510 00105$:
                           000193   511 	Sstm8s_uart1$UART1_Init$82 ==.
                           000193   512 	Sstm8s_uart1$UART1_Init$83 ==.
                                    513 ;	../SPL/src/stm8s_uart1.c: 163: UART1->CR2 &= (uint8_t)(~UART1_CR2_REN);  
                                    514 ; genAnd
      00992F A4 FB            [ 1]  515 	and	a, #0xfb
                                    516 ; genPointerSet
      009931 C7 52 35         [ 1]  517 	ld	0x5235, a
                           000198   518 	Sstm8s_uart1$UART1_Init$84 ==.
                                    519 ; genLabel
      009934                        520 00106$:
                           000198   521 	Sstm8s_uart1$UART1_Init$85 ==.
                                    522 ;	../SPL/src/stm8s_uart1.c: 111: UART1->CR3 &= (uint8_t)(~UART1_CR3_STOP);  
                                    523 ; genPointerGet
      009934 C6 52 36         [ 1]  524 	ld	a, 0x5236
                           00019B   525 	Sstm8s_uart1$UART1_Init$86 ==.
                                    526 ;	../SPL/src/stm8s_uart1.c: 167: if ((uint8_t)(SyncMode & UART1_SYNCMODE_CLOCK_DISABLE))
                                    527 ; genAnd
      009937 0D 1B            [ 1]  528 	tnz	(0x1b, sp)
      009939 2B 03            [ 1]  529 	jrmi	00133$
      00993B CC 99 46         [ 2]  530 	jp	00108$
      00993E                        531 00133$:
                                    532 ; skipping generated iCode
                           0001A2   533 	Sstm8s_uart1$UART1_Init$87 ==.
                           0001A2   534 	Sstm8s_uart1$UART1_Init$88 ==.
                                    535 ;	../SPL/src/stm8s_uart1.c: 170: UART1->CR3 &= (uint8_t)(~UART1_CR3_CKEN); 
                                    536 ; genAnd
      00993E A4 F7            [ 1]  537 	and	a, #0xf7
                                    538 ; genPointerSet
      009940 C7 52 36         [ 1]  539 	ld	0x5236, a
                           0001A7   540 	Sstm8s_uart1$UART1_Init$89 ==.
                                    541 ; genGoto
      009943 CC 99 53         [ 2]  542 	jp	00110$
                                    543 ; genLabel
      009946                        544 00108$:
                           0001AA   545 	Sstm8s_uart1$UART1_Init$90 ==.
                           0001AA   546 	Sstm8s_uart1$UART1_Init$91 ==.
                                    547 ;	../SPL/src/stm8s_uart1.c: 174: UART1->CR3 |= (uint8_t)((uint8_t)SyncMode & UART1_CR3_CKEN);
                                    548 ; genAnd
      009946 88               [ 1]  549 	push	a
                           0001AB   550 	Sstm8s_uart1$UART1_Init$92 ==.
      009947 7B 1C            [ 1]  551 	ld	a, (0x1c, sp)
      009949 A4 08            [ 1]  552 	and	a, #0x08
      00994B 6B 12            [ 1]  553 	ld	(0x12, sp), a
      00994D 84               [ 1]  554 	pop	a
                           0001B2   555 	Sstm8s_uart1$UART1_Init$93 ==.
                                    556 ; genOr
      00994E 1A 11            [ 1]  557 	or	a, (0x11, sp)
                                    558 ; genPointerSet
      009950 C7 52 36         [ 1]  559 	ld	0x5236, a
                           0001B7   560 	Sstm8s_uart1$UART1_Init$94 ==.
                                    561 ; genLabel
      009953                        562 00110$:
                           0001B7   563 	Sstm8s_uart1$UART1_Init$95 ==.
                                    564 ;	../SPL/src/stm8s_uart1.c: 176: }
                                    565 ; genEndFunction
      009953 5B 11            [ 2]  566 	addw	sp, #17
                           0001B9   567 	Sstm8s_uart1$UART1_Init$96 ==.
                           0001B9   568 	Sstm8s_uart1$UART1_Init$97 ==.
                           0001B9   569 	XG$UART1_Init$0$0 ==.
      009955 81               [ 4]  570 	ret
                           0001BA   571 	Sstm8s_uart1$UART1_Init$98 ==.
                           0001BA   572 	Sstm8s_uart1$UART1_Cmd$99 ==.
                                    573 ;	../SPL/src/stm8s_uart1.c: 184: void UART1_Cmd(FunctionalState NewState)
                                    574 ; genLabel
                                    575 ;	-----------------------------------------
                                    576 ;	 function UART1_Cmd
                                    577 ;	-----------------------------------------
                                    578 ;	Register assignment is optimal.
                                    579 ;	Stack space usage: 0 bytes.
      009956                        580 _UART1_Cmd:
                           0001BA   581 	Sstm8s_uart1$UART1_Cmd$100 ==.
                           0001BA   582 	Sstm8s_uart1$UART1_Cmd$101 ==.
                                    583 ;	../SPL/src/stm8s_uart1.c: 189: UART1->CR1 &= (uint8_t)(~UART1_CR1_UARTD); 
                                    584 ; genPointerGet
      009956 C6 52 34         [ 1]  585 	ld	a, 0x5234
                           0001BD   586 	Sstm8s_uart1$UART1_Cmd$102 ==.
                                    587 ;	../SPL/src/stm8s_uart1.c: 186: if (NewState != DISABLE)
                                    588 ; genIfx
      009959 0D 03            [ 1]  589 	tnz	(0x03, sp)
      00995B 26 03            [ 1]  590 	jrne	00111$
      00995D CC 99 68         [ 2]  591 	jp	00102$
      009960                        592 00111$:
                           0001C4   593 	Sstm8s_uart1$UART1_Cmd$103 ==.
                           0001C4   594 	Sstm8s_uart1$UART1_Cmd$104 ==.
                                    595 ;	../SPL/src/stm8s_uart1.c: 189: UART1->CR1 &= (uint8_t)(~UART1_CR1_UARTD); 
                                    596 ; genAnd
      009960 A4 DF            [ 1]  597 	and	a, #0xdf
                                    598 ; genPointerSet
      009962 C7 52 34         [ 1]  599 	ld	0x5234, a
                           0001C9   600 	Sstm8s_uart1$UART1_Cmd$105 ==.
                                    601 ; genGoto
      009965 CC 99 6D         [ 2]  602 	jp	00104$
                                    603 ; genLabel
      009968                        604 00102$:
                           0001CC   605 	Sstm8s_uart1$UART1_Cmd$106 ==.
                           0001CC   606 	Sstm8s_uart1$UART1_Cmd$107 ==.
                                    607 ;	../SPL/src/stm8s_uart1.c: 194: UART1->CR1 |= UART1_CR1_UARTD;  
                                    608 ; genOr
      009968 AA 20            [ 1]  609 	or	a, #0x20
                                    610 ; genPointerSet
      00996A C7 52 34         [ 1]  611 	ld	0x5234, a
                           0001D1   612 	Sstm8s_uart1$UART1_Cmd$108 ==.
                                    613 ; genLabel
      00996D                        614 00104$:
                           0001D1   615 	Sstm8s_uart1$UART1_Cmd$109 ==.
                                    616 ;	../SPL/src/stm8s_uart1.c: 196: }
                                    617 ; genEndFunction
                           0001D1   618 	Sstm8s_uart1$UART1_Cmd$110 ==.
                           0001D1   619 	XG$UART1_Cmd$0$0 ==.
      00996D 81               [ 4]  620 	ret
                           0001D2   621 	Sstm8s_uart1$UART1_Cmd$111 ==.
                           0001D2   622 	Sstm8s_uart1$UART1_ITConfig$112 ==.
                                    623 ;	../SPL/src/stm8s_uart1.c: 211: void UART1_ITConfig(UART1_IT_TypeDef UART1_IT, FunctionalState NewState)
                                    624 ; genLabel
                                    625 ;	-----------------------------------------
                                    626 ;	 function UART1_ITConfig
                                    627 ;	-----------------------------------------
                                    628 ;	Register assignment might be sub-optimal.
                                    629 ;	Stack space usage: 2 bytes.
      00996E                        630 _UART1_ITConfig:
                           0001D2   631 	Sstm8s_uart1$UART1_ITConfig$113 ==.
      00996E 89               [ 2]  632 	pushw	x
                           0001D3   633 	Sstm8s_uart1$UART1_ITConfig$114 ==.
                           0001D3   634 	Sstm8s_uart1$UART1_ITConfig$115 ==.
                                    635 ;	../SPL/src/stm8s_uart1.c: 220: uartreg = (uint8_t)((uint16_t)UART1_IT >> 0x08);
                                    636 ; genCast
                                    637 ; genAssign
      00996F 1E 05            [ 2]  638 	ldw	x, (0x05, sp)
                                    639 ; genRightShiftLiteral
      009971 4F               [ 1]  640 	clr	a
                                    641 ; genCast
                                    642 ; genAssign
                           0001D6   643 	Sstm8s_uart1$UART1_ITConfig$116 ==.
                                    644 ;	../SPL/src/stm8s_uart1.c: 222: itpos = (uint8_t)((uint8_t)1 << (uint8_t)((uint8_t)UART1_IT & (uint8_t)0x0F));
                                    645 ; genCast
                                    646 ; genAssign
      009972 7B 06            [ 1]  647 	ld	a, (0x06, sp)
                                    648 ; genAnd
      009974 A4 0F            [ 1]  649 	and	a, #0x0f
                                    650 ; genLeftShift
      009976 88               [ 1]  651 	push	a
                           0001DB   652 	Sstm8s_uart1$UART1_ITConfig$117 ==.
      009977 A6 01            [ 1]  653 	ld	a, #0x01
      009979 6B 03            [ 1]  654 	ld	(0x03, sp), a
      00997B 84               [ 1]  655 	pop	a
                           0001E0   656 	Sstm8s_uart1$UART1_ITConfig$118 ==.
      00997C 4D               [ 1]  657 	tnz	a
      00997D 27 05            [ 1]  658 	jreq	00144$
      00997F                        659 00143$:
      00997F 08 02            [ 1]  660 	sll	(0x02, sp)
      009981 4A               [ 1]  661 	dec	a
      009982 26 FB            [ 1]  662 	jrne	00143$
      009984                        663 00144$:
                           0001E8   664 	Sstm8s_uart1$UART1_ITConfig$119 ==.
                                    665 ;	../SPL/src/stm8s_uart1.c: 227: if (uartreg == 0x01)
                                    666 ; genCmpEQorNE
      009984 9E               [ 1]  667 	ld	a, xh
      009985 4A               [ 1]  668 	dec	a
      009986 26 07            [ 1]  669 	jrne	00146$
      009988 A6 01            [ 1]  670 	ld	a, #0x01
      00998A 6B 01            [ 1]  671 	ld	(0x01, sp), a
      00998C CC 99 91         [ 2]  672 	jp	00147$
      00998F                        673 00146$:
      00998F 0F 01            [ 1]  674 	clr	(0x01, sp)
      009991                        675 00147$:
                           0001F5   676 	Sstm8s_uart1$UART1_ITConfig$120 ==.
                           0001F5   677 	Sstm8s_uart1$UART1_ITConfig$121 ==.
                                    678 ;	../SPL/src/stm8s_uart1.c: 231: else if (uartreg == 0x02)
                                    679 ; genCmpEQorNE
      009991 9E               [ 1]  680 	ld	a, xh
      009992 A1 02            [ 1]  681 	cp	a, #0x02
      009994 26 05            [ 1]  682 	jrne	00149$
      009996 A6 01            [ 1]  683 	ld	a, #0x01
      009998 CC 99 9C         [ 2]  684 	jp	00150$
      00999B                        685 00149$:
      00999B 4F               [ 1]  686 	clr	a
      00999C                        687 00150$:
                           000200   688 	Sstm8s_uart1$UART1_ITConfig$122 ==.
                           000200   689 	Sstm8s_uart1$UART1_ITConfig$123 ==.
                                    690 ;	../SPL/src/stm8s_uart1.c: 224: if (NewState != DISABLE)
                                    691 ; genIfx
      00999C 0D 07            [ 1]  692 	tnz	(0x07, sp)
      00999E 26 03            [ 1]  693 	jrne	00151$
      0099A0 CC 99 D1         [ 2]  694 	jp	00114$
      0099A3                        695 00151$:
                           000207   696 	Sstm8s_uart1$UART1_ITConfig$124 ==.
                           000207   697 	Sstm8s_uart1$UART1_ITConfig$125 ==.
                                    698 ;	../SPL/src/stm8s_uart1.c: 227: if (uartreg == 0x01)
                                    699 ; genIfx
      0099A3 0D 01            [ 1]  700 	tnz	(0x01, sp)
      0099A5 26 03            [ 1]  701 	jrne	00152$
      0099A7 CC 99 B5         [ 2]  702 	jp	00105$
      0099AA                        703 00152$:
                           00020E   704 	Sstm8s_uart1$UART1_ITConfig$126 ==.
                           00020E   705 	Sstm8s_uart1$UART1_ITConfig$127 ==.
                                    706 ;	../SPL/src/stm8s_uart1.c: 229: UART1->CR1 |= itpos;
                                    707 ; genPointerGet
      0099AA C6 52 34         [ 1]  708 	ld	a, 0x5234
                                    709 ; genOr
      0099AD 1A 02            [ 1]  710 	or	a, (0x02, sp)
                                    711 ; genPointerSet
      0099AF C7 52 34         [ 1]  712 	ld	0x5234, a
                           000216   713 	Sstm8s_uart1$UART1_ITConfig$128 ==.
                                    714 ; genGoto
      0099B2 CC 9A 00         [ 2]  715 	jp	00116$
                                    716 ; genLabel
      0099B5                        717 00105$:
                           000219   718 	Sstm8s_uart1$UART1_ITConfig$129 ==.
                                    719 ;	../SPL/src/stm8s_uart1.c: 231: else if (uartreg == 0x02)
                                    720 ; genIfx
      0099B5 4D               [ 1]  721 	tnz	a
      0099B6 26 03            [ 1]  722 	jrne	00153$
      0099B8 CC 99 C6         [ 2]  723 	jp	00102$
      0099BB                        724 00153$:
                           00021F   725 	Sstm8s_uart1$UART1_ITConfig$130 ==.
                           00021F   726 	Sstm8s_uart1$UART1_ITConfig$131 ==.
                                    727 ;	../SPL/src/stm8s_uart1.c: 233: UART1->CR2 |= itpos;
                                    728 ; genPointerGet
      0099BB C6 52 35         [ 1]  729 	ld	a, 0x5235
                                    730 ; genOr
      0099BE 1A 02            [ 1]  731 	or	a, (0x02, sp)
                                    732 ; genPointerSet
      0099C0 C7 52 35         [ 1]  733 	ld	0x5235, a
                           000227   734 	Sstm8s_uart1$UART1_ITConfig$132 ==.
                                    735 ; genGoto
      0099C3 CC 9A 00         [ 2]  736 	jp	00116$
                                    737 ; genLabel
      0099C6                        738 00102$:
                           00022A   739 	Sstm8s_uart1$UART1_ITConfig$133 ==.
                           00022A   740 	Sstm8s_uart1$UART1_ITConfig$134 ==.
                                    741 ;	../SPL/src/stm8s_uart1.c: 237: UART1->CR4 |= itpos;
                                    742 ; genPointerGet
      0099C6 C6 52 37         [ 1]  743 	ld	a, 0x5237
                                    744 ; genOr
      0099C9 1A 02            [ 1]  745 	or	a, (0x02, sp)
                                    746 ; genPointerSet
      0099CB C7 52 37         [ 1]  747 	ld	0x5237, a
                           000232   748 	Sstm8s_uart1$UART1_ITConfig$135 ==.
                                    749 ; genGoto
      0099CE CC 9A 00         [ 2]  750 	jp	00116$
                                    751 ; genLabel
      0099D1                        752 00114$:
                           000235   753 	Sstm8s_uart1$UART1_ITConfig$136 ==.
                                    754 ;	../SPL/src/stm8s_uart1.c: 245: UART1->CR1 &= (uint8_t)(~itpos);
                                    755 ; genCpl
      0099D1 88               [ 1]  756 	push	a
                           000236   757 	Sstm8s_uart1$UART1_ITConfig$137 ==.
      0099D2 03 03            [ 1]  758 	cpl	(0x03, sp)
      0099D4 84               [ 1]  759 	pop	a
                           000239   760 	Sstm8s_uart1$UART1_ITConfig$138 ==.
                           000239   761 	Sstm8s_uart1$UART1_ITConfig$139 ==.
                           000239   762 	Sstm8s_uart1$UART1_ITConfig$140 ==.
                                    763 ;	../SPL/src/stm8s_uart1.c: 243: if (uartreg == 0x01)
                                    764 ; genIfx
      0099D5 0D 01            [ 1]  765 	tnz	(0x01, sp)
      0099D7 26 03            [ 1]  766 	jrne	00154$
      0099D9 CC 99 E7         [ 2]  767 	jp	00111$
      0099DC                        768 00154$:
                           000240   769 	Sstm8s_uart1$UART1_ITConfig$141 ==.
                           000240   770 	Sstm8s_uart1$UART1_ITConfig$142 ==.
                                    771 ;	../SPL/src/stm8s_uart1.c: 245: UART1->CR1 &= (uint8_t)(~itpos);
                                    772 ; genPointerGet
      0099DC C6 52 34         [ 1]  773 	ld	a, 0x5234
                                    774 ; genAnd
      0099DF 14 02            [ 1]  775 	and	a, (0x02, sp)
                                    776 ; genPointerSet
      0099E1 C7 52 34         [ 1]  777 	ld	0x5234, a
                           000248   778 	Sstm8s_uart1$UART1_ITConfig$143 ==.
                                    779 ; genGoto
      0099E4 CC 9A 00         [ 2]  780 	jp	00116$
                                    781 ; genLabel
      0099E7                        782 00111$:
                           00024B   783 	Sstm8s_uart1$UART1_ITConfig$144 ==.
                                    784 ;	../SPL/src/stm8s_uart1.c: 247: else if (uartreg == 0x02)
                                    785 ; genIfx
      0099E7 4D               [ 1]  786 	tnz	a
      0099E8 26 03            [ 1]  787 	jrne	00155$
      0099EA CC 99 F8         [ 2]  788 	jp	00108$
      0099ED                        789 00155$:
                           000251   790 	Sstm8s_uart1$UART1_ITConfig$145 ==.
                           000251   791 	Sstm8s_uart1$UART1_ITConfig$146 ==.
                                    792 ;	../SPL/src/stm8s_uart1.c: 249: UART1->CR2 &= (uint8_t)(~itpos);
                                    793 ; genPointerGet
      0099ED C6 52 35         [ 1]  794 	ld	a, 0x5235
                                    795 ; genAnd
      0099F0 14 02            [ 1]  796 	and	a, (0x02, sp)
                                    797 ; genPointerSet
      0099F2 C7 52 35         [ 1]  798 	ld	0x5235, a
                           000259   799 	Sstm8s_uart1$UART1_ITConfig$147 ==.
                                    800 ; genGoto
      0099F5 CC 9A 00         [ 2]  801 	jp	00116$
                                    802 ; genLabel
      0099F8                        803 00108$:
                           00025C   804 	Sstm8s_uart1$UART1_ITConfig$148 ==.
                           00025C   805 	Sstm8s_uart1$UART1_ITConfig$149 ==.
                                    806 ;	../SPL/src/stm8s_uart1.c: 253: UART1->CR4 &= (uint8_t)(~itpos);
                                    807 ; genPointerGet
      0099F8 C6 52 37         [ 1]  808 	ld	a, 0x5237
                                    809 ; genAnd
      0099FB 14 02            [ 1]  810 	and	a, (0x02, sp)
                                    811 ; genPointerSet
      0099FD C7 52 37         [ 1]  812 	ld	0x5237, a
                           000264   813 	Sstm8s_uart1$UART1_ITConfig$150 ==.
                                    814 ; genLabel
      009A00                        815 00116$:
                           000264   816 	Sstm8s_uart1$UART1_ITConfig$151 ==.
                                    817 ;	../SPL/src/stm8s_uart1.c: 257: }
                                    818 ; genEndFunction
      009A00 85               [ 2]  819 	popw	x
                           000265   820 	Sstm8s_uart1$UART1_ITConfig$152 ==.
                           000265   821 	Sstm8s_uart1$UART1_ITConfig$153 ==.
                           000265   822 	XG$UART1_ITConfig$0$0 ==.
      009A01 81               [ 4]  823 	ret
                           000266   824 	Sstm8s_uart1$UART1_ITConfig$154 ==.
                           000266   825 	Sstm8s_uart1$UART1_HalfDuplexCmd$155 ==.
                                    826 ;	../SPL/src/stm8s_uart1.c: 265: void UART1_HalfDuplexCmd(FunctionalState NewState)
                                    827 ; genLabel
                                    828 ;	-----------------------------------------
                                    829 ;	 function UART1_HalfDuplexCmd
                                    830 ;	-----------------------------------------
                                    831 ;	Register assignment is optimal.
                                    832 ;	Stack space usage: 0 bytes.
      009A02                        833 _UART1_HalfDuplexCmd:
                           000266   834 	Sstm8s_uart1$UART1_HalfDuplexCmd$156 ==.
                           000266   835 	Sstm8s_uart1$UART1_HalfDuplexCmd$157 ==.
                                    836 ;	../SPL/src/stm8s_uart1.c: 271: UART1->CR5 |= UART1_CR5_HDSEL;  /**< UART1 Half Duplex Enable  */
                                    837 ; genPointerGet
      009A02 C6 52 38         [ 1]  838 	ld	a, 0x5238
                           000269   839 	Sstm8s_uart1$UART1_HalfDuplexCmd$158 ==.
                                    840 ;	../SPL/src/stm8s_uart1.c: 269: if (NewState != DISABLE)
                                    841 ; genIfx
      009A05 0D 03            [ 1]  842 	tnz	(0x03, sp)
      009A07 26 03            [ 1]  843 	jrne	00111$
      009A09 CC 9A 14         [ 2]  844 	jp	00102$
      009A0C                        845 00111$:
                           000270   846 	Sstm8s_uart1$UART1_HalfDuplexCmd$159 ==.
                           000270   847 	Sstm8s_uart1$UART1_HalfDuplexCmd$160 ==.
                                    848 ;	../SPL/src/stm8s_uart1.c: 271: UART1->CR5 |= UART1_CR5_HDSEL;  /**< UART1 Half Duplex Enable  */
                                    849 ; genOr
      009A0C AA 08            [ 1]  850 	or	a, #0x08
                                    851 ; genPointerSet
      009A0E C7 52 38         [ 1]  852 	ld	0x5238, a
                           000275   853 	Sstm8s_uart1$UART1_HalfDuplexCmd$161 ==.
                                    854 ; genGoto
      009A11 CC 9A 19         [ 2]  855 	jp	00104$
                                    856 ; genLabel
      009A14                        857 00102$:
                           000278   858 	Sstm8s_uart1$UART1_HalfDuplexCmd$162 ==.
                           000278   859 	Sstm8s_uart1$UART1_HalfDuplexCmd$163 ==.
                                    860 ;	../SPL/src/stm8s_uart1.c: 275: UART1->CR5 &= (uint8_t)~UART1_CR5_HDSEL; /**< UART1 Half Duplex Disable */
                                    861 ; genAnd
      009A14 A4 F7            [ 1]  862 	and	a, #0xf7
                                    863 ; genPointerSet
      009A16 C7 52 38         [ 1]  864 	ld	0x5238, a
                           00027D   865 	Sstm8s_uart1$UART1_HalfDuplexCmd$164 ==.
                                    866 ; genLabel
      009A19                        867 00104$:
                           00027D   868 	Sstm8s_uart1$UART1_HalfDuplexCmd$165 ==.
                                    869 ;	../SPL/src/stm8s_uart1.c: 277: }
                                    870 ; genEndFunction
                           00027D   871 	Sstm8s_uart1$UART1_HalfDuplexCmd$166 ==.
                           00027D   872 	XG$UART1_HalfDuplexCmd$0$0 ==.
      009A19 81               [ 4]  873 	ret
                           00027E   874 	Sstm8s_uart1$UART1_HalfDuplexCmd$167 ==.
                           00027E   875 	Sstm8s_uart1$UART1_IrDAConfig$168 ==.
                                    876 ;	../SPL/src/stm8s_uart1.c: 285: void UART1_IrDAConfig(UART1_IrDAMode_TypeDef UART1_IrDAMode)
                                    877 ; genLabel
                                    878 ;	-----------------------------------------
                                    879 ;	 function UART1_IrDAConfig
                                    880 ;	-----------------------------------------
                                    881 ;	Register assignment is optimal.
                                    882 ;	Stack space usage: 0 bytes.
      009A1A                        883 _UART1_IrDAConfig:
                           00027E   884 	Sstm8s_uart1$UART1_IrDAConfig$169 ==.
                           00027E   885 	Sstm8s_uart1$UART1_IrDAConfig$170 ==.
                                    886 ;	../SPL/src/stm8s_uart1.c: 291: UART1->CR5 |= UART1_CR5_IRLP;
                                    887 ; genPointerGet
      009A1A C6 52 38         [ 1]  888 	ld	a, 0x5238
                           000281   889 	Sstm8s_uart1$UART1_IrDAConfig$171 ==.
                                    890 ;	../SPL/src/stm8s_uart1.c: 289: if (UART1_IrDAMode != UART1_IRDAMODE_NORMAL)
                                    891 ; genIfx
      009A1D 0D 03            [ 1]  892 	tnz	(0x03, sp)
      009A1F 26 03            [ 1]  893 	jrne	00111$
      009A21 CC 9A 2C         [ 2]  894 	jp	00102$
      009A24                        895 00111$:
                           000288   896 	Sstm8s_uart1$UART1_IrDAConfig$172 ==.
                           000288   897 	Sstm8s_uart1$UART1_IrDAConfig$173 ==.
                                    898 ;	../SPL/src/stm8s_uart1.c: 291: UART1->CR5 |= UART1_CR5_IRLP;
                                    899 ; genOr
      009A24 AA 04            [ 1]  900 	or	a, #0x04
                                    901 ; genPointerSet
      009A26 C7 52 38         [ 1]  902 	ld	0x5238, a
                           00028D   903 	Sstm8s_uart1$UART1_IrDAConfig$174 ==.
                                    904 ; genGoto
      009A29 CC 9A 31         [ 2]  905 	jp	00104$
                                    906 ; genLabel
      009A2C                        907 00102$:
                           000290   908 	Sstm8s_uart1$UART1_IrDAConfig$175 ==.
                           000290   909 	Sstm8s_uart1$UART1_IrDAConfig$176 ==.
                                    910 ;	../SPL/src/stm8s_uart1.c: 295: UART1->CR5 &= ((uint8_t)~UART1_CR5_IRLP);
                                    911 ; genAnd
      009A2C A4 FB            [ 1]  912 	and	a, #0xfb
                                    913 ; genPointerSet
      009A2E C7 52 38         [ 1]  914 	ld	0x5238, a
                           000295   915 	Sstm8s_uart1$UART1_IrDAConfig$177 ==.
                                    916 ; genLabel
      009A31                        917 00104$:
                           000295   918 	Sstm8s_uart1$UART1_IrDAConfig$178 ==.
                                    919 ;	../SPL/src/stm8s_uart1.c: 297: }
                                    920 ; genEndFunction
                           000295   921 	Sstm8s_uart1$UART1_IrDAConfig$179 ==.
                           000295   922 	XG$UART1_IrDAConfig$0$0 ==.
      009A31 81               [ 4]  923 	ret
                           000296   924 	Sstm8s_uart1$UART1_IrDAConfig$180 ==.
                           000296   925 	Sstm8s_uart1$UART1_IrDACmd$181 ==.
                                    926 ;	../SPL/src/stm8s_uart1.c: 305: void UART1_IrDACmd(FunctionalState NewState)
                                    927 ; genLabel
                                    928 ;	-----------------------------------------
                                    929 ;	 function UART1_IrDACmd
                                    930 ;	-----------------------------------------
                                    931 ;	Register assignment is optimal.
                                    932 ;	Stack space usage: 0 bytes.
      009A32                        933 _UART1_IrDACmd:
                           000296   934 	Sstm8s_uart1$UART1_IrDACmd$182 ==.
                           000296   935 	Sstm8s_uart1$UART1_IrDACmd$183 ==.
                                    936 ;	../SPL/src/stm8s_uart1.c: 313: UART1->CR5 |= UART1_CR5_IREN;
                                    937 ; genPointerGet
      009A32 C6 52 38         [ 1]  938 	ld	a, 0x5238
                           000299   939 	Sstm8s_uart1$UART1_IrDACmd$184 ==.
                                    940 ;	../SPL/src/stm8s_uart1.c: 310: if (NewState != DISABLE)
                                    941 ; genIfx
      009A35 0D 03            [ 1]  942 	tnz	(0x03, sp)
      009A37 26 03            [ 1]  943 	jrne	00111$
      009A39 CC 9A 44         [ 2]  944 	jp	00102$
      009A3C                        945 00111$:
                           0002A0   946 	Sstm8s_uart1$UART1_IrDACmd$185 ==.
                           0002A0   947 	Sstm8s_uart1$UART1_IrDACmd$186 ==.
                                    948 ;	../SPL/src/stm8s_uart1.c: 313: UART1->CR5 |= UART1_CR5_IREN;
                                    949 ; genOr
      009A3C AA 02            [ 1]  950 	or	a, #0x02
                                    951 ; genPointerSet
      009A3E C7 52 38         [ 1]  952 	ld	0x5238, a
                           0002A5   953 	Sstm8s_uart1$UART1_IrDACmd$187 ==.
                                    954 ; genGoto
      009A41 CC 9A 49         [ 2]  955 	jp	00104$
                                    956 ; genLabel
      009A44                        957 00102$:
                           0002A8   958 	Sstm8s_uart1$UART1_IrDACmd$188 ==.
                           0002A8   959 	Sstm8s_uart1$UART1_IrDACmd$189 ==.
                                    960 ;	../SPL/src/stm8s_uart1.c: 318: UART1->CR5 &= ((uint8_t)~UART1_CR5_IREN);
                                    961 ; genAnd
      009A44 A4 FD            [ 1]  962 	and	a, #0xfd
                                    963 ; genPointerSet
      009A46 C7 52 38         [ 1]  964 	ld	0x5238, a
                           0002AD   965 	Sstm8s_uart1$UART1_IrDACmd$190 ==.
                                    966 ; genLabel
      009A49                        967 00104$:
                           0002AD   968 	Sstm8s_uart1$UART1_IrDACmd$191 ==.
                                    969 ;	../SPL/src/stm8s_uart1.c: 320: }
                                    970 ; genEndFunction
                           0002AD   971 	Sstm8s_uart1$UART1_IrDACmd$192 ==.
                           0002AD   972 	XG$UART1_IrDACmd$0$0 ==.
      009A49 81               [ 4]  973 	ret
                           0002AE   974 	Sstm8s_uart1$UART1_IrDACmd$193 ==.
                           0002AE   975 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$194 ==.
                                    976 ;	../SPL/src/stm8s_uart1.c: 329: void UART1_LINBreakDetectionConfig(UART1_LINBreakDetectionLength_TypeDef UART1_LINBreakDetectionLength)
                                    977 ; genLabel
                                    978 ;	-----------------------------------------
                                    979 ;	 function UART1_LINBreakDetectionConfig
                                    980 ;	-----------------------------------------
                                    981 ;	Register assignment is optimal.
                                    982 ;	Stack space usage: 0 bytes.
      009A4A                        983 _UART1_LINBreakDetectionConfig:
                           0002AE   984 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$195 ==.
                           0002AE   985 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$196 ==.
                                    986 ;	../SPL/src/stm8s_uart1.c: 335: UART1->CR4 |= UART1_CR4_LBDL;
                                    987 ; genPointerGet
      009A4A C6 52 37         [ 1]  988 	ld	a, 0x5237
                           0002B1   989 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$197 ==.
                                    990 ;	../SPL/src/stm8s_uart1.c: 333: if (UART1_LINBreakDetectionLength != UART1_LINBREAKDETECTIONLENGTH_10BITS)
                                    991 ; genIfx
      009A4D 0D 03            [ 1]  992 	tnz	(0x03, sp)
      009A4F 26 03            [ 1]  993 	jrne	00111$
      009A51 CC 9A 5C         [ 2]  994 	jp	00102$
      009A54                        995 00111$:
                           0002B8   996 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$198 ==.
                           0002B8   997 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$199 ==.
                                    998 ;	../SPL/src/stm8s_uart1.c: 335: UART1->CR4 |= UART1_CR4_LBDL;
                                    999 ; genOr
      009A54 AA 20            [ 1] 1000 	or	a, #0x20
                                   1001 ; genPointerSet
      009A56 C7 52 37         [ 1] 1002 	ld	0x5237, a
                           0002BD  1003 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$200 ==.
                                   1004 ; genGoto
      009A59 CC 9A 61         [ 2] 1005 	jp	00104$
                                   1006 ; genLabel
      009A5C                       1007 00102$:
                           0002C0  1008 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$201 ==.
                           0002C0  1009 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$202 ==.
                                   1010 ;	../SPL/src/stm8s_uart1.c: 339: UART1->CR4 &= ((uint8_t)~UART1_CR4_LBDL);
                                   1011 ; genAnd
      009A5C A4 DF            [ 1] 1012 	and	a, #0xdf
                                   1013 ; genPointerSet
      009A5E C7 52 37         [ 1] 1014 	ld	0x5237, a
                           0002C5  1015 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$203 ==.
                                   1016 ; genLabel
      009A61                       1017 00104$:
                           0002C5  1018 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$204 ==.
                                   1019 ;	../SPL/src/stm8s_uart1.c: 341: }
                                   1020 ; genEndFunction
                           0002C5  1021 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$205 ==.
                           0002C5  1022 	XG$UART1_LINBreakDetectionConfig$0$0 ==.
      009A61 81               [ 4] 1023 	ret
                           0002C6  1024 	Sstm8s_uart1$UART1_LINBreakDetectionConfig$206 ==.
                           0002C6  1025 	Sstm8s_uart1$UART1_LINCmd$207 ==.
                                   1026 ;	../SPL/src/stm8s_uart1.c: 349: void UART1_LINCmd(FunctionalState NewState)
                                   1027 ; genLabel
                                   1028 ;	-----------------------------------------
                                   1029 ;	 function UART1_LINCmd
                                   1030 ;	-----------------------------------------
                                   1031 ;	Register assignment is optimal.
                                   1032 ;	Stack space usage: 0 bytes.
      009A62                       1033 _UART1_LINCmd:
                           0002C6  1034 	Sstm8s_uart1$UART1_LINCmd$208 ==.
                           0002C6  1035 	Sstm8s_uart1$UART1_LINCmd$209 ==.
                                   1036 ;	../SPL/src/stm8s_uart1.c: 356: UART1->CR3 |= UART1_CR3_LINEN;
                                   1037 ; genPointerGet
      009A62 C6 52 36         [ 1] 1038 	ld	a, 0x5236
                           0002C9  1039 	Sstm8s_uart1$UART1_LINCmd$210 ==.
                                   1040 ;	../SPL/src/stm8s_uart1.c: 353: if (NewState != DISABLE)
                                   1041 ; genIfx
      009A65 0D 03            [ 1] 1042 	tnz	(0x03, sp)
      009A67 26 03            [ 1] 1043 	jrne	00111$
      009A69 CC 9A 74         [ 2] 1044 	jp	00102$
      009A6C                       1045 00111$:
                           0002D0  1046 	Sstm8s_uart1$UART1_LINCmd$211 ==.
                           0002D0  1047 	Sstm8s_uart1$UART1_LINCmd$212 ==.
                                   1048 ;	../SPL/src/stm8s_uart1.c: 356: UART1->CR3 |= UART1_CR3_LINEN;
                                   1049 ; genOr
      009A6C AA 40            [ 1] 1050 	or	a, #0x40
                                   1051 ; genPointerSet
      009A6E C7 52 36         [ 1] 1052 	ld	0x5236, a
                           0002D5  1053 	Sstm8s_uart1$UART1_LINCmd$213 ==.
                                   1054 ; genGoto
      009A71 CC 9A 79         [ 2] 1055 	jp	00104$
                                   1056 ; genLabel
      009A74                       1057 00102$:
                           0002D8  1058 	Sstm8s_uart1$UART1_LINCmd$214 ==.
                           0002D8  1059 	Sstm8s_uart1$UART1_LINCmd$215 ==.
                                   1060 ;	../SPL/src/stm8s_uart1.c: 361: UART1->CR3 &= ((uint8_t)~UART1_CR3_LINEN);
                                   1061 ; genAnd
      009A74 A4 BF            [ 1] 1062 	and	a, #0xbf
                                   1063 ; genPointerSet
      009A76 C7 52 36         [ 1] 1064 	ld	0x5236, a
                           0002DD  1065 	Sstm8s_uart1$UART1_LINCmd$216 ==.
                                   1066 ; genLabel
      009A79                       1067 00104$:
                           0002DD  1068 	Sstm8s_uart1$UART1_LINCmd$217 ==.
                                   1069 ;	../SPL/src/stm8s_uart1.c: 363: }
                                   1070 ; genEndFunction
                           0002DD  1071 	Sstm8s_uart1$UART1_LINCmd$218 ==.
                           0002DD  1072 	XG$UART1_LINCmd$0$0 ==.
      009A79 81               [ 4] 1073 	ret
                           0002DE  1074 	Sstm8s_uart1$UART1_LINCmd$219 ==.
                           0002DE  1075 	Sstm8s_uart1$UART1_SmartCardCmd$220 ==.
                                   1076 ;	../SPL/src/stm8s_uart1.c: 371: void UART1_SmartCardCmd(FunctionalState NewState)
                                   1077 ; genLabel
                                   1078 ;	-----------------------------------------
                                   1079 ;	 function UART1_SmartCardCmd
                                   1080 ;	-----------------------------------------
                                   1081 ;	Register assignment is optimal.
                                   1082 ;	Stack space usage: 0 bytes.
      009A7A                       1083 _UART1_SmartCardCmd:
                           0002DE  1084 	Sstm8s_uart1$UART1_SmartCardCmd$221 ==.
                           0002DE  1085 	Sstm8s_uart1$UART1_SmartCardCmd$222 ==.
                                   1086 ;	../SPL/src/stm8s_uart1.c: 378: UART1->CR5 |= UART1_CR5_SCEN;
                                   1087 ; genPointerGet
      009A7A C6 52 38         [ 1] 1088 	ld	a, 0x5238
                           0002E1  1089 	Sstm8s_uart1$UART1_SmartCardCmd$223 ==.
                                   1090 ;	../SPL/src/stm8s_uart1.c: 375: if (NewState != DISABLE)
                                   1091 ; genIfx
      009A7D 0D 03            [ 1] 1092 	tnz	(0x03, sp)
      009A7F 26 03            [ 1] 1093 	jrne	00111$
      009A81 CC 9A 8C         [ 2] 1094 	jp	00102$
      009A84                       1095 00111$:
                           0002E8  1096 	Sstm8s_uart1$UART1_SmartCardCmd$224 ==.
                           0002E8  1097 	Sstm8s_uart1$UART1_SmartCardCmd$225 ==.
                                   1098 ;	../SPL/src/stm8s_uart1.c: 378: UART1->CR5 |= UART1_CR5_SCEN;
                                   1099 ; genOr
      009A84 AA 20            [ 1] 1100 	or	a, #0x20
                                   1101 ; genPointerSet
      009A86 C7 52 38         [ 1] 1102 	ld	0x5238, a
                           0002ED  1103 	Sstm8s_uart1$UART1_SmartCardCmd$226 ==.
                                   1104 ; genGoto
      009A89 CC 9A 91         [ 2] 1105 	jp	00104$
                                   1106 ; genLabel
      009A8C                       1107 00102$:
                           0002F0  1108 	Sstm8s_uart1$UART1_SmartCardCmd$227 ==.
                           0002F0  1109 	Sstm8s_uart1$UART1_SmartCardCmd$228 ==.
                                   1110 ;	../SPL/src/stm8s_uart1.c: 383: UART1->CR5 &= ((uint8_t)(~UART1_CR5_SCEN));
                                   1111 ; genAnd
      009A8C A4 DF            [ 1] 1112 	and	a, #0xdf
                                   1113 ; genPointerSet
      009A8E C7 52 38         [ 1] 1114 	ld	0x5238, a
                           0002F5  1115 	Sstm8s_uart1$UART1_SmartCardCmd$229 ==.
                                   1116 ; genLabel
      009A91                       1117 00104$:
                           0002F5  1118 	Sstm8s_uart1$UART1_SmartCardCmd$230 ==.
                                   1119 ;	../SPL/src/stm8s_uart1.c: 385: }
                                   1120 ; genEndFunction
                           0002F5  1121 	Sstm8s_uart1$UART1_SmartCardCmd$231 ==.
                           0002F5  1122 	XG$UART1_SmartCardCmd$0$0 ==.
      009A91 81               [ 4] 1123 	ret
                           0002F6  1124 	Sstm8s_uart1$UART1_SmartCardCmd$232 ==.
                           0002F6  1125 	Sstm8s_uart1$UART1_SmartCardNACKCmd$233 ==.
                                   1126 ;	../SPL/src/stm8s_uart1.c: 394: void UART1_SmartCardNACKCmd(FunctionalState NewState)
                                   1127 ; genLabel
                                   1128 ;	-----------------------------------------
                                   1129 ;	 function UART1_SmartCardNACKCmd
                                   1130 ;	-----------------------------------------
                                   1131 ;	Register assignment is optimal.
                                   1132 ;	Stack space usage: 0 bytes.
      009A92                       1133 _UART1_SmartCardNACKCmd:
                           0002F6  1134 	Sstm8s_uart1$UART1_SmartCardNACKCmd$234 ==.
                           0002F6  1135 	Sstm8s_uart1$UART1_SmartCardNACKCmd$235 ==.
                                   1136 ;	../SPL/src/stm8s_uart1.c: 401: UART1->CR5 |= UART1_CR5_NACK;
                                   1137 ; genPointerGet
      009A92 C6 52 38         [ 1] 1138 	ld	a, 0x5238
                           0002F9  1139 	Sstm8s_uart1$UART1_SmartCardNACKCmd$236 ==.
                                   1140 ;	../SPL/src/stm8s_uart1.c: 398: if (NewState != DISABLE)
                                   1141 ; genIfx
      009A95 0D 03            [ 1] 1142 	tnz	(0x03, sp)
      009A97 26 03            [ 1] 1143 	jrne	00111$
      009A99 CC 9A A4         [ 2] 1144 	jp	00102$
      009A9C                       1145 00111$:
                           000300  1146 	Sstm8s_uart1$UART1_SmartCardNACKCmd$237 ==.
                           000300  1147 	Sstm8s_uart1$UART1_SmartCardNACKCmd$238 ==.
                                   1148 ;	../SPL/src/stm8s_uart1.c: 401: UART1->CR5 |= UART1_CR5_NACK;
                                   1149 ; genOr
      009A9C AA 10            [ 1] 1150 	or	a, #0x10
                                   1151 ; genPointerSet
      009A9E C7 52 38         [ 1] 1152 	ld	0x5238, a
                           000305  1153 	Sstm8s_uart1$UART1_SmartCardNACKCmd$239 ==.
                                   1154 ; genGoto
      009AA1 CC 9A A9         [ 2] 1155 	jp	00104$
                                   1156 ; genLabel
      009AA4                       1157 00102$:
                           000308  1158 	Sstm8s_uart1$UART1_SmartCardNACKCmd$240 ==.
                           000308  1159 	Sstm8s_uart1$UART1_SmartCardNACKCmd$241 ==.
                                   1160 ;	../SPL/src/stm8s_uart1.c: 406: UART1->CR5 &= ((uint8_t)~(UART1_CR5_NACK));
                                   1161 ; genAnd
      009AA4 A4 EF            [ 1] 1162 	and	a, #0xef
                                   1163 ; genPointerSet
      009AA6 C7 52 38         [ 1] 1164 	ld	0x5238, a
                           00030D  1165 	Sstm8s_uart1$UART1_SmartCardNACKCmd$242 ==.
                                   1166 ; genLabel
      009AA9                       1167 00104$:
                           00030D  1168 	Sstm8s_uart1$UART1_SmartCardNACKCmd$243 ==.
                                   1169 ;	../SPL/src/stm8s_uart1.c: 408: }
                                   1170 ; genEndFunction
                           00030D  1171 	Sstm8s_uart1$UART1_SmartCardNACKCmd$244 ==.
                           00030D  1172 	XG$UART1_SmartCardNACKCmd$0$0 ==.
      009AA9 81               [ 4] 1173 	ret
                           00030E  1174 	Sstm8s_uart1$UART1_SmartCardNACKCmd$245 ==.
                           00030E  1175 	Sstm8s_uart1$UART1_WakeUpConfig$246 ==.
                                   1176 ;	../SPL/src/stm8s_uart1.c: 416: void UART1_WakeUpConfig(UART1_WakeUp_TypeDef UART1_WakeUp)
                                   1177 ; genLabel
                                   1178 ;	-----------------------------------------
                                   1179 ;	 function UART1_WakeUpConfig
                                   1180 ;	-----------------------------------------
                                   1181 ;	Register assignment is optimal.
                                   1182 ;	Stack space usage: 0 bytes.
      009AAA                       1183 _UART1_WakeUpConfig:
                           00030E  1184 	Sstm8s_uart1$UART1_WakeUpConfig$247 ==.
                           00030E  1185 	Sstm8s_uart1$UART1_WakeUpConfig$248 ==.
                                   1186 ;	../SPL/src/stm8s_uart1.c: 420: UART1->CR1 &= ((uint8_t)~UART1_CR1_WAKE);
                                   1187 ; genPointerGet
      009AAA C6 52 34         [ 1] 1188 	ld	a, 0x5234
                                   1189 ; genAnd
      009AAD A4 F7            [ 1] 1190 	and	a, #0xf7
                                   1191 ; genPointerSet
      009AAF C7 52 34         [ 1] 1192 	ld	0x5234, a
                           000316  1193 	Sstm8s_uart1$UART1_WakeUpConfig$249 ==.
                                   1194 ;	../SPL/src/stm8s_uart1.c: 421: UART1->CR1 |= (uint8_t)UART1_WakeUp;
                                   1195 ; genPointerGet
      009AB2 C6 52 34         [ 1] 1196 	ld	a, 0x5234
                                   1197 ; genOr
      009AB5 1A 03            [ 1] 1198 	or	a, (0x03, sp)
                                   1199 ; genPointerSet
      009AB7 C7 52 34         [ 1] 1200 	ld	0x5234, a
                                   1201 ; genLabel
      009ABA                       1202 00101$:
                           00031E  1203 	Sstm8s_uart1$UART1_WakeUpConfig$250 ==.
                                   1204 ;	../SPL/src/stm8s_uart1.c: 422: }
                                   1205 ; genEndFunction
                           00031E  1206 	Sstm8s_uart1$UART1_WakeUpConfig$251 ==.
                           00031E  1207 	XG$UART1_WakeUpConfig$0$0 ==.
      009ABA 81               [ 4] 1208 	ret
                           00031F  1209 	Sstm8s_uart1$UART1_WakeUpConfig$252 ==.
                           00031F  1210 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$253 ==.
                                   1211 ;	../SPL/src/stm8s_uart1.c: 430: void UART1_ReceiverWakeUpCmd(FunctionalState NewState)
                                   1212 ; genLabel
                                   1213 ;	-----------------------------------------
                                   1214 ;	 function UART1_ReceiverWakeUpCmd
                                   1215 ;	-----------------------------------------
                                   1216 ;	Register assignment is optimal.
                                   1217 ;	Stack space usage: 0 bytes.
      009ABB                       1218 _UART1_ReceiverWakeUpCmd:
                           00031F  1219 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$254 ==.
                           00031F  1220 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$255 ==.
                                   1221 ;	../SPL/src/stm8s_uart1.c: 437: UART1->CR2 |= UART1_CR2_RWU;
                                   1222 ; genPointerGet
      009ABB C6 52 35         [ 1] 1223 	ld	a, 0x5235
                           000322  1224 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$256 ==.
                                   1225 ;	../SPL/src/stm8s_uart1.c: 434: if (NewState != DISABLE)
                                   1226 ; genIfx
      009ABE 0D 03            [ 1] 1227 	tnz	(0x03, sp)
      009AC0 26 03            [ 1] 1228 	jrne	00111$
      009AC2 CC 9A CD         [ 2] 1229 	jp	00102$
      009AC5                       1230 00111$:
                           000329  1231 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$257 ==.
                           000329  1232 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$258 ==.
                                   1233 ;	../SPL/src/stm8s_uart1.c: 437: UART1->CR2 |= UART1_CR2_RWU;
                                   1234 ; genOr
      009AC5 AA 02            [ 1] 1235 	or	a, #0x02
                                   1236 ; genPointerSet
      009AC7 C7 52 35         [ 1] 1237 	ld	0x5235, a
                           00032E  1238 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$259 ==.
                                   1239 ; genGoto
      009ACA CC 9A D2         [ 2] 1240 	jp	00104$
                                   1241 ; genLabel
      009ACD                       1242 00102$:
                           000331  1243 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$260 ==.
                           000331  1244 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$261 ==.
                                   1245 ;	../SPL/src/stm8s_uart1.c: 442: UART1->CR2 &= ((uint8_t)~UART1_CR2_RWU);
                                   1246 ; genAnd
      009ACD A4 FD            [ 1] 1247 	and	a, #0xfd
                                   1248 ; genPointerSet
      009ACF C7 52 35         [ 1] 1249 	ld	0x5235, a
                           000336  1250 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$262 ==.
                                   1251 ; genLabel
      009AD2                       1252 00104$:
                           000336  1253 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$263 ==.
                                   1254 ;	../SPL/src/stm8s_uart1.c: 444: }
                                   1255 ; genEndFunction
                           000336  1256 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$264 ==.
                           000336  1257 	XG$UART1_ReceiverWakeUpCmd$0$0 ==.
      009AD2 81               [ 4] 1258 	ret
                           000337  1259 	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$265 ==.
                           000337  1260 	Sstm8s_uart1$UART1_ReceiveData8$266 ==.
                                   1261 ;	../SPL/src/stm8s_uart1.c: 451: uint8_t UART1_ReceiveData8(void)
                                   1262 ; genLabel
                                   1263 ;	-----------------------------------------
                                   1264 ;	 function UART1_ReceiveData8
                                   1265 ;	-----------------------------------------
                                   1266 ;	Register assignment is optimal.
                                   1267 ;	Stack space usage: 0 bytes.
      009AD3                       1268 _UART1_ReceiveData8:
                           000337  1269 	Sstm8s_uart1$UART1_ReceiveData8$267 ==.
                           000337  1270 	Sstm8s_uart1$UART1_ReceiveData8$268 ==.
                                   1271 ;	../SPL/src/stm8s_uart1.c: 453: return ((uint8_t)UART1->DR);
                                   1272 ; genPointerGet
      009AD3 C6 52 31         [ 1] 1273 	ld	a, 0x5231
                                   1274 ; genReturn
                                   1275 ; genLabel
      009AD6                       1276 00101$:
                           00033A  1277 	Sstm8s_uart1$UART1_ReceiveData8$269 ==.
                                   1278 ;	../SPL/src/stm8s_uart1.c: 454: }
                                   1279 ; genEndFunction
                           00033A  1280 	Sstm8s_uart1$UART1_ReceiveData8$270 ==.
                           00033A  1281 	XG$UART1_ReceiveData8$0$0 ==.
      009AD6 81               [ 4] 1282 	ret
                           00033B  1283 	Sstm8s_uart1$UART1_ReceiveData8$271 ==.
                           00033B  1284 	Sstm8s_uart1$UART1_ReceiveData9$272 ==.
                                   1285 ;	../SPL/src/stm8s_uart1.c: 461: uint16_t UART1_ReceiveData9(void)
                                   1286 ; genLabel
                                   1287 ;	-----------------------------------------
                                   1288 ;	 function UART1_ReceiveData9
                                   1289 ;	-----------------------------------------
                                   1290 ;	Register assignment might be sub-optimal.
                                   1291 ;	Stack space usage: 2 bytes.
      009AD7                       1292 _UART1_ReceiveData9:
                           00033B  1293 	Sstm8s_uart1$UART1_ReceiveData9$273 ==.
      009AD7 89               [ 2] 1294 	pushw	x
                           00033C  1295 	Sstm8s_uart1$UART1_ReceiveData9$274 ==.
                           00033C  1296 	Sstm8s_uart1$UART1_ReceiveData9$275 ==.
                                   1297 ;	../SPL/src/stm8s_uart1.c: 465: temp = (uint16_t)(((uint16_t)( (uint16_t)UART1->CR1 & (uint16_t)UART1_CR1_R8)) << 1);
                                   1298 ; genPointerGet
      009AD8 C6 52 34         [ 1] 1299 	ld	a, 0x5234
                                   1300 ; genCast
                                   1301 ; genAssign
      009ADB 5F               [ 1] 1302 	clrw	x
                                   1303 ; genAnd
      009ADC A4 80            [ 1] 1304 	and	a, #0x80
      009ADE 97               [ 1] 1305 	ld	xl, a
      009ADF 4F               [ 1] 1306 	clr	a
                                   1307 ; genLeftShiftLiteral
      009AE0 95               [ 1] 1308 	ld	xh, a
      009AE1 58               [ 2] 1309 	sllw	x
                                   1310 ; genAssign
      009AE2 1F 01            [ 2] 1311 	ldw	(0x01, sp), x
                           000348  1312 	Sstm8s_uart1$UART1_ReceiveData9$276 ==.
                                   1313 ;	../SPL/src/stm8s_uart1.c: 466: return (uint16_t)( (((uint16_t) UART1->DR) | temp ) & ((uint16_t)0x01FF));
                                   1314 ; genPointerGet
      009AE4 C6 52 31         [ 1] 1315 	ld	a, 0x5231
                                   1316 ; genCast
                                   1317 ; genAssign
      009AE7 5F               [ 1] 1318 	clrw	x
                                   1319 ; genOr
      009AE8 1A 02            [ 1] 1320 	or	a, (0x02, sp)
      009AEA 97               [ 1] 1321 	ld	xl, a
      009AEB 9E               [ 1] 1322 	ld	a, xh
      009AEC 1A 01            [ 1] 1323 	or	a, (0x01, sp)
                                   1324 ; genAnd
      009AEE A4 01            [ 1] 1325 	and	a, #0x01
      009AF0 95               [ 1] 1326 	ld	xh, a
                                   1327 ; genReturn
                                   1328 ; genLabel
      009AF1                       1329 00101$:
                           000355  1330 	Sstm8s_uart1$UART1_ReceiveData9$277 ==.
                                   1331 ;	../SPL/src/stm8s_uart1.c: 467: }
                                   1332 ; genEndFunction
      009AF1 5B 02            [ 2] 1333 	addw	sp, #2
                           000357  1334 	Sstm8s_uart1$UART1_ReceiveData9$278 ==.
                           000357  1335 	Sstm8s_uart1$UART1_ReceiveData9$279 ==.
                           000357  1336 	XG$UART1_ReceiveData9$0$0 ==.
      009AF3 81               [ 4] 1337 	ret
                           000358  1338 	Sstm8s_uart1$UART1_ReceiveData9$280 ==.
                           000358  1339 	Sstm8s_uart1$UART1_SendData8$281 ==.
                                   1340 ;	../SPL/src/stm8s_uart1.c: 474: void UART1_SendData8(uint8_t Data)
                                   1341 ; genLabel
                                   1342 ;	-----------------------------------------
                                   1343 ;	 function UART1_SendData8
                                   1344 ;	-----------------------------------------
                                   1345 ;	Register assignment is optimal.
                                   1346 ;	Stack space usage: 0 bytes.
      009AF4                       1347 _UART1_SendData8:
                           000358  1348 	Sstm8s_uart1$UART1_SendData8$282 ==.
                           000358  1349 	Sstm8s_uart1$UART1_SendData8$283 ==.
                                   1350 ;	../SPL/src/stm8s_uart1.c: 477: UART1->DR = Data;
                                   1351 ; genPointerSet
      009AF4 AE 52 31         [ 2] 1352 	ldw	x, #0x5231
      009AF7 7B 03            [ 1] 1353 	ld	a, (0x03, sp)
      009AF9 F7               [ 1] 1354 	ld	(x), a
                                   1355 ; genLabel
      009AFA                       1356 00101$:
                           00035E  1357 	Sstm8s_uart1$UART1_SendData8$284 ==.
                                   1358 ;	../SPL/src/stm8s_uart1.c: 478: }
                                   1359 ; genEndFunction
                           00035E  1360 	Sstm8s_uart1$UART1_SendData8$285 ==.
                           00035E  1361 	XG$UART1_SendData8$0$0 ==.
      009AFA 81               [ 4] 1362 	ret
                           00035F  1363 	Sstm8s_uart1$UART1_SendData8$286 ==.
                           00035F  1364 	Sstm8s_uart1$UART1_SendData9$287 ==.
                                   1365 ;	../SPL/src/stm8s_uart1.c: 486: void UART1_SendData9(uint16_t Data)
                                   1366 ; genLabel
                                   1367 ;	-----------------------------------------
                                   1368 ;	 function UART1_SendData9
                                   1369 ;	-----------------------------------------
                                   1370 ;	Register assignment might be sub-optimal.
                                   1371 ;	Stack space usage: 1 bytes.
      009AFB                       1372 _UART1_SendData9:
                           00035F  1373 	Sstm8s_uart1$UART1_SendData9$288 ==.
      009AFB 88               [ 1] 1374 	push	a
                           000360  1375 	Sstm8s_uart1$UART1_SendData9$289 ==.
                           000360  1376 	Sstm8s_uart1$UART1_SendData9$290 ==.
                                   1377 ;	../SPL/src/stm8s_uart1.c: 489: UART1->CR1 &= ((uint8_t)~UART1_CR1_T8);
                                   1378 ; genPointerGet
      009AFC C6 52 34         [ 1] 1379 	ld	a, 0x5234
                                   1380 ; genAnd
      009AFF A4 BF            [ 1] 1381 	and	a, #0xbf
                                   1382 ; genPointerSet
      009B01 C7 52 34         [ 1] 1383 	ld	0x5234, a
                           000368  1384 	Sstm8s_uart1$UART1_SendData9$291 ==.
                                   1385 ;	../SPL/src/stm8s_uart1.c: 491: UART1->CR1 |= (uint8_t)(((uint8_t)(Data >> 2)) & UART1_CR1_T8);
                                   1386 ; genPointerGet
      009B04 C6 52 34         [ 1] 1387 	ld	a, 0x5234
      009B07 6B 01            [ 1] 1388 	ld	(0x01, sp), a
                                   1389 ; genRightShiftLiteral
      009B09 1E 04            [ 2] 1390 	ldw	x, (0x04, sp)
      009B0B 54               [ 2] 1391 	srlw	x
      009B0C 54               [ 2] 1392 	srlw	x
                                   1393 ; genCast
                                   1394 ; genAssign
      009B0D 9F               [ 1] 1395 	ld	a, xl
                                   1396 ; genAnd
      009B0E A4 40            [ 1] 1397 	and	a, #0x40
                                   1398 ; genOr
      009B10 1A 01            [ 1] 1399 	or	a, (0x01, sp)
                                   1400 ; genPointerSet
      009B12 C7 52 34         [ 1] 1401 	ld	0x5234, a
                           000379  1402 	Sstm8s_uart1$UART1_SendData9$292 ==.
                                   1403 ;	../SPL/src/stm8s_uart1.c: 493: UART1->DR   = (uint8_t)(Data);
                                   1404 ; genCast
                                   1405 ; genAssign
      009B15 7B 05            [ 1] 1406 	ld	a, (0x05, sp)
                                   1407 ; genPointerSet
      009B17 C7 52 31         [ 1] 1408 	ld	0x5231, a
                                   1409 ; genLabel
      009B1A                       1410 00101$:
                           00037E  1411 	Sstm8s_uart1$UART1_SendData9$293 ==.
                                   1412 ;	../SPL/src/stm8s_uart1.c: 494: }
                                   1413 ; genEndFunction
      009B1A 84               [ 1] 1414 	pop	a
                           00037F  1415 	Sstm8s_uart1$UART1_SendData9$294 ==.
                           00037F  1416 	Sstm8s_uart1$UART1_SendData9$295 ==.
                           00037F  1417 	XG$UART1_SendData9$0$0 ==.
      009B1B 81               [ 4] 1418 	ret
                           000380  1419 	Sstm8s_uart1$UART1_SendData9$296 ==.
                           000380  1420 	Sstm8s_uart1$UART1_SendBreak$297 ==.
                                   1421 ;	../SPL/src/stm8s_uart1.c: 501: void UART1_SendBreak(void)
                                   1422 ; genLabel
                                   1423 ;	-----------------------------------------
                                   1424 ;	 function UART1_SendBreak
                                   1425 ;	-----------------------------------------
                                   1426 ;	Register assignment is optimal.
                                   1427 ;	Stack space usage: 0 bytes.
      009B1C                       1428 _UART1_SendBreak:
                           000380  1429 	Sstm8s_uart1$UART1_SendBreak$298 ==.
                           000380  1430 	Sstm8s_uart1$UART1_SendBreak$299 ==.
                                   1431 ;	../SPL/src/stm8s_uart1.c: 503: UART1->CR2 |= UART1_CR2_SBK;
                                   1432 ; genPointerGet
      009B1C C6 52 35         [ 1] 1433 	ld	a, 0x5235
                                   1434 ; genOr
      009B1F AA 01            [ 1] 1435 	or	a, #0x01
                                   1436 ; genPointerSet
      009B21 C7 52 35         [ 1] 1437 	ld	0x5235, a
                                   1438 ; genLabel
      009B24                       1439 00101$:
                           000388  1440 	Sstm8s_uart1$UART1_SendBreak$300 ==.
                                   1441 ;	../SPL/src/stm8s_uart1.c: 504: }
                                   1442 ; genEndFunction
                           000388  1443 	Sstm8s_uart1$UART1_SendBreak$301 ==.
                           000388  1444 	XG$UART1_SendBreak$0$0 ==.
      009B24 81               [ 4] 1445 	ret
                           000389  1446 	Sstm8s_uart1$UART1_SendBreak$302 ==.
                           000389  1447 	Sstm8s_uart1$UART1_SetAddress$303 ==.
                                   1448 ;	../SPL/src/stm8s_uart1.c: 511: void UART1_SetAddress(uint8_t UART1_Address)
                                   1449 ; genLabel
                                   1450 ;	-----------------------------------------
                                   1451 ;	 function UART1_SetAddress
                                   1452 ;	-----------------------------------------
                                   1453 ;	Register assignment is optimal.
                                   1454 ;	Stack space usage: 0 bytes.
      009B25                       1455 _UART1_SetAddress:
                           000389  1456 	Sstm8s_uart1$UART1_SetAddress$304 ==.
                           000389  1457 	Sstm8s_uart1$UART1_SetAddress$305 ==.
                                   1458 ;	../SPL/src/stm8s_uart1.c: 517: UART1->CR4 &= ((uint8_t)~UART1_CR4_ADD);
                                   1459 ; genPointerGet
      009B25 C6 52 37         [ 1] 1460 	ld	a, 0x5237
                                   1461 ; genAnd
      009B28 A4 F0            [ 1] 1462 	and	a, #0xf0
                                   1463 ; genPointerSet
      009B2A C7 52 37         [ 1] 1464 	ld	0x5237, a
                           000391  1465 	Sstm8s_uart1$UART1_SetAddress$306 ==.
                                   1466 ;	../SPL/src/stm8s_uart1.c: 519: UART1->CR4 |= UART1_Address;
                                   1467 ; genPointerGet
      009B2D C6 52 37         [ 1] 1468 	ld	a, 0x5237
                                   1469 ; genOr
      009B30 1A 03            [ 1] 1470 	or	a, (0x03, sp)
                                   1471 ; genPointerSet
      009B32 C7 52 37         [ 1] 1472 	ld	0x5237, a
                                   1473 ; genLabel
      009B35                       1474 00101$:
                           000399  1475 	Sstm8s_uart1$UART1_SetAddress$307 ==.
                                   1476 ;	../SPL/src/stm8s_uart1.c: 520: }
                                   1477 ; genEndFunction
                           000399  1478 	Sstm8s_uart1$UART1_SetAddress$308 ==.
                           000399  1479 	XG$UART1_SetAddress$0$0 ==.
      009B35 81               [ 4] 1480 	ret
                           00039A  1481 	Sstm8s_uart1$UART1_SetAddress$309 ==.
                           00039A  1482 	Sstm8s_uart1$UART1_SetGuardTime$310 ==.
                                   1483 ;	../SPL/src/stm8s_uart1.c: 528: void UART1_SetGuardTime(uint8_t UART1_GuardTime)
                                   1484 ; genLabel
                                   1485 ;	-----------------------------------------
                                   1486 ;	 function UART1_SetGuardTime
                                   1487 ;	-----------------------------------------
                                   1488 ;	Register assignment is optimal.
                                   1489 ;	Stack space usage: 0 bytes.
      009B36                       1490 _UART1_SetGuardTime:
                           00039A  1491 	Sstm8s_uart1$UART1_SetGuardTime$311 ==.
                           00039A  1492 	Sstm8s_uart1$UART1_SetGuardTime$312 ==.
                                   1493 ;	../SPL/src/stm8s_uart1.c: 531: UART1->GTR = UART1_GuardTime;
                                   1494 ; genPointerSet
      009B36 AE 52 39         [ 2] 1495 	ldw	x, #0x5239
      009B39 7B 03            [ 1] 1496 	ld	a, (0x03, sp)
      009B3B F7               [ 1] 1497 	ld	(x), a
                                   1498 ; genLabel
      009B3C                       1499 00101$:
                           0003A0  1500 	Sstm8s_uart1$UART1_SetGuardTime$313 ==.
                                   1501 ;	../SPL/src/stm8s_uart1.c: 532: }
                                   1502 ; genEndFunction
                           0003A0  1503 	Sstm8s_uart1$UART1_SetGuardTime$314 ==.
                           0003A0  1504 	XG$UART1_SetGuardTime$0$0 ==.
      009B3C 81               [ 4] 1505 	ret
                           0003A1  1506 	Sstm8s_uart1$UART1_SetGuardTime$315 ==.
                           0003A1  1507 	Sstm8s_uart1$UART1_SetPrescaler$316 ==.
                                   1508 ;	../SPL/src/stm8s_uart1.c: 556: void UART1_SetPrescaler(uint8_t UART1_Prescaler)
                                   1509 ; genLabel
                                   1510 ;	-----------------------------------------
                                   1511 ;	 function UART1_SetPrescaler
                                   1512 ;	-----------------------------------------
                                   1513 ;	Register assignment is optimal.
                                   1514 ;	Stack space usage: 0 bytes.
      009B3D                       1515 _UART1_SetPrescaler:
                           0003A1  1516 	Sstm8s_uart1$UART1_SetPrescaler$317 ==.
                           0003A1  1517 	Sstm8s_uart1$UART1_SetPrescaler$318 ==.
                                   1518 ;	../SPL/src/stm8s_uart1.c: 559: UART1->PSCR = UART1_Prescaler;
                                   1519 ; genPointerSet
      009B3D AE 52 3A         [ 2] 1520 	ldw	x, #0x523a
      009B40 7B 03            [ 1] 1521 	ld	a, (0x03, sp)
      009B42 F7               [ 1] 1522 	ld	(x), a
                                   1523 ; genLabel
      009B43                       1524 00101$:
                           0003A7  1525 	Sstm8s_uart1$UART1_SetPrescaler$319 ==.
                                   1526 ;	../SPL/src/stm8s_uart1.c: 560: }
                                   1527 ; genEndFunction
                           0003A7  1528 	Sstm8s_uart1$UART1_SetPrescaler$320 ==.
                           0003A7  1529 	XG$UART1_SetPrescaler$0$0 ==.
      009B43 81               [ 4] 1530 	ret
                           0003A8  1531 	Sstm8s_uart1$UART1_SetPrescaler$321 ==.
                           0003A8  1532 	Sstm8s_uart1$UART1_GetFlagStatus$322 ==.
                                   1533 ;	../SPL/src/stm8s_uart1.c: 568: FlagStatus UART1_GetFlagStatus(UART1_Flag_TypeDef UART1_FLAG)
                                   1534 ; genLabel
                                   1535 ;	-----------------------------------------
                                   1536 ;	 function UART1_GetFlagStatus
                                   1537 ;	-----------------------------------------
                                   1538 ;	Register assignment might be sub-optimal.
                                   1539 ;	Stack space usage: 3 bytes.
      009B44                       1540 _UART1_GetFlagStatus:
                           0003A8  1541 	Sstm8s_uart1$UART1_GetFlagStatus$323 ==.
      009B44 52 03            [ 2] 1542 	sub	sp, #3
                           0003AA  1543 	Sstm8s_uart1$UART1_GetFlagStatus$324 ==.
                           0003AA  1544 	Sstm8s_uart1$UART1_GetFlagStatus$325 ==.
                                   1545 ;	../SPL/src/stm8s_uart1.c: 577: if (UART1_FLAG == UART1_FLAG_LBDF)
                                   1546 ; genCast
                                   1547 ; genAssign
      009B46 16 06            [ 2] 1548 	ldw	y, (0x06, sp)
      009B48 17 01            [ 2] 1549 	ldw	(0x01, sp), y
                           0003AE  1550 	Sstm8s_uart1$UART1_GetFlagStatus$326 ==.
                                   1551 ;	../SPL/src/stm8s_uart1.c: 579: if ((UART1->CR4 & (uint8_t)UART1_FLAG) != (uint8_t)0x00)
                                   1552 ; genCast
                                   1553 ; genAssign
      009B4A 7B 07            [ 1] 1554 	ld	a, (0x07, sp)
      009B4C 6B 03            [ 1] 1555 	ld	(0x03, sp), a
                           0003B2  1556 	Sstm8s_uart1$UART1_GetFlagStatus$327 ==.
                                   1557 ;	../SPL/src/stm8s_uart1.c: 577: if (UART1_FLAG == UART1_FLAG_LBDF)
                                   1558 ; genCmpEQorNE
      009B4E 1E 01            [ 2] 1559 	ldw	x, (0x01, sp)
      009B50 A3 02 10         [ 2] 1560 	cpw	x, #0x0210
      009B53 26 03            [ 1] 1561 	jrne	00144$
      009B55 CC 9B 5B         [ 2] 1562 	jp	00145$
      009B58                       1563 00144$:
      009B58 CC 9B 6F         [ 2] 1564 	jp	00114$
      009B5B                       1565 00145$:
                           0003BF  1566 	Sstm8s_uart1$UART1_GetFlagStatus$328 ==.
                                   1567 ; skipping generated iCode
                           0003BF  1568 	Sstm8s_uart1$UART1_GetFlagStatus$329 ==.
                           0003BF  1569 	Sstm8s_uart1$UART1_GetFlagStatus$330 ==.
                                   1570 ;	../SPL/src/stm8s_uart1.c: 579: if ((UART1->CR4 & (uint8_t)UART1_FLAG) != (uint8_t)0x00)
                                   1571 ; genPointerGet
      009B5B C6 52 37         [ 1] 1572 	ld	a, 0x5237
                                   1573 ; genAnd
      009B5E 14 03            [ 1] 1574 	and	a, (0x03, sp)
                                   1575 ; genIfx
      009B60 4D               [ 1] 1576 	tnz	a
      009B61 26 03            [ 1] 1577 	jrne	00146$
      009B63 CC 9B 6B         [ 2] 1578 	jp	00102$
      009B66                       1579 00146$:
                           0003CA  1580 	Sstm8s_uart1$UART1_GetFlagStatus$331 ==.
                           0003CA  1581 	Sstm8s_uart1$UART1_GetFlagStatus$332 ==.
                                   1582 ;	../SPL/src/stm8s_uart1.c: 582: status = SET;
                                   1583 ; genAssign
      009B66 A6 01            [ 1] 1584 	ld	a, #0x01
                           0003CC  1585 	Sstm8s_uart1$UART1_GetFlagStatus$333 ==.
                                   1586 ; genGoto
      009B68 CC 9B A1         [ 2] 1587 	jp	00115$
                                   1588 ; genLabel
      009B6B                       1589 00102$:
                           0003CF  1590 	Sstm8s_uart1$UART1_GetFlagStatus$334 ==.
                           0003CF  1591 	Sstm8s_uart1$UART1_GetFlagStatus$335 ==.
                                   1592 ;	../SPL/src/stm8s_uart1.c: 587: status = RESET;
                                   1593 ; genAssign
      009B6B 4F               [ 1] 1594 	clr	a
                           0003D0  1595 	Sstm8s_uart1$UART1_GetFlagStatus$336 ==.
                                   1596 ; genGoto
      009B6C CC 9B A1         [ 2] 1597 	jp	00115$
                                   1598 ; genLabel
      009B6F                       1599 00114$:
                           0003D3  1600 	Sstm8s_uart1$UART1_GetFlagStatus$337 ==.
                                   1601 ;	../SPL/src/stm8s_uart1.c: 590: else if (UART1_FLAG == UART1_FLAG_SBK)
                                   1602 ; genCmpEQorNE
      009B6F 1E 01            [ 2] 1603 	ldw	x, (0x01, sp)
      009B71 A3 01 01         [ 2] 1604 	cpw	x, #0x0101
      009B74 26 03            [ 1] 1605 	jrne	00148$
      009B76 CC 9B 7C         [ 2] 1606 	jp	00149$
      009B79                       1607 00148$:
      009B79 CC 9B 90         [ 2] 1608 	jp	00111$
      009B7C                       1609 00149$:
                           0003E0  1610 	Sstm8s_uart1$UART1_GetFlagStatus$338 ==.
                                   1611 ; skipping generated iCode
                           0003E0  1612 	Sstm8s_uart1$UART1_GetFlagStatus$339 ==.
                           0003E0  1613 	Sstm8s_uart1$UART1_GetFlagStatus$340 ==.
                                   1614 ;	../SPL/src/stm8s_uart1.c: 592: if ((UART1->CR2 & (uint8_t)UART1_FLAG) != (uint8_t)0x00)
                                   1615 ; genPointerGet
      009B7C C6 52 35         [ 1] 1616 	ld	a, 0x5235
                                   1617 ; genAnd
      009B7F 14 03            [ 1] 1618 	and	a, (0x03, sp)
                                   1619 ; genIfx
      009B81 4D               [ 1] 1620 	tnz	a
      009B82 26 03            [ 1] 1621 	jrne	00150$
      009B84 CC 9B 8C         [ 2] 1622 	jp	00105$
      009B87                       1623 00150$:
                           0003EB  1624 	Sstm8s_uart1$UART1_GetFlagStatus$341 ==.
                           0003EB  1625 	Sstm8s_uart1$UART1_GetFlagStatus$342 ==.
                                   1626 ;	../SPL/src/stm8s_uart1.c: 595: status = SET;
                                   1627 ; genAssign
      009B87 A6 01            [ 1] 1628 	ld	a, #0x01
                           0003ED  1629 	Sstm8s_uart1$UART1_GetFlagStatus$343 ==.
                                   1630 ; genGoto
      009B89 CC 9B A1         [ 2] 1631 	jp	00115$
                                   1632 ; genLabel
      009B8C                       1633 00105$:
                           0003F0  1634 	Sstm8s_uart1$UART1_GetFlagStatus$344 ==.
                           0003F0  1635 	Sstm8s_uart1$UART1_GetFlagStatus$345 ==.
                                   1636 ;	../SPL/src/stm8s_uart1.c: 600: status = RESET;
                                   1637 ; genAssign
      009B8C 4F               [ 1] 1638 	clr	a
                           0003F1  1639 	Sstm8s_uart1$UART1_GetFlagStatus$346 ==.
                                   1640 ; genGoto
      009B8D CC 9B A1         [ 2] 1641 	jp	00115$
                                   1642 ; genLabel
      009B90                       1643 00111$:
                           0003F4  1644 	Sstm8s_uart1$UART1_GetFlagStatus$347 ==.
                           0003F4  1645 	Sstm8s_uart1$UART1_GetFlagStatus$348 ==.
                                   1646 ;	../SPL/src/stm8s_uart1.c: 605: if ((UART1->SR & (uint8_t)UART1_FLAG) != (uint8_t)0x00)
                                   1647 ; genPointerGet
      009B90 C6 52 30         [ 1] 1648 	ld	a, 0x5230
                                   1649 ; genAnd
      009B93 14 03            [ 1] 1650 	and	a, (0x03, sp)
                                   1651 ; genIfx
      009B95 4D               [ 1] 1652 	tnz	a
      009B96 26 03            [ 1] 1653 	jrne	00151$
      009B98 CC 9B A0         [ 2] 1654 	jp	00108$
      009B9B                       1655 00151$:
                           0003FF  1656 	Sstm8s_uart1$UART1_GetFlagStatus$349 ==.
                           0003FF  1657 	Sstm8s_uart1$UART1_GetFlagStatus$350 ==.
                                   1658 ;	../SPL/src/stm8s_uart1.c: 608: status = SET;
                                   1659 ; genAssign
      009B9B A6 01            [ 1] 1660 	ld	a, #0x01
                           000401  1661 	Sstm8s_uart1$UART1_GetFlagStatus$351 ==.
                                   1662 ; genGoto
      009B9D CC 9B A1         [ 2] 1663 	jp	00115$
                                   1664 ; genLabel
      009BA0                       1665 00108$:
                           000404  1666 	Sstm8s_uart1$UART1_GetFlagStatus$352 ==.
                           000404  1667 	Sstm8s_uart1$UART1_GetFlagStatus$353 ==.
                                   1668 ;	../SPL/src/stm8s_uart1.c: 613: status = RESET;
                                   1669 ; genAssign
      009BA0 4F               [ 1] 1670 	clr	a
                           000405  1671 	Sstm8s_uart1$UART1_GetFlagStatus$354 ==.
                                   1672 ; genLabel
      009BA1                       1673 00115$:
                           000405  1674 	Sstm8s_uart1$UART1_GetFlagStatus$355 ==.
                                   1675 ;	../SPL/src/stm8s_uart1.c: 617: return status;
                                   1676 ; genReturn
                                   1677 ; genLabel
      009BA1                       1678 00116$:
                           000405  1679 	Sstm8s_uart1$UART1_GetFlagStatus$356 ==.
                                   1680 ;	../SPL/src/stm8s_uart1.c: 618: }
                                   1681 ; genEndFunction
      009BA1 5B 03            [ 2] 1682 	addw	sp, #3
                           000407  1683 	Sstm8s_uart1$UART1_GetFlagStatus$357 ==.
                           000407  1684 	Sstm8s_uart1$UART1_GetFlagStatus$358 ==.
                           000407  1685 	XG$UART1_GetFlagStatus$0$0 ==.
      009BA3 81               [ 4] 1686 	ret
                           000408  1687 	Sstm8s_uart1$UART1_GetFlagStatus$359 ==.
                           000408  1688 	Sstm8s_uart1$UART1_ClearFlag$360 ==.
                                   1689 ;	../SPL/src/stm8s_uart1.c: 646: void UART1_ClearFlag(UART1_Flag_TypeDef UART1_FLAG)
                                   1690 ; genLabel
                                   1691 ;	-----------------------------------------
                                   1692 ;	 function UART1_ClearFlag
                                   1693 ;	-----------------------------------------
                                   1694 ;	Register assignment is optimal.
                                   1695 ;	Stack space usage: 0 bytes.
      009BA4                       1696 _UART1_ClearFlag:
                           000408  1697 	Sstm8s_uart1$UART1_ClearFlag$361 ==.
                           000408  1698 	Sstm8s_uart1$UART1_ClearFlag$362 ==.
                                   1699 ;	../SPL/src/stm8s_uart1.c: 651: if (UART1_FLAG == UART1_FLAG_RXNE)
                                   1700 ; genCast
                                   1701 ; genAssign
      009BA4 1E 03            [ 2] 1702 	ldw	x, (0x03, sp)
                                   1703 ; genCmpEQorNE
      009BA6 A3 00 20         [ 2] 1704 	cpw	x, #0x0020
      009BA9 26 03            [ 1] 1705 	jrne	00112$
      009BAB CC 9B B1         [ 2] 1706 	jp	00113$
      009BAE                       1707 00112$:
      009BAE CC 9B B8         [ 2] 1708 	jp	00102$
      009BB1                       1709 00113$:
                           000415  1710 	Sstm8s_uart1$UART1_ClearFlag$363 ==.
                                   1711 ; skipping generated iCode
                           000415  1712 	Sstm8s_uart1$UART1_ClearFlag$364 ==.
                           000415  1713 	Sstm8s_uart1$UART1_ClearFlag$365 ==.
                                   1714 ;	../SPL/src/stm8s_uart1.c: 653: UART1->SR = (uint8_t)~(UART1_SR_RXNE);
                                   1715 ; genPointerSet
      009BB1 35 DF 52 30      [ 1] 1716 	mov	0x5230+0, #0xdf
                           000419  1717 	Sstm8s_uart1$UART1_ClearFlag$366 ==.
                                   1718 ; genGoto
      009BB5 CC 9B C0         [ 2] 1719 	jp	00104$
                                   1720 ; genLabel
      009BB8                       1721 00102$:
                           00041C  1722 	Sstm8s_uart1$UART1_ClearFlag$367 ==.
                           00041C  1723 	Sstm8s_uart1$UART1_ClearFlag$368 ==.
                                   1724 ;	../SPL/src/stm8s_uart1.c: 658: UART1->CR4 &= (uint8_t)~(UART1_CR4_LBDF);
                                   1725 ; genPointerGet
      009BB8 C6 52 37         [ 1] 1726 	ld	a, 0x5237
                                   1727 ; genAnd
      009BBB A4 EF            [ 1] 1728 	and	a, #0xef
                                   1729 ; genPointerSet
      009BBD C7 52 37         [ 1] 1730 	ld	0x5237, a
                           000424  1731 	Sstm8s_uart1$UART1_ClearFlag$369 ==.
                                   1732 ; genLabel
      009BC0                       1733 00104$:
                           000424  1734 	Sstm8s_uart1$UART1_ClearFlag$370 ==.
                                   1735 ;	../SPL/src/stm8s_uart1.c: 660: }
                                   1736 ; genEndFunction
                           000424  1737 	Sstm8s_uart1$UART1_ClearFlag$371 ==.
                           000424  1738 	XG$UART1_ClearFlag$0$0 ==.
      009BC0 81               [ 4] 1739 	ret
                           000425  1740 	Sstm8s_uart1$UART1_ClearFlag$372 ==.
                           000425  1741 	Sstm8s_uart1$UART1_GetITStatus$373 ==.
                                   1742 ;	../SPL/src/stm8s_uart1.c: 675: ITStatus UART1_GetITStatus(UART1_IT_TypeDef UART1_IT)
                                   1743 ; genLabel
                                   1744 ;	-----------------------------------------
                                   1745 ;	 function UART1_GetITStatus
                                   1746 ;	-----------------------------------------
                                   1747 ;	Register assignment might be sub-optimal.
                                   1748 ;	Stack space usage: 4 bytes.
      009BC1                       1749 _UART1_GetITStatus:
                           000425  1750 	Sstm8s_uart1$UART1_GetITStatus$374 ==.
      009BC1 52 04            [ 2] 1751 	sub	sp, #4
                           000427  1752 	Sstm8s_uart1$UART1_GetITStatus$375 ==.
                           000427  1753 	Sstm8s_uart1$UART1_GetITStatus$376 ==.
                                   1754 ;	../SPL/src/stm8s_uart1.c: 687: itpos = (uint8_t)((uint8_t)1 << (uint8_t)((uint8_t)UART1_IT & (uint8_t)0x0F));
                                   1755 ; genCast
                                   1756 ; genAssign
      009BC3 7B 08            [ 1] 1757 	ld	a, (0x08, sp)
      009BC5 97               [ 1] 1758 	ld	xl, a
                                   1759 ; genAnd
      009BC6 9F               [ 1] 1760 	ld	a, xl
      009BC7 A4 0F            [ 1] 1761 	and	a, #0x0f
                                   1762 ; genLeftShift
      009BC9 88               [ 1] 1763 	push	a
                           00042E  1764 	Sstm8s_uart1$UART1_GetITStatus$377 ==.
      009BCA A6 01            [ 1] 1765 	ld	a, #0x01
      009BCC 6B 02            [ 1] 1766 	ld	(0x02, sp), a
      009BCE 84               [ 1] 1767 	pop	a
                           000433  1768 	Sstm8s_uart1$UART1_GetITStatus$378 ==.
      009BCF 4D               [ 1] 1769 	tnz	a
      009BD0 27 05            [ 1] 1770 	jreq	00162$
      009BD2                       1771 00161$:
      009BD2 08 01            [ 1] 1772 	sll	(0x01, sp)
      009BD4 4A               [ 1] 1773 	dec	a
      009BD5 26 FB            [ 1] 1774 	jrne	00161$
      009BD7                       1775 00162$:
                           00043B  1776 	Sstm8s_uart1$UART1_GetITStatus$379 ==.
                                   1777 ;	../SPL/src/stm8s_uart1.c: 689: itmask1 = (uint8_t)((uint8_t)UART1_IT >> (uint8_t)4);
                                   1778 ; genRightShiftLiteral
      009BD7 9F               [ 1] 1779 	ld	a, xl
      009BD8 4E               [ 1] 1780 	swap	a
      009BD9 A4 0F            [ 1] 1781 	and	a, #0x0f
                           00043F  1782 	Sstm8s_uart1$UART1_GetITStatus$380 ==.
                                   1783 ;	../SPL/src/stm8s_uart1.c: 691: itmask2 = (uint8_t)((uint8_t)1 << itmask1);
                                   1784 ; genLeftShift
      009BDB 88               [ 1] 1785 	push	a
                           000440  1786 	Sstm8s_uart1$UART1_GetITStatus$381 ==.
      009BDC A6 01            [ 1] 1787 	ld	a, #0x01
      009BDE 6B 03            [ 1] 1788 	ld	(0x03, sp), a
      009BE0 84               [ 1] 1789 	pop	a
                           000445  1790 	Sstm8s_uart1$UART1_GetITStatus$382 ==.
      009BE1 4D               [ 1] 1791 	tnz	a
      009BE2 27 05            [ 1] 1792 	jreq	00164$
      009BE4                       1793 00163$:
      009BE4 08 02            [ 1] 1794 	sll	(0x02, sp)
      009BE6 4A               [ 1] 1795 	dec	a
      009BE7 26 FB            [ 1] 1796 	jrne	00163$
      009BE9                       1797 00164$:
                           00044D  1798 	Sstm8s_uart1$UART1_GetITStatus$383 ==.
                                   1799 ;	../SPL/src/stm8s_uart1.c: 695: if (UART1_IT == UART1_IT_PE)
                                   1800 ; genCast
                                   1801 ; genAssign
      009BE9 16 07            [ 2] 1802 	ldw	y, (0x07, sp)
      009BEB 17 03            [ 2] 1803 	ldw	(0x03, sp), y
                                   1804 ; genCmpEQorNE
      009BED 1E 03            [ 2] 1805 	ldw	x, (0x03, sp)
      009BEF A3 01 00         [ 2] 1806 	cpw	x, #0x0100
      009BF2 26 03            [ 1] 1807 	jrne	00166$
      009BF4 CC 9B FA         [ 2] 1808 	jp	00167$
      009BF7                       1809 00166$:
      009BF7 CC 9C 1B         [ 2] 1810 	jp	00117$
      009BFA                       1811 00167$:
                           00045E  1812 	Sstm8s_uart1$UART1_GetITStatus$384 ==.
                                   1813 ; skipping generated iCode
                           00045E  1814 	Sstm8s_uart1$UART1_GetITStatus$385 ==.
                           00045E  1815 	Sstm8s_uart1$UART1_GetITStatus$386 ==.
                                   1816 ;	../SPL/src/stm8s_uart1.c: 698: enablestatus = (uint8_t)((uint8_t)UART1->CR1 & itmask2);
                                   1817 ; genPointerGet
      009BFA C6 52 34         [ 1] 1818 	ld	a, 0x5234
                                   1819 ; genAnd
      009BFD 14 02            [ 1] 1820 	and	a, (0x02, sp)
      009BFF 97               [ 1] 1821 	ld	xl, a
                           000464  1822 	Sstm8s_uart1$UART1_GetITStatus$387 ==.
                                   1823 ;	../SPL/src/stm8s_uart1.c: 701: if (((UART1->SR & itpos) != (uint8_t)0x00) && enablestatus)
                                   1824 ; genPointerGet
      009C00 C6 52 30         [ 1] 1825 	ld	a, 0x5230
                                   1826 ; genAnd
      009C03 14 01            [ 1] 1827 	and	a, (0x01, sp)
                                   1828 ; genIfx
      009C05 4D               [ 1] 1829 	tnz	a
      009C06 26 03            [ 1] 1830 	jrne	00168$
      009C08 CC 9C 17         [ 2] 1831 	jp	00102$
      009C0B                       1832 00168$:
                                   1833 ; genIfx
      009C0B 9F               [ 1] 1834 	ld	a, xl
      009C0C 4D               [ 1] 1835 	tnz	a
      009C0D 26 03            [ 1] 1836 	jrne	00169$
      009C0F CC 9C 17         [ 2] 1837 	jp	00102$
      009C12                       1838 00169$:
                           000476  1839 	Sstm8s_uart1$UART1_GetITStatus$388 ==.
                           000476  1840 	Sstm8s_uart1$UART1_GetITStatus$389 ==.
                                   1841 ;	../SPL/src/stm8s_uart1.c: 704: pendingbitstatus = SET;
                                   1842 ; genAssign
      009C12 A6 01            [ 1] 1843 	ld	a, #0x01
                           000478  1844 	Sstm8s_uart1$UART1_GetITStatus$390 ==.
                                   1845 ; genGoto
      009C14 CC 9C 67         [ 2] 1846 	jp	00118$
                                   1847 ; genLabel
      009C17                       1848 00102$:
                           00047B  1849 	Sstm8s_uart1$UART1_GetITStatus$391 ==.
                           00047B  1850 	Sstm8s_uart1$UART1_GetITStatus$392 ==.
                                   1851 ;	../SPL/src/stm8s_uart1.c: 709: pendingbitstatus = RESET;
                                   1852 ; genAssign
      009C17 4F               [ 1] 1853 	clr	a
                           00047C  1854 	Sstm8s_uart1$UART1_GetITStatus$393 ==.
                                   1855 ; genGoto
      009C18 CC 9C 67         [ 2] 1856 	jp	00118$
                                   1857 ; genLabel
      009C1B                       1858 00117$:
                           00047F  1859 	Sstm8s_uart1$UART1_GetITStatus$394 ==.
                                   1860 ;	../SPL/src/stm8s_uart1.c: 713: else if (UART1_IT == UART1_IT_LBDF)
                                   1861 ; genCmpEQorNE
      009C1B 1E 03            [ 2] 1862 	ldw	x, (0x03, sp)
      009C1D A3 03 46         [ 2] 1863 	cpw	x, #0x0346
      009C20 26 03            [ 1] 1864 	jrne	00171$
      009C22 CC 9C 28         [ 2] 1865 	jp	00172$
      009C25                       1866 00171$:
      009C25 CC 9C 49         [ 2] 1867 	jp	00114$
      009C28                       1868 00172$:
                           00048C  1869 	Sstm8s_uart1$UART1_GetITStatus$395 ==.
                                   1870 ; skipping generated iCode
                           00048C  1871 	Sstm8s_uart1$UART1_GetITStatus$396 ==.
                           00048C  1872 	Sstm8s_uart1$UART1_GetITStatus$397 ==.
                                   1873 ;	../SPL/src/stm8s_uart1.c: 716: enablestatus = (uint8_t)((uint8_t)UART1->CR4 & itmask2);
                                   1874 ; genPointerGet
      009C28 C6 52 37         [ 1] 1875 	ld	a, 0x5237
                                   1876 ; genAnd
      009C2B 14 02            [ 1] 1877 	and	a, (0x02, sp)
                                   1878 ; genAssign
      009C2D 97               [ 1] 1879 	ld	xl, a
                           000492  1880 	Sstm8s_uart1$UART1_GetITStatus$398 ==.
                                   1881 ;	../SPL/src/stm8s_uart1.c: 718: if (((UART1->CR4 & itpos) != (uint8_t)0x00) && enablestatus)
                                   1882 ; genPointerGet
      009C2E C6 52 37         [ 1] 1883 	ld	a, 0x5237
                                   1884 ; genAnd
      009C31 14 01            [ 1] 1885 	and	a, (0x01, sp)
                                   1886 ; genIfx
      009C33 4D               [ 1] 1887 	tnz	a
      009C34 26 03            [ 1] 1888 	jrne	00173$
      009C36 CC 9C 45         [ 2] 1889 	jp	00106$
      009C39                       1890 00173$:
                                   1891 ; genIfx
      009C39 9F               [ 1] 1892 	ld	a, xl
      009C3A 4D               [ 1] 1893 	tnz	a
      009C3B 26 03            [ 1] 1894 	jrne	00174$
      009C3D CC 9C 45         [ 2] 1895 	jp	00106$
      009C40                       1896 00174$:
                           0004A4  1897 	Sstm8s_uart1$UART1_GetITStatus$399 ==.
                           0004A4  1898 	Sstm8s_uart1$UART1_GetITStatus$400 ==.
                                   1899 ;	../SPL/src/stm8s_uart1.c: 721: pendingbitstatus = SET;
                                   1900 ; genAssign
      009C40 A6 01            [ 1] 1901 	ld	a, #0x01
                           0004A6  1902 	Sstm8s_uart1$UART1_GetITStatus$401 ==.
                                   1903 ; genGoto
      009C42 CC 9C 67         [ 2] 1904 	jp	00118$
                                   1905 ; genLabel
      009C45                       1906 00106$:
                           0004A9  1907 	Sstm8s_uart1$UART1_GetITStatus$402 ==.
                           0004A9  1908 	Sstm8s_uart1$UART1_GetITStatus$403 ==.
                                   1909 ;	../SPL/src/stm8s_uart1.c: 726: pendingbitstatus = RESET;
                                   1910 ; genAssign
      009C45 4F               [ 1] 1911 	clr	a
                           0004AA  1912 	Sstm8s_uart1$UART1_GetITStatus$404 ==.
                                   1913 ; genGoto
      009C46 CC 9C 67         [ 2] 1914 	jp	00118$
                                   1915 ; genLabel
      009C49                       1916 00114$:
                           0004AD  1917 	Sstm8s_uart1$UART1_GetITStatus$405 ==.
                           0004AD  1918 	Sstm8s_uart1$UART1_GetITStatus$406 ==.
                                   1919 ;	../SPL/src/stm8s_uart1.c: 732: enablestatus = (uint8_t)((uint8_t)UART1->CR2 & itmask2);
                                   1920 ; genPointerGet
      009C49 C6 52 35         [ 1] 1921 	ld	a, 0x5235
                                   1922 ; genAnd
      009C4C 14 02            [ 1] 1923 	and	a, (0x02, sp)
      009C4E 97               [ 1] 1924 	ld	xl, a
                           0004B3  1925 	Sstm8s_uart1$UART1_GetITStatus$407 ==.
                                   1926 ;	../SPL/src/stm8s_uart1.c: 734: if (((UART1->SR & itpos) != (uint8_t)0x00) && enablestatus)
                                   1927 ; genPointerGet
      009C4F C6 52 30         [ 1] 1928 	ld	a, 0x5230
                                   1929 ; genAnd
      009C52 14 01            [ 1] 1930 	and	a, (0x01, sp)
                                   1931 ; genIfx
      009C54 4D               [ 1] 1932 	tnz	a
      009C55 26 03            [ 1] 1933 	jrne	00175$
      009C57 CC 9C 66         [ 2] 1934 	jp	00110$
      009C5A                       1935 00175$:
                                   1936 ; genIfx
      009C5A 9F               [ 1] 1937 	ld	a, xl
      009C5B 4D               [ 1] 1938 	tnz	a
      009C5C 26 03            [ 1] 1939 	jrne	00176$
      009C5E CC 9C 66         [ 2] 1940 	jp	00110$
      009C61                       1941 00176$:
                           0004C5  1942 	Sstm8s_uart1$UART1_GetITStatus$408 ==.
                           0004C5  1943 	Sstm8s_uart1$UART1_GetITStatus$409 ==.
                                   1944 ;	../SPL/src/stm8s_uart1.c: 737: pendingbitstatus = SET;
                                   1945 ; genAssign
      009C61 A6 01            [ 1] 1946 	ld	a, #0x01
                           0004C7  1947 	Sstm8s_uart1$UART1_GetITStatus$410 ==.
                                   1948 ; genGoto
      009C63 CC 9C 67         [ 2] 1949 	jp	00118$
                                   1950 ; genLabel
      009C66                       1951 00110$:
                           0004CA  1952 	Sstm8s_uart1$UART1_GetITStatus$411 ==.
                           0004CA  1953 	Sstm8s_uart1$UART1_GetITStatus$412 ==.
                                   1954 ;	../SPL/src/stm8s_uart1.c: 742: pendingbitstatus = RESET;
                                   1955 ; genAssign
      009C66 4F               [ 1] 1956 	clr	a
                           0004CB  1957 	Sstm8s_uart1$UART1_GetITStatus$413 ==.
                                   1958 ; genLabel
      009C67                       1959 00118$:
                           0004CB  1960 	Sstm8s_uart1$UART1_GetITStatus$414 ==.
                                   1961 ;	../SPL/src/stm8s_uart1.c: 747: return  pendingbitstatus;
                                   1962 ; genReturn
                                   1963 ; genLabel
      009C67                       1964 00119$:
                           0004CB  1965 	Sstm8s_uart1$UART1_GetITStatus$415 ==.
                                   1966 ;	../SPL/src/stm8s_uart1.c: 748: }
                                   1967 ; genEndFunction
      009C67 5B 04            [ 2] 1968 	addw	sp, #4
                           0004CD  1969 	Sstm8s_uart1$UART1_GetITStatus$416 ==.
                           0004CD  1970 	Sstm8s_uart1$UART1_GetITStatus$417 ==.
                           0004CD  1971 	XG$UART1_GetITStatus$0$0 ==.
      009C69 81               [ 4] 1972 	ret
                           0004CE  1973 	Sstm8s_uart1$UART1_GetITStatus$418 ==.
                           0004CE  1974 	Sstm8s_uart1$UART1_ClearITPendingBit$419 ==.
                                   1975 ;	../SPL/src/stm8s_uart1.c: 775: void UART1_ClearITPendingBit(UART1_IT_TypeDef UART1_IT)
                                   1976 ; genLabel
                                   1977 ;	-----------------------------------------
                                   1978 ;	 function UART1_ClearITPendingBit
                                   1979 ;	-----------------------------------------
                                   1980 ;	Register assignment is optimal.
                                   1981 ;	Stack space usage: 0 bytes.
      009C6A                       1982 _UART1_ClearITPendingBit:
                           0004CE  1983 	Sstm8s_uart1$UART1_ClearITPendingBit$420 ==.
                           0004CE  1984 	Sstm8s_uart1$UART1_ClearITPendingBit$421 ==.
                                   1985 ;	../SPL/src/stm8s_uart1.c: 780: if (UART1_IT == UART1_IT_RXNE)
                                   1986 ; genCast
                                   1987 ; genAssign
      009C6A 1E 03            [ 2] 1988 	ldw	x, (0x03, sp)
                                   1989 ; genCmpEQorNE
      009C6C A3 02 55         [ 2] 1990 	cpw	x, #0x0255
      009C6F 26 03            [ 1] 1991 	jrne	00112$
      009C71 CC 9C 77         [ 2] 1992 	jp	00113$
      009C74                       1993 00112$:
      009C74 CC 9C 7E         [ 2] 1994 	jp	00102$
      009C77                       1995 00113$:
                           0004DB  1996 	Sstm8s_uart1$UART1_ClearITPendingBit$422 ==.
                                   1997 ; skipping generated iCode
                           0004DB  1998 	Sstm8s_uart1$UART1_ClearITPendingBit$423 ==.
                           0004DB  1999 	Sstm8s_uart1$UART1_ClearITPendingBit$424 ==.
                                   2000 ;	../SPL/src/stm8s_uart1.c: 782: UART1->SR = (uint8_t)~(UART1_SR_RXNE);
                                   2001 ; genPointerSet
      009C77 35 DF 52 30      [ 1] 2002 	mov	0x5230+0, #0xdf
                           0004DF  2003 	Sstm8s_uart1$UART1_ClearITPendingBit$425 ==.
                                   2004 ; genGoto
      009C7B CC 9C 86         [ 2] 2005 	jp	00104$
                                   2006 ; genLabel
      009C7E                       2007 00102$:
                           0004E2  2008 	Sstm8s_uart1$UART1_ClearITPendingBit$426 ==.
                           0004E2  2009 	Sstm8s_uart1$UART1_ClearITPendingBit$427 ==.
                                   2010 ;	../SPL/src/stm8s_uart1.c: 787: UART1->CR4 &= (uint8_t)~(UART1_CR4_LBDF);
                                   2011 ; genPointerGet
      009C7E C6 52 37         [ 1] 2012 	ld	a, 0x5237
                                   2013 ; genAnd
      009C81 A4 EF            [ 1] 2014 	and	a, #0xef
                                   2015 ; genPointerSet
      009C83 C7 52 37         [ 1] 2016 	ld	0x5237, a
                           0004EA  2017 	Sstm8s_uart1$UART1_ClearITPendingBit$428 ==.
                                   2018 ; genLabel
      009C86                       2019 00104$:
                           0004EA  2020 	Sstm8s_uart1$UART1_ClearITPendingBit$429 ==.
                                   2021 ;	../SPL/src/stm8s_uart1.c: 789: }
                                   2022 ; genEndFunction
                           0004EA  2023 	Sstm8s_uart1$UART1_ClearITPendingBit$430 ==.
                           0004EA  2024 	XG$UART1_ClearITPendingBit$0$0 ==.
      009C86 81               [ 4] 2025 	ret
                           0004EB  2026 	Sstm8s_uart1$UART1_ClearITPendingBit$431 ==.
                                   2027 	.area CODE
                                   2028 	.area CONST
                                   2029 	.area INITIALIZER
                                   2030 	.area CABS (ABS)
                                   2031 
                                   2032 	.area .debug_line (NOLOAD)
      0022E9 00 00 06 1D           2033 	.dw	0,Ldebug_line_end-Ldebug_line_start
      0022ED                       2034 Ldebug_line_start:
      0022ED 00 02                 2035 	.dw	2
      0022EF 00 00 00 79           2036 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      0022F3 01                    2037 	.db	1
      0022F4 01                    2038 	.db	1
      0022F5 FB                    2039 	.db	-5
      0022F6 0F                    2040 	.db	15
      0022F7 0A                    2041 	.db	10
      0022F8 00                    2042 	.db	0
      0022F9 01                    2043 	.db	1
      0022FA 01                    2044 	.db	1
      0022FB 01                    2045 	.db	1
      0022FC 01                    2046 	.db	1
      0022FD 00                    2047 	.db	0
      0022FE 00                    2048 	.db	0
      0022FF 00                    2049 	.db	0
      002300 01                    2050 	.db	1
      002301 43 3A 5C 50 72 6F 67  2051 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      002329 00                    2052 	.db	0
      00232A 43 3A 5C 50 72 6F 67  2053 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      00234D 00                    2054 	.db	0
      00234E 00                    2055 	.db	0
      00234F 2E 2E 2F 53 50 4C 2F  2056 	.ascii "../SPL/src/stm8s_uart1.c"
             73 72 63 2F 73 74 6D
             38 73 5F 75 61 72 74
             31 2E 63
      002367 00                    2057 	.db	0
      002368 00                    2058 	.uleb128	0
      002369 00                    2059 	.uleb128	0
      00236A 00                    2060 	.uleb128	0
      00236B 00                    2061 	.db	0
      00236C                       2062 Ldebug_line_stmt:
      00236C 00                    2063 	.db	0
      00236D 05                    2064 	.uleb128	5
      00236E 02                    2065 	.db	2
      00236F 00 00 97 9C           2066 	.dw	0,(Sstm8s_uart1$UART1_DeInit$0)
      002373 03                    2067 	.db	3
      002374 34                    2068 	.sleb128	52
      002375 01                    2069 	.db	1
      002376 09                    2070 	.db	9
      002377 00 00                 2071 	.dw	Sstm8s_uart1$UART1_DeInit$2-Sstm8s_uart1$UART1_DeInit$0
      002379 03                    2072 	.db	3
      00237A 04                    2073 	.sleb128	4
      00237B 01                    2074 	.db	1
      00237C 09                    2075 	.db	9
      00237D 00 03                 2076 	.dw	Sstm8s_uart1$UART1_DeInit$3-Sstm8s_uart1$UART1_DeInit$2
      00237F 03                    2077 	.db	3
      002380 01                    2078 	.sleb128	1
      002381 01                    2079 	.db	1
      002382 09                    2080 	.db	9
      002383 00 03                 2081 	.dw	Sstm8s_uart1$UART1_DeInit$4-Sstm8s_uart1$UART1_DeInit$3
      002385 03                    2082 	.db	3
      002386 02                    2083 	.sleb128	2
      002387 01                    2084 	.db	1
      002388 09                    2085 	.db	9
      002389 00 04                 2086 	.dw	Sstm8s_uart1$UART1_DeInit$5-Sstm8s_uart1$UART1_DeInit$4
      00238B 03                    2087 	.db	3
      00238C 01                    2088 	.sleb128	1
      00238D 01                    2089 	.db	1
      00238E 09                    2090 	.db	9
      00238F 00 04                 2091 	.dw	Sstm8s_uart1$UART1_DeInit$6-Sstm8s_uart1$UART1_DeInit$5
      002391 03                    2092 	.db	3
      002392 02                    2093 	.sleb128	2
      002393 01                    2094 	.db	1
      002394 09                    2095 	.db	9
      002395 00 04                 2096 	.dw	Sstm8s_uart1$UART1_DeInit$7-Sstm8s_uart1$UART1_DeInit$6
      002397 03                    2097 	.db	3
      002398 01                    2098 	.sleb128	1
      002399 01                    2099 	.db	1
      00239A 09                    2100 	.db	9
      00239B 00 04                 2101 	.dw	Sstm8s_uart1$UART1_DeInit$8-Sstm8s_uart1$UART1_DeInit$7
      00239D 03                    2102 	.db	3
      00239E 01                    2103 	.sleb128	1
      00239F 01                    2104 	.db	1
      0023A0 09                    2105 	.db	9
      0023A1 00 04                 2106 	.dw	Sstm8s_uart1$UART1_DeInit$9-Sstm8s_uart1$UART1_DeInit$8
      0023A3 03                    2107 	.db	3
      0023A4 01                    2108 	.sleb128	1
      0023A5 01                    2109 	.db	1
      0023A6 09                    2110 	.db	9
      0023A7 00 04                 2111 	.dw	Sstm8s_uart1$UART1_DeInit$10-Sstm8s_uart1$UART1_DeInit$9
      0023A9 03                    2112 	.db	3
      0023AA 01                    2113 	.sleb128	1
      0023AB 01                    2114 	.db	1
      0023AC 09                    2115 	.db	9
      0023AD 00 04                 2116 	.dw	Sstm8s_uart1$UART1_DeInit$11-Sstm8s_uart1$UART1_DeInit$10
      0023AF 03                    2117 	.db	3
      0023B0 02                    2118 	.sleb128	2
      0023B1 01                    2119 	.db	1
      0023B2 09                    2120 	.db	9
      0023B3 00 04                 2121 	.dw	Sstm8s_uart1$UART1_DeInit$12-Sstm8s_uart1$UART1_DeInit$11
      0023B5 03                    2122 	.db	3
      0023B6 01                    2123 	.sleb128	1
      0023B7 01                    2124 	.db	1
      0023B8 09                    2125 	.db	9
      0023B9 00 04                 2126 	.dw	Sstm8s_uart1$UART1_DeInit$13-Sstm8s_uart1$UART1_DeInit$12
      0023BB 03                    2127 	.db	3
      0023BC 01                    2128 	.sleb128	1
      0023BD 01                    2129 	.db	1
      0023BE 09                    2130 	.db	9
      0023BF 00 01                 2131 	.dw	1+Sstm8s_uart1$UART1_DeInit$14-Sstm8s_uart1$UART1_DeInit$13
      0023C1 00                    2132 	.db	0
      0023C2 01                    2133 	.uleb128	1
      0023C3 01                    2134 	.db	1
      0023C4 00                    2135 	.db	0
      0023C5 05                    2136 	.uleb128	5
      0023C6 02                    2137 	.db	2
      0023C7 00 00 97 C7           2138 	.dw	0,(Sstm8s_uart1$UART1_Init$16)
      0023CB 03                    2139 	.db	3
      0023CC D9 00                 2140 	.sleb128	89
      0023CE 01                    2141 	.db	1
      0023CF 09                    2142 	.db	9
      0023D0 00 02                 2143 	.dw	Sstm8s_uart1$UART1_Init$19-Sstm8s_uart1$UART1_Init$16
      0023D2 03                    2144 	.db	3
      0023D3 0F                    2145 	.sleb128	15
      0023D4 01                    2146 	.db	1
      0023D5 09                    2147 	.db	9
      0023D6 00 08                 2148 	.dw	Sstm8s_uart1$UART1_Init$20-Sstm8s_uart1$UART1_Init$19
      0023D8 03                    2149 	.db	3
      0023D9 03                    2150 	.sleb128	3
      0023DA 01                    2151 	.db	1
      0023DB 09                    2152 	.db	9
      0023DC 00 08                 2153 	.dw	Sstm8s_uart1$UART1_Init$21-Sstm8s_uart1$UART1_Init$20
      0023DE 03                    2154 	.db	3
      0023DF 03                    2155 	.sleb128	3
      0023E0 01                    2156 	.db	1
      0023E1 09                    2157 	.db	9
      0023E2 00 08                 2158 	.dw	Sstm8s_uart1$UART1_Init$22-Sstm8s_uart1$UART1_Init$21
      0023E4 03                    2159 	.db	3
      0023E5 02                    2160 	.sleb128	2
      0023E6 01                    2161 	.db	1
      0023E7 09                    2162 	.db	9
      0023E8 00 08                 2163 	.dw	Sstm8s_uart1$UART1_Init$23-Sstm8s_uart1$UART1_Init$22
      0023EA 03                    2164 	.db	3
      0023EB 03                    2165 	.sleb128	3
      0023EC 01                    2166 	.db	1
      0023ED 09                    2167 	.db	9
      0023EE 00 08                 2168 	.dw	Sstm8s_uart1$UART1_Init$24-Sstm8s_uart1$UART1_Init$23
      0023F0 03                    2169 	.db	3
      0023F1 02                    2170 	.sleb128	2
      0023F2 01                    2171 	.db	1
      0023F3 09                    2172 	.db	9
      0023F4 00 08                 2173 	.dw	Sstm8s_uart1$UART1_Init$25-Sstm8s_uart1$UART1_Init$24
      0023F6 03                    2174 	.db	3
      0023F7 03                    2175 	.sleb128	3
      0023F8 01                    2176 	.db	1
      0023F9 09                    2177 	.db	9
      0023FA 00 07                 2178 	.dw	Sstm8s_uart1$UART1_Init$26-Sstm8s_uart1$UART1_Init$25
      0023FC 03                    2179 	.db	3
      0023FD 02                    2180 	.sleb128	2
      0023FE 01                    2181 	.db	1
      0023FF 09                    2182 	.db	9
      002400 00 08                 2183 	.dw	Sstm8s_uart1$UART1_Init$27-Sstm8s_uart1$UART1_Init$26
      002402 03                    2184 	.db	3
      002403 02                    2185 	.sleb128	2
      002404 01                    2186 	.db	1
      002405 09                    2187 	.db	9
      002406 00 08                 2188 	.dw	Sstm8s_uart1$UART1_Init$28-Sstm8s_uart1$UART1_Init$27
      002408 03                    2189 	.db	3
      002409 03                    2190 	.sleb128	3
      00240A 01                    2191 	.db	1
      00240B 09                    2192 	.db	9
      00240C 00 33                 2193 	.dw	Sstm8s_uart1$UART1_Init$34-Sstm8s_uart1$UART1_Init$28
      00240E 03                    2194 	.db	3
      00240F 01                    2195 	.sleb128	1
      002410 01                    2196 	.db	1
      002411 09                    2197 	.db	9
      002412 00 2E                 2198 	.dw	Sstm8s_uart1$UART1_Init$46-Sstm8s_uart1$UART1_Init$34
      002414 03                    2199 	.db	3
      002415 02                    2200 	.sleb128	2
      002416 01                    2201 	.db	1
      002417 09                    2202 	.db	9
      002418 00 51                 2203 	.dw	Sstm8s_uart1$UART1_Init$60-Sstm8s_uart1$UART1_Init$46
      00241A 03                    2204 	.db	3
      00241B 02                    2205 	.sleb128	2
      00241C 01                    2206 	.db	1
      00241D 09                    2207 	.db	9
      00241E 00 12                 2208 	.dw	Sstm8s_uart1$UART1_Init$61-Sstm8s_uart1$UART1_Init$60
      002420 03                    2209 	.db	3
      002421 02                    2210 	.sleb128	2
      002422 01                    2211 	.db	1
      002423 09                    2212 	.db	9
      002424 00 0C                 2213 	.dw	Sstm8s_uart1$UART1_Init$62-Sstm8s_uart1$UART1_Init$61
      002426 03                    2214 	.db	3
      002427 03                    2215 	.sleb128	3
      002428 01                    2216 	.db	1
      002429 09                    2217 	.db	9
      00242A 00 08                 2218 	.dw	Sstm8s_uart1$UART1_Init$63-Sstm8s_uart1$UART1_Init$62
      00242C 03                    2219 	.db	3
      00242D 02                    2220 	.sleb128	2
      00242E 01                    2221 	.db	1
      00242F 09                    2222 	.db	9
      002430 00 08                 2223 	.dw	Sstm8s_uart1$UART1_Init$64-Sstm8s_uart1$UART1_Init$63
      002432 03                    2224 	.db	3
      002433 02                    2225 	.sleb128	2
      002434 01                    2226 	.db	1
      002435 09                    2227 	.db	9
      002436 00 0E                 2228 	.dw	Sstm8s_uart1$UART1_Init$65-Sstm8s_uart1$UART1_Init$64
      002438 03                    2229 	.db	3
      002439 7C                    2230 	.sleb128	-4
      00243A 01                    2231 	.db	1
      00243B 09                    2232 	.db	9
      00243C 00 03                 2233 	.dw	Sstm8s_uart1$UART1_Init$66-Sstm8s_uart1$UART1_Init$65
      00243E 03                    2234 	.db	3
      00243F 07                    2235 	.sleb128	7
      002440 01                    2236 	.db	1
      002441 09                    2237 	.db	9
      002442 00 0B                 2238 	.dw	Sstm8s_uart1$UART1_Init$70-Sstm8s_uart1$UART1_Init$66
      002444 03                    2239 	.db	3
      002445 03                    2240 	.sleb128	3
      002446 01                    2241 	.db	1
      002447 09                    2242 	.db	9
      002448 00 08                 2243 	.dw	Sstm8s_uart1$UART1_Init$73-Sstm8s_uart1$UART1_Init$70
      00244A 03                    2244 	.db	3
      00244B 05                    2245 	.sleb128	5
      00244C 01                    2246 	.db	1
      00244D 09                    2247 	.db	9
      00244E 00 05                 2248 	.dw	Sstm8s_uart1$UART1_Init$75-Sstm8s_uart1$UART1_Init$73
      002450 03                    2249 	.db	3
      002451 71                    2250 	.sleb128	-15
      002452 01                    2251 	.db	1
      002453 09                    2252 	.db	9
      002454 00 03                 2253 	.dw	Sstm8s_uart1$UART1_Init$76-Sstm8s_uart1$UART1_Init$75
      002456 03                    2254 	.db	3
      002457 11                    2255 	.sleb128	17
      002458 01                    2256 	.db	1
      002459 09                    2257 	.db	9
      00245A 00 0B                 2258 	.dw	Sstm8s_uart1$UART1_Init$80-Sstm8s_uart1$UART1_Init$76
      00245C 03                    2259 	.db	3
      00245D 03                    2260 	.sleb128	3
      00245E 01                    2261 	.db	1
      00245F 09                    2262 	.db	9
      002460 00 08                 2263 	.dw	Sstm8s_uart1$UART1_Init$83-Sstm8s_uart1$UART1_Init$80
      002462 03                    2264 	.db	3
      002463 05                    2265 	.sleb128	5
      002464 01                    2266 	.db	1
      002465 09                    2267 	.db	9
      002466 00 05                 2268 	.dw	Sstm8s_uart1$UART1_Init$85-Sstm8s_uart1$UART1_Init$83
      002468 03                    2269 	.db	3
      002469 4C                    2270 	.sleb128	-52
      00246A 01                    2271 	.db	1
      00246B 09                    2272 	.db	9
      00246C 00 03                 2273 	.dw	Sstm8s_uart1$UART1_Init$86-Sstm8s_uart1$UART1_Init$85
      00246E 03                    2274 	.db	3
      00246F 38                    2275 	.sleb128	56
      002470 01                    2276 	.db	1
      002471 09                    2277 	.db	9
      002472 00 07                 2278 	.dw	Sstm8s_uart1$UART1_Init$88-Sstm8s_uart1$UART1_Init$86
      002474 03                    2279 	.db	3
      002475 03                    2280 	.sleb128	3
      002476 01                    2281 	.db	1
      002477 09                    2282 	.db	9
      002478 00 08                 2283 	.dw	Sstm8s_uart1$UART1_Init$91-Sstm8s_uart1$UART1_Init$88
      00247A 03                    2284 	.db	3
      00247B 04                    2285 	.sleb128	4
      00247C 01                    2286 	.db	1
      00247D 09                    2287 	.db	9
      00247E 00 0D                 2288 	.dw	Sstm8s_uart1$UART1_Init$95-Sstm8s_uart1$UART1_Init$91
      002480 03                    2289 	.db	3
      002481 02                    2290 	.sleb128	2
      002482 01                    2291 	.db	1
      002483 09                    2292 	.db	9
      002484 00 03                 2293 	.dw	1+Sstm8s_uart1$UART1_Init$97-Sstm8s_uart1$UART1_Init$95
      002486 00                    2294 	.db	0
      002487 01                    2295 	.uleb128	1
      002488 01                    2296 	.db	1
      002489 00                    2297 	.db	0
      00248A 05                    2298 	.uleb128	5
      00248B 02                    2299 	.db	2
      00248C 00 00 99 56           2300 	.dw	0,(Sstm8s_uart1$UART1_Cmd$99)
      002490 03                    2301 	.db	3
      002491 B7 01                 2302 	.sleb128	183
      002493 01                    2303 	.db	1
      002494 09                    2304 	.db	9
      002495 00 00                 2305 	.dw	Sstm8s_uart1$UART1_Cmd$101-Sstm8s_uart1$UART1_Cmd$99
      002497 03                    2306 	.db	3
      002498 05                    2307 	.sleb128	5
      002499 01                    2308 	.db	1
      00249A 09                    2309 	.db	9
      00249B 00 03                 2310 	.dw	Sstm8s_uart1$UART1_Cmd$102-Sstm8s_uart1$UART1_Cmd$101
      00249D 03                    2311 	.db	3
      00249E 7D                    2312 	.sleb128	-3
      00249F 01                    2313 	.db	1
      0024A0 09                    2314 	.db	9
      0024A1 00 07                 2315 	.dw	Sstm8s_uart1$UART1_Cmd$104-Sstm8s_uart1$UART1_Cmd$102
      0024A3 03                    2316 	.db	3
      0024A4 03                    2317 	.sleb128	3
      0024A5 01                    2318 	.db	1
      0024A6 09                    2319 	.db	9
      0024A7 00 08                 2320 	.dw	Sstm8s_uart1$UART1_Cmd$107-Sstm8s_uart1$UART1_Cmd$104
      0024A9 03                    2321 	.db	3
      0024AA 05                    2322 	.sleb128	5
      0024AB 01                    2323 	.db	1
      0024AC 09                    2324 	.db	9
      0024AD 00 05                 2325 	.dw	Sstm8s_uart1$UART1_Cmd$109-Sstm8s_uart1$UART1_Cmd$107
      0024AF 03                    2326 	.db	3
      0024B0 02                    2327 	.sleb128	2
      0024B1 01                    2328 	.db	1
      0024B2 09                    2329 	.db	9
      0024B3 00 01                 2330 	.dw	1+Sstm8s_uart1$UART1_Cmd$110-Sstm8s_uart1$UART1_Cmd$109
      0024B5 00                    2331 	.db	0
      0024B6 01                    2332 	.uleb128	1
      0024B7 01                    2333 	.db	1
      0024B8 00                    2334 	.db	0
      0024B9 05                    2335 	.uleb128	5
      0024BA 02                    2336 	.db	2
      0024BB 00 00 99 6E           2337 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$112)
      0024BF 03                    2338 	.db	3
      0024C0 D2 01                 2339 	.sleb128	210
      0024C2 01                    2340 	.db	1
      0024C3 09                    2341 	.db	9
      0024C4 00 01                 2342 	.dw	Sstm8s_uart1$UART1_ITConfig$115-Sstm8s_uart1$UART1_ITConfig$112
      0024C6 03                    2343 	.db	3
      0024C7 09                    2344 	.sleb128	9
      0024C8 01                    2345 	.db	1
      0024C9 09                    2346 	.db	9
      0024CA 00 03                 2347 	.dw	Sstm8s_uart1$UART1_ITConfig$116-Sstm8s_uart1$UART1_ITConfig$115
      0024CC 03                    2348 	.db	3
      0024CD 02                    2349 	.sleb128	2
      0024CE 01                    2350 	.db	1
      0024CF 09                    2351 	.db	9
      0024D0 00 12                 2352 	.dw	Sstm8s_uart1$UART1_ITConfig$119-Sstm8s_uart1$UART1_ITConfig$116
      0024D2 03                    2353 	.db	3
      0024D3 05                    2354 	.sleb128	5
      0024D4 01                    2355 	.db	1
      0024D5 09                    2356 	.db	9
      0024D6 00 0D                 2357 	.dw	Sstm8s_uart1$UART1_ITConfig$121-Sstm8s_uart1$UART1_ITConfig$119
      0024D8 03                    2358 	.db	3
      0024D9 04                    2359 	.sleb128	4
      0024DA 01                    2360 	.db	1
      0024DB 09                    2361 	.db	9
      0024DC 00 0B                 2362 	.dw	Sstm8s_uart1$UART1_ITConfig$123-Sstm8s_uart1$UART1_ITConfig$121
      0024DE 03                    2363 	.db	3
      0024DF 79                    2364 	.sleb128	-7
      0024E0 01                    2365 	.db	1
      0024E1 09                    2366 	.db	9
      0024E2 00 07                 2367 	.dw	Sstm8s_uart1$UART1_ITConfig$125-Sstm8s_uart1$UART1_ITConfig$123
      0024E4 03                    2368 	.db	3
      0024E5 03                    2369 	.sleb128	3
      0024E6 01                    2370 	.db	1
      0024E7 09                    2371 	.db	9
      0024E8 00 07                 2372 	.dw	Sstm8s_uart1$UART1_ITConfig$127-Sstm8s_uart1$UART1_ITConfig$125
      0024EA 03                    2373 	.db	3
      0024EB 02                    2374 	.sleb128	2
      0024EC 01                    2375 	.db	1
      0024ED 09                    2376 	.db	9
      0024EE 00 0B                 2377 	.dw	Sstm8s_uart1$UART1_ITConfig$129-Sstm8s_uart1$UART1_ITConfig$127
      0024F0 03                    2378 	.db	3
      0024F1 02                    2379 	.sleb128	2
      0024F2 01                    2380 	.db	1
      0024F3 09                    2381 	.db	9
      0024F4 00 06                 2382 	.dw	Sstm8s_uart1$UART1_ITConfig$131-Sstm8s_uart1$UART1_ITConfig$129
      0024F6 03                    2383 	.db	3
      0024F7 02                    2384 	.sleb128	2
      0024F8 01                    2385 	.db	1
      0024F9 09                    2386 	.db	9
      0024FA 00 0B                 2387 	.dw	Sstm8s_uart1$UART1_ITConfig$134-Sstm8s_uart1$UART1_ITConfig$131
      0024FC 03                    2388 	.db	3
      0024FD 04                    2389 	.sleb128	4
      0024FE 01                    2390 	.db	1
      0024FF 09                    2391 	.db	9
      002500 00 0B                 2392 	.dw	Sstm8s_uart1$UART1_ITConfig$136-Sstm8s_uart1$UART1_ITConfig$134
      002502 03                    2393 	.db	3
      002503 08                    2394 	.sleb128	8
      002504 01                    2395 	.db	1
      002505 09                    2396 	.db	9
      002506 00 04                 2397 	.dw	Sstm8s_uart1$UART1_ITConfig$140-Sstm8s_uart1$UART1_ITConfig$136
      002508 03                    2398 	.db	3
      002509 7E                    2399 	.sleb128	-2
      00250A 01                    2400 	.db	1
      00250B 09                    2401 	.db	9
      00250C 00 07                 2402 	.dw	Sstm8s_uart1$UART1_ITConfig$142-Sstm8s_uart1$UART1_ITConfig$140
      00250E 03                    2403 	.db	3
      00250F 02                    2404 	.sleb128	2
      002510 01                    2405 	.db	1
      002511 09                    2406 	.db	9
      002512 00 0B                 2407 	.dw	Sstm8s_uart1$UART1_ITConfig$144-Sstm8s_uart1$UART1_ITConfig$142
      002514 03                    2408 	.db	3
      002515 02                    2409 	.sleb128	2
      002516 01                    2410 	.db	1
      002517 09                    2411 	.db	9
      002518 00 06                 2412 	.dw	Sstm8s_uart1$UART1_ITConfig$146-Sstm8s_uart1$UART1_ITConfig$144
      00251A 03                    2413 	.db	3
      00251B 02                    2414 	.sleb128	2
      00251C 01                    2415 	.db	1
      00251D 09                    2416 	.db	9
      00251E 00 0B                 2417 	.dw	Sstm8s_uart1$UART1_ITConfig$149-Sstm8s_uart1$UART1_ITConfig$146
      002520 03                    2418 	.db	3
      002521 04                    2419 	.sleb128	4
      002522 01                    2420 	.db	1
      002523 09                    2421 	.db	9
      002524 00 08                 2422 	.dw	Sstm8s_uart1$UART1_ITConfig$151-Sstm8s_uart1$UART1_ITConfig$149
      002526 03                    2423 	.db	3
      002527 04                    2424 	.sleb128	4
      002528 01                    2425 	.db	1
      002529 09                    2426 	.db	9
      00252A 00 02                 2427 	.dw	1+Sstm8s_uart1$UART1_ITConfig$153-Sstm8s_uart1$UART1_ITConfig$151
      00252C 00                    2428 	.db	0
      00252D 01                    2429 	.uleb128	1
      00252E 01                    2430 	.db	1
      00252F 00                    2431 	.db	0
      002530 05                    2432 	.uleb128	5
      002531 02                    2433 	.db	2
      002532 00 00 9A 02           2434 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$155)
      002536 03                    2435 	.db	3
      002537 88 02                 2436 	.sleb128	264
      002539 01                    2437 	.db	1
      00253A 09                    2438 	.db	9
      00253B 00 00                 2439 	.dw	Sstm8s_uart1$UART1_HalfDuplexCmd$157-Sstm8s_uart1$UART1_HalfDuplexCmd$155
      00253D 03                    2440 	.db	3
      00253E 06                    2441 	.sleb128	6
      00253F 01                    2442 	.db	1
      002540 09                    2443 	.db	9
      002541 00 03                 2444 	.dw	Sstm8s_uart1$UART1_HalfDuplexCmd$158-Sstm8s_uart1$UART1_HalfDuplexCmd$157
      002543 03                    2445 	.db	3
      002544 7E                    2446 	.sleb128	-2
      002545 01                    2447 	.db	1
      002546 09                    2448 	.db	9
      002547 00 07                 2449 	.dw	Sstm8s_uart1$UART1_HalfDuplexCmd$160-Sstm8s_uart1$UART1_HalfDuplexCmd$158
      002549 03                    2450 	.db	3
      00254A 02                    2451 	.sleb128	2
      00254B 01                    2452 	.db	1
      00254C 09                    2453 	.db	9
      00254D 00 08                 2454 	.dw	Sstm8s_uart1$UART1_HalfDuplexCmd$163-Sstm8s_uart1$UART1_HalfDuplexCmd$160
      00254F 03                    2455 	.db	3
      002550 04                    2456 	.sleb128	4
      002551 01                    2457 	.db	1
      002552 09                    2458 	.db	9
      002553 00 05                 2459 	.dw	Sstm8s_uart1$UART1_HalfDuplexCmd$165-Sstm8s_uart1$UART1_HalfDuplexCmd$163
      002555 03                    2460 	.db	3
      002556 02                    2461 	.sleb128	2
      002557 01                    2462 	.db	1
      002558 09                    2463 	.db	9
      002559 00 01                 2464 	.dw	1+Sstm8s_uart1$UART1_HalfDuplexCmd$166-Sstm8s_uart1$UART1_HalfDuplexCmd$165
      00255B 00                    2465 	.db	0
      00255C 01                    2466 	.uleb128	1
      00255D 01                    2467 	.db	1
      00255E 00                    2468 	.db	0
      00255F 05                    2469 	.uleb128	5
      002560 02                    2470 	.db	2
      002561 00 00 9A 1A           2471 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$168)
      002565 03                    2472 	.db	3
      002566 9C 02                 2473 	.sleb128	284
      002568 01                    2474 	.db	1
      002569 09                    2475 	.db	9
      00256A 00 00                 2476 	.dw	Sstm8s_uart1$UART1_IrDAConfig$170-Sstm8s_uart1$UART1_IrDAConfig$168
      00256C 03                    2477 	.db	3
      00256D 06                    2478 	.sleb128	6
      00256E 01                    2479 	.db	1
      00256F 09                    2480 	.db	9
      002570 00 03                 2481 	.dw	Sstm8s_uart1$UART1_IrDAConfig$171-Sstm8s_uart1$UART1_IrDAConfig$170
      002572 03                    2482 	.db	3
      002573 7E                    2483 	.sleb128	-2
      002574 01                    2484 	.db	1
      002575 09                    2485 	.db	9
      002576 00 07                 2486 	.dw	Sstm8s_uart1$UART1_IrDAConfig$173-Sstm8s_uart1$UART1_IrDAConfig$171
      002578 03                    2487 	.db	3
      002579 02                    2488 	.sleb128	2
      00257A 01                    2489 	.db	1
      00257B 09                    2490 	.db	9
      00257C 00 08                 2491 	.dw	Sstm8s_uart1$UART1_IrDAConfig$176-Sstm8s_uart1$UART1_IrDAConfig$173
      00257E 03                    2492 	.db	3
      00257F 04                    2493 	.sleb128	4
      002580 01                    2494 	.db	1
      002581 09                    2495 	.db	9
      002582 00 05                 2496 	.dw	Sstm8s_uart1$UART1_IrDAConfig$178-Sstm8s_uart1$UART1_IrDAConfig$176
      002584 03                    2497 	.db	3
      002585 02                    2498 	.sleb128	2
      002586 01                    2499 	.db	1
      002587 09                    2500 	.db	9
      002588 00 01                 2501 	.dw	1+Sstm8s_uart1$UART1_IrDAConfig$179-Sstm8s_uart1$UART1_IrDAConfig$178
      00258A 00                    2502 	.db	0
      00258B 01                    2503 	.uleb128	1
      00258C 01                    2504 	.db	1
      00258D 00                    2505 	.db	0
      00258E 05                    2506 	.uleb128	5
      00258F 02                    2507 	.db	2
      002590 00 00 9A 32           2508 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$181)
      002594 03                    2509 	.db	3
      002595 B0 02                 2510 	.sleb128	304
      002597 01                    2511 	.db	1
      002598 09                    2512 	.db	9
      002599 00 00                 2513 	.dw	Sstm8s_uart1$UART1_IrDACmd$183-Sstm8s_uart1$UART1_IrDACmd$181
      00259B 03                    2514 	.db	3
      00259C 08                    2515 	.sleb128	8
      00259D 01                    2516 	.db	1
      00259E 09                    2517 	.db	9
      00259F 00 03                 2518 	.dw	Sstm8s_uart1$UART1_IrDACmd$184-Sstm8s_uart1$UART1_IrDACmd$183
      0025A1 03                    2519 	.db	3
      0025A2 7D                    2520 	.sleb128	-3
      0025A3 01                    2521 	.db	1
      0025A4 09                    2522 	.db	9
      0025A5 00 07                 2523 	.dw	Sstm8s_uart1$UART1_IrDACmd$186-Sstm8s_uart1$UART1_IrDACmd$184
      0025A7 03                    2524 	.db	3
      0025A8 03                    2525 	.sleb128	3
      0025A9 01                    2526 	.db	1
      0025AA 09                    2527 	.db	9
      0025AB 00 08                 2528 	.dw	Sstm8s_uart1$UART1_IrDACmd$189-Sstm8s_uart1$UART1_IrDACmd$186
      0025AD 03                    2529 	.db	3
      0025AE 05                    2530 	.sleb128	5
      0025AF 01                    2531 	.db	1
      0025B0 09                    2532 	.db	9
      0025B1 00 05                 2533 	.dw	Sstm8s_uart1$UART1_IrDACmd$191-Sstm8s_uart1$UART1_IrDACmd$189
      0025B3 03                    2534 	.db	3
      0025B4 02                    2535 	.sleb128	2
      0025B5 01                    2536 	.db	1
      0025B6 09                    2537 	.db	9
      0025B7 00 01                 2538 	.dw	1+Sstm8s_uart1$UART1_IrDACmd$192-Sstm8s_uart1$UART1_IrDACmd$191
      0025B9 00                    2539 	.db	0
      0025BA 01                    2540 	.uleb128	1
      0025BB 01                    2541 	.db	1
      0025BC 00                    2542 	.db	0
      0025BD 05                    2543 	.uleb128	5
      0025BE 02                    2544 	.db	2
      0025BF 00 00 9A 4A           2545 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$194)
      0025C3 03                    2546 	.db	3
      0025C4 C8 02                 2547 	.sleb128	328
      0025C6 01                    2548 	.db	1
      0025C7 09                    2549 	.db	9
      0025C8 00 00                 2550 	.dw	Sstm8s_uart1$UART1_LINBreakDetectionConfig$196-Sstm8s_uart1$UART1_LINBreakDetectionConfig$194
      0025CA 03                    2551 	.db	3
      0025CB 06                    2552 	.sleb128	6
      0025CC 01                    2553 	.db	1
      0025CD 09                    2554 	.db	9
      0025CE 00 03                 2555 	.dw	Sstm8s_uart1$UART1_LINBreakDetectionConfig$197-Sstm8s_uart1$UART1_LINBreakDetectionConfig$196
      0025D0 03                    2556 	.db	3
      0025D1 7E                    2557 	.sleb128	-2
      0025D2 01                    2558 	.db	1
      0025D3 09                    2559 	.db	9
      0025D4 00 07                 2560 	.dw	Sstm8s_uart1$UART1_LINBreakDetectionConfig$199-Sstm8s_uart1$UART1_LINBreakDetectionConfig$197
      0025D6 03                    2561 	.db	3
      0025D7 02                    2562 	.sleb128	2
      0025D8 01                    2563 	.db	1
      0025D9 09                    2564 	.db	9
      0025DA 00 08                 2565 	.dw	Sstm8s_uart1$UART1_LINBreakDetectionConfig$202-Sstm8s_uart1$UART1_LINBreakDetectionConfig$199
      0025DC 03                    2566 	.db	3
      0025DD 04                    2567 	.sleb128	4
      0025DE 01                    2568 	.db	1
      0025DF 09                    2569 	.db	9
      0025E0 00 05                 2570 	.dw	Sstm8s_uart1$UART1_LINBreakDetectionConfig$204-Sstm8s_uart1$UART1_LINBreakDetectionConfig$202
      0025E2 03                    2571 	.db	3
      0025E3 02                    2572 	.sleb128	2
      0025E4 01                    2573 	.db	1
      0025E5 09                    2574 	.db	9
      0025E6 00 01                 2575 	.dw	1+Sstm8s_uart1$UART1_LINBreakDetectionConfig$205-Sstm8s_uart1$UART1_LINBreakDetectionConfig$204
      0025E8 00                    2576 	.db	0
      0025E9 01                    2577 	.uleb128	1
      0025EA 01                    2578 	.db	1
      0025EB 00                    2579 	.db	0
      0025EC 05                    2580 	.uleb128	5
      0025ED 02                    2581 	.db	2
      0025EE 00 00 9A 62           2582 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$207)
      0025F2 03                    2583 	.db	3
      0025F3 DC 02                 2584 	.sleb128	348
      0025F5 01                    2585 	.db	1
      0025F6 09                    2586 	.db	9
      0025F7 00 00                 2587 	.dw	Sstm8s_uart1$UART1_LINCmd$209-Sstm8s_uart1$UART1_LINCmd$207
      0025F9 03                    2588 	.db	3
      0025FA 07                    2589 	.sleb128	7
      0025FB 01                    2590 	.db	1
      0025FC 09                    2591 	.db	9
      0025FD 00 03                 2592 	.dw	Sstm8s_uart1$UART1_LINCmd$210-Sstm8s_uart1$UART1_LINCmd$209
      0025FF 03                    2593 	.db	3
      002600 7D                    2594 	.sleb128	-3
      002601 01                    2595 	.db	1
      002602 09                    2596 	.db	9
      002603 00 07                 2597 	.dw	Sstm8s_uart1$UART1_LINCmd$212-Sstm8s_uart1$UART1_LINCmd$210
      002605 03                    2598 	.db	3
      002606 03                    2599 	.sleb128	3
      002607 01                    2600 	.db	1
      002608 09                    2601 	.db	9
      002609 00 08                 2602 	.dw	Sstm8s_uart1$UART1_LINCmd$215-Sstm8s_uart1$UART1_LINCmd$212
      00260B 03                    2603 	.db	3
      00260C 05                    2604 	.sleb128	5
      00260D 01                    2605 	.db	1
      00260E 09                    2606 	.db	9
      00260F 00 05                 2607 	.dw	Sstm8s_uart1$UART1_LINCmd$217-Sstm8s_uart1$UART1_LINCmd$215
      002611 03                    2608 	.db	3
      002612 02                    2609 	.sleb128	2
      002613 01                    2610 	.db	1
      002614 09                    2611 	.db	9
      002615 00 01                 2612 	.dw	1+Sstm8s_uart1$UART1_LINCmd$218-Sstm8s_uart1$UART1_LINCmd$217
      002617 00                    2613 	.db	0
      002618 01                    2614 	.uleb128	1
      002619 01                    2615 	.db	1
      00261A 00                    2616 	.db	0
      00261B 05                    2617 	.uleb128	5
      00261C 02                    2618 	.db	2
      00261D 00 00 9A 7A           2619 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$220)
      002621 03                    2620 	.db	3
      002622 F2 02                 2621 	.sleb128	370
      002624 01                    2622 	.db	1
      002625 09                    2623 	.db	9
      002626 00 00                 2624 	.dw	Sstm8s_uart1$UART1_SmartCardCmd$222-Sstm8s_uart1$UART1_SmartCardCmd$220
      002628 03                    2625 	.db	3
      002629 07                    2626 	.sleb128	7
      00262A 01                    2627 	.db	1
      00262B 09                    2628 	.db	9
      00262C 00 03                 2629 	.dw	Sstm8s_uart1$UART1_SmartCardCmd$223-Sstm8s_uart1$UART1_SmartCardCmd$222
      00262E 03                    2630 	.db	3
      00262F 7D                    2631 	.sleb128	-3
      002630 01                    2632 	.db	1
      002631 09                    2633 	.db	9
      002632 00 07                 2634 	.dw	Sstm8s_uart1$UART1_SmartCardCmd$225-Sstm8s_uart1$UART1_SmartCardCmd$223
      002634 03                    2635 	.db	3
      002635 03                    2636 	.sleb128	3
      002636 01                    2637 	.db	1
      002637 09                    2638 	.db	9
      002638 00 08                 2639 	.dw	Sstm8s_uart1$UART1_SmartCardCmd$228-Sstm8s_uart1$UART1_SmartCardCmd$225
      00263A 03                    2640 	.db	3
      00263B 05                    2641 	.sleb128	5
      00263C 01                    2642 	.db	1
      00263D 09                    2643 	.db	9
      00263E 00 05                 2644 	.dw	Sstm8s_uart1$UART1_SmartCardCmd$230-Sstm8s_uart1$UART1_SmartCardCmd$228
      002640 03                    2645 	.db	3
      002641 02                    2646 	.sleb128	2
      002642 01                    2647 	.db	1
      002643 09                    2648 	.db	9
      002644 00 01                 2649 	.dw	1+Sstm8s_uart1$UART1_SmartCardCmd$231-Sstm8s_uart1$UART1_SmartCardCmd$230
      002646 00                    2650 	.db	0
      002647 01                    2651 	.uleb128	1
      002648 01                    2652 	.db	1
      002649 00                    2653 	.db	0
      00264A 05                    2654 	.uleb128	5
      00264B 02                    2655 	.db	2
      00264C 00 00 9A 92           2656 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$233)
      002650 03                    2657 	.db	3
      002651 89 03                 2658 	.sleb128	393
      002653 01                    2659 	.db	1
      002654 09                    2660 	.db	9
      002655 00 00                 2661 	.dw	Sstm8s_uart1$UART1_SmartCardNACKCmd$235-Sstm8s_uart1$UART1_SmartCardNACKCmd$233
      002657 03                    2662 	.db	3
      002658 07                    2663 	.sleb128	7
      002659 01                    2664 	.db	1
      00265A 09                    2665 	.db	9
      00265B 00 03                 2666 	.dw	Sstm8s_uart1$UART1_SmartCardNACKCmd$236-Sstm8s_uart1$UART1_SmartCardNACKCmd$235
      00265D 03                    2667 	.db	3
      00265E 7D                    2668 	.sleb128	-3
      00265F 01                    2669 	.db	1
      002660 09                    2670 	.db	9
      002661 00 07                 2671 	.dw	Sstm8s_uart1$UART1_SmartCardNACKCmd$238-Sstm8s_uart1$UART1_SmartCardNACKCmd$236
      002663 03                    2672 	.db	3
      002664 03                    2673 	.sleb128	3
      002665 01                    2674 	.db	1
      002666 09                    2675 	.db	9
      002667 00 08                 2676 	.dw	Sstm8s_uart1$UART1_SmartCardNACKCmd$241-Sstm8s_uart1$UART1_SmartCardNACKCmd$238
      002669 03                    2677 	.db	3
      00266A 05                    2678 	.sleb128	5
      00266B 01                    2679 	.db	1
      00266C 09                    2680 	.db	9
      00266D 00 05                 2681 	.dw	Sstm8s_uart1$UART1_SmartCardNACKCmd$243-Sstm8s_uart1$UART1_SmartCardNACKCmd$241
      00266F 03                    2682 	.db	3
      002670 02                    2683 	.sleb128	2
      002671 01                    2684 	.db	1
      002672 09                    2685 	.db	9
      002673 00 01                 2686 	.dw	1+Sstm8s_uart1$UART1_SmartCardNACKCmd$244-Sstm8s_uart1$UART1_SmartCardNACKCmd$243
      002675 00                    2687 	.db	0
      002676 01                    2688 	.uleb128	1
      002677 01                    2689 	.db	1
      002678 00                    2690 	.db	0
      002679 05                    2691 	.uleb128	5
      00267A 02                    2692 	.db	2
      00267B 00 00 9A AA           2693 	.dw	0,(Sstm8s_uart1$UART1_WakeUpConfig$246)
      00267F 03                    2694 	.db	3
      002680 9F 03                 2695 	.sleb128	415
      002682 01                    2696 	.db	1
      002683 09                    2697 	.db	9
      002684 00 00                 2698 	.dw	Sstm8s_uart1$UART1_WakeUpConfig$248-Sstm8s_uart1$UART1_WakeUpConfig$246
      002686 03                    2699 	.db	3
      002687 04                    2700 	.sleb128	4
      002688 01                    2701 	.db	1
      002689 09                    2702 	.db	9
      00268A 00 08                 2703 	.dw	Sstm8s_uart1$UART1_WakeUpConfig$249-Sstm8s_uart1$UART1_WakeUpConfig$248
      00268C 03                    2704 	.db	3
      00268D 01                    2705 	.sleb128	1
      00268E 01                    2706 	.db	1
      00268F 09                    2707 	.db	9
      002690 00 08                 2708 	.dw	Sstm8s_uart1$UART1_WakeUpConfig$250-Sstm8s_uart1$UART1_WakeUpConfig$249
      002692 03                    2709 	.db	3
      002693 01                    2710 	.sleb128	1
      002694 01                    2711 	.db	1
      002695 09                    2712 	.db	9
      002696 00 01                 2713 	.dw	1+Sstm8s_uart1$UART1_WakeUpConfig$251-Sstm8s_uart1$UART1_WakeUpConfig$250
      002698 00                    2714 	.db	0
      002699 01                    2715 	.uleb128	1
      00269A 01                    2716 	.db	1
      00269B 00                    2717 	.db	0
      00269C 05                    2718 	.uleb128	5
      00269D 02                    2719 	.db	2
      00269E 00 00 9A BB           2720 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$253)
      0026A2 03                    2721 	.db	3
      0026A3 AD 03                 2722 	.sleb128	429
      0026A5 01                    2723 	.db	1
      0026A6 09                    2724 	.db	9
      0026A7 00 00                 2725 	.dw	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$255-Sstm8s_uart1$UART1_ReceiverWakeUpCmd$253
      0026A9 03                    2726 	.db	3
      0026AA 07                    2727 	.sleb128	7
      0026AB 01                    2728 	.db	1
      0026AC 09                    2729 	.db	9
      0026AD 00 03                 2730 	.dw	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$256-Sstm8s_uart1$UART1_ReceiverWakeUpCmd$255
      0026AF 03                    2731 	.db	3
      0026B0 7D                    2732 	.sleb128	-3
      0026B1 01                    2733 	.db	1
      0026B2 09                    2734 	.db	9
      0026B3 00 07                 2735 	.dw	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$258-Sstm8s_uart1$UART1_ReceiverWakeUpCmd$256
      0026B5 03                    2736 	.db	3
      0026B6 03                    2737 	.sleb128	3
      0026B7 01                    2738 	.db	1
      0026B8 09                    2739 	.db	9
      0026B9 00 08                 2740 	.dw	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$261-Sstm8s_uart1$UART1_ReceiverWakeUpCmd$258
      0026BB 03                    2741 	.db	3
      0026BC 05                    2742 	.sleb128	5
      0026BD 01                    2743 	.db	1
      0026BE 09                    2744 	.db	9
      0026BF 00 05                 2745 	.dw	Sstm8s_uart1$UART1_ReceiverWakeUpCmd$263-Sstm8s_uart1$UART1_ReceiverWakeUpCmd$261
      0026C1 03                    2746 	.db	3
      0026C2 02                    2747 	.sleb128	2
      0026C3 01                    2748 	.db	1
      0026C4 09                    2749 	.db	9
      0026C5 00 01                 2750 	.dw	1+Sstm8s_uart1$UART1_ReceiverWakeUpCmd$264-Sstm8s_uart1$UART1_ReceiverWakeUpCmd$263
      0026C7 00                    2751 	.db	0
      0026C8 01                    2752 	.uleb128	1
      0026C9 01                    2753 	.db	1
      0026CA 00                    2754 	.db	0
      0026CB 05                    2755 	.uleb128	5
      0026CC 02                    2756 	.db	2
      0026CD 00 00 9A D3           2757 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData8$266)
      0026D1 03                    2758 	.db	3
      0026D2 C2 03                 2759 	.sleb128	450
      0026D4 01                    2760 	.db	1
      0026D5 09                    2761 	.db	9
      0026D6 00 00                 2762 	.dw	Sstm8s_uart1$UART1_ReceiveData8$268-Sstm8s_uart1$UART1_ReceiveData8$266
      0026D8 03                    2763 	.db	3
      0026D9 02                    2764 	.sleb128	2
      0026DA 01                    2765 	.db	1
      0026DB 09                    2766 	.db	9
      0026DC 00 03                 2767 	.dw	Sstm8s_uart1$UART1_ReceiveData8$269-Sstm8s_uart1$UART1_ReceiveData8$268
      0026DE 03                    2768 	.db	3
      0026DF 01                    2769 	.sleb128	1
      0026E0 01                    2770 	.db	1
      0026E1 09                    2771 	.db	9
      0026E2 00 01                 2772 	.dw	1+Sstm8s_uart1$UART1_ReceiveData8$270-Sstm8s_uart1$UART1_ReceiveData8$269
      0026E4 00                    2773 	.db	0
      0026E5 01                    2774 	.uleb128	1
      0026E6 01                    2775 	.db	1
      0026E7 00                    2776 	.db	0
      0026E8 05                    2777 	.uleb128	5
      0026E9 02                    2778 	.db	2
      0026EA 00 00 9A D7           2779 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$272)
      0026EE 03                    2780 	.db	3
      0026EF CC 03                 2781 	.sleb128	460
      0026F1 01                    2782 	.db	1
      0026F2 09                    2783 	.db	9
      0026F3 00 01                 2784 	.dw	Sstm8s_uart1$UART1_ReceiveData9$275-Sstm8s_uart1$UART1_ReceiveData9$272
      0026F5 03                    2785 	.db	3
      0026F6 04                    2786 	.sleb128	4
      0026F7 01                    2787 	.db	1
      0026F8 09                    2788 	.db	9
      0026F9 00 0C                 2789 	.dw	Sstm8s_uart1$UART1_ReceiveData9$276-Sstm8s_uart1$UART1_ReceiveData9$275
      0026FB 03                    2790 	.db	3
      0026FC 01                    2791 	.sleb128	1
      0026FD 01                    2792 	.db	1
      0026FE 09                    2793 	.db	9
      0026FF 00 0D                 2794 	.dw	Sstm8s_uart1$UART1_ReceiveData9$277-Sstm8s_uart1$UART1_ReceiveData9$276
      002701 03                    2795 	.db	3
      002702 01                    2796 	.sleb128	1
      002703 01                    2797 	.db	1
      002704 09                    2798 	.db	9
      002705 00 03                 2799 	.dw	1+Sstm8s_uart1$UART1_ReceiveData9$279-Sstm8s_uart1$UART1_ReceiveData9$277
      002707 00                    2800 	.db	0
      002708 01                    2801 	.uleb128	1
      002709 01                    2802 	.db	1
      00270A 00                    2803 	.db	0
      00270B 05                    2804 	.uleb128	5
      00270C 02                    2805 	.db	2
      00270D 00 00 9A F4           2806 	.dw	0,(Sstm8s_uart1$UART1_SendData8$281)
      002711 03                    2807 	.db	3
      002712 D9 03                 2808 	.sleb128	473
      002714 01                    2809 	.db	1
      002715 09                    2810 	.db	9
      002716 00 00                 2811 	.dw	Sstm8s_uart1$UART1_SendData8$283-Sstm8s_uart1$UART1_SendData8$281
      002718 03                    2812 	.db	3
      002719 03                    2813 	.sleb128	3
      00271A 01                    2814 	.db	1
      00271B 09                    2815 	.db	9
      00271C 00 06                 2816 	.dw	Sstm8s_uart1$UART1_SendData8$284-Sstm8s_uart1$UART1_SendData8$283
      00271E 03                    2817 	.db	3
      00271F 01                    2818 	.sleb128	1
      002720 01                    2819 	.db	1
      002721 09                    2820 	.db	9
      002722 00 01                 2821 	.dw	1+Sstm8s_uart1$UART1_SendData8$285-Sstm8s_uart1$UART1_SendData8$284
      002724 00                    2822 	.db	0
      002725 01                    2823 	.uleb128	1
      002726 01                    2824 	.db	1
      002727 00                    2825 	.db	0
      002728 05                    2826 	.uleb128	5
      002729 02                    2827 	.db	2
      00272A 00 00 9A FB           2828 	.dw	0,(Sstm8s_uart1$UART1_SendData9$287)
      00272E 03                    2829 	.db	3
      00272F E5 03                 2830 	.sleb128	485
      002731 01                    2831 	.db	1
      002732 09                    2832 	.db	9
      002733 00 01                 2833 	.dw	Sstm8s_uart1$UART1_SendData9$290-Sstm8s_uart1$UART1_SendData9$287
      002735 03                    2834 	.db	3
      002736 03                    2835 	.sleb128	3
      002737 01                    2836 	.db	1
      002738 09                    2837 	.db	9
      002739 00 08                 2838 	.dw	Sstm8s_uart1$UART1_SendData9$291-Sstm8s_uart1$UART1_SendData9$290
      00273B 03                    2839 	.db	3
      00273C 02                    2840 	.sleb128	2
      00273D 01                    2841 	.db	1
      00273E 09                    2842 	.db	9
      00273F 00 11                 2843 	.dw	Sstm8s_uart1$UART1_SendData9$292-Sstm8s_uart1$UART1_SendData9$291
      002741 03                    2844 	.db	3
      002742 02                    2845 	.sleb128	2
      002743 01                    2846 	.db	1
      002744 09                    2847 	.db	9
      002745 00 05                 2848 	.dw	Sstm8s_uart1$UART1_SendData9$293-Sstm8s_uart1$UART1_SendData9$292
      002747 03                    2849 	.db	3
      002748 01                    2850 	.sleb128	1
      002749 01                    2851 	.db	1
      00274A 09                    2852 	.db	9
      00274B 00 02                 2853 	.dw	1+Sstm8s_uart1$UART1_SendData9$295-Sstm8s_uart1$UART1_SendData9$293
      00274D 00                    2854 	.db	0
      00274E 01                    2855 	.uleb128	1
      00274F 01                    2856 	.db	1
      002750 00                    2857 	.db	0
      002751 05                    2858 	.uleb128	5
      002752 02                    2859 	.db	2
      002753 00 00 9B 1C           2860 	.dw	0,(Sstm8s_uart1$UART1_SendBreak$297)
      002757 03                    2861 	.db	3
      002758 F4 03                 2862 	.sleb128	500
      00275A 01                    2863 	.db	1
      00275B 09                    2864 	.db	9
      00275C 00 00                 2865 	.dw	Sstm8s_uart1$UART1_SendBreak$299-Sstm8s_uart1$UART1_SendBreak$297
      00275E 03                    2866 	.db	3
      00275F 02                    2867 	.sleb128	2
      002760 01                    2868 	.db	1
      002761 09                    2869 	.db	9
      002762 00 08                 2870 	.dw	Sstm8s_uart1$UART1_SendBreak$300-Sstm8s_uart1$UART1_SendBreak$299
      002764 03                    2871 	.db	3
      002765 01                    2872 	.sleb128	1
      002766 01                    2873 	.db	1
      002767 09                    2874 	.db	9
      002768 00 01                 2875 	.dw	1+Sstm8s_uart1$UART1_SendBreak$301-Sstm8s_uart1$UART1_SendBreak$300
      00276A 00                    2876 	.db	0
      00276B 01                    2877 	.uleb128	1
      00276C 01                    2878 	.db	1
      00276D 00                    2879 	.db	0
      00276E 05                    2880 	.uleb128	5
      00276F 02                    2881 	.db	2
      002770 00 00 9B 25           2882 	.dw	0,(Sstm8s_uart1$UART1_SetAddress$303)
      002774 03                    2883 	.db	3
      002775 FE 03                 2884 	.sleb128	510
      002777 01                    2885 	.db	1
      002778 09                    2886 	.db	9
      002779 00 00                 2887 	.dw	Sstm8s_uart1$UART1_SetAddress$305-Sstm8s_uart1$UART1_SetAddress$303
      00277B 03                    2888 	.db	3
      00277C 06                    2889 	.sleb128	6
      00277D 01                    2890 	.db	1
      00277E 09                    2891 	.db	9
      00277F 00 08                 2892 	.dw	Sstm8s_uart1$UART1_SetAddress$306-Sstm8s_uart1$UART1_SetAddress$305
      002781 03                    2893 	.db	3
      002782 02                    2894 	.sleb128	2
      002783 01                    2895 	.db	1
      002784 09                    2896 	.db	9
      002785 00 08                 2897 	.dw	Sstm8s_uart1$UART1_SetAddress$307-Sstm8s_uart1$UART1_SetAddress$306
      002787 03                    2898 	.db	3
      002788 01                    2899 	.sleb128	1
      002789 01                    2900 	.db	1
      00278A 09                    2901 	.db	9
      00278B 00 01                 2902 	.dw	1+Sstm8s_uart1$UART1_SetAddress$308-Sstm8s_uart1$UART1_SetAddress$307
      00278D 00                    2903 	.db	0
      00278E 01                    2904 	.uleb128	1
      00278F 01                    2905 	.db	1
      002790 00                    2906 	.db	0
      002791 05                    2907 	.uleb128	5
      002792 02                    2908 	.db	2
      002793 00 00 9B 36           2909 	.dw	0,(Sstm8s_uart1$UART1_SetGuardTime$310)
      002797 03                    2910 	.db	3
      002798 8F 04                 2911 	.sleb128	527
      00279A 01                    2912 	.db	1
      00279B 09                    2913 	.db	9
      00279C 00 00                 2914 	.dw	Sstm8s_uart1$UART1_SetGuardTime$312-Sstm8s_uart1$UART1_SetGuardTime$310
      00279E 03                    2915 	.db	3
      00279F 03                    2916 	.sleb128	3
      0027A0 01                    2917 	.db	1
      0027A1 09                    2918 	.db	9
      0027A2 00 06                 2919 	.dw	Sstm8s_uart1$UART1_SetGuardTime$313-Sstm8s_uart1$UART1_SetGuardTime$312
      0027A4 03                    2920 	.db	3
      0027A5 01                    2921 	.sleb128	1
      0027A6 01                    2922 	.db	1
      0027A7 09                    2923 	.db	9
      0027A8 00 01                 2924 	.dw	1+Sstm8s_uart1$UART1_SetGuardTime$314-Sstm8s_uart1$UART1_SetGuardTime$313
      0027AA 00                    2925 	.db	0
      0027AB 01                    2926 	.uleb128	1
      0027AC 01                    2927 	.db	1
      0027AD 00                    2928 	.db	0
      0027AE 05                    2929 	.uleb128	5
      0027AF 02                    2930 	.db	2
      0027B0 00 00 9B 3D           2931 	.dw	0,(Sstm8s_uart1$UART1_SetPrescaler$316)
      0027B4 03                    2932 	.db	3
      0027B5 AB 04                 2933 	.sleb128	555
      0027B7 01                    2934 	.db	1
      0027B8 09                    2935 	.db	9
      0027B9 00 00                 2936 	.dw	Sstm8s_uart1$UART1_SetPrescaler$318-Sstm8s_uart1$UART1_SetPrescaler$316
      0027BB 03                    2937 	.db	3
      0027BC 03                    2938 	.sleb128	3
      0027BD 01                    2939 	.db	1
      0027BE 09                    2940 	.db	9
      0027BF 00 06                 2941 	.dw	Sstm8s_uart1$UART1_SetPrescaler$319-Sstm8s_uart1$UART1_SetPrescaler$318
      0027C1 03                    2942 	.db	3
      0027C2 01                    2943 	.sleb128	1
      0027C3 01                    2944 	.db	1
      0027C4 09                    2945 	.db	9
      0027C5 00 01                 2946 	.dw	1+Sstm8s_uart1$UART1_SetPrescaler$320-Sstm8s_uart1$UART1_SetPrescaler$319
      0027C7 00                    2947 	.db	0
      0027C8 01                    2948 	.uleb128	1
      0027C9 01                    2949 	.db	1
      0027CA 00                    2950 	.db	0
      0027CB 05                    2951 	.uleb128	5
      0027CC 02                    2952 	.db	2
      0027CD 00 00 9B 44           2953 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$322)
      0027D1 03                    2954 	.db	3
      0027D2 B7 04                 2955 	.sleb128	567
      0027D4 01                    2956 	.db	1
      0027D5 09                    2957 	.db	9
      0027D6 00 02                 2958 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$325-Sstm8s_uart1$UART1_GetFlagStatus$322
      0027D8 03                    2959 	.db	3
      0027D9 09                    2960 	.sleb128	9
      0027DA 01                    2961 	.db	1
      0027DB 09                    2962 	.db	9
      0027DC 00 04                 2963 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$326-Sstm8s_uart1$UART1_GetFlagStatus$325
      0027DE 03                    2964 	.db	3
      0027DF 02                    2965 	.sleb128	2
      0027E0 01                    2966 	.db	1
      0027E1 09                    2967 	.db	9
      0027E2 00 04                 2968 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$327-Sstm8s_uart1$UART1_GetFlagStatus$326
      0027E4 03                    2969 	.db	3
      0027E5 7E                    2970 	.sleb128	-2
      0027E6 01                    2971 	.db	1
      0027E7 09                    2972 	.db	9
      0027E8 00 0D                 2973 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$330-Sstm8s_uart1$UART1_GetFlagStatus$327
      0027EA 03                    2974 	.db	3
      0027EB 02                    2975 	.sleb128	2
      0027EC 01                    2976 	.db	1
      0027ED 09                    2977 	.db	9
      0027EE 00 0B                 2978 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$332-Sstm8s_uart1$UART1_GetFlagStatus$330
      0027F0 03                    2979 	.db	3
      0027F1 03                    2980 	.sleb128	3
      0027F2 01                    2981 	.db	1
      0027F3 09                    2982 	.db	9
      0027F4 00 05                 2983 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$335-Sstm8s_uart1$UART1_GetFlagStatus$332
      0027F6 03                    2984 	.db	3
      0027F7 05                    2985 	.sleb128	5
      0027F8 01                    2986 	.db	1
      0027F9 09                    2987 	.db	9
      0027FA 00 04                 2988 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$337-Sstm8s_uart1$UART1_GetFlagStatus$335
      0027FC 03                    2989 	.db	3
      0027FD 03                    2990 	.sleb128	3
      0027FE 01                    2991 	.db	1
      0027FF 09                    2992 	.db	9
      002800 00 0D                 2993 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$340-Sstm8s_uart1$UART1_GetFlagStatus$337
      002802 03                    2994 	.db	3
      002803 02                    2995 	.sleb128	2
      002804 01                    2996 	.db	1
      002805 09                    2997 	.db	9
      002806 00 0B                 2998 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$342-Sstm8s_uart1$UART1_GetFlagStatus$340
      002808 03                    2999 	.db	3
      002809 03                    3000 	.sleb128	3
      00280A 01                    3001 	.db	1
      00280B 09                    3002 	.db	9
      00280C 00 05                 3003 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$345-Sstm8s_uart1$UART1_GetFlagStatus$342
      00280E 03                    3004 	.db	3
      00280F 05                    3005 	.sleb128	5
      002810 01                    3006 	.db	1
      002811 09                    3007 	.db	9
      002812 00 04                 3008 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$348-Sstm8s_uart1$UART1_GetFlagStatus$345
      002814 03                    3009 	.db	3
      002815 05                    3010 	.sleb128	5
      002816 01                    3011 	.db	1
      002817 09                    3012 	.db	9
      002818 00 0B                 3013 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$350-Sstm8s_uart1$UART1_GetFlagStatus$348
      00281A 03                    3014 	.db	3
      00281B 03                    3015 	.sleb128	3
      00281C 01                    3016 	.db	1
      00281D 09                    3017 	.db	9
      00281E 00 05                 3018 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$353-Sstm8s_uart1$UART1_GetFlagStatus$350
      002820 03                    3019 	.db	3
      002821 05                    3020 	.sleb128	5
      002822 01                    3021 	.db	1
      002823 09                    3022 	.db	9
      002824 00 01                 3023 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$355-Sstm8s_uart1$UART1_GetFlagStatus$353
      002826 03                    3024 	.db	3
      002827 04                    3025 	.sleb128	4
      002828 01                    3026 	.db	1
      002829 09                    3027 	.db	9
      00282A 00 00                 3028 	.dw	Sstm8s_uart1$UART1_GetFlagStatus$356-Sstm8s_uart1$UART1_GetFlagStatus$355
      00282C 03                    3029 	.db	3
      00282D 01                    3030 	.sleb128	1
      00282E 01                    3031 	.db	1
      00282F 09                    3032 	.db	9
      002830 00 03                 3033 	.dw	1+Sstm8s_uart1$UART1_GetFlagStatus$358-Sstm8s_uart1$UART1_GetFlagStatus$356
      002832 00                    3034 	.db	0
      002833 01                    3035 	.uleb128	1
      002834 01                    3036 	.db	1
      002835 00                    3037 	.db	0
      002836 05                    3038 	.uleb128	5
      002837 02                    3039 	.db	2
      002838 00 00 9B A4           3040 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$360)
      00283C 03                    3041 	.db	3
      00283D 85 05                 3042 	.sleb128	645
      00283F 01                    3043 	.db	1
      002840 09                    3044 	.db	9
      002841 00 00                 3045 	.dw	Sstm8s_uart1$UART1_ClearFlag$362-Sstm8s_uart1$UART1_ClearFlag$360
      002843 03                    3046 	.db	3
      002844 05                    3047 	.sleb128	5
      002845 01                    3048 	.db	1
      002846 09                    3049 	.db	9
      002847 00 0D                 3050 	.dw	Sstm8s_uart1$UART1_ClearFlag$365-Sstm8s_uart1$UART1_ClearFlag$362
      002849 03                    3051 	.db	3
      00284A 02                    3052 	.sleb128	2
      00284B 01                    3053 	.db	1
      00284C 09                    3054 	.db	9
      00284D 00 07                 3055 	.dw	Sstm8s_uart1$UART1_ClearFlag$368-Sstm8s_uart1$UART1_ClearFlag$365
      00284F 03                    3056 	.db	3
      002850 05                    3057 	.sleb128	5
      002851 01                    3058 	.db	1
      002852 09                    3059 	.db	9
      002853 00 08                 3060 	.dw	Sstm8s_uart1$UART1_ClearFlag$370-Sstm8s_uart1$UART1_ClearFlag$368
      002855 03                    3061 	.db	3
      002856 02                    3062 	.sleb128	2
      002857 01                    3063 	.db	1
      002858 09                    3064 	.db	9
      002859 00 01                 3065 	.dw	1+Sstm8s_uart1$UART1_ClearFlag$371-Sstm8s_uart1$UART1_ClearFlag$370
      00285B 00                    3066 	.db	0
      00285C 01                    3067 	.uleb128	1
      00285D 01                    3068 	.db	1
      00285E 00                    3069 	.db	0
      00285F 05                    3070 	.uleb128	5
      002860 02                    3071 	.db	2
      002861 00 00 9B C1           3072 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$373)
      002865 03                    3073 	.db	3
      002866 A2 05                 3074 	.sleb128	674
      002868 01                    3075 	.db	1
      002869 09                    3076 	.db	9
      00286A 00 02                 3077 	.dw	Sstm8s_uart1$UART1_GetITStatus$376-Sstm8s_uart1$UART1_GetITStatus$373
      00286C 03                    3078 	.db	3
      00286D 0C                    3079 	.sleb128	12
      00286E 01                    3080 	.db	1
      00286F 09                    3081 	.db	9
      002870 00 14                 3082 	.dw	Sstm8s_uart1$UART1_GetITStatus$379-Sstm8s_uart1$UART1_GetITStatus$376
      002872 03                    3083 	.db	3
      002873 02                    3084 	.sleb128	2
      002874 01                    3085 	.db	1
      002875 09                    3086 	.db	9
      002876 00 04                 3087 	.dw	Sstm8s_uart1$UART1_GetITStatus$380-Sstm8s_uart1$UART1_GetITStatus$379
      002878 03                    3088 	.db	3
      002879 02                    3089 	.sleb128	2
      00287A 01                    3090 	.db	1
      00287B 09                    3091 	.db	9
      00287C 00 0E                 3092 	.dw	Sstm8s_uart1$UART1_GetITStatus$383-Sstm8s_uart1$UART1_GetITStatus$380
      00287E 03                    3093 	.db	3
      00287F 04                    3094 	.sleb128	4
      002880 01                    3095 	.db	1
      002881 09                    3096 	.db	9
      002882 00 11                 3097 	.dw	Sstm8s_uart1$UART1_GetITStatus$386-Sstm8s_uart1$UART1_GetITStatus$383
      002884 03                    3098 	.db	3
      002885 03                    3099 	.sleb128	3
      002886 01                    3100 	.db	1
      002887 09                    3101 	.db	9
      002888 00 06                 3102 	.dw	Sstm8s_uart1$UART1_GetITStatus$387-Sstm8s_uart1$UART1_GetITStatus$386
      00288A 03                    3103 	.db	3
      00288B 03                    3104 	.sleb128	3
      00288C 01                    3105 	.db	1
      00288D 09                    3106 	.db	9
      00288E 00 12                 3107 	.dw	Sstm8s_uart1$UART1_GetITStatus$389-Sstm8s_uart1$UART1_GetITStatus$387
      002890 03                    3108 	.db	3
      002891 03                    3109 	.sleb128	3
      002892 01                    3110 	.db	1
      002893 09                    3111 	.db	9
      002894 00 05                 3112 	.dw	Sstm8s_uart1$UART1_GetITStatus$392-Sstm8s_uart1$UART1_GetITStatus$389
      002896 03                    3113 	.db	3
      002897 05                    3114 	.sleb128	5
      002898 01                    3115 	.db	1
      002899 09                    3116 	.db	9
      00289A 00 04                 3117 	.dw	Sstm8s_uart1$UART1_GetITStatus$394-Sstm8s_uart1$UART1_GetITStatus$392
      00289C 03                    3118 	.db	3
      00289D 04                    3119 	.sleb128	4
      00289E 01                    3120 	.db	1
      00289F 09                    3121 	.db	9
      0028A0 00 0D                 3122 	.dw	Sstm8s_uart1$UART1_GetITStatus$397-Sstm8s_uart1$UART1_GetITStatus$394
      0028A2 03                    3123 	.db	3
      0028A3 03                    3124 	.sleb128	3
      0028A4 01                    3125 	.db	1
      0028A5 09                    3126 	.db	9
      0028A6 00 06                 3127 	.dw	Sstm8s_uart1$UART1_GetITStatus$398-Sstm8s_uart1$UART1_GetITStatus$397
      0028A8 03                    3128 	.db	3
      0028A9 02                    3129 	.sleb128	2
      0028AA 01                    3130 	.db	1
      0028AB 09                    3131 	.db	9
      0028AC 00 12                 3132 	.dw	Sstm8s_uart1$UART1_GetITStatus$400-Sstm8s_uart1$UART1_GetITStatus$398
      0028AE 03                    3133 	.db	3
      0028AF 03                    3134 	.sleb128	3
      0028B0 01                    3135 	.db	1
      0028B1 09                    3136 	.db	9
      0028B2 00 05                 3137 	.dw	Sstm8s_uart1$UART1_GetITStatus$403-Sstm8s_uart1$UART1_GetITStatus$400
      0028B4 03                    3138 	.db	3
      0028B5 05                    3139 	.sleb128	5
      0028B6 01                    3140 	.db	1
      0028B7 09                    3141 	.db	9
      0028B8 00 04                 3142 	.dw	Sstm8s_uart1$UART1_GetITStatus$406-Sstm8s_uart1$UART1_GetITStatus$403
      0028BA 03                    3143 	.db	3
      0028BB 06                    3144 	.sleb128	6
      0028BC 01                    3145 	.db	1
      0028BD 09                    3146 	.db	9
      0028BE 00 06                 3147 	.dw	Sstm8s_uart1$UART1_GetITStatus$407-Sstm8s_uart1$UART1_GetITStatus$406
      0028C0 03                    3148 	.db	3
      0028C1 02                    3149 	.sleb128	2
      0028C2 01                    3150 	.db	1
      0028C3 09                    3151 	.db	9
      0028C4 00 12                 3152 	.dw	Sstm8s_uart1$UART1_GetITStatus$409-Sstm8s_uart1$UART1_GetITStatus$407
      0028C6 03                    3153 	.db	3
      0028C7 03                    3154 	.sleb128	3
      0028C8 01                    3155 	.db	1
      0028C9 09                    3156 	.db	9
      0028CA 00 05                 3157 	.dw	Sstm8s_uart1$UART1_GetITStatus$412-Sstm8s_uart1$UART1_GetITStatus$409
      0028CC 03                    3158 	.db	3
      0028CD 05                    3159 	.sleb128	5
      0028CE 01                    3160 	.db	1
      0028CF 09                    3161 	.db	9
      0028D0 00 01                 3162 	.dw	Sstm8s_uart1$UART1_GetITStatus$414-Sstm8s_uart1$UART1_GetITStatus$412
      0028D2 03                    3163 	.db	3
      0028D3 05                    3164 	.sleb128	5
      0028D4 01                    3165 	.db	1
      0028D5 09                    3166 	.db	9
      0028D6 00 00                 3167 	.dw	Sstm8s_uart1$UART1_GetITStatus$415-Sstm8s_uart1$UART1_GetITStatus$414
      0028D8 03                    3168 	.db	3
      0028D9 01                    3169 	.sleb128	1
      0028DA 01                    3170 	.db	1
      0028DB 09                    3171 	.db	9
      0028DC 00 03                 3172 	.dw	1+Sstm8s_uart1$UART1_GetITStatus$417-Sstm8s_uart1$UART1_GetITStatus$415
      0028DE 00                    3173 	.db	0
      0028DF 01                    3174 	.uleb128	1
      0028E0 01                    3175 	.db	1
      0028E1 00                    3176 	.db	0
      0028E2 05                    3177 	.uleb128	5
      0028E3 02                    3178 	.db	2
      0028E4 00 00 9C 6A           3179 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$419)
      0028E8 03                    3180 	.db	3
      0028E9 86 06                 3181 	.sleb128	774
      0028EB 01                    3182 	.db	1
      0028EC 09                    3183 	.db	9
      0028ED 00 00                 3184 	.dw	Sstm8s_uart1$UART1_ClearITPendingBit$421-Sstm8s_uart1$UART1_ClearITPendingBit$419
      0028EF 03                    3185 	.db	3
      0028F0 05                    3186 	.sleb128	5
      0028F1 01                    3187 	.db	1
      0028F2 09                    3188 	.db	9
      0028F3 00 0D                 3189 	.dw	Sstm8s_uart1$UART1_ClearITPendingBit$424-Sstm8s_uart1$UART1_ClearITPendingBit$421
      0028F5 03                    3190 	.db	3
      0028F6 02                    3191 	.sleb128	2
      0028F7 01                    3192 	.db	1
      0028F8 09                    3193 	.db	9
      0028F9 00 07                 3194 	.dw	Sstm8s_uart1$UART1_ClearITPendingBit$427-Sstm8s_uart1$UART1_ClearITPendingBit$424
      0028FB 03                    3195 	.db	3
      0028FC 05                    3196 	.sleb128	5
      0028FD 01                    3197 	.db	1
      0028FE 09                    3198 	.db	9
      0028FF 00 08                 3199 	.dw	Sstm8s_uart1$UART1_ClearITPendingBit$429-Sstm8s_uart1$UART1_ClearITPendingBit$427
      002901 03                    3200 	.db	3
      002902 02                    3201 	.sleb128	2
      002903 01                    3202 	.db	1
      002904 09                    3203 	.db	9
      002905 00 01                 3204 	.dw	1+Sstm8s_uart1$UART1_ClearITPendingBit$430-Sstm8s_uart1$UART1_ClearITPendingBit$429
      002907 00                    3205 	.db	0
      002908 01                    3206 	.uleb128	1
      002909 01                    3207 	.db	1
      00290A                       3208 Ldebug_line_end:
                                   3209 
                                   3210 	.area .debug_loc (NOLOAD)
      002BC0                       3211 Ldebug_loc_start:
      002BC0 00 00 9C 77           3212 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$422)
      002BC4 00 00 9C 87           3213 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$431)
      002BC8 00 02                 3214 	.dw	2
      002BCA 78                    3215 	.db	120
      002BCB 01                    3216 	.sleb128	1
      002BCC 00 00 9C 6A           3217 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$420)
      002BD0 00 00 9C 77           3218 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$422)
      002BD4 00 02                 3219 	.dw	2
      002BD6 78                    3220 	.db	120
      002BD7 01                    3221 	.sleb128	1
      002BD8 00 00 00 00           3222 	.dw	0,0
      002BDC 00 00 00 00           3223 	.dw	0,0
      002BE0 00 00 9C 69           3224 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$416)
      002BE4 00 00 9C 6A           3225 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$418)
      002BE8 00 02                 3226 	.dw	2
      002BEA 78                    3227 	.db	120
      002BEB 01                    3228 	.sleb128	1
      002BEC 00 00 9C 28           3229 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$395)
      002BF0 00 00 9C 69           3230 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$416)
      002BF4 00 02                 3231 	.dw	2
      002BF6 78                    3232 	.db	120
      002BF7 05                    3233 	.sleb128	5
      002BF8 00 00 9B FA           3234 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$384)
      002BFC 00 00 9C 28           3235 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$395)
      002C00 00 02                 3236 	.dw	2
      002C02 78                    3237 	.db	120
      002C03 05                    3238 	.sleb128	5
      002C04 00 00 9B E1           3239 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$382)
      002C08 00 00 9B FA           3240 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$384)
      002C0C 00 02                 3241 	.dw	2
      002C0E 78                    3242 	.db	120
      002C0F 05                    3243 	.sleb128	5
      002C10 00 00 9B DC           3244 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$381)
      002C14 00 00 9B E1           3245 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$382)
      002C18 00 02                 3246 	.dw	2
      002C1A 78                    3247 	.db	120
      002C1B 06                    3248 	.sleb128	6
      002C1C 00 00 9B CF           3249 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$378)
      002C20 00 00 9B DC           3250 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$381)
      002C24 00 02                 3251 	.dw	2
      002C26 78                    3252 	.db	120
      002C27 05                    3253 	.sleb128	5
      002C28 00 00 9B CA           3254 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$377)
      002C2C 00 00 9B CF           3255 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$378)
      002C30 00 02                 3256 	.dw	2
      002C32 78                    3257 	.db	120
      002C33 06                    3258 	.sleb128	6
      002C34 00 00 9B C3           3259 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$375)
      002C38 00 00 9B CA           3260 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$377)
      002C3C 00 02                 3261 	.dw	2
      002C3E 78                    3262 	.db	120
      002C3F 05                    3263 	.sleb128	5
      002C40 00 00 9B C1           3264 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$374)
      002C44 00 00 9B C3           3265 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$375)
      002C48 00 02                 3266 	.dw	2
      002C4A 78                    3267 	.db	120
      002C4B 01                    3268 	.sleb128	1
      002C4C 00 00 00 00           3269 	.dw	0,0
      002C50 00 00 00 00           3270 	.dw	0,0
      002C54 00 00 9B B1           3271 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$363)
      002C58 00 00 9B C1           3272 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$372)
      002C5C 00 02                 3273 	.dw	2
      002C5E 78                    3274 	.db	120
      002C5F 01                    3275 	.sleb128	1
      002C60 00 00 9B A4           3276 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$361)
      002C64 00 00 9B B1           3277 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$363)
      002C68 00 02                 3278 	.dw	2
      002C6A 78                    3279 	.db	120
      002C6B 01                    3280 	.sleb128	1
      002C6C 00 00 00 00           3281 	.dw	0,0
      002C70 00 00 00 00           3282 	.dw	0,0
      002C74 00 00 9B A3           3283 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$357)
      002C78 00 00 9B A4           3284 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$359)
      002C7C 00 02                 3285 	.dw	2
      002C7E 78                    3286 	.db	120
      002C7F 01                    3287 	.sleb128	1
      002C80 00 00 9B 7C           3288 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$338)
      002C84 00 00 9B A3           3289 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$357)
      002C88 00 02                 3290 	.dw	2
      002C8A 78                    3291 	.db	120
      002C8B 04                    3292 	.sleb128	4
      002C8C 00 00 9B 5B           3293 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$328)
      002C90 00 00 9B 7C           3294 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$338)
      002C94 00 02                 3295 	.dw	2
      002C96 78                    3296 	.db	120
      002C97 04                    3297 	.sleb128	4
      002C98 00 00 9B 46           3298 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$324)
      002C9C 00 00 9B 5B           3299 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$328)
      002CA0 00 02                 3300 	.dw	2
      002CA2 78                    3301 	.db	120
      002CA3 04                    3302 	.sleb128	4
      002CA4 00 00 9B 44           3303 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$323)
      002CA8 00 00 9B 46           3304 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$324)
      002CAC 00 02                 3305 	.dw	2
      002CAE 78                    3306 	.db	120
      002CAF 01                    3307 	.sleb128	1
      002CB0 00 00 00 00           3308 	.dw	0,0
      002CB4 00 00 00 00           3309 	.dw	0,0
      002CB8 00 00 9B 3D           3310 	.dw	0,(Sstm8s_uart1$UART1_SetPrescaler$317)
      002CBC 00 00 9B 44           3311 	.dw	0,(Sstm8s_uart1$UART1_SetPrescaler$321)
      002CC0 00 02                 3312 	.dw	2
      002CC2 78                    3313 	.db	120
      002CC3 01                    3314 	.sleb128	1
      002CC4 00 00 00 00           3315 	.dw	0,0
      002CC8 00 00 00 00           3316 	.dw	0,0
      002CCC 00 00 9B 36           3317 	.dw	0,(Sstm8s_uart1$UART1_SetGuardTime$311)
      002CD0 00 00 9B 3D           3318 	.dw	0,(Sstm8s_uart1$UART1_SetGuardTime$315)
      002CD4 00 02                 3319 	.dw	2
      002CD6 78                    3320 	.db	120
      002CD7 01                    3321 	.sleb128	1
      002CD8 00 00 00 00           3322 	.dw	0,0
      002CDC 00 00 00 00           3323 	.dw	0,0
      002CE0 00 00 9B 25           3324 	.dw	0,(Sstm8s_uart1$UART1_SetAddress$304)
      002CE4 00 00 9B 36           3325 	.dw	0,(Sstm8s_uart1$UART1_SetAddress$309)
      002CE8 00 02                 3326 	.dw	2
      002CEA 78                    3327 	.db	120
      002CEB 01                    3328 	.sleb128	1
      002CEC 00 00 00 00           3329 	.dw	0,0
      002CF0 00 00 00 00           3330 	.dw	0,0
      002CF4 00 00 9B 1C           3331 	.dw	0,(Sstm8s_uart1$UART1_SendBreak$298)
      002CF8 00 00 9B 25           3332 	.dw	0,(Sstm8s_uart1$UART1_SendBreak$302)
      002CFC 00 02                 3333 	.dw	2
      002CFE 78                    3334 	.db	120
      002CFF 01                    3335 	.sleb128	1
      002D00 00 00 00 00           3336 	.dw	0,0
      002D04 00 00 00 00           3337 	.dw	0,0
      002D08 00 00 9B 1B           3338 	.dw	0,(Sstm8s_uart1$UART1_SendData9$294)
      002D0C 00 00 9B 1C           3339 	.dw	0,(Sstm8s_uart1$UART1_SendData9$296)
      002D10 00 02                 3340 	.dw	2
      002D12 78                    3341 	.db	120
      002D13 01                    3342 	.sleb128	1
      002D14 00 00 9A FC           3343 	.dw	0,(Sstm8s_uart1$UART1_SendData9$289)
      002D18 00 00 9B 1B           3344 	.dw	0,(Sstm8s_uart1$UART1_SendData9$294)
      002D1C 00 02                 3345 	.dw	2
      002D1E 78                    3346 	.db	120
      002D1F 02                    3347 	.sleb128	2
      002D20 00 00 9A FB           3348 	.dw	0,(Sstm8s_uart1$UART1_SendData9$288)
      002D24 00 00 9A FC           3349 	.dw	0,(Sstm8s_uart1$UART1_SendData9$289)
      002D28 00 02                 3350 	.dw	2
      002D2A 78                    3351 	.db	120
      002D2B 01                    3352 	.sleb128	1
      002D2C 00 00 00 00           3353 	.dw	0,0
      002D30 00 00 00 00           3354 	.dw	0,0
      002D34 00 00 9A F4           3355 	.dw	0,(Sstm8s_uart1$UART1_SendData8$282)
      002D38 00 00 9A FB           3356 	.dw	0,(Sstm8s_uart1$UART1_SendData8$286)
      002D3C 00 02                 3357 	.dw	2
      002D3E 78                    3358 	.db	120
      002D3F 01                    3359 	.sleb128	1
      002D40 00 00 00 00           3360 	.dw	0,0
      002D44 00 00 00 00           3361 	.dw	0,0
      002D48 00 00 9A F3           3362 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$278)
      002D4C 00 00 9A F4           3363 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$280)
      002D50 00 02                 3364 	.dw	2
      002D52 78                    3365 	.db	120
      002D53 01                    3366 	.sleb128	1
      002D54 00 00 9A D8           3367 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$274)
      002D58 00 00 9A F3           3368 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$278)
      002D5C 00 02                 3369 	.dw	2
      002D5E 78                    3370 	.db	120
      002D5F 03                    3371 	.sleb128	3
      002D60 00 00 9A D7           3372 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$273)
      002D64 00 00 9A D8           3373 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$274)
      002D68 00 02                 3374 	.dw	2
      002D6A 78                    3375 	.db	120
      002D6B 01                    3376 	.sleb128	1
      002D6C 00 00 00 00           3377 	.dw	0,0
      002D70 00 00 00 00           3378 	.dw	0,0
      002D74 00 00 9A D3           3379 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData8$267)
      002D78 00 00 9A D7           3380 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData8$271)
      002D7C 00 02                 3381 	.dw	2
      002D7E 78                    3382 	.db	120
      002D7F 01                    3383 	.sleb128	1
      002D80 00 00 00 00           3384 	.dw	0,0
      002D84 00 00 00 00           3385 	.dw	0,0
      002D88 00 00 9A BB           3386 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$254)
      002D8C 00 00 9A D3           3387 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$265)
      002D90 00 02                 3388 	.dw	2
      002D92 78                    3389 	.db	120
      002D93 01                    3390 	.sleb128	1
      002D94 00 00 00 00           3391 	.dw	0,0
      002D98 00 00 00 00           3392 	.dw	0,0
      002D9C 00 00 9A AA           3393 	.dw	0,(Sstm8s_uart1$UART1_WakeUpConfig$247)
      002DA0 00 00 9A BB           3394 	.dw	0,(Sstm8s_uart1$UART1_WakeUpConfig$252)
      002DA4 00 02                 3395 	.dw	2
      002DA6 78                    3396 	.db	120
      002DA7 01                    3397 	.sleb128	1
      002DA8 00 00 00 00           3398 	.dw	0,0
      002DAC 00 00 00 00           3399 	.dw	0,0
      002DB0 00 00 9A 92           3400 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$234)
      002DB4 00 00 9A AA           3401 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$245)
      002DB8 00 02                 3402 	.dw	2
      002DBA 78                    3403 	.db	120
      002DBB 01                    3404 	.sleb128	1
      002DBC 00 00 00 00           3405 	.dw	0,0
      002DC0 00 00 00 00           3406 	.dw	0,0
      002DC4 00 00 9A 7A           3407 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$221)
      002DC8 00 00 9A 92           3408 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$232)
      002DCC 00 02                 3409 	.dw	2
      002DCE 78                    3410 	.db	120
      002DCF 01                    3411 	.sleb128	1
      002DD0 00 00 00 00           3412 	.dw	0,0
      002DD4 00 00 00 00           3413 	.dw	0,0
      002DD8 00 00 9A 62           3414 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$208)
      002DDC 00 00 9A 7A           3415 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$219)
      002DE0 00 02                 3416 	.dw	2
      002DE2 78                    3417 	.db	120
      002DE3 01                    3418 	.sleb128	1
      002DE4 00 00 00 00           3419 	.dw	0,0
      002DE8 00 00 00 00           3420 	.dw	0,0
      002DEC 00 00 9A 4A           3421 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$195)
      002DF0 00 00 9A 62           3422 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$206)
      002DF4 00 02                 3423 	.dw	2
      002DF6 78                    3424 	.db	120
      002DF7 01                    3425 	.sleb128	1
      002DF8 00 00 00 00           3426 	.dw	0,0
      002DFC 00 00 00 00           3427 	.dw	0,0
      002E00 00 00 9A 32           3428 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$182)
      002E04 00 00 9A 4A           3429 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$193)
      002E08 00 02                 3430 	.dw	2
      002E0A 78                    3431 	.db	120
      002E0B 01                    3432 	.sleb128	1
      002E0C 00 00 00 00           3433 	.dw	0,0
      002E10 00 00 00 00           3434 	.dw	0,0
      002E14 00 00 9A 1A           3435 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$169)
      002E18 00 00 9A 32           3436 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$180)
      002E1C 00 02                 3437 	.dw	2
      002E1E 78                    3438 	.db	120
      002E1F 01                    3439 	.sleb128	1
      002E20 00 00 00 00           3440 	.dw	0,0
      002E24 00 00 00 00           3441 	.dw	0,0
      002E28 00 00 9A 02           3442 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$156)
      002E2C 00 00 9A 1A           3443 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$167)
      002E30 00 02                 3444 	.dw	2
      002E32 78                    3445 	.db	120
      002E33 01                    3446 	.sleb128	1
      002E34 00 00 00 00           3447 	.dw	0,0
      002E38 00 00 00 00           3448 	.dw	0,0
      002E3C 00 00 9A 01           3449 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$152)
      002E40 00 00 9A 02           3450 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$154)
      002E44 00 02                 3451 	.dw	2
      002E46 78                    3452 	.db	120
      002E47 01                    3453 	.sleb128	1
      002E48 00 00 99 D5           3454 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$138)
      002E4C 00 00 9A 01           3455 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$152)
      002E50 00 02                 3456 	.dw	2
      002E52 78                    3457 	.db	120
      002E53 03                    3458 	.sleb128	3
      002E54 00 00 99 D2           3459 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$137)
      002E58 00 00 99 D5           3460 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$138)
      002E5C 00 02                 3461 	.dw	2
      002E5E 78                    3462 	.db	120
      002E5F 04                    3463 	.sleb128	4
      002E60 00 00 99 9C           3464 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$122)
      002E64 00 00 99 D2           3465 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$137)
      002E68 00 02                 3466 	.dw	2
      002E6A 78                    3467 	.db	120
      002E6B 03                    3468 	.sleb128	3
      002E6C 00 00 99 91           3469 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$120)
      002E70 00 00 99 9C           3470 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$122)
      002E74 00 02                 3471 	.dw	2
      002E76 78                    3472 	.db	120
      002E77 03                    3473 	.sleb128	3
      002E78 00 00 99 7C           3474 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$118)
      002E7C 00 00 99 91           3475 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$120)
      002E80 00 02                 3476 	.dw	2
      002E82 78                    3477 	.db	120
      002E83 03                    3478 	.sleb128	3
      002E84 00 00 99 77           3479 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$117)
      002E88 00 00 99 7C           3480 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$118)
      002E8C 00 02                 3481 	.dw	2
      002E8E 78                    3482 	.db	120
      002E8F 04                    3483 	.sleb128	4
      002E90 00 00 99 6F           3484 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$114)
      002E94 00 00 99 77           3485 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$117)
      002E98 00 02                 3486 	.dw	2
      002E9A 78                    3487 	.db	120
      002E9B 03                    3488 	.sleb128	3
      002E9C 00 00 99 6E           3489 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$113)
      002EA0 00 00 99 6F           3490 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$114)
      002EA4 00 02                 3491 	.dw	2
      002EA6 78                    3492 	.db	120
      002EA7 01                    3493 	.sleb128	1
      002EA8 00 00 00 00           3494 	.dw	0,0
      002EAC 00 00 00 00           3495 	.dw	0,0
      002EB0 00 00 99 56           3496 	.dw	0,(Sstm8s_uart1$UART1_Cmd$100)
      002EB4 00 00 99 6E           3497 	.dw	0,(Sstm8s_uart1$UART1_Cmd$111)
      002EB8 00 02                 3498 	.dw	2
      002EBA 78                    3499 	.db	120
      002EBB 01                    3500 	.sleb128	1
      002EBC 00 00 00 00           3501 	.dw	0,0
      002EC0 00 00 00 00           3502 	.dw	0,0
      002EC4 00 00 99 55           3503 	.dw	0,(Sstm8s_uart1$UART1_Init$96)
      002EC8 00 00 99 56           3504 	.dw	0,(Sstm8s_uart1$UART1_Init$98)
      002ECC 00 02                 3505 	.dw	2
      002ECE 78                    3506 	.db	120
      002ECF 01                    3507 	.sleb128	1
      002ED0 00 00 99 4E           3508 	.dw	0,(Sstm8s_uart1$UART1_Init$93)
      002ED4 00 00 99 55           3509 	.dw	0,(Sstm8s_uart1$UART1_Init$96)
      002ED8 00 02                 3510 	.dw	2
      002EDA 78                    3511 	.db	120
      002EDB 12                    3512 	.sleb128	18
      002EDC 00 00 99 47           3513 	.dw	0,(Sstm8s_uart1$UART1_Init$92)
      002EE0 00 00 99 4E           3514 	.dw	0,(Sstm8s_uart1$UART1_Init$93)
      002EE4 00 02                 3515 	.dw	2
      002EE6 78                    3516 	.db	120
      002EE7 13                    3517 	.sleb128	19
      002EE8 00 00 99 22           3518 	.dw	0,(Sstm8s_uart1$UART1_Init$78)
      002EEC 00 00 99 47           3519 	.dw	0,(Sstm8s_uart1$UART1_Init$92)
      002EF0 00 02                 3520 	.dw	2
      002EF2 78                    3521 	.db	120
      002EF3 12                    3522 	.sleb128	18
      002EF4 00 00 99 1D           3523 	.dw	0,(Sstm8s_uart1$UART1_Init$77)
      002EF8 00 00 99 22           3524 	.dw	0,(Sstm8s_uart1$UART1_Init$78)
      002EFC 00 02                 3525 	.dw	2
      002EFE 78                    3526 	.db	120
      002EFF 13                    3527 	.sleb128	19
      002F00 00 00 99 07           3528 	.dw	0,(Sstm8s_uart1$UART1_Init$68)
      002F04 00 00 99 1D           3529 	.dw	0,(Sstm8s_uart1$UART1_Init$77)
      002F08 00 02                 3530 	.dw	2
      002F0A 78                    3531 	.db	120
      002F0B 12                    3532 	.sleb128	18
      002F0C 00 00 99 02           3533 	.dw	0,(Sstm8s_uart1$UART1_Init$67)
      002F10 00 00 99 07           3534 	.dw	0,(Sstm8s_uart1$UART1_Init$68)
      002F14 00 02                 3535 	.dw	2
      002F16 78                    3536 	.db	120
      002F17 13                    3537 	.sleb128	19
      002F18 00 00 98 BA           3538 	.dw	0,(Sstm8s_uart1$UART1_Init$59)
      002F1C 00 00 99 02           3539 	.dw	0,(Sstm8s_uart1$UART1_Init$67)
      002F20 00 02                 3540 	.dw	2
      002F22 78                    3541 	.db	120
      002F23 12                    3542 	.sleb128	18
      002F24 00 00 98 B5           3543 	.dw	0,(Sstm8s_uart1$UART1_Init$58)
      002F28 00 00 98 BA           3544 	.dw	0,(Sstm8s_uart1$UART1_Init$59)
      002F2C 00 02                 3545 	.dw	2
      002F2E 78                    3546 	.db	120
      002F2F 1A                    3547 	.sleb128	26
      002F30 00 00 98 B3           3548 	.dw	0,(Sstm8s_uart1$UART1_Init$57)
      002F34 00 00 98 B5           3549 	.dw	0,(Sstm8s_uart1$UART1_Init$58)
      002F38 00 02                 3550 	.dw	2
      002F3A 78                    3551 	.db	120
      002F3B 18                    3552 	.sleb128	24
      002F3C 00 00 98 B2           3553 	.dw	0,(Sstm8s_uart1$UART1_Init$56)
      002F40 00 00 98 B3           3554 	.dw	0,(Sstm8s_uart1$UART1_Init$57)
      002F44 00 02                 3555 	.dw	2
      002F46 78                    3556 	.db	120
      002F47 16                    3557 	.sleb128	22
      002F48 00 00 98 B0           3558 	.dw	0,(Sstm8s_uart1$UART1_Init$55)
      002F4C 00 00 98 B2           3559 	.dw	0,(Sstm8s_uart1$UART1_Init$56)
      002F50 00 02                 3560 	.dw	2
      002F52 78                    3561 	.db	120
      002F53 15                    3562 	.sleb128	21
      002F54 00 00 98 AE           3563 	.dw	0,(Sstm8s_uart1$UART1_Init$54)
      002F58 00 00 98 B0           3564 	.dw	0,(Sstm8s_uart1$UART1_Init$55)
      002F5C 00 02                 3565 	.dw	2
      002F5E 78                    3566 	.db	120
      002F5F 14                    3567 	.sleb128	20
      002F60 00 00 98 AC           3568 	.dw	0,(Sstm8s_uart1$UART1_Init$53)
      002F64 00 00 98 AE           3569 	.dw	0,(Sstm8s_uart1$UART1_Init$54)
      002F68 00 02                 3570 	.dw	2
      002F6A 78                    3571 	.db	120
      002F6B 13                    3572 	.sleb128	19
      002F6C 00 00 98 87           3573 	.dw	0,(Sstm8s_uart1$UART1_Init$52)
      002F70 00 00 98 AC           3574 	.dw	0,(Sstm8s_uart1$UART1_Init$53)
      002F74 00 02                 3575 	.dw	2
      002F76 78                    3576 	.db	120
      002F77 12                    3577 	.sleb128	18
      002F78 00 00 98 82           3578 	.dw	0,(Sstm8s_uart1$UART1_Init$51)
      002F7C 00 00 98 87           3579 	.dw	0,(Sstm8s_uart1$UART1_Init$52)
      002F80 00 02                 3580 	.dw	2
      002F82 78                    3581 	.db	120
      002F83 1A                    3582 	.sleb128	26
      002F84 00 00 98 80           3583 	.dw	0,(Sstm8s_uart1$UART1_Init$50)
      002F88 00 00 98 82           3584 	.dw	0,(Sstm8s_uart1$UART1_Init$51)
      002F8C 00 02                 3585 	.dw	2
      002F8E 78                    3586 	.db	120
      002F8F 19                    3587 	.sleb128	25
      002F90 00 00 98 7E           3588 	.dw	0,(Sstm8s_uart1$UART1_Init$49)
      002F94 00 00 98 80           3589 	.dw	0,(Sstm8s_uart1$UART1_Init$50)
      002F98 00 02                 3590 	.dw	2
      002F9A 78                    3591 	.db	120
      002F9B 17                    3592 	.sleb128	23
      002F9C 00 00 98 7C           3593 	.dw	0,(Sstm8s_uart1$UART1_Init$48)
      002FA0 00 00 98 7E           3594 	.dw	0,(Sstm8s_uart1$UART1_Init$49)
      002FA4 00 02                 3595 	.dw	2
      002FA6 78                    3596 	.db	120
      002FA7 16                    3597 	.sleb128	22
      002FA8 00 00 98 79           3598 	.dw	0,(Sstm8s_uart1$UART1_Init$47)
      002FAC 00 00 98 7C           3599 	.dw	0,(Sstm8s_uart1$UART1_Init$48)
      002FB0 00 02                 3600 	.dw	2
      002FB2 78                    3601 	.db	120
      002FB3 14                    3602 	.sleb128	20
      002FB4 00 00 98 6D           3603 	.dw	0,(Sstm8s_uart1$UART1_Init$45)
      002FB8 00 00 98 79           3604 	.dw	0,(Sstm8s_uart1$UART1_Init$47)
      002FBC 00 02                 3605 	.dw	2
      002FBE 78                    3606 	.db	120
      002FBF 12                    3607 	.sleb128	18
      002FC0 00 00 98 68           3608 	.dw	0,(Sstm8s_uart1$UART1_Init$44)
      002FC4 00 00 98 6D           3609 	.dw	0,(Sstm8s_uart1$UART1_Init$45)
      002FC8 00 02                 3610 	.dw	2
      002FCA 78                    3611 	.db	120
      002FCB 1A                    3612 	.sleb128	26
      002FCC 00 00 98 66           3613 	.dw	0,(Sstm8s_uart1$UART1_Init$43)
      002FD0 00 00 98 68           3614 	.dw	0,(Sstm8s_uart1$UART1_Init$44)
      002FD4 00 02                 3615 	.dw	2
      002FD6 78                    3616 	.db	120
      002FD7 18                    3617 	.sleb128	24
      002FD8 00 00 98 63           3618 	.dw	0,(Sstm8s_uart1$UART1_Init$42)
      002FDC 00 00 98 66           3619 	.dw	0,(Sstm8s_uart1$UART1_Init$43)
      002FE0 00 02                 3620 	.dw	2
      002FE2 78                    3621 	.db	120
      002FE3 16                    3622 	.sleb128	22
      002FE4 00 00 98 60           3623 	.dw	0,(Sstm8s_uart1$UART1_Init$41)
      002FE8 00 00 98 63           3624 	.dw	0,(Sstm8s_uart1$UART1_Init$42)
      002FEC 00 02                 3625 	.dw	2
      002FEE 78                    3626 	.db	120
      002FEF 14                    3627 	.sleb128	20
      002FF0 00 00 98 5B           3628 	.dw	0,(Sstm8s_uart1$UART1_Init$40)
      002FF4 00 00 98 60           3629 	.dw	0,(Sstm8s_uart1$UART1_Init$41)
      002FF8 00 02                 3630 	.dw	2
      002FFA 78                    3631 	.db	120
      002FFB 12                    3632 	.sleb128	18
      002FFC 00 00 98 56           3633 	.dw	0,(Sstm8s_uart1$UART1_Init$39)
      003000 00 00 98 5B           3634 	.dw	0,(Sstm8s_uart1$UART1_Init$40)
      003004 00 02                 3635 	.dw	2
      003006 78                    3636 	.db	120
      003007 1A                    3637 	.sleb128	26
      003008 00 00 98 54           3638 	.dw	0,(Sstm8s_uart1$UART1_Init$38)
      00300C 00 00 98 56           3639 	.dw	0,(Sstm8s_uart1$UART1_Init$39)
      003010 00 02                 3640 	.dw	2
      003012 78                    3641 	.db	120
      003013 19                    3642 	.sleb128	25
      003014 00 00 98 52           3643 	.dw	0,(Sstm8s_uart1$UART1_Init$37)
      003018 00 00 98 54           3644 	.dw	0,(Sstm8s_uart1$UART1_Init$38)
      00301C 00 02                 3645 	.dw	2
      00301E 78                    3646 	.db	120
      00301F 17                    3647 	.sleb128	23
      003020 00 00 98 50           3648 	.dw	0,(Sstm8s_uart1$UART1_Init$36)
      003024 00 00 98 52           3649 	.dw	0,(Sstm8s_uart1$UART1_Init$37)
      003028 00 02                 3650 	.dw	2
      00302A 78                    3651 	.db	120
      00302B 16                    3652 	.sleb128	22
      00302C 00 00 98 4D           3653 	.dw	0,(Sstm8s_uart1$UART1_Init$35)
      003030 00 00 98 50           3654 	.dw	0,(Sstm8s_uart1$UART1_Init$36)
      003034 00 02                 3655 	.dw	2
      003036 78                    3656 	.db	120
      003037 14                    3657 	.sleb128	20
      003038 00 00 98 37           3658 	.dw	0,(Sstm8s_uart1$UART1_Init$33)
      00303C 00 00 98 4D           3659 	.dw	0,(Sstm8s_uart1$UART1_Init$35)
      003040 00 02                 3660 	.dw	2
      003042 78                    3661 	.db	120
      003043 12                    3662 	.sleb128	18
      003044 00 00 98 32           3663 	.dw	0,(Sstm8s_uart1$UART1_Init$32)
      003048 00 00 98 37           3664 	.dw	0,(Sstm8s_uart1$UART1_Init$33)
      00304C 00 02                 3665 	.dw	2
      00304E 78                    3666 	.db	120
      00304F 1A                    3667 	.sleb128	26
      003050 00 00 98 30           3668 	.dw	0,(Sstm8s_uart1$UART1_Init$31)
      003054 00 00 98 32           3669 	.dw	0,(Sstm8s_uart1$UART1_Init$32)
      003058 00 02                 3670 	.dw	2
      00305A 78                    3671 	.db	120
      00305B 18                    3672 	.sleb128	24
      00305C 00 00 98 2D           3673 	.dw	0,(Sstm8s_uart1$UART1_Init$30)
      003060 00 00 98 30           3674 	.dw	0,(Sstm8s_uart1$UART1_Init$31)
      003064 00 02                 3675 	.dw	2
      003066 78                    3676 	.db	120
      003067 16                    3677 	.sleb128	22
      003068 00 00 98 2A           3678 	.dw	0,(Sstm8s_uart1$UART1_Init$29)
      00306C 00 00 98 2D           3679 	.dw	0,(Sstm8s_uart1$UART1_Init$30)
      003070 00 02                 3680 	.dw	2
      003072 78                    3681 	.db	120
      003073 14                    3682 	.sleb128	20
      003074 00 00 97 C9           3683 	.dw	0,(Sstm8s_uart1$UART1_Init$18)
      003078 00 00 98 2A           3684 	.dw	0,(Sstm8s_uart1$UART1_Init$29)
      00307C 00 02                 3685 	.dw	2
      00307E 78                    3686 	.db	120
      00307F 12                    3687 	.sleb128	18
      003080 00 00 97 C7           3688 	.dw	0,(Sstm8s_uart1$UART1_Init$17)
      003084 00 00 97 C9           3689 	.dw	0,(Sstm8s_uart1$UART1_Init$18)
      003088 00 02                 3690 	.dw	2
      00308A 78                    3691 	.db	120
      00308B 01                    3692 	.sleb128	1
      00308C 00 00 00 00           3693 	.dw	0,0
      003090 00 00 00 00           3694 	.dw	0,0
      003094 00 00 97 9C           3695 	.dw	0,(Sstm8s_uart1$UART1_DeInit$1)
      003098 00 00 97 C7           3696 	.dw	0,(Sstm8s_uart1$UART1_DeInit$15)
      00309C 00 02                 3697 	.dw	2
      00309E 78                    3698 	.db	120
      00309F 01                    3699 	.sleb128	1
      0030A0 00 00 00 00           3700 	.dw	0,0
      0030A4 00 00 00 00           3701 	.dw	0,0
                                   3702 
                                   3703 	.area .debug_abbrev (NOLOAD)
      000628                       3704 Ldebug_abbrev:
      000628 09                    3705 	.uleb128	9
      000629 2E                    3706 	.uleb128	46
      00062A 00                    3707 	.db	0
      00062B 03                    3708 	.uleb128	3
      00062C 08                    3709 	.uleb128	8
      00062D 11                    3710 	.uleb128	17
      00062E 01                    3711 	.uleb128	1
      00062F 12                    3712 	.uleb128	18
      000630 01                    3713 	.uleb128	1
      000631 3F                    3714 	.uleb128	63
      000632 0C                    3715 	.uleb128	12
      000633 40                    3716 	.uleb128	64
      000634 06                    3717 	.uleb128	6
      000635 49                    3718 	.uleb128	73
      000636 13                    3719 	.uleb128	19
      000637 00                    3720 	.uleb128	0
      000638 00                    3721 	.uleb128	0
      000639 04                    3722 	.uleb128	4
      00063A 05                    3723 	.uleb128	5
      00063B 00                    3724 	.db	0
      00063C 02                    3725 	.uleb128	2
      00063D 0A                    3726 	.uleb128	10
      00063E 03                    3727 	.uleb128	3
      00063F 08                    3728 	.uleb128	8
      000640 49                    3729 	.uleb128	73
      000641 13                    3730 	.uleb128	19
      000642 00                    3731 	.uleb128	0
      000643 00                    3732 	.uleb128	0
      000644 03                    3733 	.uleb128	3
      000645 2E                    3734 	.uleb128	46
      000646 01                    3735 	.db	1
      000647 01                    3736 	.uleb128	1
      000648 13                    3737 	.uleb128	19
      000649 03                    3738 	.uleb128	3
      00064A 08                    3739 	.uleb128	8
      00064B 11                    3740 	.uleb128	17
      00064C 01                    3741 	.uleb128	1
      00064D 12                    3742 	.uleb128	18
      00064E 01                    3743 	.uleb128	1
      00064F 3F                    3744 	.uleb128	63
      000650 0C                    3745 	.uleb128	12
      000651 40                    3746 	.uleb128	64
      000652 06                    3747 	.uleb128	6
      000653 00                    3748 	.uleb128	0
      000654 00                    3749 	.uleb128	0
      000655 06                    3750 	.uleb128	6
      000656 34                    3751 	.uleb128	52
      000657 00                    3752 	.db	0
      000658 02                    3753 	.uleb128	2
      000659 0A                    3754 	.uleb128	10
      00065A 03                    3755 	.uleb128	3
      00065B 08                    3756 	.uleb128	8
      00065C 49                    3757 	.uleb128	73
      00065D 13                    3758 	.uleb128	19
      00065E 00                    3759 	.uleb128	0
      00065F 00                    3760 	.uleb128	0
      000660 0A                    3761 	.uleb128	10
      000661 2E                    3762 	.uleb128	46
      000662 01                    3763 	.db	1
      000663 01                    3764 	.uleb128	1
      000664 13                    3765 	.uleb128	19
      000665 03                    3766 	.uleb128	3
      000666 08                    3767 	.uleb128	8
      000667 11                    3768 	.uleb128	17
      000668 01                    3769 	.uleb128	1
      000669 12                    3770 	.uleb128	18
      00066A 01                    3771 	.uleb128	1
      00066B 3F                    3772 	.uleb128	63
      00066C 0C                    3773 	.uleb128	12
      00066D 40                    3774 	.uleb128	64
      00066E 06                    3775 	.uleb128	6
      00066F 49                    3776 	.uleb128	73
      000670 13                    3777 	.uleb128	19
      000671 00                    3778 	.uleb128	0
      000672 00                    3779 	.uleb128	0
      000673 01                    3780 	.uleb128	1
      000674 11                    3781 	.uleb128	17
      000675 01                    3782 	.db	1
      000676 03                    3783 	.uleb128	3
      000677 08                    3784 	.uleb128	8
      000678 10                    3785 	.uleb128	16
      000679 06                    3786 	.uleb128	6
      00067A 13                    3787 	.uleb128	19
      00067B 0B                    3788 	.uleb128	11
      00067C 25                    3789 	.uleb128	37
      00067D 08                    3790 	.uleb128	8
      00067E 00                    3791 	.uleb128	0
      00067F 00                    3792 	.uleb128	0
      000680 05                    3793 	.uleb128	5
      000681 0B                    3794 	.uleb128	11
      000682 00                    3795 	.db	0
      000683 11                    3796 	.uleb128	17
      000684 01                    3797 	.uleb128	1
      000685 12                    3798 	.uleb128	18
      000686 01                    3799 	.uleb128	1
      000687 00                    3800 	.uleb128	0
      000688 00                    3801 	.uleb128	0
      000689 08                    3802 	.uleb128	8
      00068A 0B                    3803 	.uleb128	11
      00068B 01                    3804 	.db	1
      00068C 01                    3805 	.uleb128	1
      00068D 13                    3806 	.uleb128	19
      00068E 11                    3807 	.uleb128	17
      00068F 01                    3808 	.uleb128	1
      000690 00                    3809 	.uleb128	0
      000691 00                    3810 	.uleb128	0
      000692 02                    3811 	.uleb128	2
      000693 2E                    3812 	.uleb128	46
      000694 00                    3813 	.db	0
      000695 03                    3814 	.uleb128	3
      000696 08                    3815 	.uleb128	8
      000697 11                    3816 	.uleb128	17
      000698 01                    3817 	.uleb128	1
      000699 12                    3818 	.uleb128	18
      00069A 01                    3819 	.uleb128	1
      00069B 3F                    3820 	.uleb128	63
      00069C 0C                    3821 	.uleb128	12
      00069D 40                    3822 	.uleb128	64
      00069E 06                    3823 	.uleb128	6
      00069F 00                    3824 	.uleb128	0
      0006A0 00                    3825 	.uleb128	0
      0006A1 0B                    3826 	.uleb128	11
      0006A2 2E                    3827 	.uleb128	46
      0006A3 01                    3828 	.db	1
      0006A4 03                    3829 	.uleb128	3
      0006A5 08                    3830 	.uleb128	8
      0006A6 11                    3831 	.uleb128	17
      0006A7 01                    3832 	.uleb128	1
      0006A8 12                    3833 	.uleb128	18
      0006A9 01                    3834 	.uleb128	1
      0006AA 3F                    3835 	.uleb128	63
      0006AB 0C                    3836 	.uleb128	12
      0006AC 40                    3837 	.uleb128	64
      0006AD 06                    3838 	.uleb128	6
      0006AE 00                    3839 	.uleb128	0
      0006AF 00                    3840 	.uleb128	0
      0006B0 07                    3841 	.uleb128	7
      0006B1 24                    3842 	.uleb128	36
      0006B2 00                    3843 	.db	0
      0006B3 03                    3844 	.uleb128	3
      0006B4 08                    3845 	.uleb128	8
      0006B5 0B                    3846 	.uleb128	11
      0006B6 0B                    3847 	.uleb128	11
      0006B7 3E                    3848 	.uleb128	62
      0006B8 0B                    3849 	.uleb128	11
      0006B9 00                    3850 	.uleb128	0
      0006BA 00                    3851 	.uleb128	0
      0006BB 00                    3852 	.uleb128	0
                                   3853 
                                   3854 	.area .debug_info (NOLOAD)
      003716 00 00 08 C7           3855 	.dw	0,Ldebug_info_end-Ldebug_info_start
      00371A                       3856 Ldebug_info_start:
      00371A 00 02                 3857 	.dw	2
      00371C 00 00 06 28           3858 	.dw	0,(Ldebug_abbrev)
      003720 04                    3859 	.db	4
      003721 01                    3860 	.uleb128	1
      003722 2E 2E 2F 53 50 4C 2F  3861 	.ascii "../SPL/src/stm8s_uart1.c"
             73 72 63 2F 73 74 6D
             38 73 5F 75 61 72 74
             31 2E 63
      00373A 00                    3862 	.db	0
      00373B 00 00 22 E9           3863 	.dw	0,(Ldebug_line_start+-4)
      00373F 01                    3864 	.db	1
      003740 53 44 43 43 20 76 65  3865 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      003759 00                    3866 	.db	0
      00375A 02                    3867 	.uleb128	2
      00375B 55 41 52 54 31 5F 44  3868 	.ascii "UART1_DeInit"
             65 49 6E 69 74
      003767 00                    3869 	.db	0
      003768 00 00 97 9C           3870 	.dw	0,(_UART1_DeInit)
      00376C 00 00 97 C7           3871 	.dw	0,(XG$UART1_DeInit$0$0+1)
      003770 01                    3872 	.db	1
      003771 00 00 30 94           3873 	.dw	0,(Ldebug_loc_start+1236)
      003775 03                    3874 	.uleb128	3
      003776 00 00 01 4C           3875 	.dw	0,332
      00377A 55 41 52 54 31 5F 49  3876 	.ascii "UART1_Init"
             6E 69 74
      003784 00                    3877 	.db	0
      003785 00 00 97 C7           3878 	.dw	0,(_UART1_Init)
      003789 00 00 99 56           3879 	.dw	0,(XG$UART1_Init$0$0+1)
      00378D 01                    3880 	.db	1
      00378E 00 00 2E C4           3881 	.dw	0,(Ldebug_loc_start+772)
      003792 04                    3882 	.uleb128	4
      003793 02                    3883 	.db	2
      003794 91                    3884 	.db	145
      003795 02                    3885 	.sleb128	2
      003796 42 61 75 64 52 61 74  3886 	.ascii "BaudRate"
             65
      00379E 00                    3887 	.db	0
      00379F 00 00 01 4C           3888 	.dw	0,332
      0037A3 04                    3889 	.uleb128	4
      0037A4 02                    3890 	.db	2
      0037A5 91                    3891 	.db	145
      0037A6 06                    3892 	.sleb128	6
      0037A7 57 6F 72 64 4C 65 6E  3893 	.ascii "WordLength"
             67 74 68
      0037B1 00                    3894 	.db	0
      0037B2 00 00 01 5D           3895 	.dw	0,349
      0037B6 04                    3896 	.uleb128	4
      0037B7 02                    3897 	.db	2
      0037B8 91                    3898 	.db	145
      0037B9 07                    3899 	.sleb128	7
      0037BA 53 74 6F 70 42 69 74  3900 	.ascii "StopBits"
             73
      0037C2 00                    3901 	.db	0
      0037C3 00 00 01 5D           3902 	.dw	0,349
      0037C7 04                    3903 	.uleb128	4
      0037C8 02                    3904 	.db	2
      0037C9 91                    3905 	.db	145
      0037CA 08                    3906 	.sleb128	8
      0037CB 50 61 72 69 74 79     3907 	.ascii "Parity"
      0037D1 00                    3908 	.db	0
      0037D2 00 00 01 5D           3909 	.dw	0,349
      0037D6 04                    3910 	.uleb128	4
      0037D7 02                    3911 	.db	2
      0037D8 91                    3912 	.db	145
      0037D9 09                    3913 	.sleb128	9
      0037DA 53 79 6E 63 4D 6F 64  3914 	.ascii "SyncMode"
             65
      0037E2 00                    3915 	.db	0
      0037E3 00 00 01 5D           3916 	.dw	0,349
      0037E7 04                    3917 	.uleb128	4
      0037E8 02                    3918 	.db	2
      0037E9 91                    3919 	.db	145
      0037EA 0A                    3920 	.sleb128	10
      0037EB 4D 6F 64 65           3921 	.ascii "Mode"
      0037EF 00                    3922 	.db	0
      0037F0 00 00 01 5D           3923 	.dw	0,349
      0037F4 05                    3924 	.uleb128	5
      0037F5 00 00 99 0C           3925 	.dw	0,(Sstm8s_uart1$UART1_Init$69)
      0037F9 00 00 99 11           3926 	.dw	0,(Sstm8s_uart1$UART1_Init$71)
      0037FD 05                    3927 	.uleb128	5
      0037FE 00 00 99 14           3928 	.dw	0,(Sstm8s_uart1$UART1_Init$72)
      003802 00 00 99 19           3929 	.dw	0,(Sstm8s_uart1$UART1_Init$74)
      003806 05                    3930 	.uleb128	5
      003807 00 00 99 27           3931 	.dw	0,(Sstm8s_uart1$UART1_Init$79)
      00380B 00 00 99 2C           3932 	.dw	0,(Sstm8s_uart1$UART1_Init$81)
      00380F 05                    3933 	.uleb128	5
      003810 00 00 99 2F           3934 	.dw	0,(Sstm8s_uart1$UART1_Init$82)
      003814 00 00 99 34           3935 	.dw	0,(Sstm8s_uart1$UART1_Init$84)
      003818 05                    3936 	.uleb128	5
      003819 00 00 99 3E           3937 	.dw	0,(Sstm8s_uart1$UART1_Init$87)
      00381D 00 00 99 43           3938 	.dw	0,(Sstm8s_uart1$UART1_Init$89)
      003821 05                    3939 	.uleb128	5
      003822 00 00 99 46           3940 	.dw	0,(Sstm8s_uart1$UART1_Init$90)
      003826 00 00 99 53           3941 	.dw	0,(Sstm8s_uart1$UART1_Init$94)
      00382A 06                    3942 	.uleb128	6
      00382B 02                    3943 	.db	2
      00382C 91                    3944 	.db	145
      00382D 6F                    3945 	.sleb128	-17
      00382E 42 61 75 64 52 61 74  3946 	.ascii "BaudRate_Mantissa"
             65 5F 4D 61 6E 74 69
             73 73 61
      00383F 00                    3947 	.db	0
      003840 00 00 01 4C           3948 	.dw	0,332
      003844 06                    3949 	.uleb128	6
      003845 02                    3950 	.db	2
      003846 91                    3951 	.db	145
      003847 73                    3952 	.sleb128	-13
      003848 42 61 75 64 52 61 74  3953 	.ascii "BaudRate_Mantissa100"
             65 5F 4D 61 6E 74 69
             73 73 61 31 30 30
      00385C 00                    3954 	.db	0
      00385D 00 00 01 4C           3955 	.dw	0,332
      003861 00                    3956 	.uleb128	0
      003862 07                    3957 	.uleb128	7
      003863 75 6E 73 69 67 6E 65  3958 	.ascii "unsigned long"
             64 20 6C 6F 6E 67
      003870 00                    3959 	.db	0
      003871 04                    3960 	.db	4
      003872 07                    3961 	.db	7
      003873 07                    3962 	.uleb128	7
      003874 75 6E 73 69 67 6E 65  3963 	.ascii "unsigned char"
             64 20 63 68 61 72
      003881 00                    3964 	.db	0
      003882 01                    3965 	.db	1
      003883 08                    3966 	.db	8
      003884 03                    3967 	.uleb128	3
      003885 00 00 01 AE           3968 	.dw	0,430
      003889 55 41 52 54 31 5F 43  3969 	.ascii "UART1_Cmd"
             6D 64
      003892 00                    3970 	.db	0
      003893 00 00 99 56           3971 	.dw	0,(_UART1_Cmd)
      003897 00 00 99 6E           3972 	.dw	0,(XG$UART1_Cmd$0$0+1)
      00389B 01                    3973 	.db	1
      00389C 00 00 2E B0           3974 	.dw	0,(Ldebug_loc_start+752)
      0038A0 04                    3975 	.uleb128	4
      0038A1 02                    3976 	.db	2
      0038A2 91                    3977 	.db	145
      0038A3 02                    3978 	.sleb128	2
      0038A4 4E 65 77 53 74 61 74  3979 	.ascii "NewState"
             65
      0038AC 00                    3980 	.db	0
      0038AD 00 00 01 5D           3981 	.dw	0,349
      0038B1 05                    3982 	.uleb128	5
      0038B2 00 00 99 60           3983 	.dw	0,(Sstm8s_uart1$UART1_Cmd$103)
      0038B6 00 00 99 65           3984 	.dw	0,(Sstm8s_uart1$UART1_Cmd$105)
      0038BA 05                    3985 	.uleb128	5
      0038BB 00 00 99 68           3986 	.dw	0,(Sstm8s_uart1$UART1_Cmd$106)
      0038BF 00 00 99 6D           3987 	.dw	0,(Sstm8s_uart1$UART1_Cmd$108)
      0038C3 00                    3988 	.uleb128	0
      0038C4 03                    3989 	.uleb128	3
      0038C5 00 00 02 59           3990 	.dw	0,601
      0038C9 55 41 52 54 31 5F 49  3991 	.ascii "UART1_ITConfig"
             54 43 6F 6E 66 69 67
      0038D7 00                    3992 	.db	0
      0038D8 00 00 99 6E           3993 	.dw	0,(_UART1_ITConfig)
      0038DC 00 00 9A 02           3994 	.dw	0,(XG$UART1_ITConfig$0$0+1)
      0038E0 01                    3995 	.db	1
      0038E1 00 00 2E 3C           3996 	.dw	0,(Ldebug_loc_start+636)
      0038E5 04                    3997 	.uleb128	4
      0038E6 02                    3998 	.db	2
      0038E7 91                    3999 	.db	145
      0038E8 02                    4000 	.sleb128	2
      0038E9 55 41 52 54 31 5F 49  4001 	.ascii "UART1_IT"
             54
      0038F1 00                    4002 	.db	0
      0038F2 00 00 02 59           4003 	.dw	0,601
      0038F6 04                    4004 	.uleb128	4
      0038F7 02                    4005 	.db	2
      0038F8 91                    4006 	.db	145
      0038F9 04                    4007 	.sleb128	4
      0038FA 4E 65 77 53 74 61 74  4008 	.ascii "NewState"
             65
      003902 00                    4009 	.db	0
      003903 00 00 01 5D           4010 	.dw	0,349
      003907 08                    4011 	.uleb128	8
      003908 00 00 02 16           4012 	.dw	0,534
      00390C 00 00 99 A3           4013 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$124)
      003910 05                    4014 	.uleb128	5
      003911 00 00 99 AA           4015 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$126)
      003915 00 00 99 B2           4016 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$128)
      003919 05                    4017 	.uleb128	5
      00391A 00 00 99 BB           4018 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$130)
      00391E 00 00 99 C3           4019 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$132)
      003922 05                    4020 	.uleb128	5
      003923 00 00 99 C6           4021 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$133)
      003927 00 00 99 CE           4022 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$135)
      00392B 00                    4023 	.uleb128	0
      00392C 08                    4024 	.uleb128	8
      00392D 00 00 02 3B           4025 	.dw	0,571
      003931 00 00 99 D5           4026 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$139)
      003935 05                    4027 	.uleb128	5
      003936 00 00 99 DC           4028 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$141)
      00393A 00 00 99 E4           4029 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$143)
      00393E 05                    4030 	.uleb128	5
      00393F 00 00 99 ED           4031 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$145)
      003943 00 00 99 F5           4032 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$147)
      003947 05                    4033 	.uleb128	5
      003948 00 00 99 F8           4034 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$148)
      00394C 00 00 9A 00           4035 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$150)
      003950 00                    4036 	.uleb128	0
      003951 06                    4037 	.uleb128	6
      003952 01                    4038 	.db	1
      003953 52                    4039 	.db	82
      003954 75 61 72 74 72 65 67  4040 	.ascii "uartreg"
      00395B 00                    4041 	.db	0
      00395C 00 00 01 5D           4042 	.dw	0,349
      003960 06                    4043 	.uleb128	6
      003961 02                    4044 	.db	2
      003962 91                    4045 	.db	145
      003963 7F                    4046 	.sleb128	-1
      003964 69 74 70 6F 73        4047 	.ascii "itpos"
      003969 00                    4048 	.db	0
      00396A 00 00 01 5D           4049 	.dw	0,349
      00396E 00                    4050 	.uleb128	0
      00396F 07                    4051 	.uleb128	7
      003970 75 6E 73 69 67 6E 65  4052 	.ascii "unsigned int"
             64 20 69 6E 74
      00397C 00                    4053 	.db	0
      00397D 02                    4054 	.db	2
      00397E 07                    4055 	.db	7
      00397F 03                    4056 	.uleb128	3
      003980 00 00 02 B3           4057 	.dw	0,691
      003984 55 41 52 54 31 5F 48  4058 	.ascii "UART1_HalfDuplexCmd"
             61 6C 66 44 75 70 6C
             65 78 43 6D 64
      003997 00                    4059 	.db	0
      003998 00 00 9A 02           4060 	.dw	0,(_UART1_HalfDuplexCmd)
      00399C 00 00 9A 1A           4061 	.dw	0,(XG$UART1_HalfDuplexCmd$0$0+1)
      0039A0 01                    4062 	.db	1
      0039A1 00 00 2E 28           4063 	.dw	0,(Ldebug_loc_start+616)
      0039A5 04                    4064 	.uleb128	4
      0039A6 02                    4065 	.db	2
      0039A7 91                    4066 	.db	145
      0039A8 02                    4067 	.sleb128	2
      0039A9 4E 65 77 53 74 61 74  4068 	.ascii "NewState"
             65
      0039B1 00                    4069 	.db	0
      0039B2 00 00 01 5D           4070 	.dw	0,349
      0039B6 05                    4071 	.uleb128	5
      0039B7 00 00 9A 0C           4072 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$159)
      0039BB 00 00 9A 11           4073 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$161)
      0039BF 05                    4074 	.uleb128	5
      0039C0 00 00 9A 14           4075 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$162)
      0039C4 00 00 9A 19           4076 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$164)
      0039C8 00                    4077 	.uleb128	0
      0039C9 03                    4078 	.uleb128	3
      0039CA 00 00 03 00           4079 	.dw	0,768
      0039CE 55 41 52 54 31 5F 49  4080 	.ascii "UART1_IrDAConfig"
             72 44 41 43 6F 6E 66
             69 67
      0039DE 00                    4081 	.db	0
      0039DF 00 00 9A 1A           4082 	.dw	0,(_UART1_IrDAConfig)
      0039E3 00 00 9A 32           4083 	.dw	0,(XG$UART1_IrDAConfig$0$0+1)
      0039E7 01                    4084 	.db	1
      0039E8 00 00 2E 14           4085 	.dw	0,(Ldebug_loc_start+596)
      0039EC 04                    4086 	.uleb128	4
      0039ED 02                    4087 	.db	2
      0039EE 91                    4088 	.db	145
      0039EF 02                    4089 	.sleb128	2
      0039F0 55 41 52 54 31 5F 49  4090 	.ascii "UART1_IrDAMode"
             72 44 41 4D 6F 64 65
      0039FE 00                    4091 	.db	0
      0039FF 00 00 01 5D           4092 	.dw	0,349
      003A03 05                    4093 	.uleb128	5
      003A04 00 00 9A 24           4094 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$172)
      003A08 00 00 9A 29           4095 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$174)
      003A0C 05                    4096 	.uleb128	5
      003A0D 00 00 9A 2C           4097 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$175)
      003A11 00 00 9A 31           4098 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$177)
      003A15 00                    4099 	.uleb128	0
      003A16 03                    4100 	.uleb128	3
      003A17 00 00 03 44           4101 	.dw	0,836
      003A1B 55 41 52 54 31 5F 49  4102 	.ascii "UART1_IrDACmd"
             72 44 41 43 6D 64
      003A28 00                    4103 	.db	0
      003A29 00 00 9A 32           4104 	.dw	0,(_UART1_IrDACmd)
      003A2D 00 00 9A 4A           4105 	.dw	0,(XG$UART1_IrDACmd$0$0+1)
      003A31 01                    4106 	.db	1
      003A32 00 00 2E 00           4107 	.dw	0,(Ldebug_loc_start+576)
      003A36 04                    4108 	.uleb128	4
      003A37 02                    4109 	.db	2
      003A38 91                    4110 	.db	145
      003A39 02                    4111 	.sleb128	2
      003A3A 4E 65 77 53 74 61 74  4112 	.ascii "NewState"
             65
      003A42 00                    4113 	.db	0
      003A43 00 00 01 5D           4114 	.dw	0,349
      003A47 05                    4115 	.uleb128	5
      003A48 00 00 9A 3C           4116 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$185)
      003A4C 00 00 9A 41           4117 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$187)
      003A50 05                    4118 	.uleb128	5
      003A51 00 00 9A 44           4119 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$188)
      003A55 00 00 9A 49           4120 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$190)
      003A59 00                    4121 	.uleb128	0
      003A5A 03                    4122 	.uleb128	3
      003A5B 00 00 03 AD           4123 	.dw	0,941
      003A5F 55 41 52 54 31 5F 4C  4124 	.ascii "UART1_LINBreakDetectionConfig"
             49 4E 42 72 65 61 6B
             44 65 74 65 63 74 69
             6F 6E 43 6F 6E 66 69
             67
      003A7C 00                    4125 	.db	0
      003A7D 00 00 9A 4A           4126 	.dw	0,(_UART1_LINBreakDetectionConfig)
      003A81 00 00 9A 62           4127 	.dw	0,(XG$UART1_LINBreakDetectionConfig$0$0+1)
      003A85 01                    4128 	.db	1
      003A86 00 00 2D EC           4129 	.dw	0,(Ldebug_loc_start+556)
      003A8A 04                    4130 	.uleb128	4
      003A8B 02                    4131 	.db	2
      003A8C 91                    4132 	.db	145
      003A8D 02                    4133 	.sleb128	2
      003A8E 55 41 52 54 31 5F 4C  4134 	.ascii "UART1_LINBreakDetectionLength"
             49 4E 42 72 65 61 6B
             44 65 74 65 63 74 69
             6F 6E 4C 65 6E 67 74
             68
      003AAB 00                    4135 	.db	0
      003AAC 00 00 01 5D           4136 	.dw	0,349
      003AB0 05                    4137 	.uleb128	5
      003AB1 00 00 9A 54           4138 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$198)
      003AB5 00 00 9A 59           4139 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$200)
      003AB9 05                    4140 	.uleb128	5
      003ABA 00 00 9A 5C           4141 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$201)
      003ABE 00 00 9A 61           4142 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$203)
      003AC2 00                    4143 	.uleb128	0
      003AC3 03                    4144 	.uleb128	3
      003AC4 00 00 03 F0           4145 	.dw	0,1008
      003AC8 55 41 52 54 31 5F 4C  4146 	.ascii "UART1_LINCmd"
             49 4E 43 6D 64
      003AD4 00                    4147 	.db	0
      003AD5 00 00 9A 62           4148 	.dw	0,(_UART1_LINCmd)
      003AD9 00 00 9A 7A           4149 	.dw	0,(XG$UART1_LINCmd$0$0+1)
      003ADD 01                    4150 	.db	1
      003ADE 00 00 2D D8           4151 	.dw	0,(Ldebug_loc_start+536)
      003AE2 04                    4152 	.uleb128	4
      003AE3 02                    4153 	.db	2
      003AE4 91                    4154 	.db	145
      003AE5 02                    4155 	.sleb128	2
      003AE6 4E 65 77 53 74 61 74  4156 	.ascii "NewState"
             65
      003AEE 00                    4157 	.db	0
      003AEF 00 00 01 5D           4158 	.dw	0,349
      003AF3 05                    4159 	.uleb128	5
      003AF4 00 00 9A 6C           4160 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$211)
      003AF8 00 00 9A 71           4161 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$213)
      003AFC 05                    4162 	.uleb128	5
      003AFD 00 00 9A 74           4163 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$214)
      003B01 00 00 9A 79           4164 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$216)
      003B05 00                    4165 	.uleb128	0
      003B06 03                    4166 	.uleb128	3
      003B07 00 00 04 39           4167 	.dw	0,1081
      003B0B 55 41 52 54 31 5F 53  4168 	.ascii "UART1_SmartCardCmd"
             6D 61 72 74 43 61 72
             64 43 6D 64
      003B1D 00                    4169 	.db	0
      003B1E 00 00 9A 7A           4170 	.dw	0,(_UART1_SmartCardCmd)
      003B22 00 00 9A 92           4171 	.dw	0,(XG$UART1_SmartCardCmd$0$0+1)
      003B26 01                    4172 	.db	1
      003B27 00 00 2D C4           4173 	.dw	0,(Ldebug_loc_start+516)
      003B2B 04                    4174 	.uleb128	4
      003B2C 02                    4175 	.db	2
      003B2D 91                    4176 	.db	145
      003B2E 02                    4177 	.sleb128	2
      003B2F 4E 65 77 53 74 61 74  4178 	.ascii "NewState"
             65
      003B37 00                    4179 	.db	0
      003B38 00 00 01 5D           4180 	.dw	0,349
      003B3C 05                    4181 	.uleb128	5
      003B3D 00 00 9A 84           4182 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$224)
      003B41 00 00 9A 89           4183 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$226)
      003B45 05                    4184 	.uleb128	5
      003B46 00 00 9A 8C           4185 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$227)
      003B4A 00 00 9A 91           4186 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$229)
      003B4E 00                    4187 	.uleb128	0
      003B4F 03                    4188 	.uleb128	3
      003B50 00 00 04 86           4189 	.dw	0,1158
      003B54 55 41 52 54 31 5F 53  4190 	.ascii "UART1_SmartCardNACKCmd"
             6D 61 72 74 43 61 72
             64 4E 41 43 4B 43 6D
             64
      003B6A 00                    4191 	.db	0
      003B6B 00 00 9A 92           4192 	.dw	0,(_UART1_SmartCardNACKCmd)
      003B6F 00 00 9A AA           4193 	.dw	0,(XG$UART1_SmartCardNACKCmd$0$0+1)
      003B73 01                    4194 	.db	1
      003B74 00 00 2D B0           4195 	.dw	0,(Ldebug_loc_start+496)
      003B78 04                    4196 	.uleb128	4
      003B79 02                    4197 	.db	2
      003B7A 91                    4198 	.db	145
      003B7B 02                    4199 	.sleb128	2
      003B7C 4E 65 77 53 74 61 74  4200 	.ascii "NewState"
             65
      003B84 00                    4201 	.db	0
      003B85 00 00 01 5D           4202 	.dw	0,349
      003B89 05                    4203 	.uleb128	5
      003B8A 00 00 9A 9C           4204 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$237)
      003B8E 00 00 9A A1           4205 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$239)
      003B92 05                    4206 	.uleb128	5
      003B93 00 00 9A A4           4207 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$240)
      003B97 00 00 9A A9           4208 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$242)
      003B9B 00                    4209 	.uleb128	0
      003B9C 03                    4210 	.uleb128	3
      003B9D 00 00 04 C1           4211 	.dw	0,1217
      003BA1 55 41 52 54 31 5F 57  4212 	.ascii "UART1_WakeUpConfig"
             61 6B 65 55 70 43 6F
             6E 66 69 67
      003BB3 00                    4213 	.db	0
      003BB4 00 00 9A AA           4214 	.dw	0,(_UART1_WakeUpConfig)
      003BB8 00 00 9A BB           4215 	.dw	0,(XG$UART1_WakeUpConfig$0$0+1)
      003BBC 01                    4216 	.db	1
      003BBD 00 00 2D 9C           4217 	.dw	0,(Ldebug_loc_start+476)
      003BC1 04                    4218 	.uleb128	4
      003BC2 02                    4219 	.db	2
      003BC3 91                    4220 	.db	145
      003BC4 02                    4221 	.sleb128	2
      003BC5 55 41 52 54 31 5F 57  4222 	.ascii "UART1_WakeUp"
             61 6B 65 55 70
      003BD1 00                    4223 	.db	0
      003BD2 00 00 01 5D           4224 	.dw	0,349
      003BD6 00                    4225 	.uleb128	0
      003BD7 03                    4226 	.uleb128	3
      003BD8 00 00 05 0F           4227 	.dw	0,1295
      003BDC 55 41 52 54 31 5F 52  4228 	.ascii "UART1_ReceiverWakeUpCmd"
             65 63 65 69 76 65 72
             57 61 6B 65 55 70 43
             6D 64
      003BF3 00                    4229 	.db	0
      003BF4 00 00 9A BB           4230 	.dw	0,(_UART1_ReceiverWakeUpCmd)
      003BF8 00 00 9A D3           4231 	.dw	0,(XG$UART1_ReceiverWakeUpCmd$0$0+1)
      003BFC 01                    4232 	.db	1
      003BFD 00 00 2D 88           4233 	.dw	0,(Ldebug_loc_start+456)
      003C01 04                    4234 	.uleb128	4
      003C02 02                    4235 	.db	2
      003C03 91                    4236 	.db	145
      003C04 02                    4237 	.sleb128	2
      003C05 4E 65 77 53 74 61 74  4238 	.ascii "NewState"
             65
      003C0D 00                    4239 	.db	0
      003C0E 00 00 01 5D           4240 	.dw	0,349
      003C12 05                    4241 	.uleb128	5
      003C13 00 00 9A C5           4242 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$257)
      003C17 00 00 9A CA           4243 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$259)
      003C1B 05                    4244 	.uleb128	5
      003C1C 00 00 9A CD           4245 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$260)
      003C20 00 00 9A D2           4246 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$262)
      003C24 00                    4247 	.uleb128	0
      003C25 09                    4248 	.uleb128	9
      003C26 55 41 52 54 31 5F 52  4249 	.ascii "UART1_ReceiveData8"
             65 63 65 69 76 65 44
             61 74 61 38
      003C38 00                    4250 	.db	0
      003C39 00 00 9A D3           4251 	.dw	0,(_UART1_ReceiveData8)
      003C3D 00 00 9A D7           4252 	.dw	0,(XG$UART1_ReceiveData8$0$0+1)
      003C41 01                    4253 	.db	1
      003C42 00 00 2D 74           4254 	.dw	0,(Ldebug_loc_start+436)
      003C46 00 00 01 5D           4255 	.dw	0,349
      003C4A 07                    4256 	.uleb128	7
      003C4B 75 6E 73 69 67 6E 65  4257 	.ascii "unsigned int"
             64 20 69 6E 74
      003C57 00                    4258 	.db	0
      003C58 02                    4259 	.db	2
      003C59 07                    4260 	.db	7
      003C5A 0A                    4261 	.uleb128	10
      003C5B 00 00 05 7B           4262 	.dw	0,1403
      003C5F 55 41 52 54 31 5F 52  4263 	.ascii "UART1_ReceiveData9"
             65 63 65 69 76 65 44
             61 74 61 39
      003C71 00                    4264 	.db	0
      003C72 00 00 9A D7           4265 	.dw	0,(_UART1_ReceiveData9)
      003C76 00 00 9A F4           4266 	.dw	0,(XG$UART1_ReceiveData9$0$0+1)
      003C7A 01                    4267 	.db	1
      003C7B 00 00 2D 48           4268 	.dw	0,(Ldebug_loc_start+392)
      003C7F 00 00 05 34           4269 	.dw	0,1332
      003C83 06                    4270 	.uleb128	6
      003C84 02                    4271 	.db	2
      003C85 91                    4272 	.db	145
      003C86 7E                    4273 	.sleb128	-2
      003C87 74 65 6D 70           4274 	.ascii "temp"
      003C8B 00                    4275 	.db	0
      003C8C 00 00 05 34           4276 	.dw	0,1332
      003C90 00                    4277 	.uleb128	0
      003C91 03                    4278 	.uleb128	3
      003C92 00 00 05 AB           4279 	.dw	0,1451
      003C96 55 41 52 54 31 5F 53  4280 	.ascii "UART1_SendData8"
             65 6E 64 44 61 74 61
             38
      003CA5 00                    4281 	.db	0
      003CA6 00 00 9A F4           4282 	.dw	0,(_UART1_SendData8)
      003CAA 00 00 9A FB           4283 	.dw	0,(XG$UART1_SendData8$0$0+1)
      003CAE 01                    4284 	.db	1
      003CAF 00 00 2D 34           4285 	.dw	0,(Ldebug_loc_start+372)
      003CB3 04                    4286 	.uleb128	4
      003CB4 02                    4287 	.db	2
      003CB5 91                    4288 	.db	145
      003CB6 02                    4289 	.sleb128	2
      003CB7 44 61 74 61           4290 	.ascii "Data"
      003CBB 00                    4291 	.db	0
      003CBC 00 00 01 5D           4292 	.dw	0,349
      003CC0 00                    4293 	.uleb128	0
      003CC1 03                    4294 	.uleb128	3
      003CC2 00 00 05 DB           4295 	.dw	0,1499
      003CC6 55 41 52 54 31 5F 53  4296 	.ascii "UART1_SendData9"
             65 6E 64 44 61 74 61
             39
      003CD5 00                    4297 	.db	0
      003CD6 00 00 9A FB           4298 	.dw	0,(_UART1_SendData9)
      003CDA 00 00 9B 1C           4299 	.dw	0,(XG$UART1_SendData9$0$0+1)
      003CDE 01                    4300 	.db	1
      003CDF 00 00 2D 08           4301 	.dw	0,(Ldebug_loc_start+328)
      003CE3 04                    4302 	.uleb128	4
      003CE4 02                    4303 	.db	2
      003CE5 91                    4304 	.db	145
      003CE6 02                    4305 	.sleb128	2
      003CE7 44 61 74 61           4306 	.ascii "Data"
      003CEB 00                    4307 	.db	0
      003CEC 00 00 05 34           4308 	.dw	0,1332
      003CF0 00                    4309 	.uleb128	0
      003CF1 02                    4310 	.uleb128	2
      003CF2 55 41 52 54 31 5F 53  4311 	.ascii "UART1_SendBreak"
             65 6E 64 42 72 65 61
             6B
      003D01 00                    4312 	.db	0
      003D02 00 00 9B 1C           4313 	.dw	0,(_UART1_SendBreak)
      003D06 00 00 9B 25           4314 	.dw	0,(XG$UART1_SendBreak$0$0+1)
      003D0A 01                    4315 	.db	1
      003D0B 00 00 2C F4           4316 	.dw	0,(Ldebug_loc_start+308)
      003D0F 03                    4317 	.uleb128	3
      003D10 00 00 06 33           4318 	.dw	0,1587
      003D14 55 41 52 54 31 5F 53  4319 	.ascii "UART1_SetAddress"
             65 74 41 64 64 72 65
             73 73
      003D24 00                    4320 	.db	0
      003D25 00 00 9B 25           4321 	.dw	0,(_UART1_SetAddress)
      003D29 00 00 9B 36           4322 	.dw	0,(XG$UART1_SetAddress$0$0+1)
      003D2D 01                    4323 	.db	1
      003D2E 00 00 2C E0           4324 	.dw	0,(Ldebug_loc_start+288)
      003D32 04                    4325 	.uleb128	4
      003D33 02                    4326 	.db	2
      003D34 91                    4327 	.db	145
      003D35 02                    4328 	.sleb128	2
      003D36 55 41 52 54 31 5F 41  4329 	.ascii "UART1_Address"
             64 64 72 65 73 73
      003D43 00                    4330 	.db	0
      003D44 00 00 01 5D           4331 	.dw	0,349
      003D48 00                    4332 	.uleb128	0
      003D49 03                    4333 	.uleb128	3
      003D4A 00 00 06 71           4334 	.dw	0,1649
      003D4E 55 41 52 54 31 5F 53  4335 	.ascii "UART1_SetGuardTime"
             65 74 47 75 61 72 64
             54 69 6D 65
      003D60 00                    4336 	.db	0
      003D61 00 00 9B 36           4337 	.dw	0,(_UART1_SetGuardTime)
      003D65 00 00 9B 3D           4338 	.dw	0,(XG$UART1_SetGuardTime$0$0+1)
      003D69 01                    4339 	.db	1
      003D6A 00 00 2C CC           4340 	.dw	0,(Ldebug_loc_start+268)
      003D6E 04                    4341 	.uleb128	4
      003D6F 02                    4342 	.db	2
      003D70 91                    4343 	.db	145
      003D71 02                    4344 	.sleb128	2
      003D72 55 41 52 54 31 5F 47  4345 	.ascii "UART1_GuardTime"
             75 61 72 64 54 69 6D
             65
      003D81 00                    4346 	.db	0
      003D82 00 00 01 5D           4347 	.dw	0,349
      003D86 00                    4348 	.uleb128	0
      003D87 03                    4349 	.uleb128	3
      003D88 00 00 06 AF           4350 	.dw	0,1711
      003D8C 55 41 52 54 31 5F 53  4351 	.ascii "UART1_SetPrescaler"
             65 74 50 72 65 73 63
             61 6C 65 72
      003D9E 00                    4352 	.db	0
      003D9F 00 00 9B 3D           4353 	.dw	0,(_UART1_SetPrescaler)
      003DA3 00 00 9B 44           4354 	.dw	0,(XG$UART1_SetPrescaler$0$0+1)
      003DA7 01                    4355 	.db	1
      003DA8 00 00 2C B8           4356 	.dw	0,(Ldebug_loc_start+248)
      003DAC 04                    4357 	.uleb128	4
      003DAD 02                    4358 	.db	2
      003DAE 91                    4359 	.db	145
      003DAF 02                    4360 	.sleb128	2
      003DB0 55 41 52 54 31 5F 50  4361 	.ascii "UART1_Prescaler"
             72 65 73 63 61 6C 65
             72
      003DBF 00                    4362 	.db	0
      003DC0 00 00 01 5D           4363 	.dw	0,349
      003DC4 00                    4364 	.uleb128	0
      003DC5 0A                    4365 	.uleb128	10
      003DC6 00 00 07 4F           4366 	.dw	0,1871
      003DCA 55 41 52 54 31 5F 47  4367 	.ascii "UART1_GetFlagStatus"
             65 74 46 6C 61 67 53
             74 61 74 75 73
      003DDD 00                    4368 	.db	0
      003DDE 00 00 9B 44           4369 	.dw	0,(_UART1_GetFlagStatus)
      003DE2 00 00 9B A4           4370 	.dw	0,(XG$UART1_GetFlagStatus$0$0+1)
      003DE6 01                    4371 	.db	1
      003DE7 00 00 2C 74           4372 	.dw	0,(Ldebug_loc_start+180)
      003DEB 00 00 01 5D           4373 	.dw	0,349
      003DEF 04                    4374 	.uleb128	4
      003DF0 02                    4375 	.db	2
      003DF1 91                    4376 	.db	145
      003DF2 02                    4377 	.sleb128	2
      003DF3 55 41 52 54 31 5F 46  4378 	.ascii "UART1_FLAG"
             4C 41 47
      003DFD 00                    4379 	.db	0
      003DFE 00 00 02 59           4380 	.dw	0,601
      003E02 08                    4381 	.uleb128	8
      003E03 00 00 07 08           4382 	.dw	0,1800
      003E07 00 00 9B 5B           4383 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$329)
      003E0B 05                    4384 	.uleb128	5
      003E0C 00 00 9B 66           4385 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$331)
      003E10 00 00 9B 68           4386 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$333)
      003E14 05                    4387 	.uleb128	5
      003E15 00 00 9B 6B           4388 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$334)
      003E19 00 00 9B 6C           4389 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$336)
      003E1D 00                    4390 	.uleb128	0
      003E1E 08                    4391 	.uleb128	8
      003E1F 00 00 07 24           4392 	.dw	0,1828
      003E23 00 00 9B 7C           4393 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$339)
      003E27 05                    4394 	.uleb128	5
      003E28 00 00 9B 87           4395 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$341)
      003E2C 00 00 9B 89           4396 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$343)
      003E30 05                    4397 	.uleb128	5
      003E31 00 00 9B 8C           4398 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$344)
      003E35 00 00 9B 8D           4399 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$346)
      003E39 00                    4400 	.uleb128	0
      003E3A 08                    4401 	.uleb128	8
      003E3B 00 00 07 40           4402 	.dw	0,1856
      003E3F 00 00 9B 90           4403 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$347)
      003E43 05                    4404 	.uleb128	5
      003E44 00 00 9B 9B           4405 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$349)
      003E48 00 00 9B 9D           4406 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$351)
      003E4C 05                    4407 	.uleb128	5
      003E4D 00 00 9B A0           4408 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$352)
      003E51 00 00 9B A1           4409 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$354)
      003E55 00                    4410 	.uleb128	0
      003E56 06                    4411 	.uleb128	6
      003E57 01                    4412 	.db	1
      003E58 50                    4413 	.db	80
      003E59 73 74 61 74 75 73     4414 	.ascii "status"
      003E5F 00                    4415 	.db	0
      003E60 00 00 01 5D           4416 	.dw	0,349
      003E64 00                    4417 	.uleb128	0
      003E65 03                    4418 	.uleb128	3
      003E66 00 00 07 97           4419 	.dw	0,1943
      003E6A 55 41 52 54 31 5F 43  4420 	.ascii "UART1_ClearFlag"
             6C 65 61 72 46 6C 61
             67
      003E79 00                    4421 	.db	0
      003E7A 00 00 9B A4           4422 	.dw	0,(_UART1_ClearFlag)
      003E7E 00 00 9B C1           4423 	.dw	0,(XG$UART1_ClearFlag$0$0+1)
      003E82 01                    4424 	.db	1
      003E83 00 00 2C 54           4425 	.dw	0,(Ldebug_loc_start+148)
      003E87 04                    4426 	.uleb128	4
      003E88 02                    4427 	.db	2
      003E89 91                    4428 	.db	145
      003E8A 02                    4429 	.sleb128	2
      003E8B 55 41 52 54 31 5F 46  4430 	.ascii "UART1_FLAG"
             4C 41 47
      003E95 00                    4431 	.db	0
      003E96 00 00 02 59           4432 	.dw	0,601
      003E9A 05                    4433 	.uleb128	5
      003E9B 00 00 9B B1           4434 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$364)
      003E9F 00 00 9B B5           4435 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$366)
      003EA3 05                    4436 	.uleb128	5
      003EA4 00 00 9B B8           4437 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$367)
      003EA8 00 00 9B C0           4438 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$369)
      003EAC 00                    4439 	.uleb128	0
      003EAD 0A                    4440 	.uleb128	10
      003EAE 00 00 08 7E           4441 	.dw	0,2174
      003EB2 55 41 52 54 31 5F 47  4442 	.ascii "UART1_GetITStatus"
             65 74 49 54 53 74 61
             74 75 73
      003EC3 00                    4443 	.db	0
      003EC4 00 00 9B C1           4444 	.dw	0,(_UART1_GetITStatus)
      003EC8 00 00 9C 6A           4445 	.dw	0,(XG$UART1_GetITStatus$0$0+1)
      003ECC 01                    4446 	.db	1
      003ECD 00 00 2B E0           4447 	.dw	0,(Ldebug_loc_start+32)
      003ED1 00 00 01 5D           4448 	.dw	0,349
      003ED5 04                    4449 	.uleb128	4
      003ED6 02                    4450 	.db	2
      003ED7 91                    4451 	.db	145
      003ED8 02                    4452 	.sleb128	2
      003ED9 55 41 52 54 31 5F 49  4453 	.ascii "UART1_IT"
             54
      003EE1 00                    4454 	.db	0
      003EE2 00 00 02 59           4455 	.dw	0,601
      003EE6 08                    4456 	.uleb128	8
      003EE7 00 00 07 EC           4457 	.dw	0,2028
      003EEB 00 00 9B FA           4458 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$385)
      003EEF 05                    4459 	.uleb128	5
      003EF0 00 00 9C 12           4460 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$388)
      003EF4 00 00 9C 14           4461 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$390)
      003EF8 05                    4462 	.uleb128	5
      003EF9 00 00 9C 17           4463 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$391)
      003EFD 00 00 9C 18           4464 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$393)
      003F01 00                    4465 	.uleb128	0
      003F02 08                    4466 	.uleb128	8
      003F03 00 00 08 08           4467 	.dw	0,2056
      003F07 00 00 9C 28           4468 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$396)
      003F0B 05                    4469 	.uleb128	5
      003F0C 00 00 9C 40           4470 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$399)
      003F10 00 00 9C 42           4471 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$401)
      003F14 05                    4472 	.uleb128	5
      003F15 00 00 9C 45           4473 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$402)
      003F19 00 00 9C 46           4474 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$404)
      003F1D 00                    4475 	.uleb128	0
      003F1E 08                    4476 	.uleb128	8
      003F1F 00 00 08 24           4477 	.dw	0,2084
      003F23 00 00 9C 49           4478 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$405)
      003F27 05                    4479 	.uleb128	5
      003F28 00 00 9C 61           4480 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$408)
      003F2C 00 00 9C 63           4481 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$410)
      003F30 05                    4482 	.uleb128	5
      003F31 00 00 9C 66           4483 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$411)
      003F35 00 00 9C 67           4484 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$413)
      003F39 00                    4485 	.uleb128	0
      003F3A 06                    4486 	.uleb128	6
      003F3B 01                    4487 	.db	1
      003F3C 50                    4488 	.db	80
      003F3D 70 65 6E 64 69 6E 67  4489 	.ascii "pendingbitstatus"
             62 69 74 73 74 61 74
             75 73
      003F4D 00                    4490 	.db	0
      003F4E 00 00 01 5D           4491 	.dw	0,349
      003F52 06                    4492 	.uleb128	6
      003F53 02                    4493 	.db	2
      003F54 91                    4494 	.db	145
      003F55 7C                    4495 	.sleb128	-4
      003F56 69 74 70 6F 73        4496 	.ascii "itpos"
      003F5B 00                    4497 	.db	0
      003F5C 00 00 01 5D           4498 	.dw	0,349
      003F60 06                    4499 	.uleb128	6
      003F61 01                    4500 	.db	1
      003F62 50                    4501 	.db	80
      003F63 69 74 6D 61 73 6B 31  4502 	.ascii "itmask1"
      003F6A 00                    4503 	.db	0
      003F6B 00 00 01 5D           4504 	.dw	0,349
      003F6F 06                    4505 	.uleb128	6
      003F70 02                    4506 	.db	2
      003F71 91                    4507 	.db	145
      003F72 7D                    4508 	.sleb128	-3
      003F73 69 74 6D 61 73 6B 32  4509 	.ascii "itmask2"
      003F7A 00                    4510 	.db	0
      003F7B 00 00 01 5D           4511 	.dw	0,349
      003F7F 06                    4512 	.uleb128	6
      003F80 01                    4513 	.db	1
      003F81 51                    4514 	.db	81
      003F82 65 6E 61 62 6C 65 73  4515 	.ascii "enablestatus"
             74 61 74 75 73
      003F8E 00                    4516 	.db	0
      003F8F 00 00 01 5D           4517 	.dw	0,349
      003F93 00                    4518 	.uleb128	0
      003F94 0B                    4519 	.uleb128	11
      003F95 55 41 52 54 31 5F 43  4520 	.ascii "UART1_ClearITPendingBit"
             6C 65 61 72 49 54 50
             65 6E 64 69 6E 67 42
             69 74
      003FAC 00                    4521 	.db	0
      003FAD 00 00 9C 6A           4522 	.dw	0,(_UART1_ClearITPendingBit)
      003FB1 00 00 9C 87           4523 	.dw	0,(XG$UART1_ClearITPendingBit$0$0+1)
      003FB5 01                    4524 	.db	1
      003FB6 00 00 2B C0           4525 	.dw	0,(Ldebug_loc_start)
      003FBA 04                    4526 	.uleb128	4
      003FBB 02                    4527 	.db	2
      003FBC 91                    4528 	.db	145
      003FBD 02                    4529 	.sleb128	2
      003FBE 55 41 52 54 31 5F 49  4530 	.ascii "UART1_IT"
             54
      003FC6 00                    4531 	.db	0
      003FC7 00 00 02 59           4532 	.dw	0,601
      003FCB 05                    4533 	.uleb128	5
      003FCC 00 00 9C 77           4534 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$423)
      003FD0 00 00 9C 7B           4535 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$425)
      003FD4 05                    4536 	.uleb128	5
      003FD5 00 00 9C 7E           4537 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$426)
      003FD9 00 00 9C 86           4538 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$428)
      003FDD 00                    4539 	.uleb128	0
      003FDE 00                    4540 	.uleb128	0
      003FDF 00                    4541 	.uleb128	0
      003FE0 00                    4542 	.uleb128	0
      003FE1                       4543 Ldebug_info_end:
                                   4544 
                                   4545 	.area .debug_pubnames (NOLOAD)
      000AF5 00 00 02 31           4546 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      000AF9                       4547 Ldebug_pubnames_start:
      000AF9 00 02                 4548 	.dw	2
      000AFB 00 00 37 16           4549 	.dw	0,(Ldebug_info_start-4)
      000AFF 00 00 08 CB           4550 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      000B03 00 00 00 44           4551 	.dw	0,68
      000B07 55 41 52 54 31 5F 44  4552 	.ascii "UART1_DeInit"
             65 49 6E 69 74
      000B13 00                    4553 	.db	0
      000B14 00 00 00 5F           4554 	.dw	0,95
      000B18 55 41 52 54 31 5F 49  4555 	.ascii "UART1_Init"
             6E 69 74
      000B22 00                    4556 	.db	0
      000B23 00 00 01 6E           4557 	.dw	0,366
      000B27 55 41 52 54 31 5F 43  4558 	.ascii "UART1_Cmd"
             6D 64
      000B30 00                    4559 	.db	0
      000B31 00 00 01 AE           4560 	.dw	0,430
      000B35 55 41 52 54 31 5F 49  4561 	.ascii "UART1_ITConfig"
             54 43 6F 6E 66 69 67
      000B43 00                    4562 	.db	0
      000B44 00 00 02 69           4563 	.dw	0,617
      000B48 55 41 52 54 31 5F 48  4564 	.ascii "UART1_HalfDuplexCmd"
             61 6C 66 44 75 70 6C
             65 78 43 6D 64
      000B5B 00                    4565 	.db	0
      000B5C 00 00 02 B3           4566 	.dw	0,691
      000B60 55 41 52 54 31 5F 49  4567 	.ascii "UART1_IrDAConfig"
             72 44 41 43 6F 6E 66
             69 67
      000B70 00                    4568 	.db	0
      000B71 00 00 03 00           4569 	.dw	0,768
      000B75 55 41 52 54 31 5F 49  4570 	.ascii "UART1_IrDACmd"
             72 44 41 43 6D 64
      000B82 00                    4571 	.db	0
      000B83 00 00 03 44           4572 	.dw	0,836
      000B87 55 41 52 54 31 5F 4C  4573 	.ascii "UART1_LINBreakDetectionConfig"
             49 4E 42 72 65 61 6B
             44 65 74 65 63 74 69
             6F 6E 43 6F 6E 66 69
             67
      000BA4 00                    4574 	.db	0
      000BA5 00 00 03 AD           4575 	.dw	0,941
      000BA9 55 41 52 54 31 5F 4C  4576 	.ascii "UART1_LINCmd"
             49 4E 43 6D 64
      000BB5 00                    4577 	.db	0
      000BB6 00 00 03 F0           4578 	.dw	0,1008
      000BBA 55 41 52 54 31 5F 53  4579 	.ascii "UART1_SmartCardCmd"
             6D 61 72 74 43 61 72
             64 43 6D 64
      000BCC 00                    4580 	.db	0
      000BCD 00 00 04 39           4581 	.dw	0,1081
      000BD1 55 41 52 54 31 5F 53  4582 	.ascii "UART1_SmartCardNACKCmd"
             6D 61 72 74 43 61 72
             64 4E 41 43 4B 43 6D
             64
      000BE7 00                    4583 	.db	0
      000BE8 00 00 04 86           4584 	.dw	0,1158
      000BEC 55 41 52 54 31 5F 57  4585 	.ascii "UART1_WakeUpConfig"
             61 6B 65 55 70 43 6F
             6E 66 69 67
      000BFE 00                    4586 	.db	0
      000BFF 00 00 04 C1           4587 	.dw	0,1217
      000C03 55 41 52 54 31 5F 52  4588 	.ascii "UART1_ReceiverWakeUpCmd"
             65 63 65 69 76 65 72
             57 61 6B 65 55 70 43
             6D 64
      000C1A 00                    4589 	.db	0
      000C1B 00 00 05 0F           4590 	.dw	0,1295
      000C1F 55 41 52 54 31 5F 52  4591 	.ascii "UART1_ReceiveData8"
             65 63 65 69 76 65 44
             61 74 61 38
      000C31 00                    4592 	.db	0
      000C32 00 00 05 44           4593 	.dw	0,1348
      000C36 55 41 52 54 31 5F 52  4594 	.ascii "UART1_ReceiveData9"
             65 63 65 69 76 65 44
             61 74 61 39
      000C48 00                    4595 	.db	0
      000C49 00 00 05 7B           4596 	.dw	0,1403
      000C4D 55 41 52 54 31 5F 53  4597 	.ascii "UART1_SendData8"
             65 6E 64 44 61 74 61
             38
      000C5C 00                    4598 	.db	0
      000C5D 00 00 05 AB           4599 	.dw	0,1451
      000C61 55 41 52 54 31 5F 53  4600 	.ascii "UART1_SendData9"
             65 6E 64 44 61 74 61
             39
      000C70 00                    4601 	.db	0
      000C71 00 00 05 DB           4602 	.dw	0,1499
      000C75 55 41 52 54 31 5F 53  4603 	.ascii "UART1_SendBreak"
             65 6E 64 42 72 65 61
             6B
      000C84 00                    4604 	.db	0
      000C85 00 00 05 F9           4605 	.dw	0,1529
      000C89 55 41 52 54 31 5F 53  4606 	.ascii "UART1_SetAddress"
             65 74 41 64 64 72 65
             73 73
      000C99 00                    4607 	.db	0
      000C9A 00 00 06 33           4608 	.dw	0,1587
      000C9E 55 41 52 54 31 5F 53  4609 	.ascii "UART1_SetGuardTime"
             65 74 47 75 61 72 64
             54 69 6D 65
      000CB0 00                    4610 	.db	0
      000CB1 00 00 06 71           4611 	.dw	0,1649
      000CB5 55 41 52 54 31 5F 53  4612 	.ascii "UART1_SetPrescaler"
             65 74 50 72 65 73 63
             61 6C 65 72
      000CC7 00                    4613 	.db	0
      000CC8 00 00 06 AF           4614 	.dw	0,1711
      000CCC 55 41 52 54 31 5F 47  4615 	.ascii "UART1_GetFlagStatus"
             65 74 46 6C 61 67 53
             74 61 74 75 73
      000CDF 00                    4616 	.db	0
      000CE0 00 00 07 4F           4617 	.dw	0,1871
      000CE4 55 41 52 54 31 5F 43  4618 	.ascii "UART1_ClearFlag"
             6C 65 61 72 46 6C 61
             67
      000CF3 00                    4619 	.db	0
      000CF4 00 00 07 97           4620 	.dw	0,1943
      000CF8 55 41 52 54 31 5F 47  4621 	.ascii "UART1_GetITStatus"
             65 74 49 54 53 74 61
             74 75 73
      000D09 00                    4622 	.db	0
      000D0A 00 00 08 7E           4623 	.dw	0,2174
      000D0E 55 41 52 54 31 5F 43  4624 	.ascii "UART1_ClearITPendingBit"
             6C 65 61 72 49 54 50
             65 6E 64 69 6E 67 42
             69 74
      000D25 00                    4625 	.db	0
      000D26 00 00 00 00           4626 	.dw	0,0
      000D2A                       4627 Ldebug_pubnames_end:
                                   4628 
                                   4629 	.area .debug_frame (NOLOAD)
      002830 00 00                 4630 	.dw	0
      002832 00 0E                 4631 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      002834                       4632 Ldebug_CIE0_start:
      002834 FF FF                 4633 	.dw	0xffff
      002836 FF FF                 4634 	.dw	0xffff
      002838 01                    4635 	.db	1
      002839 00                    4636 	.db	0
      00283A 01                    4637 	.uleb128	1
      00283B 7F                    4638 	.sleb128	-1
      00283C 09                    4639 	.db	9
      00283D 0C                    4640 	.db	12
      00283E 08                    4641 	.uleb128	8
      00283F 02                    4642 	.uleb128	2
      002840 89                    4643 	.db	137
      002841 01                    4644 	.uleb128	1
      002842                       4645 Ldebug_CIE0_end:
      002842 00 00 00 1A           4646 	.dw	0,26
      002846 00 00 28 30           4647 	.dw	0,(Ldebug_CIE0_start-4)
      00284A 00 00 9C 6A           4648 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$420)	;initial loc
      00284E 00 00 00 1D           4649 	.dw	0,Sstm8s_uart1$UART1_ClearITPendingBit$431-Sstm8s_uart1$UART1_ClearITPendingBit$420
      002852 01                    4650 	.db	1
      002853 00 00 9C 6A           4651 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$420)
      002857 0E                    4652 	.db	14
      002858 02                    4653 	.uleb128	2
      002859 01                    4654 	.db	1
      00285A 00 00 9C 77           4655 	.dw	0,(Sstm8s_uart1$UART1_ClearITPendingBit$422)
      00285E 0E                    4656 	.db	14
      00285F 02                    4657 	.uleb128	2
                                   4658 
                                   4659 	.area .debug_frame (NOLOAD)
      002860 00 00                 4660 	.dw	0
      002862 00 0E                 4661 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      002864                       4662 Ldebug_CIE1_start:
      002864 FF FF                 4663 	.dw	0xffff
      002866 FF FF                 4664 	.dw	0xffff
      002868 01                    4665 	.db	1
      002869 00                    4666 	.db	0
      00286A 01                    4667 	.uleb128	1
      00286B 7F                    4668 	.sleb128	-1
      00286C 09                    4669 	.db	9
      00286D 0C                    4670 	.db	12
      00286E 08                    4671 	.uleb128	8
      00286F 02                    4672 	.uleb128	2
      002870 89                    4673 	.db	137
      002871 01                    4674 	.uleb128	1
      002872                       4675 Ldebug_CIE1_end:
      002872 00 00 00 4B           4676 	.dw	0,75
      002876 00 00 28 60           4677 	.dw	0,(Ldebug_CIE1_start-4)
      00287A 00 00 9B C1           4678 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$374)	;initial loc
      00287E 00 00 00 A9           4679 	.dw	0,Sstm8s_uart1$UART1_GetITStatus$418-Sstm8s_uart1$UART1_GetITStatus$374
      002882 01                    4680 	.db	1
      002883 00 00 9B C1           4681 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$374)
      002887 0E                    4682 	.db	14
      002888 02                    4683 	.uleb128	2
      002889 01                    4684 	.db	1
      00288A 00 00 9B C3           4685 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$375)
      00288E 0E                    4686 	.db	14
      00288F 06                    4687 	.uleb128	6
      002890 01                    4688 	.db	1
      002891 00 00 9B CA           4689 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$377)
      002895 0E                    4690 	.db	14
      002896 07                    4691 	.uleb128	7
      002897 01                    4692 	.db	1
      002898 00 00 9B CF           4693 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$378)
      00289C 0E                    4694 	.db	14
      00289D 06                    4695 	.uleb128	6
      00289E 01                    4696 	.db	1
      00289F 00 00 9B DC           4697 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$381)
      0028A3 0E                    4698 	.db	14
      0028A4 07                    4699 	.uleb128	7
      0028A5 01                    4700 	.db	1
      0028A6 00 00 9B E1           4701 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$382)
      0028AA 0E                    4702 	.db	14
      0028AB 06                    4703 	.uleb128	6
      0028AC 01                    4704 	.db	1
      0028AD 00 00 9B FA           4705 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$384)
      0028B1 0E                    4706 	.db	14
      0028B2 06                    4707 	.uleb128	6
      0028B3 01                    4708 	.db	1
      0028B4 00 00 9C 28           4709 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$395)
      0028B8 0E                    4710 	.db	14
      0028B9 06                    4711 	.uleb128	6
      0028BA 01                    4712 	.db	1
      0028BB 00 00 9C 69           4713 	.dw	0,(Sstm8s_uart1$UART1_GetITStatus$416)
      0028BF 0E                    4714 	.db	14
      0028C0 02                    4715 	.uleb128	2
                                   4716 
                                   4717 	.area .debug_frame (NOLOAD)
      0028C1 00 00                 4718 	.dw	0
      0028C3 00 0E                 4719 	.dw	Ldebug_CIE2_end-Ldebug_CIE2_start
      0028C5                       4720 Ldebug_CIE2_start:
      0028C5 FF FF                 4721 	.dw	0xffff
      0028C7 FF FF                 4722 	.dw	0xffff
      0028C9 01                    4723 	.db	1
      0028CA 00                    4724 	.db	0
      0028CB 01                    4725 	.uleb128	1
      0028CC 7F                    4726 	.sleb128	-1
      0028CD 09                    4727 	.db	9
      0028CE 0C                    4728 	.db	12
      0028CF 08                    4729 	.uleb128	8
      0028D0 02                    4730 	.uleb128	2
      0028D1 89                    4731 	.db	137
      0028D2 01                    4732 	.uleb128	1
      0028D3                       4733 Ldebug_CIE2_end:
      0028D3 00 00 00 1A           4734 	.dw	0,26
      0028D7 00 00 28 C1           4735 	.dw	0,(Ldebug_CIE2_start-4)
      0028DB 00 00 9B A4           4736 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$361)	;initial loc
      0028DF 00 00 00 1D           4737 	.dw	0,Sstm8s_uart1$UART1_ClearFlag$372-Sstm8s_uart1$UART1_ClearFlag$361
      0028E3 01                    4738 	.db	1
      0028E4 00 00 9B A4           4739 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$361)
      0028E8 0E                    4740 	.db	14
      0028E9 02                    4741 	.uleb128	2
      0028EA 01                    4742 	.db	1
      0028EB 00 00 9B B1           4743 	.dw	0,(Sstm8s_uart1$UART1_ClearFlag$363)
      0028EF 0E                    4744 	.db	14
      0028F0 02                    4745 	.uleb128	2
                                   4746 
                                   4747 	.area .debug_frame (NOLOAD)
      0028F1 00 00                 4748 	.dw	0
      0028F3 00 0E                 4749 	.dw	Ldebug_CIE3_end-Ldebug_CIE3_start
      0028F5                       4750 Ldebug_CIE3_start:
      0028F5 FF FF                 4751 	.dw	0xffff
      0028F7 FF FF                 4752 	.dw	0xffff
      0028F9 01                    4753 	.db	1
      0028FA 00                    4754 	.db	0
      0028FB 01                    4755 	.uleb128	1
      0028FC 7F                    4756 	.sleb128	-1
      0028FD 09                    4757 	.db	9
      0028FE 0C                    4758 	.db	12
      0028FF 08                    4759 	.uleb128	8
      002900 02                    4760 	.uleb128	2
      002901 89                    4761 	.db	137
      002902 01                    4762 	.uleb128	1
      002903                       4763 Ldebug_CIE3_end:
      002903 00 00 00 2F           4764 	.dw	0,47
      002907 00 00 28 F1           4765 	.dw	0,(Ldebug_CIE3_start-4)
      00290B 00 00 9B 44           4766 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$323)	;initial loc
      00290F 00 00 00 60           4767 	.dw	0,Sstm8s_uart1$UART1_GetFlagStatus$359-Sstm8s_uart1$UART1_GetFlagStatus$323
      002913 01                    4768 	.db	1
      002914 00 00 9B 44           4769 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$323)
      002918 0E                    4770 	.db	14
      002919 02                    4771 	.uleb128	2
      00291A 01                    4772 	.db	1
      00291B 00 00 9B 46           4773 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$324)
      00291F 0E                    4774 	.db	14
      002920 05                    4775 	.uleb128	5
      002921 01                    4776 	.db	1
      002922 00 00 9B 5B           4777 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$328)
      002926 0E                    4778 	.db	14
      002927 05                    4779 	.uleb128	5
      002928 01                    4780 	.db	1
      002929 00 00 9B 7C           4781 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$338)
      00292D 0E                    4782 	.db	14
      00292E 05                    4783 	.uleb128	5
      00292F 01                    4784 	.db	1
      002930 00 00 9B A3           4785 	.dw	0,(Sstm8s_uart1$UART1_GetFlagStatus$357)
      002934 0E                    4786 	.db	14
      002935 02                    4787 	.uleb128	2
                                   4788 
                                   4789 	.area .debug_frame (NOLOAD)
      002936 00 00                 4790 	.dw	0
      002938 00 0E                 4791 	.dw	Ldebug_CIE4_end-Ldebug_CIE4_start
      00293A                       4792 Ldebug_CIE4_start:
      00293A FF FF                 4793 	.dw	0xffff
      00293C FF FF                 4794 	.dw	0xffff
      00293E 01                    4795 	.db	1
      00293F 00                    4796 	.db	0
      002940 01                    4797 	.uleb128	1
      002941 7F                    4798 	.sleb128	-1
      002942 09                    4799 	.db	9
      002943 0C                    4800 	.db	12
      002944 08                    4801 	.uleb128	8
      002945 02                    4802 	.uleb128	2
      002946 89                    4803 	.db	137
      002947 01                    4804 	.uleb128	1
      002948                       4805 Ldebug_CIE4_end:
      002948 00 00 00 13           4806 	.dw	0,19
      00294C 00 00 29 36           4807 	.dw	0,(Ldebug_CIE4_start-4)
      002950 00 00 9B 3D           4808 	.dw	0,(Sstm8s_uart1$UART1_SetPrescaler$317)	;initial loc
      002954 00 00 00 07           4809 	.dw	0,Sstm8s_uart1$UART1_SetPrescaler$321-Sstm8s_uart1$UART1_SetPrescaler$317
      002958 01                    4810 	.db	1
      002959 00 00 9B 3D           4811 	.dw	0,(Sstm8s_uart1$UART1_SetPrescaler$317)
      00295D 0E                    4812 	.db	14
      00295E 02                    4813 	.uleb128	2
                                   4814 
                                   4815 	.area .debug_frame (NOLOAD)
      00295F 00 00                 4816 	.dw	0
      002961 00 0E                 4817 	.dw	Ldebug_CIE5_end-Ldebug_CIE5_start
      002963                       4818 Ldebug_CIE5_start:
      002963 FF FF                 4819 	.dw	0xffff
      002965 FF FF                 4820 	.dw	0xffff
      002967 01                    4821 	.db	1
      002968 00                    4822 	.db	0
      002969 01                    4823 	.uleb128	1
      00296A 7F                    4824 	.sleb128	-1
      00296B 09                    4825 	.db	9
      00296C 0C                    4826 	.db	12
      00296D 08                    4827 	.uleb128	8
      00296E 02                    4828 	.uleb128	2
      00296F 89                    4829 	.db	137
      002970 01                    4830 	.uleb128	1
      002971                       4831 Ldebug_CIE5_end:
      002971 00 00 00 13           4832 	.dw	0,19
      002975 00 00 29 5F           4833 	.dw	0,(Ldebug_CIE5_start-4)
      002979 00 00 9B 36           4834 	.dw	0,(Sstm8s_uart1$UART1_SetGuardTime$311)	;initial loc
      00297D 00 00 00 07           4835 	.dw	0,Sstm8s_uart1$UART1_SetGuardTime$315-Sstm8s_uart1$UART1_SetGuardTime$311
      002981 01                    4836 	.db	1
      002982 00 00 9B 36           4837 	.dw	0,(Sstm8s_uart1$UART1_SetGuardTime$311)
      002986 0E                    4838 	.db	14
      002987 02                    4839 	.uleb128	2
                                   4840 
                                   4841 	.area .debug_frame (NOLOAD)
      002988 00 00                 4842 	.dw	0
      00298A 00 0E                 4843 	.dw	Ldebug_CIE6_end-Ldebug_CIE6_start
      00298C                       4844 Ldebug_CIE6_start:
      00298C FF FF                 4845 	.dw	0xffff
      00298E FF FF                 4846 	.dw	0xffff
      002990 01                    4847 	.db	1
      002991 00                    4848 	.db	0
      002992 01                    4849 	.uleb128	1
      002993 7F                    4850 	.sleb128	-1
      002994 09                    4851 	.db	9
      002995 0C                    4852 	.db	12
      002996 08                    4853 	.uleb128	8
      002997 02                    4854 	.uleb128	2
      002998 89                    4855 	.db	137
      002999 01                    4856 	.uleb128	1
      00299A                       4857 Ldebug_CIE6_end:
      00299A 00 00 00 13           4858 	.dw	0,19
      00299E 00 00 29 88           4859 	.dw	0,(Ldebug_CIE6_start-4)
      0029A2 00 00 9B 25           4860 	.dw	0,(Sstm8s_uart1$UART1_SetAddress$304)	;initial loc
      0029A6 00 00 00 11           4861 	.dw	0,Sstm8s_uart1$UART1_SetAddress$309-Sstm8s_uart1$UART1_SetAddress$304
      0029AA 01                    4862 	.db	1
      0029AB 00 00 9B 25           4863 	.dw	0,(Sstm8s_uart1$UART1_SetAddress$304)
      0029AF 0E                    4864 	.db	14
      0029B0 02                    4865 	.uleb128	2
                                   4866 
                                   4867 	.area .debug_frame (NOLOAD)
      0029B1 00 00                 4868 	.dw	0
      0029B3 00 0E                 4869 	.dw	Ldebug_CIE7_end-Ldebug_CIE7_start
      0029B5                       4870 Ldebug_CIE7_start:
      0029B5 FF FF                 4871 	.dw	0xffff
      0029B7 FF FF                 4872 	.dw	0xffff
      0029B9 01                    4873 	.db	1
      0029BA 00                    4874 	.db	0
      0029BB 01                    4875 	.uleb128	1
      0029BC 7F                    4876 	.sleb128	-1
      0029BD 09                    4877 	.db	9
      0029BE 0C                    4878 	.db	12
      0029BF 08                    4879 	.uleb128	8
      0029C0 02                    4880 	.uleb128	2
      0029C1 89                    4881 	.db	137
      0029C2 01                    4882 	.uleb128	1
      0029C3                       4883 Ldebug_CIE7_end:
      0029C3 00 00 00 13           4884 	.dw	0,19
      0029C7 00 00 29 B1           4885 	.dw	0,(Ldebug_CIE7_start-4)
      0029CB 00 00 9B 1C           4886 	.dw	0,(Sstm8s_uart1$UART1_SendBreak$298)	;initial loc
      0029CF 00 00 00 09           4887 	.dw	0,Sstm8s_uart1$UART1_SendBreak$302-Sstm8s_uart1$UART1_SendBreak$298
      0029D3 01                    4888 	.db	1
      0029D4 00 00 9B 1C           4889 	.dw	0,(Sstm8s_uart1$UART1_SendBreak$298)
      0029D8 0E                    4890 	.db	14
      0029D9 02                    4891 	.uleb128	2
                                   4892 
                                   4893 	.area .debug_frame (NOLOAD)
      0029DA 00 00                 4894 	.dw	0
      0029DC 00 0E                 4895 	.dw	Ldebug_CIE8_end-Ldebug_CIE8_start
      0029DE                       4896 Ldebug_CIE8_start:
      0029DE FF FF                 4897 	.dw	0xffff
      0029E0 FF FF                 4898 	.dw	0xffff
      0029E2 01                    4899 	.db	1
      0029E3 00                    4900 	.db	0
      0029E4 01                    4901 	.uleb128	1
      0029E5 7F                    4902 	.sleb128	-1
      0029E6 09                    4903 	.db	9
      0029E7 0C                    4904 	.db	12
      0029E8 08                    4905 	.uleb128	8
      0029E9 02                    4906 	.uleb128	2
      0029EA 89                    4907 	.db	137
      0029EB 01                    4908 	.uleb128	1
      0029EC                       4909 Ldebug_CIE8_end:
      0029EC 00 00 00 21           4910 	.dw	0,33
      0029F0 00 00 29 DA           4911 	.dw	0,(Ldebug_CIE8_start-4)
      0029F4 00 00 9A FB           4912 	.dw	0,(Sstm8s_uart1$UART1_SendData9$288)	;initial loc
      0029F8 00 00 00 21           4913 	.dw	0,Sstm8s_uart1$UART1_SendData9$296-Sstm8s_uart1$UART1_SendData9$288
      0029FC 01                    4914 	.db	1
      0029FD 00 00 9A FB           4915 	.dw	0,(Sstm8s_uart1$UART1_SendData9$288)
      002A01 0E                    4916 	.db	14
      002A02 02                    4917 	.uleb128	2
      002A03 01                    4918 	.db	1
      002A04 00 00 9A FC           4919 	.dw	0,(Sstm8s_uart1$UART1_SendData9$289)
      002A08 0E                    4920 	.db	14
      002A09 03                    4921 	.uleb128	3
      002A0A 01                    4922 	.db	1
      002A0B 00 00 9B 1B           4923 	.dw	0,(Sstm8s_uart1$UART1_SendData9$294)
      002A0F 0E                    4924 	.db	14
      002A10 02                    4925 	.uleb128	2
                                   4926 
                                   4927 	.area .debug_frame (NOLOAD)
      002A11 00 00                 4928 	.dw	0
      002A13 00 0E                 4929 	.dw	Ldebug_CIE9_end-Ldebug_CIE9_start
      002A15                       4930 Ldebug_CIE9_start:
      002A15 FF FF                 4931 	.dw	0xffff
      002A17 FF FF                 4932 	.dw	0xffff
      002A19 01                    4933 	.db	1
      002A1A 00                    4934 	.db	0
      002A1B 01                    4935 	.uleb128	1
      002A1C 7F                    4936 	.sleb128	-1
      002A1D 09                    4937 	.db	9
      002A1E 0C                    4938 	.db	12
      002A1F 08                    4939 	.uleb128	8
      002A20 02                    4940 	.uleb128	2
      002A21 89                    4941 	.db	137
      002A22 01                    4942 	.uleb128	1
      002A23                       4943 Ldebug_CIE9_end:
      002A23 00 00 00 13           4944 	.dw	0,19
      002A27 00 00 2A 11           4945 	.dw	0,(Ldebug_CIE9_start-4)
      002A2B 00 00 9A F4           4946 	.dw	0,(Sstm8s_uart1$UART1_SendData8$282)	;initial loc
      002A2F 00 00 00 07           4947 	.dw	0,Sstm8s_uart1$UART1_SendData8$286-Sstm8s_uart1$UART1_SendData8$282
      002A33 01                    4948 	.db	1
      002A34 00 00 9A F4           4949 	.dw	0,(Sstm8s_uart1$UART1_SendData8$282)
      002A38 0E                    4950 	.db	14
      002A39 02                    4951 	.uleb128	2
                                   4952 
                                   4953 	.area .debug_frame (NOLOAD)
      002A3A 00 00                 4954 	.dw	0
      002A3C 00 0E                 4955 	.dw	Ldebug_CIE10_end-Ldebug_CIE10_start
      002A3E                       4956 Ldebug_CIE10_start:
      002A3E FF FF                 4957 	.dw	0xffff
      002A40 FF FF                 4958 	.dw	0xffff
      002A42 01                    4959 	.db	1
      002A43 00                    4960 	.db	0
      002A44 01                    4961 	.uleb128	1
      002A45 7F                    4962 	.sleb128	-1
      002A46 09                    4963 	.db	9
      002A47 0C                    4964 	.db	12
      002A48 08                    4965 	.uleb128	8
      002A49 02                    4966 	.uleb128	2
      002A4A 89                    4967 	.db	137
      002A4B 01                    4968 	.uleb128	1
      002A4C                       4969 Ldebug_CIE10_end:
      002A4C 00 00 00 21           4970 	.dw	0,33
      002A50 00 00 2A 3A           4971 	.dw	0,(Ldebug_CIE10_start-4)
      002A54 00 00 9A D7           4972 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$273)	;initial loc
      002A58 00 00 00 1D           4973 	.dw	0,Sstm8s_uart1$UART1_ReceiveData9$280-Sstm8s_uart1$UART1_ReceiveData9$273
      002A5C 01                    4974 	.db	1
      002A5D 00 00 9A D7           4975 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$273)
      002A61 0E                    4976 	.db	14
      002A62 02                    4977 	.uleb128	2
      002A63 01                    4978 	.db	1
      002A64 00 00 9A D8           4979 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$274)
      002A68 0E                    4980 	.db	14
      002A69 04                    4981 	.uleb128	4
      002A6A 01                    4982 	.db	1
      002A6B 00 00 9A F3           4983 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData9$278)
      002A6F 0E                    4984 	.db	14
      002A70 02                    4985 	.uleb128	2
                                   4986 
                                   4987 	.area .debug_frame (NOLOAD)
      002A71 00 00                 4988 	.dw	0
      002A73 00 0E                 4989 	.dw	Ldebug_CIE11_end-Ldebug_CIE11_start
      002A75                       4990 Ldebug_CIE11_start:
      002A75 FF FF                 4991 	.dw	0xffff
      002A77 FF FF                 4992 	.dw	0xffff
      002A79 01                    4993 	.db	1
      002A7A 00                    4994 	.db	0
      002A7B 01                    4995 	.uleb128	1
      002A7C 7F                    4996 	.sleb128	-1
      002A7D 09                    4997 	.db	9
      002A7E 0C                    4998 	.db	12
      002A7F 08                    4999 	.uleb128	8
      002A80 02                    5000 	.uleb128	2
      002A81 89                    5001 	.db	137
      002A82 01                    5002 	.uleb128	1
      002A83                       5003 Ldebug_CIE11_end:
      002A83 00 00 00 13           5004 	.dw	0,19
      002A87 00 00 2A 71           5005 	.dw	0,(Ldebug_CIE11_start-4)
      002A8B 00 00 9A D3           5006 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData8$267)	;initial loc
      002A8F 00 00 00 04           5007 	.dw	0,Sstm8s_uart1$UART1_ReceiveData8$271-Sstm8s_uart1$UART1_ReceiveData8$267
      002A93 01                    5008 	.db	1
      002A94 00 00 9A D3           5009 	.dw	0,(Sstm8s_uart1$UART1_ReceiveData8$267)
      002A98 0E                    5010 	.db	14
      002A99 02                    5011 	.uleb128	2
                                   5012 
                                   5013 	.area .debug_frame (NOLOAD)
      002A9A 00 00                 5014 	.dw	0
      002A9C 00 0E                 5015 	.dw	Ldebug_CIE12_end-Ldebug_CIE12_start
      002A9E                       5016 Ldebug_CIE12_start:
      002A9E FF FF                 5017 	.dw	0xffff
      002AA0 FF FF                 5018 	.dw	0xffff
      002AA2 01                    5019 	.db	1
      002AA3 00                    5020 	.db	0
      002AA4 01                    5021 	.uleb128	1
      002AA5 7F                    5022 	.sleb128	-1
      002AA6 09                    5023 	.db	9
      002AA7 0C                    5024 	.db	12
      002AA8 08                    5025 	.uleb128	8
      002AA9 02                    5026 	.uleb128	2
      002AAA 89                    5027 	.db	137
      002AAB 01                    5028 	.uleb128	1
      002AAC                       5029 Ldebug_CIE12_end:
      002AAC 00 00 00 13           5030 	.dw	0,19
      002AB0 00 00 2A 9A           5031 	.dw	0,(Ldebug_CIE12_start-4)
      002AB4 00 00 9A BB           5032 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$254)	;initial loc
      002AB8 00 00 00 18           5033 	.dw	0,Sstm8s_uart1$UART1_ReceiverWakeUpCmd$265-Sstm8s_uart1$UART1_ReceiverWakeUpCmd$254
      002ABC 01                    5034 	.db	1
      002ABD 00 00 9A BB           5035 	.dw	0,(Sstm8s_uart1$UART1_ReceiverWakeUpCmd$254)
      002AC1 0E                    5036 	.db	14
      002AC2 02                    5037 	.uleb128	2
                                   5038 
                                   5039 	.area .debug_frame (NOLOAD)
      002AC3 00 00                 5040 	.dw	0
      002AC5 00 0E                 5041 	.dw	Ldebug_CIE13_end-Ldebug_CIE13_start
      002AC7                       5042 Ldebug_CIE13_start:
      002AC7 FF FF                 5043 	.dw	0xffff
      002AC9 FF FF                 5044 	.dw	0xffff
      002ACB 01                    5045 	.db	1
      002ACC 00                    5046 	.db	0
      002ACD 01                    5047 	.uleb128	1
      002ACE 7F                    5048 	.sleb128	-1
      002ACF 09                    5049 	.db	9
      002AD0 0C                    5050 	.db	12
      002AD1 08                    5051 	.uleb128	8
      002AD2 02                    5052 	.uleb128	2
      002AD3 89                    5053 	.db	137
      002AD4 01                    5054 	.uleb128	1
      002AD5                       5055 Ldebug_CIE13_end:
      002AD5 00 00 00 13           5056 	.dw	0,19
      002AD9 00 00 2A C3           5057 	.dw	0,(Ldebug_CIE13_start-4)
      002ADD 00 00 9A AA           5058 	.dw	0,(Sstm8s_uart1$UART1_WakeUpConfig$247)	;initial loc
      002AE1 00 00 00 11           5059 	.dw	0,Sstm8s_uart1$UART1_WakeUpConfig$252-Sstm8s_uart1$UART1_WakeUpConfig$247
      002AE5 01                    5060 	.db	1
      002AE6 00 00 9A AA           5061 	.dw	0,(Sstm8s_uart1$UART1_WakeUpConfig$247)
      002AEA 0E                    5062 	.db	14
      002AEB 02                    5063 	.uleb128	2
                                   5064 
                                   5065 	.area .debug_frame (NOLOAD)
      002AEC 00 00                 5066 	.dw	0
      002AEE 00 0E                 5067 	.dw	Ldebug_CIE14_end-Ldebug_CIE14_start
      002AF0                       5068 Ldebug_CIE14_start:
      002AF0 FF FF                 5069 	.dw	0xffff
      002AF2 FF FF                 5070 	.dw	0xffff
      002AF4 01                    5071 	.db	1
      002AF5 00                    5072 	.db	0
      002AF6 01                    5073 	.uleb128	1
      002AF7 7F                    5074 	.sleb128	-1
      002AF8 09                    5075 	.db	9
      002AF9 0C                    5076 	.db	12
      002AFA 08                    5077 	.uleb128	8
      002AFB 02                    5078 	.uleb128	2
      002AFC 89                    5079 	.db	137
      002AFD 01                    5080 	.uleb128	1
      002AFE                       5081 Ldebug_CIE14_end:
      002AFE 00 00 00 13           5082 	.dw	0,19
      002B02 00 00 2A EC           5083 	.dw	0,(Ldebug_CIE14_start-4)
      002B06 00 00 9A 92           5084 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$234)	;initial loc
      002B0A 00 00 00 18           5085 	.dw	0,Sstm8s_uart1$UART1_SmartCardNACKCmd$245-Sstm8s_uart1$UART1_SmartCardNACKCmd$234
      002B0E 01                    5086 	.db	1
      002B0F 00 00 9A 92           5087 	.dw	0,(Sstm8s_uart1$UART1_SmartCardNACKCmd$234)
      002B13 0E                    5088 	.db	14
      002B14 02                    5089 	.uleb128	2
                                   5090 
                                   5091 	.area .debug_frame (NOLOAD)
      002B15 00 00                 5092 	.dw	0
      002B17 00 0E                 5093 	.dw	Ldebug_CIE15_end-Ldebug_CIE15_start
      002B19                       5094 Ldebug_CIE15_start:
      002B19 FF FF                 5095 	.dw	0xffff
      002B1B FF FF                 5096 	.dw	0xffff
      002B1D 01                    5097 	.db	1
      002B1E 00                    5098 	.db	0
      002B1F 01                    5099 	.uleb128	1
      002B20 7F                    5100 	.sleb128	-1
      002B21 09                    5101 	.db	9
      002B22 0C                    5102 	.db	12
      002B23 08                    5103 	.uleb128	8
      002B24 02                    5104 	.uleb128	2
      002B25 89                    5105 	.db	137
      002B26 01                    5106 	.uleb128	1
      002B27                       5107 Ldebug_CIE15_end:
      002B27 00 00 00 13           5108 	.dw	0,19
      002B2B 00 00 2B 15           5109 	.dw	0,(Ldebug_CIE15_start-4)
      002B2F 00 00 9A 7A           5110 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$221)	;initial loc
      002B33 00 00 00 18           5111 	.dw	0,Sstm8s_uart1$UART1_SmartCardCmd$232-Sstm8s_uart1$UART1_SmartCardCmd$221
      002B37 01                    5112 	.db	1
      002B38 00 00 9A 7A           5113 	.dw	0,(Sstm8s_uart1$UART1_SmartCardCmd$221)
      002B3C 0E                    5114 	.db	14
      002B3D 02                    5115 	.uleb128	2
                                   5116 
                                   5117 	.area .debug_frame (NOLOAD)
      002B3E 00 00                 5118 	.dw	0
      002B40 00 0E                 5119 	.dw	Ldebug_CIE16_end-Ldebug_CIE16_start
      002B42                       5120 Ldebug_CIE16_start:
      002B42 FF FF                 5121 	.dw	0xffff
      002B44 FF FF                 5122 	.dw	0xffff
      002B46 01                    5123 	.db	1
      002B47 00                    5124 	.db	0
      002B48 01                    5125 	.uleb128	1
      002B49 7F                    5126 	.sleb128	-1
      002B4A 09                    5127 	.db	9
      002B4B 0C                    5128 	.db	12
      002B4C 08                    5129 	.uleb128	8
      002B4D 02                    5130 	.uleb128	2
      002B4E 89                    5131 	.db	137
      002B4F 01                    5132 	.uleb128	1
      002B50                       5133 Ldebug_CIE16_end:
      002B50 00 00 00 13           5134 	.dw	0,19
      002B54 00 00 2B 3E           5135 	.dw	0,(Ldebug_CIE16_start-4)
      002B58 00 00 9A 62           5136 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$208)	;initial loc
      002B5C 00 00 00 18           5137 	.dw	0,Sstm8s_uart1$UART1_LINCmd$219-Sstm8s_uart1$UART1_LINCmd$208
      002B60 01                    5138 	.db	1
      002B61 00 00 9A 62           5139 	.dw	0,(Sstm8s_uart1$UART1_LINCmd$208)
      002B65 0E                    5140 	.db	14
      002B66 02                    5141 	.uleb128	2
                                   5142 
                                   5143 	.area .debug_frame (NOLOAD)
      002B67 00 00                 5144 	.dw	0
      002B69 00 0E                 5145 	.dw	Ldebug_CIE17_end-Ldebug_CIE17_start
      002B6B                       5146 Ldebug_CIE17_start:
      002B6B FF FF                 5147 	.dw	0xffff
      002B6D FF FF                 5148 	.dw	0xffff
      002B6F 01                    5149 	.db	1
      002B70 00                    5150 	.db	0
      002B71 01                    5151 	.uleb128	1
      002B72 7F                    5152 	.sleb128	-1
      002B73 09                    5153 	.db	9
      002B74 0C                    5154 	.db	12
      002B75 08                    5155 	.uleb128	8
      002B76 02                    5156 	.uleb128	2
      002B77 89                    5157 	.db	137
      002B78 01                    5158 	.uleb128	1
      002B79                       5159 Ldebug_CIE17_end:
      002B79 00 00 00 13           5160 	.dw	0,19
      002B7D 00 00 2B 67           5161 	.dw	0,(Ldebug_CIE17_start-4)
      002B81 00 00 9A 4A           5162 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$195)	;initial loc
      002B85 00 00 00 18           5163 	.dw	0,Sstm8s_uart1$UART1_LINBreakDetectionConfig$206-Sstm8s_uart1$UART1_LINBreakDetectionConfig$195
      002B89 01                    5164 	.db	1
      002B8A 00 00 9A 4A           5165 	.dw	0,(Sstm8s_uart1$UART1_LINBreakDetectionConfig$195)
      002B8E 0E                    5166 	.db	14
      002B8F 02                    5167 	.uleb128	2
                                   5168 
                                   5169 	.area .debug_frame (NOLOAD)
      002B90 00 00                 5170 	.dw	0
      002B92 00 0E                 5171 	.dw	Ldebug_CIE18_end-Ldebug_CIE18_start
      002B94                       5172 Ldebug_CIE18_start:
      002B94 FF FF                 5173 	.dw	0xffff
      002B96 FF FF                 5174 	.dw	0xffff
      002B98 01                    5175 	.db	1
      002B99 00                    5176 	.db	0
      002B9A 01                    5177 	.uleb128	1
      002B9B 7F                    5178 	.sleb128	-1
      002B9C 09                    5179 	.db	9
      002B9D 0C                    5180 	.db	12
      002B9E 08                    5181 	.uleb128	8
      002B9F 02                    5182 	.uleb128	2
      002BA0 89                    5183 	.db	137
      002BA1 01                    5184 	.uleb128	1
      002BA2                       5185 Ldebug_CIE18_end:
      002BA2 00 00 00 13           5186 	.dw	0,19
      002BA6 00 00 2B 90           5187 	.dw	0,(Ldebug_CIE18_start-4)
      002BAA 00 00 9A 32           5188 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$182)	;initial loc
      002BAE 00 00 00 18           5189 	.dw	0,Sstm8s_uart1$UART1_IrDACmd$193-Sstm8s_uart1$UART1_IrDACmd$182
      002BB2 01                    5190 	.db	1
      002BB3 00 00 9A 32           5191 	.dw	0,(Sstm8s_uart1$UART1_IrDACmd$182)
      002BB7 0E                    5192 	.db	14
      002BB8 02                    5193 	.uleb128	2
                                   5194 
                                   5195 	.area .debug_frame (NOLOAD)
      002BB9 00 00                 5196 	.dw	0
      002BBB 00 0E                 5197 	.dw	Ldebug_CIE19_end-Ldebug_CIE19_start
      002BBD                       5198 Ldebug_CIE19_start:
      002BBD FF FF                 5199 	.dw	0xffff
      002BBF FF FF                 5200 	.dw	0xffff
      002BC1 01                    5201 	.db	1
      002BC2 00                    5202 	.db	0
      002BC3 01                    5203 	.uleb128	1
      002BC4 7F                    5204 	.sleb128	-1
      002BC5 09                    5205 	.db	9
      002BC6 0C                    5206 	.db	12
      002BC7 08                    5207 	.uleb128	8
      002BC8 02                    5208 	.uleb128	2
      002BC9 89                    5209 	.db	137
      002BCA 01                    5210 	.uleb128	1
      002BCB                       5211 Ldebug_CIE19_end:
      002BCB 00 00 00 13           5212 	.dw	0,19
      002BCF 00 00 2B B9           5213 	.dw	0,(Ldebug_CIE19_start-4)
      002BD3 00 00 9A 1A           5214 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$169)	;initial loc
      002BD7 00 00 00 18           5215 	.dw	0,Sstm8s_uart1$UART1_IrDAConfig$180-Sstm8s_uart1$UART1_IrDAConfig$169
      002BDB 01                    5216 	.db	1
      002BDC 00 00 9A 1A           5217 	.dw	0,(Sstm8s_uart1$UART1_IrDAConfig$169)
      002BE0 0E                    5218 	.db	14
      002BE1 02                    5219 	.uleb128	2
                                   5220 
                                   5221 	.area .debug_frame (NOLOAD)
      002BE2 00 00                 5222 	.dw	0
      002BE4 00 0E                 5223 	.dw	Ldebug_CIE20_end-Ldebug_CIE20_start
      002BE6                       5224 Ldebug_CIE20_start:
      002BE6 FF FF                 5225 	.dw	0xffff
      002BE8 FF FF                 5226 	.dw	0xffff
      002BEA 01                    5227 	.db	1
      002BEB 00                    5228 	.db	0
      002BEC 01                    5229 	.uleb128	1
      002BED 7F                    5230 	.sleb128	-1
      002BEE 09                    5231 	.db	9
      002BEF 0C                    5232 	.db	12
      002BF0 08                    5233 	.uleb128	8
      002BF1 02                    5234 	.uleb128	2
      002BF2 89                    5235 	.db	137
      002BF3 01                    5236 	.uleb128	1
      002BF4                       5237 Ldebug_CIE20_end:
      002BF4 00 00 00 13           5238 	.dw	0,19
      002BF8 00 00 2B E2           5239 	.dw	0,(Ldebug_CIE20_start-4)
      002BFC 00 00 9A 02           5240 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$156)	;initial loc
      002C00 00 00 00 18           5241 	.dw	0,Sstm8s_uart1$UART1_HalfDuplexCmd$167-Sstm8s_uart1$UART1_HalfDuplexCmd$156
      002C04 01                    5242 	.db	1
      002C05 00 00 9A 02           5243 	.dw	0,(Sstm8s_uart1$UART1_HalfDuplexCmd$156)
      002C09 0E                    5244 	.db	14
      002C0A 02                    5245 	.uleb128	2
                                   5246 
                                   5247 	.area .debug_frame (NOLOAD)
      002C0B 00 00                 5248 	.dw	0
      002C0D 00 0E                 5249 	.dw	Ldebug_CIE21_end-Ldebug_CIE21_start
      002C0F                       5250 Ldebug_CIE21_start:
      002C0F FF FF                 5251 	.dw	0xffff
      002C11 FF FF                 5252 	.dw	0xffff
      002C13 01                    5253 	.db	1
      002C14 00                    5254 	.db	0
      002C15 01                    5255 	.uleb128	1
      002C16 7F                    5256 	.sleb128	-1
      002C17 09                    5257 	.db	9
      002C18 0C                    5258 	.db	12
      002C19 08                    5259 	.uleb128	8
      002C1A 02                    5260 	.uleb128	2
      002C1B 89                    5261 	.db	137
      002C1C 01                    5262 	.uleb128	1
      002C1D                       5263 Ldebug_CIE21_end:
      002C1D 00 00 00 4B           5264 	.dw	0,75
      002C21 00 00 2C 0B           5265 	.dw	0,(Ldebug_CIE21_start-4)
      002C25 00 00 99 6E           5266 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$113)	;initial loc
      002C29 00 00 00 94           5267 	.dw	0,Sstm8s_uart1$UART1_ITConfig$154-Sstm8s_uart1$UART1_ITConfig$113
      002C2D 01                    5268 	.db	1
      002C2E 00 00 99 6E           5269 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$113)
      002C32 0E                    5270 	.db	14
      002C33 02                    5271 	.uleb128	2
      002C34 01                    5272 	.db	1
      002C35 00 00 99 6F           5273 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$114)
      002C39 0E                    5274 	.db	14
      002C3A 04                    5275 	.uleb128	4
      002C3B 01                    5276 	.db	1
      002C3C 00 00 99 77           5277 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$117)
      002C40 0E                    5278 	.db	14
      002C41 05                    5279 	.uleb128	5
      002C42 01                    5280 	.db	1
      002C43 00 00 99 7C           5281 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$118)
      002C47 0E                    5282 	.db	14
      002C48 04                    5283 	.uleb128	4
      002C49 01                    5284 	.db	1
      002C4A 00 00 99 91           5285 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$120)
      002C4E 0E                    5286 	.db	14
      002C4F 04                    5287 	.uleb128	4
      002C50 01                    5288 	.db	1
      002C51 00 00 99 9C           5289 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$122)
      002C55 0E                    5290 	.db	14
      002C56 04                    5291 	.uleb128	4
      002C57 01                    5292 	.db	1
      002C58 00 00 99 D2           5293 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$137)
      002C5C 0E                    5294 	.db	14
      002C5D 05                    5295 	.uleb128	5
      002C5E 01                    5296 	.db	1
      002C5F 00 00 99 D5           5297 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$138)
      002C63 0E                    5298 	.db	14
      002C64 04                    5299 	.uleb128	4
      002C65 01                    5300 	.db	1
      002C66 00 00 9A 01           5301 	.dw	0,(Sstm8s_uart1$UART1_ITConfig$152)
      002C6A 0E                    5302 	.db	14
      002C6B 02                    5303 	.uleb128	2
                                   5304 
                                   5305 	.area .debug_frame (NOLOAD)
      002C6C 00 00                 5306 	.dw	0
      002C6E 00 0E                 5307 	.dw	Ldebug_CIE22_end-Ldebug_CIE22_start
      002C70                       5308 Ldebug_CIE22_start:
      002C70 FF FF                 5309 	.dw	0xffff
      002C72 FF FF                 5310 	.dw	0xffff
      002C74 01                    5311 	.db	1
      002C75 00                    5312 	.db	0
      002C76 01                    5313 	.uleb128	1
      002C77 7F                    5314 	.sleb128	-1
      002C78 09                    5315 	.db	9
      002C79 0C                    5316 	.db	12
      002C7A 08                    5317 	.uleb128	8
      002C7B 02                    5318 	.uleb128	2
      002C7C 89                    5319 	.db	137
      002C7D 01                    5320 	.uleb128	1
      002C7E                       5321 Ldebug_CIE22_end:
      002C7E 00 00 00 13           5322 	.dw	0,19
      002C82 00 00 2C 6C           5323 	.dw	0,(Ldebug_CIE22_start-4)
      002C86 00 00 99 56           5324 	.dw	0,(Sstm8s_uart1$UART1_Cmd$100)	;initial loc
      002C8A 00 00 00 18           5325 	.dw	0,Sstm8s_uart1$UART1_Cmd$111-Sstm8s_uart1$UART1_Cmd$100
      002C8E 01                    5326 	.db	1
      002C8F 00 00 99 56           5327 	.dw	0,(Sstm8s_uart1$UART1_Cmd$100)
      002C93 0E                    5328 	.db	14
      002C94 02                    5329 	.uleb128	2
                                   5330 
                                   5331 	.area .debug_frame (NOLOAD)
      002C95 00 00                 5332 	.dw	0
      002C97 00 0E                 5333 	.dw	Ldebug_CIE23_end-Ldebug_CIE23_start
      002C99                       5334 Ldebug_CIE23_start:
      002C99 FF FF                 5335 	.dw	0xffff
      002C9B FF FF                 5336 	.dw	0xffff
      002C9D 01                    5337 	.db	1
      002C9E 00                    5338 	.db	0
      002C9F 01                    5339 	.uleb128	1
      002CA0 7F                    5340 	.sleb128	-1
      002CA1 09                    5341 	.db	9
      002CA2 0C                    5342 	.db	12
      002CA3 08                    5343 	.uleb128	8
      002CA4 02                    5344 	.uleb128	2
      002CA5 89                    5345 	.db	137
      002CA6 01                    5346 	.uleb128	1
      002CA7                       5347 Ldebug_CIE23_end:
      002CA7 00 00 01 16           5348 	.dw	0,278
      002CAB 00 00 2C 95           5349 	.dw	0,(Ldebug_CIE23_start-4)
      002CAF 00 00 97 C7           5350 	.dw	0,(Sstm8s_uart1$UART1_Init$17)	;initial loc
      002CB3 00 00 01 8F           5351 	.dw	0,Sstm8s_uart1$UART1_Init$98-Sstm8s_uart1$UART1_Init$17
      002CB7 01                    5352 	.db	1
      002CB8 00 00 97 C7           5353 	.dw	0,(Sstm8s_uart1$UART1_Init$17)
      002CBC 0E                    5354 	.db	14
      002CBD 02                    5355 	.uleb128	2
      002CBE 01                    5356 	.db	1
      002CBF 00 00 97 C9           5357 	.dw	0,(Sstm8s_uart1$UART1_Init$18)
      002CC3 0E                    5358 	.db	14
      002CC4 13                    5359 	.uleb128	19
      002CC5 01                    5360 	.db	1
      002CC6 00 00 98 2A           5361 	.dw	0,(Sstm8s_uart1$UART1_Init$29)
      002CCA 0E                    5362 	.db	14
      002CCB 15                    5363 	.uleb128	21
      002CCC 01                    5364 	.db	1
      002CCD 00 00 98 2D           5365 	.dw	0,(Sstm8s_uart1$UART1_Init$30)
      002CD1 0E                    5366 	.db	14
      002CD2 17                    5367 	.uleb128	23
      002CD3 01                    5368 	.db	1
      002CD4 00 00 98 30           5369 	.dw	0,(Sstm8s_uart1$UART1_Init$31)
      002CD8 0E                    5370 	.db	14
      002CD9 19                    5371 	.uleb128	25
      002CDA 01                    5372 	.db	1
      002CDB 00 00 98 32           5373 	.dw	0,(Sstm8s_uart1$UART1_Init$32)
      002CDF 0E                    5374 	.db	14
      002CE0 1B                    5375 	.uleb128	27
      002CE1 01                    5376 	.db	1
      002CE2 00 00 98 37           5377 	.dw	0,(Sstm8s_uart1$UART1_Init$33)
      002CE6 0E                    5378 	.db	14
      002CE7 13                    5379 	.uleb128	19
      002CE8 01                    5380 	.db	1
      002CE9 00 00 98 4D           5381 	.dw	0,(Sstm8s_uart1$UART1_Init$35)
      002CED 0E                    5382 	.db	14
      002CEE 15                    5383 	.uleb128	21
      002CEF 01                    5384 	.db	1
      002CF0 00 00 98 50           5385 	.dw	0,(Sstm8s_uart1$UART1_Init$36)
      002CF4 0E                    5386 	.db	14
      002CF5 17                    5387 	.uleb128	23
      002CF6 01                    5388 	.db	1
      002CF7 00 00 98 52           5389 	.dw	0,(Sstm8s_uart1$UART1_Init$37)
      002CFB 0E                    5390 	.db	14
      002CFC 18                    5391 	.uleb128	24
      002CFD 01                    5392 	.db	1
      002CFE 00 00 98 54           5393 	.dw	0,(Sstm8s_uart1$UART1_Init$38)
      002D02 0E                    5394 	.db	14
      002D03 1A                    5395 	.uleb128	26
      002D04 01                    5396 	.db	1
      002D05 00 00 98 56           5397 	.dw	0,(Sstm8s_uart1$UART1_Init$39)
      002D09 0E                    5398 	.db	14
      002D0A 1B                    5399 	.uleb128	27
      002D0B 01                    5400 	.db	1
      002D0C 00 00 98 5B           5401 	.dw	0,(Sstm8s_uart1$UART1_Init$40)
      002D10 0E                    5402 	.db	14
      002D11 13                    5403 	.uleb128	19
      002D12 01                    5404 	.db	1
      002D13 00 00 98 60           5405 	.dw	0,(Sstm8s_uart1$UART1_Init$41)
      002D17 0E                    5406 	.db	14
      002D18 15                    5407 	.uleb128	21
      002D19 01                    5408 	.db	1
      002D1A 00 00 98 63           5409 	.dw	0,(Sstm8s_uart1$UART1_Init$42)
      002D1E 0E                    5410 	.db	14
      002D1F 17                    5411 	.uleb128	23
      002D20 01                    5412 	.db	1
      002D21 00 00 98 66           5413 	.dw	0,(Sstm8s_uart1$UART1_Init$43)
      002D25 0E                    5414 	.db	14
      002D26 19                    5415 	.uleb128	25
      002D27 01                    5416 	.db	1
      002D28 00 00 98 68           5417 	.dw	0,(Sstm8s_uart1$UART1_Init$44)
      002D2C 0E                    5418 	.db	14
      002D2D 1B                    5419 	.uleb128	27
      002D2E 01                    5420 	.db	1
      002D2F 00 00 98 6D           5421 	.dw	0,(Sstm8s_uart1$UART1_Init$45)
      002D33 0E                    5422 	.db	14
      002D34 13                    5423 	.uleb128	19
      002D35 01                    5424 	.db	1
      002D36 00 00 98 79           5425 	.dw	0,(Sstm8s_uart1$UART1_Init$47)
      002D3A 0E                    5426 	.db	14
      002D3B 15                    5427 	.uleb128	21
      002D3C 01                    5428 	.db	1
      002D3D 00 00 98 7C           5429 	.dw	0,(Sstm8s_uart1$UART1_Init$48)
      002D41 0E                    5430 	.db	14
      002D42 17                    5431 	.uleb128	23
      002D43 01                    5432 	.db	1
      002D44 00 00 98 7E           5433 	.dw	0,(Sstm8s_uart1$UART1_Init$49)
      002D48 0E                    5434 	.db	14
      002D49 18                    5435 	.uleb128	24
      002D4A 01                    5436 	.db	1
      002D4B 00 00 98 80           5437 	.dw	0,(Sstm8s_uart1$UART1_Init$50)
      002D4F 0E                    5438 	.db	14
      002D50 1A                    5439 	.uleb128	26
      002D51 01                    5440 	.db	1
      002D52 00 00 98 82           5441 	.dw	0,(Sstm8s_uart1$UART1_Init$51)
      002D56 0E                    5442 	.db	14
      002D57 1B                    5443 	.uleb128	27
      002D58 01                    5444 	.db	1
      002D59 00 00 98 87           5445 	.dw	0,(Sstm8s_uart1$UART1_Init$52)
      002D5D 0E                    5446 	.db	14
      002D5E 13                    5447 	.uleb128	19
      002D5F 01                    5448 	.db	1
      002D60 00 00 98 AC           5449 	.dw	0,(Sstm8s_uart1$UART1_Init$53)
      002D64 0E                    5450 	.db	14
      002D65 14                    5451 	.uleb128	20
      002D66 01                    5452 	.db	1
      002D67 00 00 98 AE           5453 	.dw	0,(Sstm8s_uart1$UART1_Init$54)
      002D6B 0E                    5454 	.db	14
      002D6C 15                    5455 	.uleb128	21
      002D6D 01                    5456 	.db	1
      002D6E 00 00 98 B0           5457 	.dw	0,(Sstm8s_uart1$UART1_Init$55)
      002D72 0E                    5458 	.db	14
      002D73 16                    5459 	.uleb128	22
      002D74 01                    5460 	.db	1
      002D75 00 00 98 B2           5461 	.dw	0,(Sstm8s_uart1$UART1_Init$56)
      002D79 0E                    5462 	.db	14
      002D7A 17                    5463 	.uleb128	23
      002D7B 01                    5464 	.db	1
      002D7C 00 00 98 B3           5465 	.dw	0,(Sstm8s_uart1$UART1_Init$57)
      002D80 0E                    5466 	.db	14
      002D81 19                    5467 	.uleb128	25
      002D82 01                    5468 	.db	1
      002D83 00 00 98 B5           5469 	.dw	0,(Sstm8s_uart1$UART1_Init$58)
      002D87 0E                    5470 	.db	14
      002D88 1B                    5471 	.uleb128	27
      002D89 01                    5472 	.db	1
      002D8A 00 00 98 BA           5473 	.dw	0,(Sstm8s_uart1$UART1_Init$59)
      002D8E 0E                    5474 	.db	14
      002D8F 13                    5475 	.uleb128	19
      002D90 01                    5476 	.db	1
      002D91 00 00 99 02           5477 	.dw	0,(Sstm8s_uart1$UART1_Init$67)
      002D95 0E                    5478 	.db	14
      002D96 14                    5479 	.uleb128	20
      002D97 01                    5480 	.db	1
      002D98 00 00 99 07           5481 	.dw	0,(Sstm8s_uart1$UART1_Init$68)
      002D9C 0E                    5482 	.db	14
      002D9D 13                    5483 	.uleb128	19
      002D9E 01                    5484 	.db	1
      002D9F 00 00 99 1D           5485 	.dw	0,(Sstm8s_uart1$UART1_Init$77)
      002DA3 0E                    5486 	.db	14
      002DA4 14                    5487 	.uleb128	20
      002DA5 01                    5488 	.db	1
      002DA6 00 00 99 22           5489 	.dw	0,(Sstm8s_uart1$UART1_Init$78)
      002DAA 0E                    5490 	.db	14
      002DAB 13                    5491 	.uleb128	19
      002DAC 01                    5492 	.db	1
      002DAD 00 00 99 47           5493 	.dw	0,(Sstm8s_uart1$UART1_Init$92)
      002DB1 0E                    5494 	.db	14
      002DB2 14                    5495 	.uleb128	20
      002DB3 01                    5496 	.db	1
      002DB4 00 00 99 4E           5497 	.dw	0,(Sstm8s_uart1$UART1_Init$93)
      002DB8 0E                    5498 	.db	14
      002DB9 13                    5499 	.uleb128	19
      002DBA 01                    5500 	.db	1
      002DBB 00 00 99 55           5501 	.dw	0,(Sstm8s_uart1$UART1_Init$96)
      002DBF 0E                    5502 	.db	14
      002DC0 02                    5503 	.uleb128	2
                                   5504 
                                   5505 	.area .debug_frame (NOLOAD)
      002DC1 00 00                 5506 	.dw	0
      002DC3 00 0E                 5507 	.dw	Ldebug_CIE24_end-Ldebug_CIE24_start
      002DC5                       5508 Ldebug_CIE24_start:
      002DC5 FF FF                 5509 	.dw	0xffff
      002DC7 FF FF                 5510 	.dw	0xffff
      002DC9 01                    5511 	.db	1
      002DCA 00                    5512 	.db	0
      002DCB 01                    5513 	.uleb128	1
      002DCC 7F                    5514 	.sleb128	-1
      002DCD 09                    5515 	.db	9
      002DCE 0C                    5516 	.db	12
      002DCF 08                    5517 	.uleb128	8
      002DD0 02                    5518 	.uleb128	2
      002DD1 89                    5519 	.db	137
      002DD2 01                    5520 	.uleb128	1
      002DD3                       5521 Ldebug_CIE24_end:
      002DD3 00 00 00 13           5522 	.dw	0,19
      002DD7 00 00 2D C1           5523 	.dw	0,(Ldebug_CIE24_start-4)
      002DDB 00 00 97 9C           5524 	.dw	0,(Sstm8s_uart1$UART1_DeInit$1)	;initial loc
      002DDF 00 00 00 2B           5525 	.dw	0,Sstm8s_uart1$UART1_DeInit$15-Sstm8s_uart1$UART1_DeInit$1
      002DE3 01                    5526 	.db	1
      002DE4 00 00 97 9C           5527 	.dw	0,(Sstm8s_uart1$UART1_DeInit$1)
      002DE8 0E                    5528 	.db	14
      002DE9 02                    5529 	.uleb128	2
