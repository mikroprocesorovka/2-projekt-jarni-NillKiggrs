                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module stm8s_tim4
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _TIM4_DeInit
                                     12 	.globl _TIM4_TimeBaseInit
                                     13 	.globl _TIM4_Cmd
                                     14 	.globl _TIM4_ITConfig
                                     15 	.globl _TIM4_UpdateDisableConfig
                                     16 	.globl _TIM4_UpdateRequestConfig
                                     17 	.globl _TIM4_SelectOnePulseMode
                                     18 	.globl _TIM4_PrescalerConfig
                                     19 	.globl _TIM4_ARRPreloadConfig
                                     20 	.globl _TIM4_GenerateEvent
                                     21 	.globl _TIM4_SetCounter
                                     22 	.globl _TIM4_SetAutoreload
                                     23 	.globl _TIM4_GetCounter
                                     24 	.globl _TIM4_GetPrescaler
                                     25 	.globl _TIM4_GetFlagStatus
                                     26 	.globl _TIM4_ClearFlag
                                     27 	.globl _TIM4_GetITStatus
                                     28 	.globl _TIM4_ClearITPendingBit
                                     29 ;--------------------------------------------------------
                                     30 ; ram data
                                     31 ;--------------------------------------------------------
                                     32 	.area DATA
                                     33 ;--------------------------------------------------------
                                     34 ; ram data
                                     35 ;--------------------------------------------------------
                                     36 	.area INITIALIZED
                                     37 ;--------------------------------------------------------
                                     38 ; absolute external ram data
                                     39 ;--------------------------------------------------------
                                     40 	.area DABS (ABS)
                                     41 
                                     42 ; default segment ordering for linker
                                     43 	.area HOME
                                     44 	.area GSINIT
                                     45 	.area GSFINAL
                                     46 	.area CONST
                                     47 	.area INITIALIZER
                                     48 	.area CODE
                                     49 
                                     50 ;--------------------------------------------------------
                                     51 ; global & static initialisations
                                     52 ;--------------------------------------------------------
                                     53 	.area HOME
                                     54 	.area GSINIT
                                     55 	.area GSFINAL
                                     56 	.area GSINIT
                                     57 ;--------------------------------------------------------
                                     58 ; Home
                                     59 ;--------------------------------------------------------
                                     60 	.area HOME
                                     61 	.area HOME
                                     62 ;--------------------------------------------------------
                                     63 ; code
                                     64 ;--------------------------------------------------------
                                     65 	.area CODE
                           000000    66 	Sstm8s_tim4$TIM4_DeInit$0 ==.
                                     67 ;	../SPL/src/stm8s_tim4.c: 49: void TIM4_DeInit(void)
                                     68 ; genLabel
                                     69 ;	-----------------------------------------
                                     70 ;	 function TIM4_DeInit
                                     71 ;	-----------------------------------------
                                     72 ;	Register assignment is optimal.
                                     73 ;	Stack space usage: 0 bytes.
      0094AE                         74 _TIM4_DeInit:
                           000000    75 	Sstm8s_tim4$TIM4_DeInit$1 ==.
                           000000    76 	Sstm8s_tim4$TIM4_DeInit$2 ==.
                                     77 ;	../SPL/src/stm8s_tim4.c: 51: TIM4->CR1 = TIM4_CR1_RESET_VALUE;
                                     78 ; genPointerSet
      0094AE 35 00 53 40      [ 1]   79 	mov	0x5340+0, #0x00
                           000004    80 	Sstm8s_tim4$TIM4_DeInit$3 ==.
                                     81 ;	../SPL/src/stm8s_tim4.c: 52: TIM4->IER = TIM4_IER_RESET_VALUE;
                                     82 ; genPointerSet
      0094B2 35 00 53 41      [ 1]   83 	mov	0x5341+0, #0x00
                           000008    84 	Sstm8s_tim4$TIM4_DeInit$4 ==.
                                     85 ;	../SPL/src/stm8s_tim4.c: 53: TIM4->CNTR = TIM4_CNTR_RESET_VALUE;
                                     86 ; genPointerSet
      0094B6 35 00 53 44      [ 1]   87 	mov	0x5344+0, #0x00
                           00000C    88 	Sstm8s_tim4$TIM4_DeInit$5 ==.
                                     89 ;	../SPL/src/stm8s_tim4.c: 54: TIM4->PSCR = TIM4_PSCR_RESET_VALUE;
                                     90 ; genPointerSet
      0094BA 35 00 53 45      [ 1]   91 	mov	0x5345+0, #0x00
                           000010    92 	Sstm8s_tim4$TIM4_DeInit$6 ==.
                                     93 ;	../SPL/src/stm8s_tim4.c: 55: TIM4->ARR = TIM4_ARR_RESET_VALUE;
                                     94 ; genPointerSet
      0094BE 35 FF 53 46      [ 1]   95 	mov	0x5346+0, #0xff
                           000014    96 	Sstm8s_tim4$TIM4_DeInit$7 ==.
                                     97 ;	../SPL/src/stm8s_tim4.c: 56: TIM4->SR1 = TIM4_SR1_RESET_VALUE;
                                     98 ; genPointerSet
      0094C2 35 00 53 42      [ 1]   99 	mov	0x5342+0, #0x00
                                    100 ; genLabel
      0094C6                        101 00101$:
                           000018   102 	Sstm8s_tim4$TIM4_DeInit$8 ==.
                                    103 ;	../SPL/src/stm8s_tim4.c: 57: }
                                    104 ; genEndFunction
                           000018   105 	Sstm8s_tim4$TIM4_DeInit$9 ==.
                           000018   106 	XG$TIM4_DeInit$0$0 ==.
      0094C6 81               [ 4]  107 	ret
                           000019   108 	Sstm8s_tim4$TIM4_DeInit$10 ==.
                           000019   109 	Sstm8s_tim4$TIM4_TimeBaseInit$11 ==.
                                    110 ;	../SPL/src/stm8s_tim4.c: 65: void TIM4_TimeBaseInit(TIM4_Prescaler_TypeDef TIM4_Prescaler, uint8_t TIM4_Period)
                                    111 ; genLabel
                                    112 ;	-----------------------------------------
                                    113 ;	 function TIM4_TimeBaseInit
                                    114 ;	-----------------------------------------
                                    115 ;	Register assignment is optimal.
                                    116 ;	Stack space usage: 0 bytes.
      0094C7                        117 _TIM4_TimeBaseInit:
                           000019   118 	Sstm8s_tim4$TIM4_TimeBaseInit$12 ==.
                           000019   119 	Sstm8s_tim4$TIM4_TimeBaseInit$13 ==.
                                    120 ;	../SPL/src/stm8s_tim4.c: 70: TIM4->PSCR = (uint8_t)(TIM4_Prescaler);
                                    121 ; genPointerSet
      0094C7 AE 53 45         [ 2]  122 	ldw	x, #0x5345
      0094CA 7B 03            [ 1]  123 	ld	a, (0x03, sp)
      0094CC F7               [ 1]  124 	ld	(x), a
                           00001F   125 	Sstm8s_tim4$TIM4_TimeBaseInit$14 ==.
                                    126 ;	../SPL/src/stm8s_tim4.c: 72: TIM4->ARR = (uint8_t)(TIM4_Period);
                                    127 ; genPointerSet
      0094CD AE 53 46         [ 2]  128 	ldw	x, #0x5346
      0094D0 7B 04            [ 1]  129 	ld	a, (0x04, sp)
      0094D2 F7               [ 1]  130 	ld	(x), a
                                    131 ; genLabel
      0094D3                        132 00101$:
                           000025   133 	Sstm8s_tim4$TIM4_TimeBaseInit$15 ==.
                                    134 ;	../SPL/src/stm8s_tim4.c: 73: }
                                    135 ; genEndFunction
                           000025   136 	Sstm8s_tim4$TIM4_TimeBaseInit$16 ==.
                           000025   137 	XG$TIM4_TimeBaseInit$0$0 ==.
      0094D3 81               [ 4]  138 	ret
                           000026   139 	Sstm8s_tim4$TIM4_TimeBaseInit$17 ==.
                           000026   140 	Sstm8s_tim4$TIM4_Cmd$18 ==.
                                    141 ;	../SPL/src/stm8s_tim4.c: 81: void TIM4_Cmd(FunctionalState NewState)
                                    142 ; genLabel
                                    143 ;	-----------------------------------------
                                    144 ;	 function TIM4_Cmd
                                    145 ;	-----------------------------------------
                                    146 ;	Register assignment is optimal.
                                    147 ;	Stack space usage: 0 bytes.
      0094D4                        148 _TIM4_Cmd:
                           000026   149 	Sstm8s_tim4$TIM4_Cmd$19 ==.
                           000026   150 	Sstm8s_tim4$TIM4_Cmd$20 ==.
                                    151 ;	../SPL/src/stm8s_tim4.c: 89: TIM4->CR1 |= TIM4_CR1_CEN;
                                    152 ; genPointerGet
      0094D4 C6 53 40         [ 1]  153 	ld	a, 0x5340
                           000029   154 	Sstm8s_tim4$TIM4_Cmd$21 ==.
                                    155 ;	../SPL/src/stm8s_tim4.c: 87: if (NewState != DISABLE)
                                    156 ; genIfx
      0094D7 0D 03            [ 1]  157 	tnz	(0x03, sp)
      0094D9 26 03            [ 1]  158 	jrne	00111$
      0094DB CC 94 E6         [ 2]  159 	jp	00102$
      0094DE                        160 00111$:
                           000030   161 	Sstm8s_tim4$TIM4_Cmd$22 ==.
                           000030   162 	Sstm8s_tim4$TIM4_Cmd$23 ==.
                                    163 ;	../SPL/src/stm8s_tim4.c: 89: TIM4->CR1 |= TIM4_CR1_CEN;
                                    164 ; genOr
      0094DE AA 01            [ 1]  165 	or	a, #0x01
                                    166 ; genPointerSet
      0094E0 C7 53 40         [ 1]  167 	ld	0x5340, a
                           000035   168 	Sstm8s_tim4$TIM4_Cmd$24 ==.
                                    169 ; genGoto
      0094E3 CC 94 EB         [ 2]  170 	jp	00104$
                                    171 ; genLabel
      0094E6                        172 00102$:
                           000038   173 	Sstm8s_tim4$TIM4_Cmd$25 ==.
                           000038   174 	Sstm8s_tim4$TIM4_Cmd$26 ==.
                                    175 ;	../SPL/src/stm8s_tim4.c: 93: TIM4->CR1 &= (uint8_t)(~TIM4_CR1_CEN);
                                    176 ; genAnd
      0094E6 A4 FE            [ 1]  177 	and	a, #0xfe
                                    178 ; genPointerSet
      0094E8 C7 53 40         [ 1]  179 	ld	0x5340, a
                           00003D   180 	Sstm8s_tim4$TIM4_Cmd$27 ==.
                                    181 ; genLabel
      0094EB                        182 00104$:
                           00003D   183 	Sstm8s_tim4$TIM4_Cmd$28 ==.
                                    184 ;	../SPL/src/stm8s_tim4.c: 95: }
                                    185 ; genEndFunction
                           00003D   186 	Sstm8s_tim4$TIM4_Cmd$29 ==.
                           00003D   187 	XG$TIM4_Cmd$0$0 ==.
      0094EB 81               [ 4]  188 	ret
                           00003E   189 	Sstm8s_tim4$TIM4_Cmd$30 ==.
                           00003E   190 	Sstm8s_tim4$TIM4_ITConfig$31 ==.
                                    191 ;	../SPL/src/stm8s_tim4.c: 107: void TIM4_ITConfig(TIM4_IT_TypeDef TIM4_IT, FunctionalState NewState)
                                    192 ; genLabel
                                    193 ;	-----------------------------------------
                                    194 ;	 function TIM4_ITConfig
                                    195 ;	-----------------------------------------
                                    196 ;	Register assignment is optimal.
                                    197 ;	Stack space usage: 1 bytes.
      0094EC                        198 _TIM4_ITConfig:
                           00003E   199 	Sstm8s_tim4$TIM4_ITConfig$32 ==.
      0094EC 88               [ 1]  200 	push	a
                           00003F   201 	Sstm8s_tim4$TIM4_ITConfig$33 ==.
                           00003F   202 	Sstm8s_tim4$TIM4_ITConfig$34 ==.
                                    203 ;	../SPL/src/stm8s_tim4.c: 116: TIM4->IER |= (uint8_t)TIM4_IT;
                                    204 ; genPointerGet
      0094ED C6 53 41         [ 1]  205 	ld	a, 0x5341
                           000042   206 	Sstm8s_tim4$TIM4_ITConfig$35 ==.
                                    207 ;	../SPL/src/stm8s_tim4.c: 113: if (NewState != DISABLE)
                                    208 ; genIfx
      0094F0 0D 05            [ 1]  209 	tnz	(0x05, sp)
      0094F2 26 03            [ 1]  210 	jrne	00111$
      0094F4 CC 94 FF         [ 2]  211 	jp	00102$
      0094F7                        212 00111$:
                           000049   213 	Sstm8s_tim4$TIM4_ITConfig$36 ==.
                           000049   214 	Sstm8s_tim4$TIM4_ITConfig$37 ==.
                                    215 ;	../SPL/src/stm8s_tim4.c: 116: TIM4->IER |= (uint8_t)TIM4_IT;
                                    216 ; genOr
      0094F7 1A 04            [ 1]  217 	or	a, (0x04, sp)
                                    218 ; genPointerSet
      0094F9 C7 53 41         [ 1]  219 	ld	0x5341, a
                           00004E   220 	Sstm8s_tim4$TIM4_ITConfig$38 ==.
                                    221 ; genGoto
      0094FC CC 95 0B         [ 2]  222 	jp	00104$
                                    223 ; genLabel
      0094FF                        224 00102$:
                           000051   225 	Sstm8s_tim4$TIM4_ITConfig$39 ==.
                           000051   226 	Sstm8s_tim4$TIM4_ITConfig$40 ==.
                                    227 ;	../SPL/src/stm8s_tim4.c: 121: TIM4->IER &= (uint8_t)(~TIM4_IT);
                                    228 ; genCpl
      0094FF 88               [ 1]  229 	push	a
                           000052   230 	Sstm8s_tim4$TIM4_ITConfig$41 ==.
      009500 7B 05            [ 1]  231 	ld	a, (0x05, sp)
      009502 43               [ 1]  232 	cpl	a
      009503 6B 02            [ 1]  233 	ld	(0x02, sp), a
      009505 84               [ 1]  234 	pop	a
                           000058   235 	Sstm8s_tim4$TIM4_ITConfig$42 ==.
                                    236 ; genAnd
      009506 14 01            [ 1]  237 	and	a, (0x01, sp)
                                    238 ; genPointerSet
      009508 C7 53 41         [ 1]  239 	ld	0x5341, a
                           00005D   240 	Sstm8s_tim4$TIM4_ITConfig$43 ==.
                                    241 ; genLabel
      00950B                        242 00104$:
                           00005D   243 	Sstm8s_tim4$TIM4_ITConfig$44 ==.
                                    244 ;	../SPL/src/stm8s_tim4.c: 123: }
                                    245 ; genEndFunction
      00950B 84               [ 1]  246 	pop	a
                           00005E   247 	Sstm8s_tim4$TIM4_ITConfig$45 ==.
                           00005E   248 	Sstm8s_tim4$TIM4_ITConfig$46 ==.
                           00005E   249 	XG$TIM4_ITConfig$0$0 ==.
      00950C 81               [ 4]  250 	ret
                           00005F   251 	Sstm8s_tim4$TIM4_ITConfig$47 ==.
                           00005F   252 	Sstm8s_tim4$TIM4_UpdateDisableConfig$48 ==.
                                    253 ;	../SPL/src/stm8s_tim4.c: 131: void TIM4_UpdateDisableConfig(FunctionalState NewState)
                                    254 ; genLabel
                                    255 ;	-----------------------------------------
                                    256 ;	 function TIM4_UpdateDisableConfig
                                    257 ;	-----------------------------------------
                                    258 ;	Register assignment is optimal.
                                    259 ;	Stack space usage: 0 bytes.
      00950D                        260 _TIM4_UpdateDisableConfig:
                           00005F   261 	Sstm8s_tim4$TIM4_UpdateDisableConfig$49 ==.
                           00005F   262 	Sstm8s_tim4$TIM4_UpdateDisableConfig$50 ==.
                                    263 ;	../SPL/src/stm8s_tim4.c: 139: TIM4->CR1 |= TIM4_CR1_UDIS;
                                    264 ; genPointerGet
      00950D C6 53 40         [ 1]  265 	ld	a, 0x5340
                           000062   266 	Sstm8s_tim4$TIM4_UpdateDisableConfig$51 ==.
                                    267 ;	../SPL/src/stm8s_tim4.c: 137: if (NewState != DISABLE)
                                    268 ; genIfx
      009510 0D 03            [ 1]  269 	tnz	(0x03, sp)
      009512 26 03            [ 1]  270 	jrne	00111$
      009514 CC 95 1F         [ 2]  271 	jp	00102$
      009517                        272 00111$:
                           000069   273 	Sstm8s_tim4$TIM4_UpdateDisableConfig$52 ==.
                           000069   274 	Sstm8s_tim4$TIM4_UpdateDisableConfig$53 ==.
                                    275 ;	../SPL/src/stm8s_tim4.c: 139: TIM4->CR1 |= TIM4_CR1_UDIS;
                                    276 ; genOr
      009517 AA 02            [ 1]  277 	or	a, #0x02
                                    278 ; genPointerSet
      009519 C7 53 40         [ 1]  279 	ld	0x5340, a
                           00006E   280 	Sstm8s_tim4$TIM4_UpdateDisableConfig$54 ==.
                                    281 ; genGoto
      00951C CC 95 24         [ 2]  282 	jp	00104$
                                    283 ; genLabel
      00951F                        284 00102$:
                           000071   285 	Sstm8s_tim4$TIM4_UpdateDisableConfig$55 ==.
                           000071   286 	Sstm8s_tim4$TIM4_UpdateDisableConfig$56 ==.
                                    287 ;	../SPL/src/stm8s_tim4.c: 143: TIM4->CR1 &= (uint8_t)(~TIM4_CR1_UDIS);
                                    288 ; genAnd
      00951F A4 FD            [ 1]  289 	and	a, #0xfd
                                    290 ; genPointerSet
      009521 C7 53 40         [ 1]  291 	ld	0x5340, a
                           000076   292 	Sstm8s_tim4$TIM4_UpdateDisableConfig$57 ==.
                                    293 ; genLabel
      009524                        294 00104$:
                           000076   295 	Sstm8s_tim4$TIM4_UpdateDisableConfig$58 ==.
                                    296 ;	../SPL/src/stm8s_tim4.c: 145: }
                                    297 ; genEndFunction
                           000076   298 	Sstm8s_tim4$TIM4_UpdateDisableConfig$59 ==.
                           000076   299 	XG$TIM4_UpdateDisableConfig$0$0 ==.
      009524 81               [ 4]  300 	ret
                           000077   301 	Sstm8s_tim4$TIM4_UpdateDisableConfig$60 ==.
                           000077   302 	Sstm8s_tim4$TIM4_UpdateRequestConfig$61 ==.
                                    303 ;	../SPL/src/stm8s_tim4.c: 155: void TIM4_UpdateRequestConfig(TIM4_UpdateSource_TypeDef TIM4_UpdateSource)
                                    304 ; genLabel
                                    305 ;	-----------------------------------------
                                    306 ;	 function TIM4_UpdateRequestConfig
                                    307 ;	-----------------------------------------
                                    308 ;	Register assignment is optimal.
                                    309 ;	Stack space usage: 0 bytes.
      009525                        310 _TIM4_UpdateRequestConfig:
                           000077   311 	Sstm8s_tim4$TIM4_UpdateRequestConfig$62 ==.
                           000077   312 	Sstm8s_tim4$TIM4_UpdateRequestConfig$63 ==.
                                    313 ;	../SPL/src/stm8s_tim4.c: 163: TIM4->CR1 |= TIM4_CR1_URS;
                                    314 ; genPointerGet
      009525 C6 53 40         [ 1]  315 	ld	a, 0x5340
                           00007A   316 	Sstm8s_tim4$TIM4_UpdateRequestConfig$64 ==.
                                    317 ;	../SPL/src/stm8s_tim4.c: 161: if (TIM4_UpdateSource != TIM4_UPDATESOURCE_GLOBAL)
                                    318 ; genIfx
      009528 0D 03            [ 1]  319 	tnz	(0x03, sp)
      00952A 26 03            [ 1]  320 	jrne	00111$
      00952C CC 95 37         [ 2]  321 	jp	00102$
      00952F                        322 00111$:
                           000081   323 	Sstm8s_tim4$TIM4_UpdateRequestConfig$65 ==.
                           000081   324 	Sstm8s_tim4$TIM4_UpdateRequestConfig$66 ==.
                                    325 ;	../SPL/src/stm8s_tim4.c: 163: TIM4->CR1 |= TIM4_CR1_URS;
                                    326 ; genOr
      00952F AA 04            [ 1]  327 	or	a, #0x04
                                    328 ; genPointerSet
      009531 C7 53 40         [ 1]  329 	ld	0x5340, a
                           000086   330 	Sstm8s_tim4$TIM4_UpdateRequestConfig$67 ==.
                                    331 ; genGoto
      009534 CC 95 3C         [ 2]  332 	jp	00104$
                                    333 ; genLabel
      009537                        334 00102$:
                           000089   335 	Sstm8s_tim4$TIM4_UpdateRequestConfig$68 ==.
                           000089   336 	Sstm8s_tim4$TIM4_UpdateRequestConfig$69 ==.
                                    337 ;	../SPL/src/stm8s_tim4.c: 167: TIM4->CR1 &= (uint8_t)(~TIM4_CR1_URS);
                                    338 ; genAnd
      009537 A4 FB            [ 1]  339 	and	a, #0xfb
                                    340 ; genPointerSet
      009539 C7 53 40         [ 1]  341 	ld	0x5340, a
                           00008E   342 	Sstm8s_tim4$TIM4_UpdateRequestConfig$70 ==.
                                    343 ; genLabel
      00953C                        344 00104$:
                           00008E   345 	Sstm8s_tim4$TIM4_UpdateRequestConfig$71 ==.
                                    346 ;	../SPL/src/stm8s_tim4.c: 169: }
                                    347 ; genEndFunction
                           00008E   348 	Sstm8s_tim4$TIM4_UpdateRequestConfig$72 ==.
                           00008E   349 	XG$TIM4_UpdateRequestConfig$0$0 ==.
      00953C 81               [ 4]  350 	ret
                           00008F   351 	Sstm8s_tim4$TIM4_UpdateRequestConfig$73 ==.
                           00008F   352 	Sstm8s_tim4$TIM4_SelectOnePulseMode$74 ==.
                                    353 ;	../SPL/src/stm8s_tim4.c: 179: void TIM4_SelectOnePulseMode(TIM4_OPMode_TypeDef TIM4_OPMode)
                                    354 ; genLabel
                                    355 ;	-----------------------------------------
                                    356 ;	 function TIM4_SelectOnePulseMode
                                    357 ;	-----------------------------------------
                                    358 ;	Register assignment is optimal.
                                    359 ;	Stack space usage: 0 bytes.
      00953D                        360 _TIM4_SelectOnePulseMode:
                           00008F   361 	Sstm8s_tim4$TIM4_SelectOnePulseMode$75 ==.
                           00008F   362 	Sstm8s_tim4$TIM4_SelectOnePulseMode$76 ==.
                                    363 ;	../SPL/src/stm8s_tim4.c: 187: TIM4->CR1 |= TIM4_CR1_OPM;
                                    364 ; genPointerGet
      00953D C6 53 40         [ 1]  365 	ld	a, 0x5340
                           000092   366 	Sstm8s_tim4$TIM4_SelectOnePulseMode$77 ==.
                                    367 ;	../SPL/src/stm8s_tim4.c: 185: if (TIM4_OPMode != TIM4_OPMODE_REPETITIVE)
                                    368 ; genIfx
      009540 0D 03            [ 1]  369 	tnz	(0x03, sp)
      009542 26 03            [ 1]  370 	jrne	00111$
      009544 CC 95 4F         [ 2]  371 	jp	00102$
      009547                        372 00111$:
                           000099   373 	Sstm8s_tim4$TIM4_SelectOnePulseMode$78 ==.
                           000099   374 	Sstm8s_tim4$TIM4_SelectOnePulseMode$79 ==.
                                    375 ;	../SPL/src/stm8s_tim4.c: 187: TIM4->CR1 |= TIM4_CR1_OPM;
                                    376 ; genOr
      009547 AA 08            [ 1]  377 	or	a, #0x08
                                    378 ; genPointerSet
      009549 C7 53 40         [ 1]  379 	ld	0x5340, a
                           00009E   380 	Sstm8s_tim4$TIM4_SelectOnePulseMode$80 ==.
                                    381 ; genGoto
      00954C CC 95 54         [ 2]  382 	jp	00104$
                                    383 ; genLabel
      00954F                        384 00102$:
                           0000A1   385 	Sstm8s_tim4$TIM4_SelectOnePulseMode$81 ==.
                           0000A1   386 	Sstm8s_tim4$TIM4_SelectOnePulseMode$82 ==.
                                    387 ;	../SPL/src/stm8s_tim4.c: 191: TIM4->CR1 &= (uint8_t)(~TIM4_CR1_OPM);
                                    388 ; genAnd
      00954F A4 F7            [ 1]  389 	and	a, #0xf7
                                    390 ; genPointerSet
      009551 C7 53 40         [ 1]  391 	ld	0x5340, a
                           0000A6   392 	Sstm8s_tim4$TIM4_SelectOnePulseMode$83 ==.
                                    393 ; genLabel
      009554                        394 00104$:
                           0000A6   395 	Sstm8s_tim4$TIM4_SelectOnePulseMode$84 ==.
                                    396 ;	../SPL/src/stm8s_tim4.c: 193: }
                                    397 ; genEndFunction
                           0000A6   398 	Sstm8s_tim4$TIM4_SelectOnePulseMode$85 ==.
                           0000A6   399 	XG$TIM4_SelectOnePulseMode$0$0 ==.
      009554 81               [ 4]  400 	ret
                           0000A7   401 	Sstm8s_tim4$TIM4_SelectOnePulseMode$86 ==.
                           0000A7   402 	Sstm8s_tim4$TIM4_PrescalerConfig$87 ==.
                                    403 ;	../SPL/src/stm8s_tim4.c: 215: void TIM4_PrescalerConfig(TIM4_Prescaler_TypeDef Prescaler, TIM4_PSCReloadMode_TypeDef TIM4_PSCReloadMode)
                                    404 ; genLabel
                                    405 ;	-----------------------------------------
                                    406 ;	 function TIM4_PrescalerConfig
                                    407 ;	-----------------------------------------
                                    408 ;	Register assignment is optimal.
                                    409 ;	Stack space usage: 0 bytes.
      009555                        410 _TIM4_PrescalerConfig:
                           0000A7   411 	Sstm8s_tim4$TIM4_PrescalerConfig$88 ==.
                           0000A7   412 	Sstm8s_tim4$TIM4_PrescalerConfig$89 ==.
                                    413 ;	../SPL/src/stm8s_tim4.c: 222: TIM4->PSCR = (uint8_t)Prescaler;
                                    414 ; genPointerSet
      009555 AE 53 45         [ 2]  415 	ldw	x, #0x5345
      009558 7B 03            [ 1]  416 	ld	a, (0x03, sp)
      00955A F7               [ 1]  417 	ld	(x), a
                           0000AD   418 	Sstm8s_tim4$TIM4_PrescalerConfig$90 ==.
                                    419 ;	../SPL/src/stm8s_tim4.c: 225: TIM4->EGR = (uint8_t)TIM4_PSCReloadMode;
                                    420 ; genPointerSet
      00955B AE 53 43         [ 2]  421 	ldw	x, #0x5343
      00955E 7B 04            [ 1]  422 	ld	a, (0x04, sp)
      009560 F7               [ 1]  423 	ld	(x), a
                                    424 ; genLabel
      009561                        425 00101$:
                           0000B3   426 	Sstm8s_tim4$TIM4_PrescalerConfig$91 ==.
                                    427 ;	../SPL/src/stm8s_tim4.c: 226: }
                                    428 ; genEndFunction
                           0000B3   429 	Sstm8s_tim4$TIM4_PrescalerConfig$92 ==.
                           0000B3   430 	XG$TIM4_PrescalerConfig$0$0 ==.
      009561 81               [ 4]  431 	ret
                           0000B4   432 	Sstm8s_tim4$TIM4_PrescalerConfig$93 ==.
                           0000B4   433 	Sstm8s_tim4$TIM4_ARRPreloadConfig$94 ==.
                                    434 ;	../SPL/src/stm8s_tim4.c: 234: void TIM4_ARRPreloadConfig(FunctionalState NewState)
                                    435 ; genLabel
                                    436 ;	-----------------------------------------
                                    437 ;	 function TIM4_ARRPreloadConfig
                                    438 ;	-----------------------------------------
                                    439 ;	Register assignment is optimal.
                                    440 ;	Stack space usage: 0 bytes.
      009562                        441 _TIM4_ARRPreloadConfig:
                           0000B4   442 	Sstm8s_tim4$TIM4_ARRPreloadConfig$95 ==.
                           0000B4   443 	Sstm8s_tim4$TIM4_ARRPreloadConfig$96 ==.
                                    444 ;	../SPL/src/stm8s_tim4.c: 242: TIM4->CR1 |= TIM4_CR1_ARPE;
                                    445 ; genPointerGet
      009562 C6 53 40         [ 1]  446 	ld	a, 0x5340
                           0000B7   447 	Sstm8s_tim4$TIM4_ARRPreloadConfig$97 ==.
                                    448 ;	../SPL/src/stm8s_tim4.c: 240: if (NewState != DISABLE)
                                    449 ; genIfx
      009565 0D 03            [ 1]  450 	tnz	(0x03, sp)
      009567 26 03            [ 1]  451 	jrne	00111$
      009569 CC 95 74         [ 2]  452 	jp	00102$
      00956C                        453 00111$:
                           0000BE   454 	Sstm8s_tim4$TIM4_ARRPreloadConfig$98 ==.
                           0000BE   455 	Sstm8s_tim4$TIM4_ARRPreloadConfig$99 ==.
                                    456 ;	../SPL/src/stm8s_tim4.c: 242: TIM4->CR1 |= TIM4_CR1_ARPE;
                                    457 ; genOr
      00956C AA 80            [ 1]  458 	or	a, #0x80
                                    459 ; genPointerSet
      00956E C7 53 40         [ 1]  460 	ld	0x5340, a
                           0000C3   461 	Sstm8s_tim4$TIM4_ARRPreloadConfig$100 ==.
                                    462 ; genGoto
      009571 CC 95 79         [ 2]  463 	jp	00104$
                                    464 ; genLabel
      009574                        465 00102$:
                           0000C6   466 	Sstm8s_tim4$TIM4_ARRPreloadConfig$101 ==.
                           0000C6   467 	Sstm8s_tim4$TIM4_ARRPreloadConfig$102 ==.
                                    468 ;	../SPL/src/stm8s_tim4.c: 246: TIM4->CR1 &= (uint8_t)(~TIM4_CR1_ARPE);
                                    469 ; genAnd
      009574 A4 7F            [ 1]  470 	and	a, #0x7f
                                    471 ; genPointerSet
      009576 C7 53 40         [ 1]  472 	ld	0x5340, a
                           0000CB   473 	Sstm8s_tim4$TIM4_ARRPreloadConfig$103 ==.
                                    474 ; genLabel
      009579                        475 00104$:
                           0000CB   476 	Sstm8s_tim4$TIM4_ARRPreloadConfig$104 ==.
                                    477 ;	../SPL/src/stm8s_tim4.c: 248: }
                                    478 ; genEndFunction
                           0000CB   479 	Sstm8s_tim4$TIM4_ARRPreloadConfig$105 ==.
                           0000CB   480 	XG$TIM4_ARRPreloadConfig$0$0 ==.
      009579 81               [ 4]  481 	ret
                           0000CC   482 	Sstm8s_tim4$TIM4_ARRPreloadConfig$106 ==.
                           0000CC   483 	Sstm8s_tim4$TIM4_GenerateEvent$107 ==.
                                    484 ;	../SPL/src/stm8s_tim4.c: 257: void TIM4_GenerateEvent(TIM4_EventSource_TypeDef TIM4_EventSource)
                                    485 ; genLabel
                                    486 ;	-----------------------------------------
                                    487 ;	 function TIM4_GenerateEvent
                                    488 ;	-----------------------------------------
                                    489 ;	Register assignment is optimal.
                                    490 ;	Stack space usage: 0 bytes.
      00957A                        491 _TIM4_GenerateEvent:
                           0000CC   492 	Sstm8s_tim4$TIM4_GenerateEvent$108 ==.
                           0000CC   493 	Sstm8s_tim4$TIM4_GenerateEvent$109 ==.
                                    494 ;	../SPL/src/stm8s_tim4.c: 263: TIM4->EGR = (uint8_t)(TIM4_EventSource);
                                    495 ; genPointerSet
      00957A AE 53 43         [ 2]  496 	ldw	x, #0x5343
      00957D 7B 03            [ 1]  497 	ld	a, (0x03, sp)
      00957F F7               [ 1]  498 	ld	(x), a
                                    499 ; genLabel
      009580                        500 00101$:
                           0000D2   501 	Sstm8s_tim4$TIM4_GenerateEvent$110 ==.
                                    502 ;	../SPL/src/stm8s_tim4.c: 264: }
                                    503 ; genEndFunction
                           0000D2   504 	Sstm8s_tim4$TIM4_GenerateEvent$111 ==.
                           0000D2   505 	XG$TIM4_GenerateEvent$0$0 ==.
      009580 81               [ 4]  506 	ret
                           0000D3   507 	Sstm8s_tim4$TIM4_GenerateEvent$112 ==.
                           0000D3   508 	Sstm8s_tim4$TIM4_SetCounter$113 ==.
                                    509 ;	../SPL/src/stm8s_tim4.c: 272: void TIM4_SetCounter(uint8_t Counter)
                                    510 ; genLabel
                                    511 ;	-----------------------------------------
                                    512 ;	 function TIM4_SetCounter
                                    513 ;	-----------------------------------------
                                    514 ;	Register assignment is optimal.
                                    515 ;	Stack space usage: 0 bytes.
      009581                        516 _TIM4_SetCounter:
                           0000D3   517 	Sstm8s_tim4$TIM4_SetCounter$114 ==.
                           0000D3   518 	Sstm8s_tim4$TIM4_SetCounter$115 ==.
                                    519 ;	../SPL/src/stm8s_tim4.c: 275: TIM4->CNTR = (uint8_t)(Counter);
                                    520 ; genPointerSet
      009581 AE 53 44         [ 2]  521 	ldw	x, #0x5344
      009584 7B 03            [ 1]  522 	ld	a, (0x03, sp)
      009586 F7               [ 1]  523 	ld	(x), a
                                    524 ; genLabel
      009587                        525 00101$:
                           0000D9   526 	Sstm8s_tim4$TIM4_SetCounter$116 ==.
                                    527 ;	../SPL/src/stm8s_tim4.c: 276: }
                                    528 ; genEndFunction
                           0000D9   529 	Sstm8s_tim4$TIM4_SetCounter$117 ==.
                           0000D9   530 	XG$TIM4_SetCounter$0$0 ==.
      009587 81               [ 4]  531 	ret
                           0000DA   532 	Sstm8s_tim4$TIM4_SetCounter$118 ==.
                           0000DA   533 	Sstm8s_tim4$TIM4_SetAutoreload$119 ==.
                                    534 ;	../SPL/src/stm8s_tim4.c: 284: void TIM4_SetAutoreload(uint8_t Autoreload)
                                    535 ; genLabel
                                    536 ;	-----------------------------------------
                                    537 ;	 function TIM4_SetAutoreload
                                    538 ;	-----------------------------------------
                                    539 ;	Register assignment is optimal.
                                    540 ;	Stack space usage: 0 bytes.
      009588                        541 _TIM4_SetAutoreload:
                           0000DA   542 	Sstm8s_tim4$TIM4_SetAutoreload$120 ==.
                           0000DA   543 	Sstm8s_tim4$TIM4_SetAutoreload$121 ==.
                                    544 ;	../SPL/src/stm8s_tim4.c: 287: TIM4->ARR = (uint8_t)(Autoreload);
                                    545 ; genPointerSet
      009588 AE 53 46         [ 2]  546 	ldw	x, #0x5346
      00958B 7B 03            [ 1]  547 	ld	a, (0x03, sp)
      00958D F7               [ 1]  548 	ld	(x), a
                                    549 ; genLabel
      00958E                        550 00101$:
                           0000E0   551 	Sstm8s_tim4$TIM4_SetAutoreload$122 ==.
                                    552 ;	../SPL/src/stm8s_tim4.c: 288: }
                                    553 ; genEndFunction
                           0000E0   554 	Sstm8s_tim4$TIM4_SetAutoreload$123 ==.
                           0000E0   555 	XG$TIM4_SetAutoreload$0$0 ==.
      00958E 81               [ 4]  556 	ret
                           0000E1   557 	Sstm8s_tim4$TIM4_SetAutoreload$124 ==.
                           0000E1   558 	Sstm8s_tim4$TIM4_GetCounter$125 ==.
                                    559 ;	../SPL/src/stm8s_tim4.c: 295: uint8_t TIM4_GetCounter(void)
                                    560 ; genLabel
                                    561 ;	-----------------------------------------
                                    562 ;	 function TIM4_GetCounter
                                    563 ;	-----------------------------------------
                                    564 ;	Register assignment is optimal.
                                    565 ;	Stack space usage: 0 bytes.
      00958F                        566 _TIM4_GetCounter:
                           0000E1   567 	Sstm8s_tim4$TIM4_GetCounter$126 ==.
                           0000E1   568 	Sstm8s_tim4$TIM4_GetCounter$127 ==.
                                    569 ;	../SPL/src/stm8s_tim4.c: 298: return (uint8_t)(TIM4->CNTR);
                                    570 ; genPointerGet
      00958F C6 53 44         [ 1]  571 	ld	a, 0x5344
                                    572 ; genReturn
                                    573 ; genLabel
      009592                        574 00101$:
                           0000E4   575 	Sstm8s_tim4$TIM4_GetCounter$128 ==.
                                    576 ;	../SPL/src/stm8s_tim4.c: 299: }
                                    577 ; genEndFunction
                           0000E4   578 	Sstm8s_tim4$TIM4_GetCounter$129 ==.
                           0000E4   579 	XG$TIM4_GetCounter$0$0 ==.
      009592 81               [ 4]  580 	ret
                           0000E5   581 	Sstm8s_tim4$TIM4_GetCounter$130 ==.
                           0000E5   582 	Sstm8s_tim4$TIM4_GetPrescaler$131 ==.
                                    583 ;	../SPL/src/stm8s_tim4.c: 306: TIM4_Prescaler_TypeDef TIM4_GetPrescaler(void)
                                    584 ; genLabel
                                    585 ;	-----------------------------------------
                                    586 ;	 function TIM4_GetPrescaler
                                    587 ;	-----------------------------------------
                                    588 ;	Register assignment is optimal.
                                    589 ;	Stack space usage: 0 bytes.
      009593                        590 _TIM4_GetPrescaler:
                           0000E5   591 	Sstm8s_tim4$TIM4_GetPrescaler$132 ==.
                           0000E5   592 	Sstm8s_tim4$TIM4_GetPrescaler$133 ==.
                                    593 ;	../SPL/src/stm8s_tim4.c: 309: return (TIM4_Prescaler_TypeDef)(TIM4->PSCR);
                                    594 ; genPointerGet
      009593 C6 53 45         [ 1]  595 	ld	a, 0x5345
                                    596 ; genReturn
                                    597 ; genLabel
      009596                        598 00101$:
                           0000E8   599 	Sstm8s_tim4$TIM4_GetPrescaler$134 ==.
                                    600 ;	../SPL/src/stm8s_tim4.c: 310: }
                                    601 ; genEndFunction
                           0000E8   602 	Sstm8s_tim4$TIM4_GetPrescaler$135 ==.
                           0000E8   603 	XG$TIM4_GetPrescaler$0$0 ==.
      009596 81               [ 4]  604 	ret
                           0000E9   605 	Sstm8s_tim4$TIM4_GetPrescaler$136 ==.
                           0000E9   606 	Sstm8s_tim4$TIM4_GetFlagStatus$137 ==.
                                    607 ;	../SPL/src/stm8s_tim4.c: 319: FlagStatus TIM4_GetFlagStatus(TIM4_FLAG_TypeDef TIM4_FLAG)
                                    608 ; genLabel
                                    609 ;	-----------------------------------------
                                    610 ;	 function TIM4_GetFlagStatus
                                    611 ;	-----------------------------------------
                                    612 ;	Register assignment is optimal.
                                    613 ;	Stack space usage: 0 bytes.
      009597                        614 _TIM4_GetFlagStatus:
                           0000E9   615 	Sstm8s_tim4$TIM4_GetFlagStatus$138 ==.
                           0000E9   616 	Sstm8s_tim4$TIM4_GetFlagStatus$139 ==.
                                    617 ;	../SPL/src/stm8s_tim4.c: 326: if ((TIM4->SR1 & (uint8_t)TIM4_FLAG)  != 0)
                                    618 ; genPointerGet
      009597 C6 53 42         [ 1]  619 	ld	a, 0x5342
                                    620 ; genAnd
      00959A 14 03            [ 1]  621 	and	a, (0x03, sp)
                                    622 ; genIfx
      00959C 4D               [ 1]  623 	tnz	a
      00959D 26 03            [ 1]  624 	jrne	00111$
      00959F CC 95 A7         [ 2]  625 	jp	00102$
      0095A2                        626 00111$:
                           0000F4   627 	Sstm8s_tim4$TIM4_GetFlagStatus$140 ==.
                           0000F4   628 	Sstm8s_tim4$TIM4_GetFlagStatus$141 ==.
                                    629 ;	../SPL/src/stm8s_tim4.c: 328: bitstatus = SET;
                                    630 ; genAssign
      0095A2 A6 01            [ 1]  631 	ld	a, #0x01
                           0000F6   632 	Sstm8s_tim4$TIM4_GetFlagStatus$142 ==.
                                    633 ; genGoto
      0095A4 CC 95 A8         [ 2]  634 	jp	00103$
                                    635 ; genLabel
      0095A7                        636 00102$:
                           0000F9   637 	Sstm8s_tim4$TIM4_GetFlagStatus$143 ==.
                           0000F9   638 	Sstm8s_tim4$TIM4_GetFlagStatus$144 ==.
                                    639 ;	../SPL/src/stm8s_tim4.c: 332: bitstatus = RESET;
                                    640 ; genAssign
      0095A7 4F               [ 1]  641 	clr	a
                           0000FA   642 	Sstm8s_tim4$TIM4_GetFlagStatus$145 ==.
                                    643 ; genLabel
      0095A8                        644 00103$:
                           0000FA   645 	Sstm8s_tim4$TIM4_GetFlagStatus$146 ==.
                                    646 ;	../SPL/src/stm8s_tim4.c: 334: return ((FlagStatus)bitstatus);
                                    647 ; genReturn
                                    648 ; genLabel
      0095A8                        649 00104$:
                           0000FA   650 	Sstm8s_tim4$TIM4_GetFlagStatus$147 ==.
                                    651 ;	../SPL/src/stm8s_tim4.c: 335: }
                                    652 ; genEndFunction
                           0000FA   653 	Sstm8s_tim4$TIM4_GetFlagStatus$148 ==.
                           0000FA   654 	XG$TIM4_GetFlagStatus$0$0 ==.
      0095A8 81               [ 4]  655 	ret
                           0000FB   656 	Sstm8s_tim4$TIM4_GetFlagStatus$149 ==.
                           0000FB   657 	Sstm8s_tim4$TIM4_ClearFlag$150 ==.
                                    658 ;	../SPL/src/stm8s_tim4.c: 344: void TIM4_ClearFlag(TIM4_FLAG_TypeDef TIM4_FLAG)
                                    659 ; genLabel
                                    660 ;	-----------------------------------------
                                    661 ;	 function TIM4_ClearFlag
                                    662 ;	-----------------------------------------
                                    663 ;	Register assignment is optimal.
                                    664 ;	Stack space usage: 0 bytes.
      0095A9                        665 _TIM4_ClearFlag:
                           0000FB   666 	Sstm8s_tim4$TIM4_ClearFlag$151 ==.
                           0000FB   667 	Sstm8s_tim4$TIM4_ClearFlag$152 ==.
                                    668 ;	../SPL/src/stm8s_tim4.c: 350: TIM4->SR1 = (uint8_t)(~TIM4_FLAG);
                                    669 ; genCpl
      0095A9 7B 03            [ 1]  670 	ld	a, (0x03, sp)
      0095AB 43               [ 1]  671 	cpl	a
                                    672 ; genPointerSet
      0095AC C7 53 42         [ 1]  673 	ld	0x5342, a
                                    674 ; genLabel
      0095AF                        675 00101$:
                           000101   676 	Sstm8s_tim4$TIM4_ClearFlag$153 ==.
                                    677 ;	../SPL/src/stm8s_tim4.c: 351: }
                                    678 ; genEndFunction
                           000101   679 	Sstm8s_tim4$TIM4_ClearFlag$154 ==.
                           000101   680 	XG$TIM4_ClearFlag$0$0 ==.
      0095AF 81               [ 4]  681 	ret
                           000102   682 	Sstm8s_tim4$TIM4_ClearFlag$155 ==.
                           000102   683 	Sstm8s_tim4$TIM4_GetITStatus$156 ==.
                                    684 ;	../SPL/src/stm8s_tim4.c: 360: ITStatus TIM4_GetITStatus(TIM4_IT_TypeDef TIM4_IT)
                                    685 ; genLabel
                                    686 ;	-----------------------------------------
                                    687 ;	 function TIM4_GetITStatus
                                    688 ;	-----------------------------------------
                                    689 ;	Register assignment is optimal.
                                    690 ;	Stack space usage: 1 bytes.
      0095B0                        691 _TIM4_GetITStatus:
                           000102   692 	Sstm8s_tim4$TIM4_GetITStatus$157 ==.
      0095B0 88               [ 1]  693 	push	a
                           000103   694 	Sstm8s_tim4$TIM4_GetITStatus$158 ==.
                           000103   695 	Sstm8s_tim4$TIM4_GetITStatus$159 ==.
                                    696 ;	../SPL/src/stm8s_tim4.c: 369: itstatus = (uint8_t)(TIM4->SR1 & (uint8_t)TIM4_IT);
                                    697 ; genPointerGet
      0095B1 C6 53 42         [ 1]  698 	ld	a, 0x5342
                                    699 ; genAnd
      0095B4 14 04            [ 1]  700 	and	a, (0x04, sp)
                                    701 ; genAssign
      0095B6 6B 01            [ 1]  702 	ld	(0x01, sp), a
                           00010A   703 	Sstm8s_tim4$TIM4_GetITStatus$160 ==.
                                    704 ;	../SPL/src/stm8s_tim4.c: 371: itenable = (uint8_t)(TIM4->IER & (uint8_t)TIM4_IT);
                                    705 ; genPointerGet
      0095B8 C6 53 41         [ 1]  706 	ld	a, 0x5341
                                    707 ; genAnd
      0095BB 14 04            [ 1]  708 	and	a, (0x04, sp)
                                    709 ; genAssign
                           00010F   710 	Sstm8s_tim4$TIM4_GetITStatus$161 ==.
                                    711 ;	../SPL/src/stm8s_tim4.c: 373: if ((itstatus != (uint8_t)RESET ) && (itenable != (uint8_t)RESET ))
                                    712 ; genIfx
      0095BD 0D 01            [ 1]  713 	tnz	(0x01, sp)
      0095BF 26 03            [ 1]  714 	jrne	00117$
      0095C1 CC 95 CF         [ 2]  715 	jp	00102$
      0095C4                        716 00117$:
                                    717 ; genIfx
      0095C4 4D               [ 1]  718 	tnz	a
      0095C5 26 03            [ 1]  719 	jrne	00118$
      0095C7 CC 95 CF         [ 2]  720 	jp	00102$
      0095CA                        721 00118$:
                           00011C   722 	Sstm8s_tim4$TIM4_GetITStatus$162 ==.
                           00011C   723 	Sstm8s_tim4$TIM4_GetITStatus$163 ==.
                                    724 ;	../SPL/src/stm8s_tim4.c: 375: bitstatus = (ITStatus)SET;
                                    725 ; genAssign
      0095CA A6 01            [ 1]  726 	ld	a, #0x01
                           00011E   727 	Sstm8s_tim4$TIM4_GetITStatus$164 ==.
                                    728 ; genGoto
      0095CC CC 95 D0         [ 2]  729 	jp	00103$
                                    730 ; genLabel
      0095CF                        731 00102$:
                           000121   732 	Sstm8s_tim4$TIM4_GetITStatus$165 ==.
                           000121   733 	Sstm8s_tim4$TIM4_GetITStatus$166 ==.
                                    734 ;	../SPL/src/stm8s_tim4.c: 379: bitstatus = (ITStatus)RESET;
                                    735 ; genAssign
      0095CF 4F               [ 1]  736 	clr	a
                           000122   737 	Sstm8s_tim4$TIM4_GetITStatus$167 ==.
                                    738 ; genLabel
      0095D0                        739 00103$:
                           000122   740 	Sstm8s_tim4$TIM4_GetITStatus$168 ==.
                                    741 ;	../SPL/src/stm8s_tim4.c: 381: return ((ITStatus)bitstatus);
                                    742 ; genReturn
                                    743 ; genLabel
      0095D0                        744 00105$:
                           000122   745 	Sstm8s_tim4$TIM4_GetITStatus$169 ==.
                                    746 ;	../SPL/src/stm8s_tim4.c: 382: }
                                    747 ; genEndFunction
      0095D0 5B 01            [ 2]  748 	addw	sp, #1
                           000124   749 	Sstm8s_tim4$TIM4_GetITStatus$170 ==.
                           000124   750 	Sstm8s_tim4$TIM4_GetITStatus$171 ==.
                           000124   751 	XG$TIM4_GetITStatus$0$0 ==.
      0095D2 81               [ 4]  752 	ret
                           000125   753 	Sstm8s_tim4$TIM4_GetITStatus$172 ==.
                           000125   754 	Sstm8s_tim4$TIM4_ClearITPendingBit$173 ==.
                                    755 ;	../SPL/src/stm8s_tim4.c: 391: void TIM4_ClearITPendingBit(TIM4_IT_TypeDef TIM4_IT)
                                    756 ; genLabel
                                    757 ;	-----------------------------------------
                                    758 ;	 function TIM4_ClearITPendingBit
                                    759 ;	-----------------------------------------
                                    760 ;	Register assignment is optimal.
                                    761 ;	Stack space usage: 0 bytes.
      0095D3                        762 _TIM4_ClearITPendingBit:
                           000125   763 	Sstm8s_tim4$TIM4_ClearITPendingBit$174 ==.
                           000125   764 	Sstm8s_tim4$TIM4_ClearITPendingBit$175 ==.
                                    765 ;	../SPL/src/stm8s_tim4.c: 397: TIM4->SR1 = (uint8_t)(~TIM4_IT);
                                    766 ; genCpl
      0095D3 7B 03            [ 1]  767 	ld	a, (0x03, sp)
      0095D5 43               [ 1]  768 	cpl	a
                                    769 ; genPointerSet
      0095D6 C7 53 42         [ 1]  770 	ld	0x5342, a
                                    771 ; genLabel
      0095D9                        772 00101$:
                           00012B   773 	Sstm8s_tim4$TIM4_ClearITPendingBit$176 ==.
                                    774 ;	../SPL/src/stm8s_tim4.c: 398: }
                                    775 ; genEndFunction
                           00012B   776 	Sstm8s_tim4$TIM4_ClearITPendingBit$177 ==.
                           00012B   777 	XG$TIM4_ClearITPendingBit$0$0 ==.
      0095D9 81               [ 4]  778 	ret
                           00012C   779 	Sstm8s_tim4$TIM4_ClearITPendingBit$178 ==.
                                    780 	.area CODE
                                    781 	.area CONST
                                    782 	.area INITIALIZER
                                    783 	.area CABS (ABS)
                                    784 
                                    785 	.area .debug_line (NOLOAD)
      001D0D 00 00 03 4D            786 	.dw	0,Ldebug_line_end-Ldebug_line_start
      001D11                        787 Ldebug_line_start:
      001D11 00 02                  788 	.dw	2
      001D13 00 00 00 78            789 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      001D17 01                     790 	.db	1
      001D18 01                     791 	.db	1
      001D19 FB                     792 	.db	-5
      001D1A 0F                     793 	.db	15
      001D1B 0A                     794 	.db	10
      001D1C 00                     795 	.db	0
      001D1D 01                     796 	.db	1
      001D1E 01                     797 	.db	1
      001D1F 01                     798 	.db	1
      001D20 01                     799 	.db	1
      001D21 00                     800 	.db	0
      001D22 00                     801 	.db	0
      001D23 00                     802 	.db	0
      001D24 01                     803 	.db	1
      001D25 43 3A 5C 50 72 6F 67   804 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      001D4D 00                     805 	.db	0
      001D4E 43 3A 5C 50 72 6F 67   806 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      001D71 00                     807 	.db	0
      001D72 00                     808 	.db	0
      001D73 2E 2E 2F 53 50 4C 2F   809 	.ascii "../SPL/src/stm8s_tim4.c"
             73 72 63 2F 73 74 6D
             38 73 5F 74 69 6D 34
             2E 63
      001D8A 00                     810 	.db	0
      001D8B 00                     811 	.uleb128	0
      001D8C 00                     812 	.uleb128	0
      001D8D 00                     813 	.uleb128	0
      001D8E 00                     814 	.db	0
      001D8F                        815 Ldebug_line_stmt:
      001D8F 00                     816 	.db	0
      001D90 05                     817 	.uleb128	5
      001D91 02                     818 	.db	2
      001D92 00 00 94 AE            819 	.dw	0,(Sstm8s_tim4$TIM4_DeInit$0)
      001D96 03                     820 	.db	3
      001D97 30                     821 	.sleb128	48
      001D98 01                     822 	.db	1
      001D99 09                     823 	.db	9
      001D9A 00 00                  824 	.dw	Sstm8s_tim4$TIM4_DeInit$2-Sstm8s_tim4$TIM4_DeInit$0
      001D9C 03                     825 	.db	3
      001D9D 02                     826 	.sleb128	2
      001D9E 01                     827 	.db	1
      001D9F 09                     828 	.db	9
      001DA0 00 04                  829 	.dw	Sstm8s_tim4$TIM4_DeInit$3-Sstm8s_tim4$TIM4_DeInit$2
      001DA2 03                     830 	.db	3
      001DA3 01                     831 	.sleb128	1
      001DA4 01                     832 	.db	1
      001DA5 09                     833 	.db	9
      001DA6 00 04                  834 	.dw	Sstm8s_tim4$TIM4_DeInit$4-Sstm8s_tim4$TIM4_DeInit$3
      001DA8 03                     835 	.db	3
      001DA9 01                     836 	.sleb128	1
      001DAA 01                     837 	.db	1
      001DAB 09                     838 	.db	9
      001DAC 00 04                  839 	.dw	Sstm8s_tim4$TIM4_DeInit$5-Sstm8s_tim4$TIM4_DeInit$4
      001DAE 03                     840 	.db	3
      001DAF 01                     841 	.sleb128	1
      001DB0 01                     842 	.db	1
      001DB1 09                     843 	.db	9
      001DB2 00 04                  844 	.dw	Sstm8s_tim4$TIM4_DeInit$6-Sstm8s_tim4$TIM4_DeInit$5
      001DB4 03                     845 	.db	3
      001DB5 01                     846 	.sleb128	1
      001DB6 01                     847 	.db	1
      001DB7 09                     848 	.db	9
      001DB8 00 04                  849 	.dw	Sstm8s_tim4$TIM4_DeInit$7-Sstm8s_tim4$TIM4_DeInit$6
      001DBA 03                     850 	.db	3
      001DBB 01                     851 	.sleb128	1
      001DBC 01                     852 	.db	1
      001DBD 09                     853 	.db	9
      001DBE 00 04                  854 	.dw	Sstm8s_tim4$TIM4_DeInit$8-Sstm8s_tim4$TIM4_DeInit$7
      001DC0 03                     855 	.db	3
      001DC1 01                     856 	.sleb128	1
      001DC2 01                     857 	.db	1
      001DC3 09                     858 	.db	9
      001DC4 00 01                  859 	.dw	1+Sstm8s_tim4$TIM4_DeInit$9-Sstm8s_tim4$TIM4_DeInit$8
      001DC6 00                     860 	.db	0
      001DC7 01                     861 	.uleb128	1
      001DC8 01                     862 	.db	1
      001DC9 00                     863 	.db	0
      001DCA 05                     864 	.uleb128	5
      001DCB 02                     865 	.db	2
      001DCC 00 00 94 C7            866 	.dw	0,(Sstm8s_tim4$TIM4_TimeBaseInit$11)
      001DD0 03                     867 	.db	3
      001DD1 C0 00                  868 	.sleb128	64
      001DD3 01                     869 	.db	1
      001DD4 09                     870 	.db	9
      001DD5 00 00                  871 	.dw	Sstm8s_tim4$TIM4_TimeBaseInit$13-Sstm8s_tim4$TIM4_TimeBaseInit$11
      001DD7 03                     872 	.db	3
      001DD8 05                     873 	.sleb128	5
      001DD9 01                     874 	.db	1
      001DDA 09                     875 	.db	9
      001DDB 00 06                  876 	.dw	Sstm8s_tim4$TIM4_TimeBaseInit$14-Sstm8s_tim4$TIM4_TimeBaseInit$13
      001DDD 03                     877 	.db	3
      001DDE 02                     878 	.sleb128	2
      001DDF 01                     879 	.db	1
      001DE0 09                     880 	.db	9
      001DE1 00 06                  881 	.dw	Sstm8s_tim4$TIM4_TimeBaseInit$15-Sstm8s_tim4$TIM4_TimeBaseInit$14
      001DE3 03                     882 	.db	3
      001DE4 01                     883 	.sleb128	1
      001DE5 01                     884 	.db	1
      001DE6 09                     885 	.db	9
      001DE7 00 01                  886 	.dw	1+Sstm8s_tim4$TIM4_TimeBaseInit$16-Sstm8s_tim4$TIM4_TimeBaseInit$15
      001DE9 00                     887 	.db	0
      001DEA 01                     888 	.uleb128	1
      001DEB 01                     889 	.db	1
      001DEC 00                     890 	.db	0
      001DED 05                     891 	.uleb128	5
      001DEE 02                     892 	.db	2
      001DEF 00 00 94 D4            893 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$18)
      001DF3 03                     894 	.db	3
      001DF4 D0 00                  895 	.sleb128	80
      001DF6 01                     896 	.db	1
      001DF7 09                     897 	.db	9
      001DF8 00 00                  898 	.dw	Sstm8s_tim4$TIM4_Cmd$20-Sstm8s_tim4$TIM4_Cmd$18
      001DFA 03                     899 	.db	3
      001DFB 08                     900 	.sleb128	8
      001DFC 01                     901 	.db	1
      001DFD 09                     902 	.db	9
      001DFE 00 03                  903 	.dw	Sstm8s_tim4$TIM4_Cmd$21-Sstm8s_tim4$TIM4_Cmd$20
      001E00 03                     904 	.db	3
      001E01 7E                     905 	.sleb128	-2
      001E02 01                     906 	.db	1
      001E03 09                     907 	.db	9
      001E04 00 07                  908 	.dw	Sstm8s_tim4$TIM4_Cmd$23-Sstm8s_tim4$TIM4_Cmd$21
      001E06 03                     909 	.db	3
      001E07 02                     910 	.sleb128	2
      001E08 01                     911 	.db	1
      001E09 09                     912 	.db	9
      001E0A 00 08                  913 	.dw	Sstm8s_tim4$TIM4_Cmd$26-Sstm8s_tim4$TIM4_Cmd$23
      001E0C 03                     914 	.db	3
      001E0D 04                     915 	.sleb128	4
      001E0E 01                     916 	.db	1
      001E0F 09                     917 	.db	9
      001E10 00 05                  918 	.dw	Sstm8s_tim4$TIM4_Cmd$28-Sstm8s_tim4$TIM4_Cmd$26
      001E12 03                     919 	.db	3
      001E13 02                     920 	.sleb128	2
      001E14 01                     921 	.db	1
      001E15 09                     922 	.db	9
      001E16 00 01                  923 	.dw	1+Sstm8s_tim4$TIM4_Cmd$29-Sstm8s_tim4$TIM4_Cmd$28
      001E18 00                     924 	.db	0
      001E19 01                     925 	.uleb128	1
      001E1A 01                     926 	.db	1
      001E1B 00                     927 	.db	0
      001E1C 05                     928 	.uleb128	5
      001E1D 02                     929 	.db	2
      001E1E 00 00 94 EC            930 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$31)
      001E22 03                     931 	.db	3
      001E23 EA 00                  932 	.sleb128	106
      001E25 01                     933 	.db	1
      001E26 09                     934 	.db	9
      001E27 00 01                  935 	.dw	Sstm8s_tim4$TIM4_ITConfig$34-Sstm8s_tim4$TIM4_ITConfig$31
      001E29 03                     936 	.db	3
      001E2A 09                     937 	.sleb128	9
      001E2B 01                     938 	.db	1
      001E2C 09                     939 	.db	9
      001E2D 00 03                  940 	.dw	Sstm8s_tim4$TIM4_ITConfig$35-Sstm8s_tim4$TIM4_ITConfig$34
      001E2F 03                     941 	.db	3
      001E30 7D                     942 	.sleb128	-3
      001E31 01                     943 	.db	1
      001E32 09                     944 	.db	9
      001E33 00 07                  945 	.dw	Sstm8s_tim4$TIM4_ITConfig$37-Sstm8s_tim4$TIM4_ITConfig$35
      001E35 03                     946 	.db	3
      001E36 03                     947 	.sleb128	3
      001E37 01                     948 	.db	1
      001E38 09                     949 	.db	9
      001E39 00 08                  950 	.dw	Sstm8s_tim4$TIM4_ITConfig$40-Sstm8s_tim4$TIM4_ITConfig$37
      001E3B 03                     951 	.db	3
      001E3C 05                     952 	.sleb128	5
      001E3D 01                     953 	.db	1
      001E3E 09                     954 	.db	9
      001E3F 00 0C                  955 	.dw	Sstm8s_tim4$TIM4_ITConfig$44-Sstm8s_tim4$TIM4_ITConfig$40
      001E41 03                     956 	.db	3
      001E42 02                     957 	.sleb128	2
      001E43 01                     958 	.db	1
      001E44 09                     959 	.db	9
      001E45 00 02                  960 	.dw	1+Sstm8s_tim4$TIM4_ITConfig$46-Sstm8s_tim4$TIM4_ITConfig$44
      001E47 00                     961 	.db	0
      001E48 01                     962 	.uleb128	1
      001E49 01                     963 	.db	1
      001E4A 00                     964 	.db	0
      001E4B 05                     965 	.uleb128	5
      001E4C 02                     966 	.db	2
      001E4D 00 00 95 0D            967 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$48)
      001E51 03                     968 	.db	3
      001E52 82 01                  969 	.sleb128	130
      001E54 01                     970 	.db	1
      001E55 09                     971 	.db	9
      001E56 00 00                  972 	.dw	Sstm8s_tim4$TIM4_UpdateDisableConfig$50-Sstm8s_tim4$TIM4_UpdateDisableConfig$48
      001E58 03                     973 	.db	3
      001E59 08                     974 	.sleb128	8
      001E5A 01                     975 	.db	1
      001E5B 09                     976 	.db	9
      001E5C 00 03                  977 	.dw	Sstm8s_tim4$TIM4_UpdateDisableConfig$51-Sstm8s_tim4$TIM4_UpdateDisableConfig$50
      001E5E 03                     978 	.db	3
      001E5F 7E                     979 	.sleb128	-2
      001E60 01                     980 	.db	1
      001E61 09                     981 	.db	9
      001E62 00 07                  982 	.dw	Sstm8s_tim4$TIM4_UpdateDisableConfig$53-Sstm8s_tim4$TIM4_UpdateDisableConfig$51
      001E64 03                     983 	.db	3
      001E65 02                     984 	.sleb128	2
      001E66 01                     985 	.db	1
      001E67 09                     986 	.db	9
      001E68 00 08                  987 	.dw	Sstm8s_tim4$TIM4_UpdateDisableConfig$56-Sstm8s_tim4$TIM4_UpdateDisableConfig$53
      001E6A 03                     988 	.db	3
      001E6B 04                     989 	.sleb128	4
      001E6C 01                     990 	.db	1
      001E6D 09                     991 	.db	9
      001E6E 00 05                  992 	.dw	Sstm8s_tim4$TIM4_UpdateDisableConfig$58-Sstm8s_tim4$TIM4_UpdateDisableConfig$56
      001E70 03                     993 	.db	3
      001E71 02                     994 	.sleb128	2
      001E72 01                     995 	.db	1
      001E73 09                     996 	.db	9
      001E74 00 01                  997 	.dw	1+Sstm8s_tim4$TIM4_UpdateDisableConfig$59-Sstm8s_tim4$TIM4_UpdateDisableConfig$58
      001E76 00                     998 	.db	0
      001E77 01                     999 	.uleb128	1
      001E78 01                    1000 	.db	1
      001E79 00                    1001 	.db	0
      001E7A 05                    1002 	.uleb128	5
      001E7B 02                    1003 	.db	2
      001E7C 00 00 95 25           1004 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$61)
      001E80 03                    1005 	.db	3
      001E81 9A 01                 1006 	.sleb128	154
      001E83 01                    1007 	.db	1
      001E84 09                    1008 	.db	9
      001E85 00 00                 1009 	.dw	Sstm8s_tim4$TIM4_UpdateRequestConfig$63-Sstm8s_tim4$TIM4_UpdateRequestConfig$61
      001E87 03                    1010 	.db	3
      001E88 08                    1011 	.sleb128	8
      001E89 01                    1012 	.db	1
      001E8A 09                    1013 	.db	9
      001E8B 00 03                 1014 	.dw	Sstm8s_tim4$TIM4_UpdateRequestConfig$64-Sstm8s_tim4$TIM4_UpdateRequestConfig$63
      001E8D 03                    1015 	.db	3
      001E8E 7E                    1016 	.sleb128	-2
      001E8F 01                    1017 	.db	1
      001E90 09                    1018 	.db	9
      001E91 00 07                 1019 	.dw	Sstm8s_tim4$TIM4_UpdateRequestConfig$66-Sstm8s_tim4$TIM4_UpdateRequestConfig$64
      001E93 03                    1020 	.db	3
      001E94 02                    1021 	.sleb128	2
      001E95 01                    1022 	.db	1
      001E96 09                    1023 	.db	9
      001E97 00 08                 1024 	.dw	Sstm8s_tim4$TIM4_UpdateRequestConfig$69-Sstm8s_tim4$TIM4_UpdateRequestConfig$66
      001E99 03                    1025 	.db	3
      001E9A 04                    1026 	.sleb128	4
      001E9B 01                    1027 	.db	1
      001E9C 09                    1028 	.db	9
      001E9D 00 05                 1029 	.dw	Sstm8s_tim4$TIM4_UpdateRequestConfig$71-Sstm8s_tim4$TIM4_UpdateRequestConfig$69
      001E9F 03                    1030 	.db	3
      001EA0 02                    1031 	.sleb128	2
      001EA1 01                    1032 	.db	1
      001EA2 09                    1033 	.db	9
      001EA3 00 01                 1034 	.dw	1+Sstm8s_tim4$TIM4_UpdateRequestConfig$72-Sstm8s_tim4$TIM4_UpdateRequestConfig$71
      001EA5 00                    1035 	.db	0
      001EA6 01                    1036 	.uleb128	1
      001EA7 01                    1037 	.db	1
      001EA8 00                    1038 	.db	0
      001EA9 05                    1039 	.uleb128	5
      001EAA 02                    1040 	.db	2
      001EAB 00 00 95 3D           1041 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$74)
      001EAF 03                    1042 	.db	3
      001EB0 B2 01                 1043 	.sleb128	178
      001EB2 01                    1044 	.db	1
      001EB3 09                    1045 	.db	9
      001EB4 00 00                 1046 	.dw	Sstm8s_tim4$TIM4_SelectOnePulseMode$76-Sstm8s_tim4$TIM4_SelectOnePulseMode$74
      001EB6 03                    1047 	.db	3
      001EB7 08                    1048 	.sleb128	8
      001EB8 01                    1049 	.db	1
      001EB9 09                    1050 	.db	9
      001EBA 00 03                 1051 	.dw	Sstm8s_tim4$TIM4_SelectOnePulseMode$77-Sstm8s_tim4$TIM4_SelectOnePulseMode$76
      001EBC 03                    1052 	.db	3
      001EBD 7E                    1053 	.sleb128	-2
      001EBE 01                    1054 	.db	1
      001EBF 09                    1055 	.db	9
      001EC0 00 07                 1056 	.dw	Sstm8s_tim4$TIM4_SelectOnePulseMode$79-Sstm8s_tim4$TIM4_SelectOnePulseMode$77
      001EC2 03                    1057 	.db	3
      001EC3 02                    1058 	.sleb128	2
      001EC4 01                    1059 	.db	1
      001EC5 09                    1060 	.db	9
      001EC6 00 08                 1061 	.dw	Sstm8s_tim4$TIM4_SelectOnePulseMode$82-Sstm8s_tim4$TIM4_SelectOnePulseMode$79
      001EC8 03                    1062 	.db	3
      001EC9 04                    1063 	.sleb128	4
      001ECA 01                    1064 	.db	1
      001ECB 09                    1065 	.db	9
      001ECC 00 05                 1066 	.dw	Sstm8s_tim4$TIM4_SelectOnePulseMode$84-Sstm8s_tim4$TIM4_SelectOnePulseMode$82
      001ECE 03                    1067 	.db	3
      001ECF 02                    1068 	.sleb128	2
      001ED0 01                    1069 	.db	1
      001ED1 09                    1070 	.db	9
      001ED2 00 01                 1071 	.dw	1+Sstm8s_tim4$TIM4_SelectOnePulseMode$85-Sstm8s_tim4$TIM4_SelectOnePulseMode$84
      001ED4 00                    1072 	.db	0
      001ED5 01                    1073 	.uleb128	1
      001ED6 01                    1074 	.db	1
      001ED7 00                    1075 	.db	0
      001ED8 05                    1076 	.uleb128	5
      001ED9 02                    1077 	.db	2
      001EDA 00 00 95 55           1078 	.dw	0,(Sstm8s_tim4$TIM4_PrescalerConfig$87)
      001EDE 03                    1079 	.db	3
      001EDF D6 01                 1080 	.sleb128	214
      001EE1 01                    1081 	.db	1
      001EE2 09                    1082 	.db	9
      001EE3 00 00                 1083 	.dw	Sstm8s_tim4$TIM4_PrescalerConfig$89-Sstm8s_tim4$TIM4_PrescalerConfig$87
      001EE5 03                    1084 	.db	3
      001EE6 07                    1085 	.sleb128	7
      001EE7 01                    1086 	.db	1
      001EE8 09                    1087 	.db	9
      001EE9 00 06                 1088 	.dw	Sstm8s_tim4$TIM4_PrescalerConfig$90-Sstm8s_tim4$TIM4_PrescalerConfig$89
      001EEB 03                    1089 	.db	3
      001EEC 03                    1090 	.sleb128	3
      001EED 01                    1091 	.db	1
      001EEE 09                    1092 	.db	9
      001EEF 00 06                 1093 	.dw	Sstm8s_tim4$TIM4_PrescalerConfig$91-Sstm8s_tim4$TIM4_PrescalerConfig$90
      001EF1 03                    1094 	.db	3
      001EF2 01                    1095 	.sleb128	1
      001EF3 01                    1096 	.db	1
      001EF4 09                    1097 	.db	9
      001EF5 00 01                 1098 	.dw	1+Sstm8s_tim4$TIM4_PrescalerConfig$92-Sstm8s_tim4$TIM4_PrescalerConfig$91
      001EF7 00                    1099 	.db	0
      001EF8 01                    1100 	.uleb128	1
      001EF9 01                    1101 	.db	1
      001EFA 00                    1102 	.db	0
      001EFB 05                    1103 	.uleb128	5
      001EFC 02                    1104 	.db	2
      001EFD 00 00 95 62           1105 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$94)
      001F01 03                    1106 	.db	3
      001F02 E9 01                 1107 	.sleb128	233
      001F04 01                    1108 	.db	1
      001F05 09                    1109 	.db	9
      001F06 00 00                 1110 	.dw	Sstm8s_tim4$TIM4_ARRPreloadConfig$96-Sstm8s_tim4$TIM4_ARRPreloadConfig$94
      001F08 03                    1111 	.db	3
      001F09 08                    1112 	.sleb128	8
      001F0A 01                    1113 	.db	1
      001F0B 09                    1114 	.db	9
      001F0C 00 03                 1115 	.dw	Sstm8s_tim4$TIM4_ARRPreloadConfig$97-Sstm8s_tim4$TIM4_ARRPreloadConfig$96
      001F0E 03                    1116 	.db	3
      001F0F 7E                    1117 	.sleb128	-2
      001F10 01                    1118 	.db	1
      001F11 09                    1119 	.db	9
      001F12 00 07                 1120 	.dw	Sstm8s_tim4$TIM4_ARRPreloadConfig$99-Sstm8s_tim4$TIM4_ARRPreloadConfig$97
      001F14 03                    1121 	.db	3
      001F15 02                    1122 	.sleb128	2
      001F16 01                    1123 	.db	1
      001F17 09                    1124 	.db	9
      001F18 00 08                 1125 	.dw	Sstm8s_tim4$TIM4_ARRPreloadConfig$102-Sstm8s_tim4$TIM4_ARRPreloadConfig$99
      001F1A 03                    1126 	.db	3
      001F1B 04                    1127 	.sleb128	4
      001F1C 01                    1128 	.db	1
      001F1D 09                    1129 	.db	9
      001F1E 00 05                 1130 	.dw	Sstm8s_tim4$TIM4_ARRPreloadConfig$104-Sstm8s_tim4$TIM4_ARRPreloadConfig$102
      001F20 03                    1131 	.db	3
      001F21 02                    1132 	.sleb128	2
      001F22 01                    1133 	.db	1
      001F23 09                    1134 	.db	9
      001F24 00 01                 1135 	.dw	1+Sstm8s_tim4$TIM4_ARRPreloadConfig$105-Sstm8s_tim4$TIM4_ARRPreloadConfig$104
      001F26 00                    1136 	.db	0
      001F27 01                    1137 	.uleb128	1
      001F28 01                    1138 	.db	1
      001F29 00                    1139 	.db	0
      001F2A 05                    1140 	.uleb128	5
      001F2B 02                    1141 	.db	2
      001F2C 00 00 95 7A           1142 	.dw	0,(Sstm8s_tim4$TIM4_GenerateEvent$107)
      001F30 03                    1143 	.db	3
      001F31 80 02                 1144 	.sleb128	256
      001F33 01                    1145 	.db	1
      001F34 09                    1146 	.db	9
      001F35 00 00                 1147 	.dw	Sstm8s_tim4$TIM4_GenerateEvent$109-Sstm8s_tim4$TIM4_GenerateEvent$107
      001F37 03                    1148 	.db	3
      001F38 06                    1149 	.sleb128	6
      001F39 01                    1150 	.db	1
      001F3A 09                    1151 	.db	9
      001F3B 00 06                 1152 	.dw	Sstm8s_tim4$TIM4_GenerateEvent$110-Sstm8s_tim4$TIM4_GenerateEvent$109
      001F3D 03                    1153 	.db	3
      001F3E 01                    1154 	.sleb128	1
      001F3F 01                    1155 	.db	1
      001F40 09                    1156 	.db	9
      001F41 00 01                 1157 	.dw	1+Sstm8s_tim4$TIM4_GenerateEvent$111-Sstm8s_tim4$TIM4_GenerateEvent$110
      001F43 00                    1158 	.db	0
      001F44 01                    1159 	.uleb128	1
      001F45 01                    1160 	.db	1
      001F46 00                    1161 	.db	0
      001F47 05                    1162 	.uleb128	5
      001F48 02                    1163 	.db	2
      001F49 00 00 95 81           1164 	.dw	0,(Sstm8s_tim4$TIM4_SetCounter$113)
      001F4D 03                    1165 	.db	3
      001F4E 8F 02                 1166 	.sleb128	271
      001F50 01                    1167 	.db	1
      001F51 09                    1168 	.db	9
      001F52 00 00                 1169 	.dw	Sstm8s_tim4$TIM4_SetCounter$115-Sstm8s_tim4$TIM4_SetCounter$113
      001F54 03                    1170 	.db	3
      001F55 03                    1171 	.sleb128	3
      001F56 01                    1172 	.db	1
      001F57 09                    1173 	.db	9
      001F58 00 06                 1174 	.dw	Sstm8s_tim4$TIM4_SetCounter$116-Sstm8s_tim4$TIM4_SetCounter$115
      001F5A 03                    1175 	.db	3
      001F5B 01                    1176 	.sleb128	1
      001F5C 01                    1177 	.db	1
      001F5D 09                    1178 	.db	9
      001F5E 00 01                 1179 	.dw	1+Sstm8s_tim4$TIM4_SetCounter$117-Sstm8s_tim4$TIM4_SetCounter$116
      001F60 00                    1180 	.db	0
      001F61 01                    1181 	.uleb128	1
      001F62 01                    1182 	.db	1
      001F63 00                    1183 	.db	0
      001F64 05                    1184 	.uleb128	5
      001F65 02                    1185 	.db	2
      001F66 00 00 95 88           1186 	.dw	0,(Sstm8s_tim4$TIM4_SetAutoreload$119)
      001F6A 03                    1187 	.db	3
      001F6B 9B 02                 1188 	.sleb128	283
      001F6D 01                    1189 	.db	1
      001F6E 09                    1190 	.db	9
      001F6F 00 00                 1191 	.dw	Sstm8s_tim4$TIM4_SetAutoreload$121-Sstm8s_tim4$TIM4_SetAutoreload$119
      001F71 03                    1192 	.db	3
      001F72 03                    1193 	.sleb128	3
      001F73 01                    1194 	.db	1
      001F74 09                    1195 	.db	9
      001F75 00 06                 1196 	.dw	Sstm8s_tim4$TIM4_SetAutoreload$122-Sstm8s_tim4$TIM4_SetAutoreload$121
      001F77 03                    1197 	.db	3
      001F78 01                    1198 	.sleb128	1
      001F79 01                    1199 	.db	1
      001F7A 09                    1200 	.db	9
      001F7B 00 01                 1201 	.dw	1+Sstm8s_tim4$TIM4_SetAutoreload$123-Sstm8s_tim4$TIM4_SetAutoreload$122
      001F7D 00                    1202 	.db	0
      001F7E 01                    1203 	.uleb128	1
      001F7F 01                    1204 	.db	1
      001F80 00                    1205 	.db	0
      001F81 05                    1206 	.uleb128	5
      001F82 02                    1207 	.db	2
      001F83 00 00 95 8F           1208 	.dw	0,(Sstm8s_tim4$TIM4_GetCounter$125)
      001F87 03                    1209 	.db	3
      001F88 A6 02                 1210 	.sleb128	294
      001F8A 01                    1211 	.db	1
      001F8B 09                    1212 	.db	9
      001F8C 00 00                 1213 	.dw	Sstm8s_tim4$TIM4_GetCounter$127-Sstm8s_tim4$TIM4_GetCounter$125
      001F8E 03                    1214 	.db	3
      001F8F 03                    1215 	.sleb128	3
      001F90 01                    1216 	.db	1
      001F91 09                    1217 	.db	9
      001F92 00 03                 1218 	.dw	Sstm8s_tim4$TIM4_GetCounter$128-Sstm8s_tim4$TIM4_GetCounter$127
      001F94 03                    1219 	.db	3
      001F95 01                    1220 	.sleb128	1
      001F96 01                    1221 	.db	1
      001F97 09                    1222 	.db	9
      001F98 00 01                 1223 	.dw	1+Sstm8s_tim4$TIM4_GetCounter$129-Sstm8s_tim4$TIM4_GetCounter$128
      001F9A 00                    1224 	.db	0
      001F9B 01                    1225 	.uleb128	1
      001F9C 01                    1226 	.db	1
      001F9D 00                    1227 	.db	0
      001F9E 05                    1228 	.uleb128	5
      001F9F 02                    1229 	.db	2
      001FA0 00 00 95 93           1230 	.dw	0,(Sstm8s_tim4$TIM4_GetPrescaler$131)
      001FA4 03                    1231 	.db	3
      001FA5 B1 02                 1232 	.sleb128	305
      001FA7 01                    1233 	.db	1
      001FA8 09                    1234 	.db	9
      001FA9 00 00                 1235 	.dw	Sstm8s_tim4$TIM4_GetPrescaler$133-Sstm8s_tim4$TIM4_GetPrescaler$131
      001FAB 03                    1236 	.db	3
      001FAC 03                    1237 	.sleb128	3
      001FAD 01                    1238 	.db	1
      001FAE 09                    1239 	.db	9
      001FAF 00 03                 1240 	.dw	Sstm8s_tim4$TIM4_GetPrescaler$134-Sstm8s_tim4$TIM4_GetPrescaler$133
      001FB1 03                    1241 	.db	3
      001FB2 01                    1242 	.sleb128	1
      001FB3 01                    1243 	.db	1
      001FB4 09                    1244 	.db	9
      001FB5 00 01                 1245 	.dw	1+Sstm8s_tim4$TIM4_GetPrescaler$135-Sstm8s_tim4$TIM4_GetPrescaler$134
      001FB7 00                    1246 	.db	0
      001FB8 01                    1247 	.uleb128	1
      001FB9 01                    1248 	.db	1
      001FBA 00                    1249 	.db	0
      001FBB 05                    1250 	.uleb128	5
      001FBC 02                    1251 	.db	2
      001FBD 00 00 95 97           1252 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$137)
      001FC1 03                    1253 	.db	3
      001FC2 BE 02                 1254 	.sleb128	318
      001FC4 01                    1255 	.db	1
      001FC5 09                    1256 	.db	9
      001FC6 00 00                 1257 	.dw	Sstm8s_tim4$TIM4_GetFlagStatus$139-Sstm8s_tim4$TIM4_GetFlagStatus$137
      001FC8 03                    1258 	.db	3
      001FC9 07                    1259 	.sleb128	7
      001FCA 01                    1260 	.db	1
      001FCB 09                    1261 	.db	9
      001FCC 00 0B                 1262 	.dw	Sstm8s_tim4$TIM4_GetFlagStatus$141-Sstm8s_tim4$TIM4_GetFlagStatus$139
      001FCE 03                    1263 	.db	3
      001FCF 02                    1264 	.sleb128	2
      001FD0 01                    1265 	.db	1
      001FD1 09                    1266 	.db	9
      001FD2 00 05                 1267 	.dw	Sstm8s_tim4$TIM4_GetFlagStatus$144-Sstm8s_tim4$TIM4_GetFlagStatus$141
      001FD4 03                    1268 	.db	3
      001FD5 04                    1269 	.sleb128	4
      001FD6 01                    1270 	.db	1
      001FD7 09                    1271 	.db	9
      001FD8 00 01                 1272 	.dw	Sstm8s_tim4$TIM4_GetFlagStatus$146-Sstm8s_tim4$TIM4_GetFlagStatus$144
      001FDA 03                    1273 	.db	3
      001FDB 02                    1274 	.sleb128	2
      001FDC 01                    1275 	.db	1
      001FDD 09                    1276 	.db	9
      001FDE 00 00                 1277 	.dw	Sstm8s_tim4$TIM4_GetFlagStatus$147-Sstm8s_tim4$TIM4_GetFlagStatus$146
      001FE0 03                    1278 	.db	3
      001FE1 01                    1279 	.sleb128	1
      001FE2 01                    1280 	.db	1
      001FE3 09                    1281 	.db	9
      001FE4 00 01                 1282 	.dw	1+Sstm8s_tim4$TIM4_GetFlagStatus$148-Sstm8s_tim4$TIM4_GetFlagStatus$147
      001FE6 00                    1283 	.db	0
      001FE7 01                    1284 	.uleb128	1
      001FE8 01                    1285 	.db	1
      001FE9 00                    1286 	.db	0
      001FEA 05                    1287 	.uleb128	5
      001FEB 02                    1288 	.db	2
      001FEC 00 00 95 A9           1289 	.dw	0,(Sstm8s_tim4$TIM4_ClearFlag$150)
      001FF0 03                    1290 	.db	3
      001FF1 D7 02                 1291 	.sleb128	343
      001FF3 01                    1292 	.db	1
      001FF4 09                    1293 	.db	9
      001FF5 00 00                 1294 	.dw	Sstm8s_tim4$TIM4_ClearFlag$152-Sstm8s_tim4$TIM4_ClearFlag$150
      001FF7 03                    1295 	.db	3
      001FF8 06                    1296 	.sleb128	6
      001FF9 01                    1297 	.db	1
      001FFA 09                    1298 	.db	9
      001FFB 00 06                 1299 	.dw	Sstm8s_tim4$TIM4_ClearFlag$153-Sstm8s_tim4$TIM4_ClearFlag$152
      001FFD 03                    1300 	.db	3
      001FFE 01                    1301 	.sleb128	1
      001FFF 01                    1302 	.db	1
      002000 09                    1303 	.db	9
      002001 00 01                 1304 	.dw	1+Sstm8s_tim4$TIM4_ClearFlag$154-Sstm8s_tim4$TIM4_ClearFlag$153
      002003 00                    1305 	.db	0
      002004 01                    1306 	.uleb128	1
      002005 01                    1307 	.db	1
      002006 00                    1308 	.db	0
      002007 05                    1309 	.uleb128	5
      002008 02                    1310 	.db	2
      002009 00 00 95 B0           1311 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$156)
      00200D 03                    1312 	.db	3
      00200E E7 02                 1313 	.sleb128	359
      002010 01                    1314 	.db	1
      002011 09                    1315 	.db	9
      002012 00 01                 1316 	.dw	Sstm8s_tim4$TIM4_GetITStatus$159-Sstm8s_tim4$TIM4_GetITStatus$156
      002014 03                    1317 	.db	3
      002015 09                    1318 	.sleb128	9
      002016 01                    1319 	.db	1
      002017 09                    1320 	.db	9
      002018 00 07                 1321 	.dw	Sstm8s_tim4$TIM4_GetITStatus$160-Sstm8s_tim4$TIM4_GetITStatus$159
      00201A 03                    1322 	.db	3
      00201B 02                    1323 	.sleb128	2
      00201C 01                    1324 	.db	1
      00201D 09                    1325 	.db	9
      00201E 00 05                 1326 	.dw	Sstm8s_tim4$TIM4_GetITStatus$161-Sstm8s_tim4$TIM4_GetITStatus$160
      002020 03                    1327 	.db	3
      002021 02                    1328 	.sleb128	2
      002022 01                    1329 	.db	1
      002023 09                    1330 	.db	9
      002024 00 0D                 1331 	.dw	Sstm8s_tim4$TIM4_GetITStatus$163-Sstm8s_tim4$TIM4_GetITStatus$161
      002026 03                    1332 	.db	3
      002027 02                    1333 	.sleb128	2
      002028 01                    1334 	.db	1
      002029 09                    1335 	.db	9
      00202A 00 05                 1336 	.dw	Sstm8s_tim4$TIM4_GetITStatus$166-Sstm8s_tim4$TIM4_GetITStatus$163
      00202C 03                    1337 	.db	3
      00202D 04                    1338 	.sleb128	4
      00202E 01                    1339 	.db	1
      00202F 09                    1340 	.db	9
      002030 00 01                 1341 	.dw	Sstm8s_tim4$TIM4_GetITStatus$168-Sstm8s_tim4$TIM4_GetITStatus$166
      002032 03                    1342 	.db	3
      002033 02                    1343 	.sleb128	2
      002034 01                    1344 	.db	1
      002035 09                    1345 	.db	9
      002036 00 00                 1346 	.dw	Sstm8s_tim4$TIM4_GetITStatus$169-Sstm8s_tim4$TIM4_GetITStatus$168
      002038 03                    1347 	.db	3
      002039 01                    1348 	.sleb128	1
      00203A 01                    1349 	.db	1
      00203B 09                    1350 	.db	9
      00203C 00 03                 1351 	.dw	1+Sstm8s_tim4$TIM4_GetITStatus$171-Sstm8s_tim4$TIM4_GetITStatus$169
      00203E 00                    1352 	.db	0
      00203F 01                    1353 	.uleb128	1
      002040 01                    1354 	.db	1
      002041 00                    1355 	.db	0
      002042 05                    1356 	.uleb128	5
      002043 02                    1357 	.db	2
      002044 00 00 95 D3           1358 	.dw	0,(Sstm8s_tim4$TIM4_ClearITPendingBit$173)
      002048 03                    1359 	.db	3
      002049 86 03                 1360 	.sleb128	390
      00204B 01                    1361 	.db	1
      00204C 09                    1362 	.db	9
      00204D 00 00                 1363 	.dw	Sstm8s_tim4$TIM4_ClearITPendingBit$175-Sstm8s_tim4$TIM4_ClearITPendingBit$173
      00204F 03                    1364 	.db	3
      002050 06                    1365 	.sleb128	6
      002051 01                    1366 	.db	1
      002052 09                    1367 	.db	9
      002053 00 06                 1368 	.dw	Sstm8s_tim4$TIM4_ClearITPendingBit$176-Sstm8s_tim4$TIM4_ClearITPendingBit$175
      002055 03                    1369 	.db	3
      002056 01                    1370 	.sleb128	1
      002057 01                    1371 	.db	1
      002058 09                    1372 	.db	9
      002059 00 01                 1373 	.dw	1+Sstm8s_tim4$TIM4_ClearITPendingBit$177-Sstm8s_tim4$TIM4_ClearITPendingBit$176
      00205B 00                    1374 	.db	0
      00205C 01                    1375 	.uleb128	1
      00205D 01                    1376 	.db	1
      00205E                       1377 Ldebug_line_end:
                                   1378 
                                   1379 	.area .debug_loc (NOLOAD)
      00294C                       1380 Ldebug_loc_start:
      00294C 00 00 95 D3           1381 	.dw	0,(Sstm8s_tim4$TIM4_ClearITPendingBit$174)
      002950 00 00 95 DA           1382 	.dw	0,(Sstm8s_tim4$TIM4_ClearITPendingBit$178)
      002954 00 02                 1383 	.dw	2
      002956 78                    1384 	.db	120
      002957 01                    1385 	.sleb128	1
      002958 00 00 00 00           1386 	.dw	0,0
      00295C 00 00 00 00           1387 	.dw	0,0
      002960 00 00 95 D2           1388 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$170)
      002964 00 00 95 D3           1389 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$172)
      002968 00 02                 1390 	.dw	2
      00296A 78                    1391 	.db	120
      00296B 01                    1392 	.sleb128	1
      00296C 00 00 95 B1           1393 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$158)
      002970 00 00 95 D2           1394 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$170)
      002974 00 02                 1395 	.dw	2
      002976 78                    1396 	.db	120
      002977 02                    1397 	.sleb128	2
      002978 00 00 95 B0           1398 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$157)
      00297C 00 00 95 B1           1399 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$158)
      002980 00 02                 1400 	.dw	2
      002982 78                    1401 	.db	120
      002983 01                    1402 	.sleb128	1
      002984 00 00 00 00           1403 	.dw	0,0
      002988 00 00 00 00           1404 	.dw	0,0
      00298C 00 00 95 A9           1405 	.dw	0,(Sstm8s_tim4$TIM4_ClearFlag$151)
      002990 00 00 95 B0           1406 	.dw	0,(Sstm8s_tim4$TIM4_ClearFlag$155)
      002994 00 02                 1407 	.dw	2
      002996 78                    1408 	.db	120
      002997 01                    1409 	.sleb128	1
      002998 00 00 00 00           1410 	.dw	0,0
      00299C 00 00 00 00           1411 	.dw	0,0
      0029A0 00 00 95 97           1412 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$138)
      0029A4 00 00 95 A9           1413 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$149)
      0029A8 00 02                 1414 	.dw	2
      0029AA 78                    1415 	.db	120
      0029AB 01                    1416 	.sleb128	1
      0029AC 00 00 00 00           1417 	.dw	0,0
      0029B0 00 00 00 00           1418 	.dw	0,0
      0029B4 00 00 95 93           1419 	.dw	0,(Sstm8s_tim4$TIM4_GetPrescaler$132)
      0029B8 00 00 95 97           1420 	.dw	0,(Sstm8s_tim4$TIM4_GetPrescaler$136)
      0029BC 00 02                 1421 	.dw	2
      0029BE 78                    1422 	.db	120
      0029BF 01                    1423 	.sleb128	1
      0029C0 00 00 00 00           1424 	.dw	0,0
      0029C4 00 00 00 00           1425 	.dw	0,0
      0029C8 00 00 95 8F           1426 	.dw	0,(Sstm8s_tim4$TIM4_GetCounter$126)
      0029CC 00 00 95 93           1427 	.dw	0,(Sstm8s_tim4$TIM4_GetCounter$130)
      0029D0 00 02                 1428 	.dw	2
      0029D2 78                    1429 	.db	120
      0029D3 01                    1430 	.sleb128	1
      0029D4 00 00 00 00           1431 	.dw	0,0
      0029D8 00 00 00 00           1432 	.dw	0,0
      0029DC 00 00 95 88           1433 	.dw	0,(Sstm8s_tim4$TIM4_SetAutoreload$120)
      0029E0 00 00 95 8F           1434 	.dw	0,(Sstm8s_tim4$TIM4_SetAutoreload$124)
      0029E4 00 02                 1435 	.dw	2
      0029E6 78                    1436 	.db	120
      0029E7 01                    1437 	.sleb128	1
      0029E8 00 00 00 00           1438 	.dw	0,0
      0029EC 00 00 00 00           1439 	.dw	0,0
      0029F0 00 00 95 81           1440 	.dw	0,(Sstm8s_tim4$TIM4_SetCounter$114)
      0029F4 00 00 95 88           1441 	.dw	0,(Sstm8s_tim4$TIM4_SetCounter$118)
      0029F8 00 02                 1442 	.dw	2
      0029FA 78                    1443 	.db	120
      0029FB 01                    1444 	.sleb128	1
      0029FC 00 00 00 00           1445 	.dw	0,0
      002A00 00 00 00 00           1446 	.dw	0,0
      002A04 00 00 95 7A           1447 	.dw	0,(Sstm8s_tim4$TIM4_GenerateEvent$108)
      002A08 00 00 95 81           1448 	.dw	0,(Sstm8s_tim4$TIM4_GenerateEvent$112)
      002A0C 00 02                 1449 	.dw	2
      002A0E 78                    1450 	.db	120
      002A0F 01                    1451 	.sleb128	1
      002A10 00 00 00 00           1452 	.dw	0,0
      002A14 00 00 00 00           1453 	.dw	0,0
      002A18 00 00 95 62           1454 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$95)
      002A1C 00 00 95 7A           1455 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$106)
      002A20 00 02                 1456 	.dw	2
      002A22 78                    1457 	.db	120
      002A23 01                    1458 	.sleb128	1
      002A24 00 00 00 00           1459 	.dw	0,0
      002A28 00 00 00 00           1460 	.dw	0,0
      002A2C 00 00 95 55           1461 	.dw	0,(Sstm8s_tim4$TIM4_PrescalerConfig$88)
      002A30 00 00 95 62           1462 	.dw	0,(Sstm8s_tim4$TIM4_PrescalerConfig$93)
      002A34 00 02                 1463 	.dw	2
      002A36 78                    1464 	.db	120
      002A37 01                    1465 	.sleb128	1
      002A38 00 00 00 00           1466 	.dw	0,0
      002A3C 00 00 00 00           1467 	.dw	0,0
      002A40 00 00 95 3D           1468 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$75)
      002A44 00 00 95 55           1469 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$86)
      002A48 00 02                 1470 	.dw	2
      002A4A 78                    1471 	.db	120
      002A4B 01                    1472 	.sleb128	1
      002A4C 00 00 00 00           1473 	.dw	0,0
      002A50 00 00 00 00           1474 	.dw	0,0
      002A54 00 00 95 25           1475 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$62)
      002A58 00 00 95 3D           1476 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$73)
      002A5C 00 02                 1477 	.dw	2
      002A5E 78                    1478 	.db	120
      002A5F 01                    1479 	.sleb128	1
      002A60 00 00 00 00           1480 	.dw	0,0
      002A64 00 00 00 00           1481 	.dw	0,0
      002A68 00 00 95 0D           1482 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$49)
      002A6C 00 00 95 25           1483 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$60)
      002A70 00 02                 1484 	.dw	2
      002A72 78                    1485 	.db	120
      002A73 01                    1486 	.sleb128	1
      002A74 00 00 00 00           1487 	.dw	0,0
      002A78 00 00 00 00           1488 	.dw	0,0
      002A7C 00 00 95 0C           1489 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$45)
      002A80 00 00 95 0D           1490 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$47)
      002A84 00 02                 1491 	.dw	2
      002A86 78                    1492 	.db	120
      002A87 01                    1493 	.sleb128	1
      002A88 00 00 95 06           1494 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$42)
      002A8C 00 00 95 0C           1495 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$45)
      002A90 00 02                 1496 	.dw	2
      002A92 78                    1497 	.db	120
      002A93 02                    1498 	.sleb128	2
      002A94 00 00 95 00           1499 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$41)
      002A98 00 00 95 06           1500 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$42)
      002A9C 00 02                 1501 	.dw	2
      002A9E 78                    1502 	.db	120
      002A9F 03                    1503 	.sleb128	3
      002AA0 00 00 94 ED           1504 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$33)
      002AA4 00 00 95 00           1505 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$41)
      002AA8 00 02                 1506 	.dw	2
      002AAA 78                    1507 	.db	120
      002AAB 02                    1508 	.sleb128	2
      002AAC 00 00 94 EC           1509 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$32)
      002AB0 00 00 94 ED           1510 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$33)
      002AB4 00 02                 1511 	.dw	2
      002AB6 78                    1512 	.db	120
      002AB7 01                    1513 	.sleb128	1
      002AB8 00 00 00 00           1514 	.dw	0,0
      002ABC 00 00 00 00           1515 	.dw	0,0
      002AC0 00 00 94 D4           1516 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$19)
      002AC4 00 00 94 EC           1517 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$30)
      002AC8 00 02                 1518 	.dw	2
      002ACA 78                    1519 	.db	120
      002ACB 01                    1520 	.sleb128	1
      002ACC 00 00 00 00           1521 	.dw	0,0
      002AD0 00 00 00 00           1522 	.dw	0,0
      002AD4 00 00 94 C7           1523 	.dw	0,(Sstm8s_tim4$TIM4_TimeBaseInit$12)
      002AD8 00 00 94 D4           1524 	.dw	0,(Sstm8s_tim4$TIM4_TimeBaseInit$17)
      002ADC 00 02                 1525 	.dw	2
      002ADE 78                    1526 	.db	120
      002ADF 01                    1527 	.sleb128	1
      002AE0 00 00 00 00           1528 	.dw	0,0
      002AE4 00 00 00 00           1529 	.dw	0,0
      002AE8 00 00 94 AE           1530 	.dw	0,(Sstm8s_tim4$TIM4_DeInit$1)
      002AEC 00 00 94 C7           1531 	.dw	0,(Sstm8s_tim4$TIM4_DeInit$10)
      002AF0 00 02                 1532 	.dw	2
      002AF2 78                    1533 	.db	120
      002AF3 01                    1534 	.sleb128	1
      002AF4 00 00 00 00           1535 	.dw	0,0
      002AF8 00 00 00 00           1536 	.dw	0,0
                                   1537 
                                   1538 	.area .debug_abbrev (NOLOAD)
      000523                       1539 Ldebug_abbrev:
      000523 07                    1540 	.uleb128	7
      000524 2E                    1541 	.uleb128	46
      000525 00                    1542 	.db	0
      000526 03                    1543 	.uleb128	3
      000527 08                    1544 	.uleb128	8
      000528 11                    1545 	.uleb128	17
      000529 01                    1546 	.uleb128	1
      00052A 12                    1547 	.uleb128	18
      00052B 01                    1548 	.uleb128	1
      00052C 3F                    1549 	.uleb128	63
      00052D 0C                    1550 	.uleb128	12
      00052E 40                    1551 	.uleb128	64
      00052F 06                    1552 	.uleb128	6
      000530 49                    1553 	.uleb128	73
      000531 13                    1554 	.uleb128	19
      000532 00                    1555 	.uleb128	0
      000533 00                    1556 	.uleb128	0
      000534 04                    1557 	.uleb128	4
      000535 05                    1558 	.uleb128	5
      000536 00                    1559 	.db	0
      000537 02                    1560 	.uleb128	2
      000538 0A                    1561 	.uleb128	10
      000539 03                    1562 	.uleb128	3
      00053A 08                    1563 	.uleb128	8
      00053B 49                    1564 	.uleb128	73
      00053C 13                    1565 	.uleb128	19
      00053D 00                    1566 	.uleb128	0
      00053E 00                    1567 	.uleb128	0
      00053F 03                    1568 	.uleb128	3
      000540 2E                    1569 	.uleb128	46
      000541 01                    1570 	.db	1
      000542 01                    1571 	.uleb128	1
      000543 13                    1572 	.uleb128	19
      000544 03                    1573 	.uleb128	3
      000545 08                    1574 	.uleb128	8
      000546 11                    1575 	.uleb128	17
      000547 01                    1576 	.uleb128	1
      000548 12                    1577 	.uleb128	18
      000549 01                    1578 	.uleb128	1
      00054A 3F                    1579 	.uleb128	63
      00054B 0C                    1580 	.uleb128	12
      00054C 40                    1581 	.uleb128	64
      00054D 06                    1582 	.uleb128	6
      00054E 00                    1583 	.uleb128	0
      00054F 00                    1584 	.uleb128	0
      000550 09                    1585 	.uleb128	9
      000551 34                    1586 	.uleb128	52
      000552 00                    1587 	.db	0
      000553 02                    1588 	.uleb128	2
      000554 0A                    1589 	.uleb128	10
      000555 03                    1590 	.uleb128	3
      000556 08                    1591 	.uleb128	8
      000557 49                    1592 	.uleb128	73
      000558 13                    1593 	.uleb128	19
      000559 00                    1594 	.uleb128	0
      00055A 00                    1595 	.uleb128	0
      00055B 08                    1596 	.uleb128	8
      00055C 2E                    1597 	.uleb128	46
      00055D 01                    1598 	.db	1
      00055E 01                    1599 	.uleb128	1
      00055F 13                    1600 	.uleb128	19
      000560 03                    1601 	.uleb128	3
      000561 08                    1602 	.uleb128	8
      000562 11                    1603 	.uleb128	17
      000563 01                    1604 	.uleb128	1
      000564 12                    1605 	.uleb128	18
      000565 01                    1606 	.uleb128	1
      000566 3F                    1607 	.uleb128	63
      000567 0C                    1608 	.uleb128	12
      000568 40                    1609 	.uleb128	64
      000569 06                    1610 	.uleb128	6
      00056A 49                    1611 	.uleb128	73
      00056B 13                    1612 	.uleb128	19
      00056C 00                    1613 	.uleb128	0
      00056D 00                    1614 	.uleb128	0
      00056E 01                    1615 	.uleb128	1
      00056F 11                    1616 	.uleb128	17
      000570 01                    1617 	.db	1
      000571 03                    1618 	.uleb128	3
      000572 08                    1619 	.uleb128	8
      000573 10                    1620 	.uleb128	16
      000574 06                    1621 	.uleb128	6
      000575 13                    1622 	.uleb128	19
      000576 0B                    1623 	.uleb128	11
      000577 25                    1624 	.uleb128	37
      000578 08                    1625 	.uleb128	8
      000579 00                    1626 	.uleb128	0
      00057A 00                    1627 	.uleb128	0
      00057B 06                    1628 	.uleb128	6
      00057C 0B                    1629 	.uleb128	11
      00057D 00                    1630 	.db	0
      00057E 11                    1631 	.uleb128	17
      00057F 01                    1632 	.uleb128	1
      000580 12                    1633 	.uleb128	18
      000581 01                    1634 	.uleb128	1
      000582 00                    1635 	.uleb128	0
      000583 00                    1636 	.uleb128	0
      000584 02                    1637 	.uleb128	2
      000585 2E                    1638 	.uleb128	46
      000586 00                    1639 	.db	0
      000587 03                    1640 	.uleb128	3
      000588 08                    1641 	.uleb128	8
      000589 11                    1642 	.uleb128	17
      00058A 01                    1643 	.uleb128	1
      00058B 12                    1644 	.uleb128	18
      00058C 01                    1645 	.uleb128	1
      00058D 3F                    1646 	.uleb128	63
      00058E 0C                    1647 	.uleb128	12
      00058F 40                    1648 	.uleb128	64
      000590 06                    1649 	.uleb128	6
      000591 00                    1650 	.uleb128	0
      000592 00                    1651 	.uleb128	0
      000593 0A                    1652 	.uleb128	10
      000594 2E                    1653 	.uleb128	46
      000595 01                    1654 	.db	1
      000596 03                    1655 	.uleb128	3
      000597 08                    1656 	.uleb128	8
      000598 11                    1657 	.uleb128	17
      000599 01                    1658 	.uleb128	1
      00059A 12                    1659 	.uleb128	18
      00059B 01                    1660 	.uleb128	1
      00059C 3F                    1661 	.uleb128	63
      00059D 0C                    1662 	.uleb128	12
      00059E 40                    1663 	.uleb128	64
      00059F 06                    1664 	.uleb128	6
      0005A0 00                    1665 	.uleb128	0
      0005A1 00                    1666 	.uleb128	0
      0005A2 05                    1667 	.uleb128	5
      0005A3 24                    1668 	.uleb128	36
      0005A4 00                    1669 	.db	0
      0005A5 03                    1670 	.uleb128	3
      0005A6 08                    1671 	.uleb128	8
      0005A7 0B                    1672 	.uleb128	11
      0005A8 0B                    1673 	.uleb128	11
      0005A9 3E                    1674 	.uleb128	62
      0005AA 0B                    1675 	.uleb128	11
      0005AB 00                    1676 	.uleb128	0
      0005AC 00                    1677 	.uleb128	0
      0005AD 00                    1678 	.uleb128	0
                                   1679 
                                   1680 	.area .debug_info (NOLOAD)
      003067 00 00 05 1F           1681 	.dw	0,Ldebug_info_end-Ldebug_info_start
      00306B                       1682 Ldebug_info_start:
      00306B 00 02                 1683 	.dw	2
      00306D 00 00 05 23           1684 	.dw	0,(Ldebug_abbrev)
      003071 04                    1685 	.db	4
      003072 01                    1686 	.uleb128	1
      003073 2E 2E 2F 53 50 4C 2F  1687 	.ascii "../SPL/src/stm8s_tim4.c"
             73 72 63 2F 73 74 6D
             38 73 5F 74 69 6D 34
             2E 63
      00308A 00                    1688 	.db	0
      00308B 00 00 1D 0D           1689 	.dw	0,(Ldebug_line_start+-4)
      00308F 01                    1690 	.db	1
      003090 53 44 43 43 20 76 65  1691 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      0030A9 00                    1692 	.db	0
      0030AA 02                    1693 	.uleb128	2
      0030AB 54 49 4D 34 5F 44 65  1694 	.ascii "TIM4_DeInit"
             49 6E 69 74
      0030B6 00                    1695 	.db	0
      0030B7 00 00 94 AE           1696 	.dw	0,(_TIM4_DeInit)
      0030BB 00 00 94 C7           1697 	.dw	0,(XG$TIM4_DeInit$0$0+1)
      0030BF 01                    1698 	.db	1
      0030C0 00 00 2A E8           1699 	.dw	0,(Ldebug_loc_start+412)
      0030C4 03                    1700 	.uleb128	3
      0030C5 00 00 00 AD           1701 	.dw	0,173
      0030C9 54 49 4D 34 5F 54 69  1702 	.ascii "TIM4_TimeBaseInit"
             6D 65 42 61 73 65 49
             6E 69 74
      0030DA 00                    1703 	.db	0
      0030DB 00 00 94 C7           1704 	.dw	0,(_TIM4_TimeBaseInit)
      0030DF 00 00 94 D4           1705 	.dw	0,(XG$TIM4_TimeBaseInit$0$0+1)
      0030E3 01                    1706 	.db	1
      0030E4 00 00 2A D4           1707 	.dw	0,(Ldebug_loc_start+392)
      0030E8 04                    1708 	.uleb128	4
      0030E9 02                    1709 	.db	2
      0030EA 91                    1710 	.db	145
      0030EB 02                    1711 	.sleb128	2
      0030EC 54 49 4D 34 5F 50 72  1712 	.ascii "TIM4_Prescaler"
             65 73 63 61 6C 65 72
      0030FA 00                    1713 	.db	0
      0030FB 00 00 00 AD           1714 	.dw	0,173
      0030FF 04                    1715 	.uleb128	4
      003100 02                    1716 	.db	2
      003101 91                    1717 	.db	145
      003102 03                    1718 	.sleb128	3
      003103 54 49 4D 34 5F 50 65  1719 	.ascii "TIM4_Period"
             72 69 6F 64
      00310E 00                    1720 	.db	0
      00310F 00 00 00 AD           1721 	.dw	0,173
      003113 00                    1722 	.uleb128	0
      003114 05                    1723 	.uleb128	5
      003115 75 6E 73 69 67 6E 65  1724 	.ascii "unsigned char"
             64 20 63 68 61 72
      003122 00                    1725 	.db	0
      003123 01                    1726 	.db	1
      003124 08                    1727 	.db	8
      003125 03                    1728 	.uleb128	3
      003126 00 00 00 FD           1729 	.dw	0,253
      00312A 54 49 4D 34 5F 43 6D  1730 	.ascii "TIM4_Cmd"
             64
      003132 00                    1731 	.db	0
      003133 00 00 94 D4           1732 	.dw	0,(_TIM4_Cmd)
      003137 00 00 94 EC           1733 	.dw	0,(XG$TIM4_Cmd$0$0+1)
      00313B 01                    1734 	.db	1
      00313C 00 00 2A C0           1735 	.dw	0,(Ldebug_loc_start+372)
      003140 04                    1736 	.uleb128	4
      003141 02                    1737 	.db	2
      003142 91                    1738 	.db	145
      003143 02                    1739 	.sleb128	2
      003144 4E 65 77 53 74 61 74  1740 	.ascii "NewState"
             65
      00314C 00                    1741 	.db	0
      00314D 00 00 00 AD           1742 	.dw	0,173
      003151 06                    1743 	.uleb128	6
      003152 00 00 94 DE           1744 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$22)
      003156 00 00 94 E3           1745 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$24)
      00315A 06                    1746 	.uleb128	6
      00315B 00 00 94 E6           1747 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$25)
      00315F 00 00 94 EB           1748 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$27)
      003163 00                    1749 	.uleb128	0
      003164 03                    1750 	.uleb128	3
      003165 00 00 01 51           1751 	.dw	0,337
      003169 54 49 4D 34 5F 49 54  1752 	.ascii "TIM4_ITConfig"
             43 6F 6E 66 69 67
      003176 00                    1753 	.db	0
      003177 00 00 94 EC           1754 	.dw	0,(_TIM4_ITConfig)
      00317B 00 00 95 0D           1755 	.dw	0,(XG$TIM4_ITConfig$0$0+1)
      00317F 01                    1756 	.db	1
      003180 00 00 2A 7C           1757 	.dw	0,(Ldebug_loc_start+304)
      003184 04                    1758 	.uleb128	4
      003185 02                    1759 	.db	2
      003186 91                    1760 	.db	145
      003187 02                    1761 	.sleb128	2
      003188 54 49 4D 34 5F 49 54  1762 	.ascii "TIM4_IT"
      00318F 00                    1763 	.db	0
      003190 00 00 00 AD           1764 	.dw	0,173
      003194 04                    1765 	.uleb128	4
      003195 02                    1766 	.db	2
      003196 91                    1767 	.db	145
      003197 03                    1768 	.sleb128	3
      003198 4E 65 77 53 74 61 74  1769 	.ascii "NewState"
             65
      0031A0 00                    1770 	.db	0
      0031A1 00 00 00 AD           1771 	.dw	0,173
      0031A5 06                    1772 	.uleb128	6
      0031A6 00 00 94 F7           1773 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$36)
      0031AA 00 00 94 FC           1774 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$38)
      0031AE 06                    1775 	.uleb128	6
      0031AF 00 00 94 FF           1776 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$39)
      0031B3 00 00 95 0B           1777 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$43)
      0031B7 00                    1778 	.uleb128	0
      0031B8 03                    1779 	.uleb128	3
      0031B9 00 00 01 A0           1780 	.dw	0,416
      0031BD 54 49 4D 34 5F 55 70  1781 	.ascii "TIM4_UpdateDisableConfig"
             64 61 74 65 44 69 73
             61 62 6C 65 43 6F 6E
             66 69 67
      0031D5 00                    1782 	.db	0
      0031D6 00 00 95 0D           1783 	.dw	0,(_TIM4_UpdateDisableConfig)
      0031DA 00 00 95 25           1784 	.dw	0,(XG$TIM4_UpdateDisableConfig$0$0+1)
      0031DE 01                    1785 	.db	1
      0031DF 00 00 2A 68           1786 	.dw	0,(Ldebug_loc_start+284)
      0031E3 04                    1787 	.uleb128	4
      0031E4 02                    1788 	.db	2
      0031E5 91                    1789 	.db	145
      0031E6 02                    1790 	.sleb128	2
      0031E7 4E 65 77 53 74 61 74  1791 	.ascii "NewState"
             65
      0031EF 00                    1792 	.db	0
      0031F0 00 00 00 AD           1793 	.dw	0,173
      0031F4 06                    1794 	.uleb128	6
      0031F5 00 00 95 17           1795 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$52)
      0031F9 00 00 95 1C           1796 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$54)
      0031FD 06                    1797 	.uleb128	6
      0031FE 00 00 95 1F           1798 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$55)
      003202 00 00 95 24           1799 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$57)
      003206 00                    1800 	.uleb128	0
      003207 03                    1801 	.uleb128	3
      003208 00 00 01 F8           1802 	.dw	0,504
      00320C 54 49 4D 34 5F 55 70  1803 	.ascii "TIM4_UpdateRequestConfig"
             64 61 74 65 52 65 71
             75 65 73 74 43 6F 6E
             66 69 67
      003224 00                    1804 	.db	0
      003225 00 00 95 25           1805 	.dw	0,(_TIM4_UpdateRequestConfig)
      003229 00 00 95 3D           1806 	.dw	0,(XG$TIM4_UpdateRequestConfig$0$0+1)
      00322D 01                    1807 	.db	1
      00322E 00 00 2A 54           1808 	.dw	0,(Ldebug_loc_start+264)
      003232 04                    1809 	.uleb128	4
      003233 02                    1810 	.db	2
      003234 91                    1811 	.db	145
      003235 02                    1812 	.sleb128	2
      003236 54 49 4D 34 5F 55 70  1813 	.ascii "TIM4_UpdateSource"
             64 61 74 65 53 6F 75
             72 63 65
      003247 00                    1814 	.db	0
      003248 00 00 00 AD           1815 	.dw	0,173
      00324C 06                    1816 	.uleb128	6
      00324D 00 00 95 2F           1817 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$65)
      003251 00 00 95 34           1818 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$67)
      003255 06                    1819 	.uleb128	6
      003256 00 00 95 37           1820 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$68)
      00325A 00 00 95 3C           1821 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$70)
      00325E 00                    1822 	.uleb128	0
      00325F 03                    1823 	.uleb128	3
      003260 00 00 02 49           1824 	.dw	0,585
      003264 54 49 4D 34 5F 53 65  1825 	.ascii "TIM4_SelectOnePulseMode"
             6C 65 63 74 4F 6E 65
             50 75 6C 73 65 4D 6F
             64 65
      00327B 00                    1826 	.db	0
      00327C 00 00 95 3D           1827 	.dw	0,(_TIM4_SelectOnePulseMode)
      003280 00 00 95 55           1828 	.dw	0,(XG$TIM4_SelectOnePulseMode$0$0+1)
      003284 01                    1829 	.db	1
      003285 00 00 2A 40           1830 	.dw	0,(Ldebug_loc_start+244)
      003289 04                    1831 	.uleb128	4
      00328A 02                    1832 	.db	2
      00328B 91                    1833 	.db	145
      00328C 02                    1834 	.sleb128	2
      00328D 54 49 4D 34 5F 4F 50  1835 	.ascii "TIM4_OPMode"
             4D 6F 64 65
      003298 00                    1836 	.db	0
      003299 00 00 00 AD           1837 	.dw	0,173
      00329D 06                    1838 	.uleb128	6
      00329E 00 00 95 47           1839 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$78)
      0032A2 00 00 95 4C           1840 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$80)
      0032A6 06                    1841 	.uleb128	6
      0032A7 00 00 95 4F           1842 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$81)
      0032AB 00 00 95 54           1843 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$83)
      0032AF 00                    1844 	.uleb128	0
      0032B0 03                    1845 	.uleb128	3
      0032B1 00 00 02 9E           1846 	.dw	0,670
      0032B5 54 49 4D 34 5F 50 72  1847 	.ascii "TIM4_PrescalerConfig"
             65 73 63 61 6C 65 72
             43 6F 6E 66 69 67
      0032C9 00                    1848 	.db	0
      0032CA 00 00 95 55           1849 	.dw	0,(_TIM4_PrescalerConfig)
      0032CE 00 00 95 62           1850 	.dw	0,(XG$TIM4_PrescalerConfig$0$0+1)
      0032D2 01                    1851 	.db	1
      0032D3 00 00 2A 2C           1852 	.dw	0,(Ldebug_loc_start+224)
      0032D7 04                    1853 	.uleb128	4
      0032D8 02                    1854 	.db	2
      0032D9 91                    1855 	.db	145
      0032DA 02                    1856 	.sleb128	2
      0032DB 50 72 65 73 63 61 6C  1857 	.ascii "Prescaler"
             65 72
      0032E4 00                    1858 	.db	0
      0032E5 00 00 00 AD           1859 	.dw	0,173
      0032E9 04                    1860 	.uleb128	4
      0032EA 02                    1861 	.db	2
      0032EB 91                    1862 	.db	145
      0032EC 03                    1863 	.sleb128	3
      0032ED 54 49 4D 34 5F 50 53  1864 	.ascii "TIM4_PSCReloadMode"
             43 52 65 6C 6F 61 64
             4D 6F 64 65
      0032FF 00                    1865 	.db	0
      003300 00 00 00 AD           1866 	.dw	0,173
      003304 00                    1867 	.uleb128	0
      003305 03                    1868 	.uleb128	3
      003306 00 00 02 EA           1869 	.dw	0,746
      00330A 54 49 4D 34 5F 41 52  1870 	.ascii "TIM4_ARRPreloadConfig"
             52 50 72 65 6C 6F 61
             64 43 6F 6E 66 69 67
      00331F 00                    1871 	.db	0
      003320 00 00 95 62           1872 	.dw	0,(_TIM4_ARRPreloadConfig)
      003324 00 00 95 7A           1873 	.dw	0,(XG$TIM4_ARRPreloadConfig$0$0+1)
      003328 01                    1874 	.db	1
      003329 00 00 2A 18           1875 	.dw	0,(Ldebug_loc_start+204)
      00332D 04                    1876 	.uleb128	4
      00332E 02                    1877 	.db	2
      00332F 91                    1878 	.db	145
      003330 02                    1879 	.sleb128	2
      003331 4E 65 77 53 74 61 74  1880 	.ascii "NewState"
             65
      003339 00                    1881 	.db	0
      00333A 00 00 00 AD           1882 	.dw	0,173
      00333E 06                    1883 	.uleb128	6
      00333F 00 00 95 6C           1884 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$98)
      003343 00 00 95 71           1885 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$100)
      003347 06                    1886 	.uleb128	6
      003348 00 00 95 74           1887 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$101)
      00334C 00 00 95 79           1888 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$103)
      003350 00                    1889 	.uleb128	0
      003351 03                    1890 	.uleb128	3
      003352 00 00 03 29           1891 	.dw	0,809
      003356 54 49 4D 34 5F 47 65  1892 	.ascii "TIM4_GenerateEvent"
             6E 65 72 61 74 65 45
             76 65 6E 74
      003368 00                    1893 	.db	0
      003369 00 00 95 7A           1894 	.dw	0,(_TIM4_GenerateEvent)
      00336D 00 00 95 81           1895 	.dw	0,(XG$TIM4_GenerateEvent$0$0+1)
      003371 01                    1896 	.db	1
      003372 00 00 2A 04           1897 	.dw	0,(Ldebug_loc_start+184)
      003376 04                    1898 	.uleb128	4
      003377 02                    1899 	.db	2
      003378 91                    1900 	.db	145
      003379 02                    1901 	.sleb128	2
      00337A 54 49 4D 34 5F 45 76  1902 	.ascii "TIM4_EventSource"
             65 6E 74 53 6F 75 72
             63 65
      00338A 00                    1903 	.db	0
      00338B 00 00 00 AD           1904 	.dw	0,173
      00338F 00                    1905 	.uleb128	0
      003390 03                    1906 	.uleb128	3
      003391 00 00 03 5C           1907 	.dw	0,860
      003395 54 49 4D 34 5F 53 65  1908 	.ascii "TIM4_SetCounter"
             74 43 6F 75 6E 74 65
             72
      0033A4 00                    1909 	.db	0
      0033A5 00 00 95 81           1910 	.dw	0,(_TIM4_SetCounter)
      0033A9 00 00 95 88           1911 	.dw	0,(XG$TIM4_SetCounter$0$0+1)
      0033AD 01                    1912 	.db	1
      0033AE 00 00 29 F0           1913 	.dw	0,(Ldebug_loc_start+164)
      0033B2 04                    1914 	.uleb128	4
      0033B3 02                    1915 	.db	2
      0033B4 91                    1916 	.db	145
      0033B5 02                    1917 	.sleb128	2
      0033B6 43 6F 75 6E 74 65 72  1918 	.ascii "Counter"
      0033BD 00                    1919 	.db	0
      0033BE 00 00 00 AD           1920 	.dw	0,173
      0033C2 00                    1921 	.uleb128	0
      0033C3 03                    1922 	.uleb128	3
      0033C4 00 00 03 95           1923 	.dw	0,917
      0033C8 54 49 4D 34 5F 53 65  1924 	.ascii "TIM4_SetAutoreload"
             74 41 75 74 6F 72 65
             6C 6F 61 64
      0033DA 00                    1925 	.db	0
      0033DB 00 00 95 88           1926 	.dw	0,(_TIM4_SetAutoreload)
      0033DF 00 00 95 8F           1927 	.dw	0,(XG$TIM4_SetAutoreload$0$0+1)
      0033E3 01                    1928 	.db	1
      0033E4 00 00 29 DC           1929 	.dw	0,(Ldebug_loc_start+144)
      0033E8 04                    1930 	.uleb128	4
      0033E9 02                    1931 	.db	2
      0033EA 91                    1932 	.db	145
      0033EB 02                    1933 	.sleb128	2
      0033EC 41 75 74 6F 72 65 6C  1934 	.ascii "Autoreload"
             6F 61 64
      0033F6 00                    1935 	.db	0
      0033F7 00 00 00 AD           1936 	.dw	0,173
      0033FB 00                    1937 	.uleb128	0
      0033FC 07                    1938 	.uleb128	7
      0033FD 54 49 4D 34 5F 47 65  1939 	.ascii "TIM4_GetCounter"
             74 43 6F 75 6E 74 65
             72
      00340C 00                    1940 	.db	0
      00340D 00 00 95 8F           1941 	.dw	0,(_TIM4_GetCounter)
      003411 00 00 95 93           1942 	.dw	0,(XG$TIM4_GetCounter$0$0+1)
      003415 01                    1943 	.db	1
      003416 00 00 29 C8           1944 	.dw	0,(Ldebug_loc_start+124)
      00341A 00 00 00 AD           1945 	.dw	0,173
      00341E 07                    1946 	.uleb128	7
      00341F 54 49 4D 34 5F 47 65  1947 	.ascii "TIM4_GetPrescaler"
             74 50 72 65 73 63 61
             6C 65 72
      003430 00                    1948 	.db	0
      003431 00 00 95 93           1949 	.dw	0,(_TIM4_GetPrescaler)
      003435 00 00 95 97           1950 	.dw	0,(XG$TIM4_GetPrescaler$0$0+1)
      003439 01                    1951 	.db	1
      00343A 00 00 29 B4           1952 	.dw	0,(Ldebug_loc_start+104)
      00343E 00 00 00 AD           1953 	.dw	0,173
      003442 08                    1954 	.uleb128	8
      003443 00 00 04 3A           1955 	.dw	0,1082
      003447 54 49 4D 34 5F 47 65  1956 	.ascii "TIM4_GetFlagStatus"
             74 46 6C 61 67 53 74
             61 74 75 73
      003459 00                    1957 	.db	0
      00345A 00 00 95 97           1958 	.dw	0,(_TIM4_GetFlagStatus)
      00345E 00 00 95 A9           1959 	.dw	0,(XG$TIM4_GetFlagStatus$0$0+1)
      003462 01                    1960 	.db	1
      003463 00 00 29 A0           1961 	.dw	0,(Ldebug_loc_start+84)
      003467 00 00 00 AD           1962 	.dw	0,173
      00346B 04                    1963 	.uleb128	4
      00346C 02                    1964 	.db	2
      00346D 91                    1965 	.db	145
      00346E 02                    1966 	.sleb128	2
      00346F 54 49 4D 34 5F 46 4C  1967 	.ascii "TIM4_FLAG"
             41 47
      003478 00                    1968 	.db	0
      003479 00 00 00 AD           1969 	.dw	0,173
      00347D 06                    1970 	.uleb128	6
      00347E 00 00 95 A2           1971 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$140)
      003482 00 00 95 A4           1972 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$142)
      003486 06                    1973 	.uleb128	6
      003487 00 00 95 A7           1974 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$143)
      00348B 00 00 95 A8           1975 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$145)
      00348F 09                    1976 	.uleb128	9
      003490 01                    1977 	.db	1
      003491 50                    1978 	.db	80
      003492 62 69 74 73 74 61 74  1979 	.ascii "bitstatus"
             75 73
      00349B 00                    1980 	.db	0
      00349C 00 00 00 AD           1981 	.dw	0,173
      0034A0 00                    1982 	.uleb128	0
      0034A1 03                    1983 	.uleb128	3
      0034A2 00 00 04 6E           1984 	.dw	0,1134
      0034A6 54 49 4D 34 5F 43 6C  1985 	.ascii "TIM4_ClearFlag"
             65 61 72 46 6C 61 67
      0034B4 00                    1986 	.db	0
      0034B5 00 00 95 A9           1987 	.dw	0,(_TIM4_ClearFlag)
      0034B9 00 00 95 B0           1988 	.dw	0,(XG$TIM4_ClearFlag$0$0+1)
      0034BD 01                    1989 	.db	1
      0034BE 00 00 29 8C           1990 	.dw	0,(Ldebug_loc_start+64)
      0034C2 04                    1991 	.uleb128	4
      0034C3 02                    1992 	.db	2
      0034C4 91                    1993 	.db	145
      0034C5 02                    1994 	.sleb128	2
      0034C6 54 49 4D 34 5F 46 4C  1995 	.ascii "TIM4_FLAG"
             41 47
      0034CF 00                    1996 	.db	0
      0034D0 00 00 00 AD           1997 	.dw	0,173
      0034D4 00                    1998 	.uleb128	0
      0034D5 08                    1999 	.uleb128	8
      0034D6 00 00 04 EA           2000 	.dw	0,1258
      0034DA 54 49 4D 34 5F 47 65  2001 	.ascii "TIM4_GetITStatus"
             74 49 54 53 74 61 74
             75 73
      0034EA 00                    2002 	.db	0
      0034EB 00 00 95 B0           2003 	.dw	0,(_TIM4_GetITStatus)
      0034EF 00 00 95 D3           2004 	.dw	0,(XG$TIM4_GetITStatus$0$0+1)
      0034F3 01                    2005 	.db	1
      0034F4 00 00 29 60           2006 	.dw	0,(Ldebug_loc_start+20)
      0034F8 00 00 00 AD           2007 	.dw	0,173
      0034FC 04                    2008 	.uleb128	4
      0034FD 02                    2009 	.db	2
      0034FE 91                    2010 	.db	145
      0034FF 02                    2011 	.sleb128	2
      003500 54 49 4D 34 5F 49 54  2012 	.ascii "TIM4_IT"
      003507 00                    2013 	.db	0
      003508 00 00 00 AD           2014 	.dw	0,173
      00350C 06                    2015 	.uleb128	6
      00350D 00 00 95 CA           2016 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$162)
      003511 00 00 95 CC           2017 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$164)
      003515 06                    2018 	.uleb128	6
      003516 00 00 95 CF           2019 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$165)
      00351A 00 00 95 D0           2020 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$167)
      00351E 09                    2021 	.uleb128	9
      00351F 01                    2022 	.db	1
      003520 50                    2023 	.db	80
      003521 62 69 74 73 74 61 74  2024 	.ascii "bitstatus"
             75 73
      00352A 00                    2025 	.db	0
      00352B 00 00 00 AD           2026 	.dw	0,173
      00352F 09                    2027 	.uleb128	9
      003530 02                    2028 	.db	2
      003531 91                    2029 	.db	145
      003532 7F                    2030 	.sleb128	-1
      003533 69 74 73 74 61 74 75  2031 	.ascii "itstatus"
             73
      00353B 00                    2032 	.db	0
      00353C 00 00 00 AD           2033 	.dw	0,173
      003540 09                    2034 	.uleb128	9
      003541 01                    2035 	.db	1
      003542 50                    2036 	.db	80
      003543 69 74 65 6E 61 62 6C  2037 	.ascii "itenable"
             65
      00354B 00                    2038 	.db	0
      00354C 00 00 00 AD           2039 	.dw	0,173
      003550 00                    2040 	.uleb128	0
      003551 0A                    2041 	.uleb128	10
      003552 54 49 4D 34 5F 43 6C  2042 	.ascii "TIM4_ClearITPendingBit"
             65 61 72 49 54 50 65
             6E 64 69 6E 67 42 69
             74
      003568 00                    2043 	.db	0
      003569 00 00 95 D3           2044 	.dw	0,(_TIM4_ClearITPendingBit)
      00356D 00 00 95 DA           2045 	.dw	0,(XG$TIM4_ClearITPendingBit$0$0+1)
      003571 01                    2046 	.db	1
      003572 00 00 29 4C           2047 	.dw	0,(Ldebug_loc_start)
      003576 04                    2048 	.uleb128	4
      003577 02                    2049 	.db	2
      003578 91                    2050 	.db	145
      003579 02                    2051 	.sleb128	2
      00357A 54 49 4D 34 5F 49 54  2052 	.ascii "TIM4_IT"
      003581 00                    2053 	.db	0
      003582 00 00 00 AD           2054 	.dw	0,173
      003586 00                    2055 	.uleb128	0
      003587 00                    2056 	.uleb128	0
      003588 00                    2057 	.uleb128	0
      003589 00                    2058 	.uleb128	0
      00358A                       2059 Ldebug_info_end:
                                   2060 
                                   2061 	.area .debug_pubnames (NOLOAD)
      0008CC 00 00 01 A2           2062 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      0008D0                       2063 Ldebug_pubnames_start:
      0008D0 00 02                 2064 	.dw	2
      0008D2 00 00 30 67           2065 	.dw	0,(Ldebug_info_start-4)
      0008D6 00 00 05 23           2066 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      0008DA 00 00 00 43           2067 	.dw	0,67
      0008DE 54 49 4D 34 5F 44 65  2068 	.ascii "TIM4_DeInit"
             49 6E 69 74
      0008E9 00                    2069 	.db	0
      0008EA 00 00 00 5D           2070 	.dw	0,93
      0008EE 54 49 4D 34 5F 54 69  2071 	.ascii "TIM4_TimeBaseInit"
             6D 65 42 61 73 65 49
             6E 69 74
      0008FF 00                    2072 	.db	0
      000900 00 00 00 BE           2073 	.dw	0,190
      000904 54 49 4D 34 5F 43 6D  2074 	.ascii "TIM4_Cmd"
             64
      00090C 00                    2075 	.db	0
      00090D 00 00 00 FD           2076 	.dw	0,253
      000911 54 49 4D 34 5F 49 54  2077 	.ascii "TIM4_ITConfig"
             43 6F 6E 66 69 67
      00091E 00                    2078 	.db	0
      00091F 00 00 01 51           2079 	.dw	0,337
      000923 54 49 4D 34 5F 55 70  2080 	.ascii "TIM4_UpdateDisableConfig"
             64 61 74 65 44 69 73
             61 62 6C 65 43 6F 6E
             66 69 67
      00093B 00                    2081 	.db	0
      00093C 00 00 01 A0           2082 	.dw	0,416
      000940 54 49 4D 34 5F 55 70  2083 	.ascii "TIM4_UpdateRequestConfig"
             64 61 74 65 52 65 71
             75 65 73 74 43 6F 6E
             66 69 67
      000958 00                    2084 	.db	0
      000959 00 00 01 F8           2085 	.dw	0,504
      00095D 54 49 4D 34 5F 53 65  2086 	.ascii "TIM4_SelectOnePulseMode"
             6C 65 63 74 4F 6E 65
             50 75 6C 73 65 4D 6F
             64 65
      000974 00                    2087 	.db	0
      000975 00 00 02 49           2088 	.dw	0,585
      000979 54 49 4D 34 5F 50 72  2089 	.ascii "TIM4_PrescalerConfig"
             65 73 63 61 6C 65 72
             43 6F 6E 66 69 67
      00098D 00                    2090 	.db	0
      00098E 00 00 02 9E           2091 	.dw	0,670
      000992 54 49 4D 34 5F 41 52  2092 	.ascii "TIM4_ARRPreloadConfig"
             52 50 72 65 6C 6F 61
             64 43 6F 6E 66 69 67
      0009A7 00                    2093 	.db	0
      0009A8 00 00 02 EA           2094 	.dw	0,746
      0009AC 54 49 4D 34 5F 47 65  2095 	.ascii "TIM4_GenerateEvent"
             6E 65 72 61 74 65 45
             76 65 6E 74
      0009BE 00                    2096 	.db	0
      0009BF 00 00 03 29           2097 	.dw	0,809
      0009C3 54 49 4D 34 5F 53 65  2098 	.ascii "TIM4_SetCounter"
             74 43 6F 75 6E 74 65
             72
      0009D2 00                    2099 	.db	0
      0009D3 00 00 03 5C           2100 	.dw	0,860
      0009D7 54 49 4D 34 5F 53 65  2101 	.ascii "TIM4_SetAutoreload"
             74 41 75 74 6F 72 65
             6C 6F 61 64
      0009E9 00                    2102 	.db	0
      0009EA 00 00 03 95           2103 	.dw	0,917
      0009EE 54 49 4D 34 5F 47 65  2104 	.ascii "TIM4_GetCounter"
             74 43 6F 75 6E 74 65
             72
      0009FD 00                    2105 	.db	0
      0009FE 00 00 03 B7           2106 	.dw	0,951
      000A02 54 49 4D 34 5F 47 65  2107 	.ascii "TIM4_GetPrescaler"
             74 50 72 65 73 63 61
             6C 65 72
      000A13 00                    2108 	.db	0
      000A14 00 00 03 DB           2109 	.dw	0,987
      000A18 54 49 4D 34 5F 47 65  2110 	.ascii "TIM4_GetFlagStatus"
             74 46 6C 61 67 53 74
             61 74 75 73
      000A2A 00                    2111 	.db	0
      000A2B 00 00 04 3A           2112 	.dw	0,1082
      000A2F 54 49 4D 34 5F 43 6C  2113 	.ascii "TIM4_ClearFlag"
             65 61 72 46 6C 61 67
      000A3D 00                    2114 	.db	0
      000A3E 00 00 04 6E           2115 	.dw	0,1134
      000A42 54 49 4D 34 5F 47 65  2116 	.ascii "TIM4_GetITStatus"
             74 49 54 53 74 61 74
             75 73
      000A52 00                    2117 	.db	0
      000A53 00 00 04 EA           2118 	.dw	0,1258
      000A57 54 49 4D 34 5F 43 6C  2119 	.ascii "TIM4_ClearITPendingBit"
             65 61 72 49 54 50 65
             6E 64 69 6E 67 42 69
             74
      000A6D 00                    2120 	.db	0
      000A6E 00 00 00 00           2121 	.dw	0,0
      000A72                       2122 Ldebug_pubnames_end:
                                   2123 
                                   2124 	.area .debug_frame (NOLOAD)
      00241F 00 00                 2125 	.dw	0
      002421 00 0E                 2126 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      002423                       2127 Ldebug_CIE0_start:
      002423 FF FF                 2128 	.dw	0xffff
      002425 FF FF                 2129 	.dw	0xffff
      002427 01                    2130 	.db	1
      002428 00                    2131 	.db	0
      002429 01                    2132 	.uleb128	1
      00242A 7F                    2133 	.sleb128	-1
      00242B 09                    2134 	.db	9
      00242C 0C                    2135 	.db	12
      00242D 08                    2136 	.uleb128	8
      00242E 02                    2137 	.uleb128	2
      00242F 89                    2138 	.db	137
      002430 01                    2139 	.uleb128	1
      002431                       2140 Ldebug_CIE0_end:
      002431 00 00 00 13           2141 	.dw	0,19
      002435 00 00 24 1F           2142 	.dw	0,(Ldebug_CIE0_start-4)
      002439 00 00 95 D3           2143 	.dw	0,(Sstm8s_tim4$TIM4_ClearITPendingBit$174)	;initial loc
      00243D 00 00 00 07           2144 	.dw	0,Sstm8s_tim4$TIM4_ClearITPendingBit$178-Sstm8s_tim4$TIM4_ClearITPendingBit$174
      002441 01                    2145 	.db	1
      002442 00 00 95 D3           2146 	.dw	0,(Sstm8s_tim4$TIM4_ClearITPendingBit$174)
      002446 0E                    2147 	.db	14
      002447 02                    2148 	.uleb128	2
                                   2149 
                                   2150 	.area .debug_frame (NOLOAD)
      002448 00 00                 2151 	.dw	0
      00244A 00 0E                 2152 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      00244C                       2153 Ldebug_CIE1_start:
      00244C FF FF                 2154 	.dw	0xffff
      00244E FF FF                 2155 	.dw	0xffff
      002450 01                    2156 	.db	1
      002451 00                    2157 	.db	0
      002452 01                    2158 	.uleb128	1
      002453 7F                    2159 	.sleb128	-1
      002454 09                    2160 	.db	9
      002455 0C                    2161 	.db	12
      002456 08                    2162 	.uleb128	8
      002457 02                    2163 	.uleb128	2
      002458 89                    2164 	.db	137
      002459 01                    2165 	.uleb128	1
      00245A                       2166 Ldebug_CIE1_end:
      00245A 00 00 00 21           2167 	.dw	0,33
      00245E 00 00 24 48           2168 	.dw	0,(Ldebug_CIE1_start-4)
      002462 00 00 95 B0           2169 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$157)	;initial loc
      002466 00 00 00 23           2170 	.dw	0,Sstm8s_tim4$TIM4_GetITStatus$172-Sstm8s_tim4$TIM4_GetITStatus$157
      00246A 01                    2171 	.db	1
      00246B 00 00 95 B0           2172 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$157)
      00246F 0E                    2173 	.db	14
      002470 02                    2174 	.uleb128	2
      002471 01                    2175 	.db	1
      002472 00 00 95 B1           2176 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$158)
      002476 0E                    2177 	.db	14
      002477 03                    2178 	.uleb128	3
      002478 01                    2179 	.db	1
      002479 00 00 95 D2           2180 	.dw	0,(Sstm8s_tim4$TIM4_GetITStatus$170)
      00247D 0E                    2181 	.db	14
      00247E 02                    2182 	.uleb128	2
                                   2183 
                                   2184 	.area .debug_frame (NOLOAD)
      00247F 00 00                 2185 	.dw	0
      002481 00 0E                 2186 	.dw	Ldebug_CIE2_end-Ldebug_CIE2_start
      002483                       2187 Ldebug_CIE2_start:
      002483 FF FF                 2188 	.dw	0xffff
      002485 FF FF                 2189 	.dw	0xffff
      002487 01                    2190 	.db	1
      002488 00                    2191 	.db	0
      002489 01                    2192 	.uleb128	1
      00248A 7F                    2193 	.sleb128	-1
      00248B 09                    2194 	.db	9
      00248C 0C                    2195 	.db	12
      00248D 08                    2196 	.uleb128	8
      00248E 02                    2197 	.uleb128	2
      00248F 89                    2198 	.db	137
      002490 01                    2199 	.uleb128	1
      002491                       2200 Ldebug_CIE2_end:
      002491 00 00 00 13           2201 	.dw	0,19
      002495 00 00 24 7F           2202 	.dw	0,(Ldebug_CIE2_start-4)
      002499 00 00 95 A9           2203 	.dw	0,(Sstm8s_tim4$TIM4_ClearFlag$151)	;initial loc
      00249D 00 00 00 07           2204 	.dw	0,Sstm8s_tim4$TIM4_ClearFlag$155-Sstm8s_tim4$TIM4_ClearFlag$151
      0024A1 01                    2205 	.db	1
      0024A2 00 00 95 A9           2206 	.dw	0,(Sstm8s_tim4$TIM4_ClearFlag$151)
      0024A6 0E                    2207 	.db	14
      0024A7 02                    2208 	.uleb128	2
                                   2209 
                                   2210 	.area .debug_frame (NOLOAD)
      0024A8 00 00                 2211 	.dw	0
      0024AA 00 0E                 2212 	.dw	Ldebug_CIE3_end-Ldebug_CIE3_start
      0024AC                       2213 Ldebug_CIE3_start:
      0024AC FF FF                 2214 	.dw	0xffff
      0024AE FF FF                 2215 	.dw	0xffff
      0024B0 01                    2216 	.db	1
      0024B1 00                    2217 	.db	0
      0024B2 01                    2218 	.uleb128	1
      0024B3 7F                    2219 	.sleb128	-1
      0024B4 09                    2220 	.db	9
      0024B5 0C                    2221 	.db	12
      0024B6 08                    2222 	.uleb128	8
      0024B7 02                    2223 	.uleb128	2
      0024B8 89                    2224 	.db	137
      0024B9 01                    2225 	.uleb128	1
      0024BA                       2226 Ldebug_CIE3_end:
      0024BA 00 00 00 13           2227 	.dw	0,19
      0024BE 00 00 24 A8           2228 	.dw	0,(Ldebug_CIE3_start-4)
      0024C2 00 00 95 97           2229 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$138)	;initial loc
      0024C6 00 00 00 12           2230 	.dw	0,Sstm8s_tim4$TIM4_GetFlagStatus$149-Sstm8s_tim4$TIM4_GetFlagStatus$138
      0024CA 01                    2231 	.db	1
      0024CB 00 00 95 97           2232 	.dw	0,(Sstm8s_tim4$TIM4_GetFlagStatus$138)
      0024CF 0E                    2233 	.db	14
      0024D0 02                    2234 	.uleb128	2
                                   2235 
                                   2236 	.area .debug_frame (NOLOAD)
      0024D1 00 00                 2237 	.dw	0
      0024D3 00 0E                 2238 	.dw	Ldebug_CIE4_end-Ldebug_CIE4_start
      0024D5                       2239 Ldebug_CIE4_start:
      0024D5 FF FF                 2240 	.dw	0xffff
      0024D7 FF FF                 2241 	.dw	0xffff
      0024D9 01                    2242 	.db	1
      0024DA 00                    2243 	.db	0
      0024DB 01                    2244 	.uleb128	1
      0024DC 7F                    2245 	.sleb128	-1
      0024DD 09                    2246 	.db	9
      0024DE 0C                    2247 	.db	12
      0024DF 08                    2248 	.uleb128	8
      0024E0 02                    2249 	.uleb128	2
      0024E1 89                    2250 	.db	137
      0024E2 01                    2251 	.uleb128	1
      0024E3                       2252 Ldebug_CIE4_end:
      0024E3 00 00 00 13           2253 	.dw	0,19
      0024E7 00 00 24 D1           2254 	.dw	0,(Ldebug_CIE4_start-4)
      0024EB 00 00 95 93           2255 	.dw	0,(Sstm8s_tim4$TIM4_GetPrescaler$132)	;initial loc
      0024EF 00 00 00 04           2256 	.dw	0,Sstm8s_tim4$TIM4_GetPrescaler$136-Sstm8s_tim4$TIM4_GetPrescaler$132
      0024F3 01                    2257 	.db	1
      0024F4 00 00 95 93           2258 	.dw	0,(Sstm8s_tim4$TIM4_GetPrescaler$132)
      0024F8 0E                    2259 	.db	14
      0024F9 02                    2260 	.uleb128	2
                                   2261 
                                   2262 	.area .debug_frame (NOLOAD)
      0024FA 00 00                 2263 	.dw	0
      0024FC 00 0E                 2264 	.dw	Ldebug_CIE5_end-Ldebug_CIE5_start
      0024FE                       2265 Ldebug_CIE5_start:
      0024FE FF FF                 2266 	.dw	0xffff
      002500 FF FF                 2267 	.dw	0xffff
      002502 01                    2268 	.db	1
      002503 00                    2269 	.db	0
      002504 01                    2270 	.uleb128	1
      002505 7F                    2271 	.sleb128	-1
      002506 09                    2272 	.db	9
      002507 0C                    2273 	.db	12
      002508 08                    2274 	.uleb128	8
      002509 02                    2275 	.uleb128	2
      00250A 89                    2276 	.db	137
      00250B 01                    2277 	.uleb128	1
      00250C                       2278 Ldebug_CIE5_end:
      00250C 00 00 00 13           2279 	.dw	0,19
      002510 00 00 24 FA           2280 	.dw	0,(Ldebug_CIE5_start-4)
      002514 00 00 95 8F           2281 	.dw	0,(Sstm8s_tim4$TIM4_GetCounter$126)	;initial loc
      002518 00 00 00 04           2282 	.dw	0,Sstm8s_tim4$TIM4_GetCounter$130-Sstm8s_tim4$TIM4_GetCounter$126
      00251C 01                    2283 	.db	1
      00251D 00 00 95 8F           2284 	.dw	0,(Sstm8s_tim4$TIM4_GetCounter$126)
      002521 0E                    2285 	.db	14
      002522 02                    2286 	.uleb128	2
                                   2287 
                                   2288 	.area .debug_frame (NOLOAD)
      002523 00 00                 2289 	.dw	0
      002525 00 0E                 2290 	.dw	Ldebug_CIE6_end-Ldebug_CIE6_start
      002527                       2291 Ldebug_CIE6_start:
      002527 FF FF                 2292 	.dw	0xffff
      002529 FF FF                 2293 	.dw	0xffff
      00252B 01                    2294 	.db	1
      00252C 00                    2295 	.db	0
      00252D 01                    2296 	.uleb128	1
      00252E 7F                    2297 	.sleb128	-1
      00252F 09                    2298 	.db	9
      002530 0C                    2299 	.db	12
      002531 08                    2300 	.uleb128	8
      002532 02                    2301 	.uleb128	2
      002533 89                    2302 	.db	137
      002534 01                    2303 	.uleb128	1
      002535                       2304 Ldebug_CIE6_end:
      002535 00 00 00 13           2305 	.dw	0,19
      002539 00 00 25 23           2306 	.dw	0,(Ldebug_CIE6_start-4)
      00253D 00 00 95 88           2307 	.dw	0,(Sstm8s_tim4$TIM4_SetAutoreload$120)	;initial loc
      002541 00 00 00 07           2308 	.dw	0,Sstm8s_tim4$TIM4_SetAutoreload$124-Sstm8s_tim4$TIM4_SetAutoreload$120
      002545 01                    2309 	.db	1
      002546 00 00 95 88           2310 	.dw	0,(Sstm8s_tim4$TIM4_SetAutoreload$120)
      00254A 0E                    2311 	.db	14
      00254B 02                    2312 	.uleb128	2
                                   2313 
                                   2314 	.area .debug_frame (NOLOAD)
      00254C 00 00                 2315 	.dw	0
      00254E 00 0E                 2316 	.dw	Ldebug_CIE7_end-Ldebug_CIE7_start
      002550                       2317 Ldebug_CIE7_start:
      002550 FF FF                 2318 	.dw	0xffff
      002552 FF FF                 2319 	.dw	0xffff
      002554 01                    2320 	.db	1
      002555 00                    2321 	.db	0
      002556 01                    2322 	.uleb128	1
      002557 7F                    2323 	.sleb128	-1
      002558 09                    2324 	.db	9
      002559 0C                    2325 	.db	12
      00255A 08                    2326 	.uleb128	8
      00255B 02                    2327 	.uleb128	2
      00255C 89                    2328 	.db	137
      00255D 01                    2329 	.uleb128	1
      00255E                       2330 Ldebug_CIE7_end:
      00255E 00 00 00 13           2331 	.dw	0,19
      002562 00 00 25 4C           2332 	.dw	0,(Ldebug_CIE7_start-4)
      002566 00 00 95 81           2333 	.dw	0,(Sstm8s_tim4$TIM4_SetCounter$114)	;initial loc
      00256A 00 00 00 07           2334 	.dw	0,Sstm8s_tim4$TIM4_SetCounter$118-Sstm8s_tim4$TIM4_SetCounter$114
      00256E 01                    2335 	.db	1
      00256F 00 00 95 81           2336 	.dw	0,(Sstm8s_tim4$TIM4_SetCounter$114)
      002573 0E                    2337 	.db	14
      002574 02                    2338 	.uleb128	2
                                   2339 
                                   2340 	.area .debug_frame (NOLOAD)
      002575 00 00                 2341 	.dw	0
      002577 00 0E                 2342 	.dw	Ldebug_CIE8_end-Ldebug_CIE8_start
      002579                       2343 Ldebug_CIE8_start:
      002579 FF FF                 2344 	.dw	0xffff
      00257B FF FF                 2345 	.dw	0xffff
      00257D 01                    2346 	.db	1
      00257E 00                    2347 	.db	0
      00257F 01                    2348 	.uleb128	1
      002580 7F                    2349 	.sleb128	-1
      002581 09                    2350 	.db	9
      002582 0C                    2351 	.db	12
      002583 08                    2352 	.uleb128	8
      002584 02                    2353 	.uleb128	2
      002585 89                    2354 	.db	137
      002586 01                    2355 	.uleb128	1
      002587                       2356 Ldebug_CIE8_end:
      002587 00 00 00 13           2357 	.dw	0,19
      00258B 00 00 25 75           2358 	.dw	0,(Ldebug_CIE8_start-4)
      00258F 00 00 95 7A           2359 	.dw	0,(Sstm8s_tim4$TIM4_GenerateEvent$108)	;initial loc
      002593 00 00 00 07           2360 	.dw	0,Sstm8s_tim4$TIM4_GenerateEvent$112-Sstm8s_tim4$TIM4_GenerateEvent$108
      002597 01                    2361 	.db	1
      002598 00 00 95 7A           2362 	.dw	0,(Sstm8s_tim4$TIM4_GenerateEvent$108)
      00259C 0E                    2363 	.db	14
      00259D 02                    2364 	.uleb128	2
                                   2365 
                                   2366 	.area .debug_frame (NOLOAD)
      00259E 00 00                 2367 	.dw	0
      0025A0 00 0E                 2368 	.dw	Ldebug_CIE9_end-Ldebug_CIE9_start
      0025A2                       2369 Ldebug_CIE9_start:
      0025A2 FF FF                 2370 	.dw	0xffff
      0025A4 FF FF                 2371 	.dw	0xffff
      0025A6 01                    2372 	.db	1
      0025A7 00                    2373 	.db	0
      0025A8 01                    2374 	.uleb128	1
      0025A9 7F                    2375 	.sleb128	-1
      0025AA 09                    2376 	.db	9
      0025AB 0C                    2377 	.db	12
      0025AC 08                    2378 	.uleb128	8
      0025AD 02                    2379 	.uleb128	2
      0025AE 89                    2380 	.db	137
      0025AF 01                    2381 	.uleb128	1
      0025B0                       2382 Ldebug_CIE9_end:
      0025B0 00 00 00 13           2383 	.dw	0,19
      0025B4 00 00 25 9E           2384 	.dw	0,(Ldebug_CIE9_start-4)
      0025B8 00 00 95 62           2385 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$95)	;initial loc
      0025BC 00 00 00 18           2386 	.dw	0,Sstm8s_tim4$TIM4_ARRPreloadConfig$106-Sstm8s_tim4$TIM4_ARRPreloadConfig$95
      0025C0 01                    2387 	.db	1
      0025C1 00 00 95 62           2388 	.dw	0,(Sstm8s_tim4$TIM4_ARRPreloadConfig$95)
      0025C5 0E                    2389 	.db	14
      0025C6 02                    2390 	.uleb128	2
                                   2391 
                                   2392 	.area .debug_frame (NOLOAD)
      0025C7 00 00                 2393 	.dw	0
      0025C9 00 0E                 2394 	.dw	Ldebug_CIE10_end-Ldebug_CIE10_start
      0025CB                       2395 Ldebug_CIE10_start:
      0025CB FF FF                 2396 	.dw	0xffff
      0025CD FF FF                 2397 	.dw	0xffff
      0025CF 01                    2398 	.db	1
      0025D0 00                    2399 	.db	0
      0025D1 01                    2400 	.uleb128	1
      0025D2 7F                    2401 	.sleb128	-1
      0025D3 09                    2402 	.db	9
      0025D4 0C                    2403 	.db	12
      0025D5 08                    2404 	.uleb128	8
      0025D6 02                    2405 	.uleb128	2
      0025D7 89                    2406 	.db	137
      0025D8 01                    2407 	.uleb128	1
      0025D9                       2408 Ldebug_CIE10_end:
      0025D9 00 00 00 13           2409 	.dw	0,19
      0025DD 00 00 25 C7           2410 	.dw	0,(Ldebug_CIE10_start-4)
      0025E1 00 00 95 55           2411 	.dw	0,(Sstm8s_tim4$TIM4_PrescalerConfig$88)	;initial loc
      0025E5 00 00 00 0D           2412 	.dw	0,Sstm8s_tim4$TIM4_PrescalerConfig$93-Sstm8s_tim4$TIM4_PrescalerConfig$88
      0025E9 01                    2413 	.db	1
      0025EA 00 00 95 55           2414 	.dw	0,(Sstm8s_tim4$TIM4_PrescalerConfig$88)
      0025EE 0E                    2415 	.db	14
      0025EF 02                    2416 	.uleb128	2
                                   2417 
                                   2418 	.area .debug_frame (NOLOAD)
      0025F0 00 00                 2419 	.dw	0
      0025F2 00 0E                 2420 	.dw	Ldebug_CIE11_end-Ldebug_CIE11_start
      0025F4                       2421 Ldebug_CIE11_start:
      0025F4 FF FF                 2422 	.dw	0xffff
      0025F6 FF FF                 2423 	.dw	0xffff
      0025F8 01                    2424 	.db	1
      0025F9 00                    2425 	.db	0
      0025FA 01                    2426 	.uleb128	1
      0025FB 7F                    2427 	.sleb128	-1
      0025FC 09                    2428 	.db	9
      0025FD 0C                    2429 	.db	12
      0025FE 08                    2430 	.uleb128	8
      0025FF 02                    2431 	.uleb128	2
      002600 89                    2432 	.db	137
      002601 01                    2433 	.uleb128	1
      002602                       2434 Ldebug_CIE11_end:
      002602 00 00 00 13           2435 	.dw	0,19
      002606 00 00 25 F0           2436 	.dw	0,(Ldebug_CIE11_start-4)
      00260A 00 00 95 3D           2437 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$75)	;initial loc
      00260E 00 00 00 18           2438 	.dw	0,Sstm8s_tim4$TIM4_SelectOnePulseMode$86-Sstm8s_tim4$TIM4_SelectOnePulseMode$75
      002612 01                    2439 	.db	1
      002613 00 00 95 3D           2440 	.dw	0,(Sstm8s_tim4$TIM4_SelectOnePulseMode$75)
      002617 0E                    2441 	.db	14
      002618 02                    2442 	.uleb128	2
                                   2443 
                                   2444 	.area .debug_frame (NOLOAD)
      002619 00 00                 2445 	.dw	0
      00261B 00 0E                 2446 	.dw	Ldebug_CIE12_end-Ldebug_CIE12_start
      00261D                       2447 Ldebug_CIE12_start:
      00261D FF FF                 2448 	.dw	0xffff
      00261F FF FF                 2449 	.dw	0xffff
      002621 01                    2450 	.db	1
      002622 00                    2451 	.db	0
      002623 01                    2452 	.uleb128	1
      002624 7F                    2453 	.sleb128	-1
      002625 09                    2454 	.db	9
      002626 0C                    2455 	.db	12
      002627 08                    2456 	.uleb128	8
      002628 02                    2457 	.uleb128	2
      002629 89                    2458 	.db	137
      00262A 01                    2459 	.uleb128	1
      00262B                       2460 Ldebug_CIE12_end:
      00262B 00 00 00 13           2461 	.dw	0,19
      00262F 00 00 26 19           2462 	.dw	0,(Ldebug_CIE12_start-4)
      002633 00 00 95 25           2463 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$62)	;initial loc
      002637 00 00 00 18           2464 	.dw	0,Sstm8s_tim4$TIM4_UpdateRequestConfig$73-Sstm8s_tim4$TIM4_UpdateRequestConfig$62
      00263B 01                    2465 	.db	1
      00263C 00 00 95 25           2466 	.dw	0,(Sstm8s_tim4$TIM4_UpdateRequestConfig$62)
      002640 0E                    2467 	.db	14
      002641 02                    2468 	.uleb128	2
                                   2469 
                                   2470 	.area .debug_frame (NOLOAD)
      002642 00 00                 2471 	.dw	0
      002644 00 0E                 2472 	.dw	Ldebug_CIE13_end-Ldebug_CIE13_start
      002646                       2473 Ldebug_CIE13_start:
      002646 FF FF                 2474 	.dw	0xffff
      002648 FF FF                 2475 	.dw	0xffff
      00264A 01                    2476 	.db	1
      00264B 00                    2477 	.db	0
      00264C 01                    2478 	.uleb128	1
      00264D 7F                    2479 	.sleb128	-1
      00264E 09                    2480 	.db	9
      00264F 0C                    2481 	.db	12
      002650 08                    2482 	.uleb128	8
      002651 02                    2483 	.uleb128	2
      002652 89                    2484 	.db	137
      002653 01                    2485 	.uleb128	1
      002654                       2486 Ldebug_CIE13_end:
      002654 00 00 00 13           2487 	.dw	0,19
      002658 00 00 26 42           2488 	.dw	0,(Ldebug_CIE13_start-4)
      00265C 00 00 95 0D           2489 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$49)	;initial loc
      002660 00 00 00 18           2490 	.dw	0,Sstm8s_tim4$TIM4_UpdateDisableConfig$60-Sstm8s_tim4$TIM4_UpdateDisableConfig$49
      002664 01                    2491 	.db	1
      002665 00 00 95 0D           2492 	.dw	0,(Sstm8s_tim4$TIM4_UpdateDisableConfig$49)
      002669 0E                    2493 	.db	14
      00266A 02                    2494 	.uleb128	2
                                   2495 
                                   2496 	.area .debug_frame (NOLOAD)
      00266B 00 00                 2497 	.dw	0
      00266D 00 0E                 2498 	.dw	Ldebug_CIE14_end-Ldebug_CIE14_start
      00266F                       2499 Ldebug_CIE14_start:
      00266F FF FF                 2500 	.dw	0xffff
      002671 FF FF                 2501 	.dw	0xffff
      002673 01                    2502 	.db	1
      002674 00                    2503 	.db	0
      002675 01                    2504 	.uleb128	1
      002676 7F                    2505 	.sleb128	-1
      002677 09                    2506 	.db	9
      002678 0C                    2507 	.db	12
      002679 08                    2508 	.uleb128	8
      00267A 02                    2509 	.uleb128	2
      00267B 89                    2510 	.db	137
      00267C 01                    2511 	.uleb128	1
      00267D                       2512 Ldebug_CIE14_end:
      00267D 00 00 00 2F           2513 	.dw	0,47
      002681 00 00 26 6B           2514 	.dw	0,(Ldebug_CIE14_start-4)
      002685 00 00 94 EC           2515 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$32)	;initial loc
      002689 00 00 00 21           2516 	.dw	0,Sstm8s_tim4$TIM4_ITConfig$47-Sstm8s_tim4$TIM4_ITConfig$32
      00268D 01                    2517 	.db	1
      00268E 00 00 94 EC           2518 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$32)
      002692 0E                    2519 	.db	14
      002693 02                    2520 	.uleb128	2
      002694 01                    2521 	.db	1
      002695 00 00 94 ED           2522 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$33)
      002699 0E                    2523 	.db	14
      00269A 03                    2524 	.uleb128	3
      00269B 01                    2525 	.db	1
      00269C 00 00 95 00           2526 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$41)
      0026A0 0E                    2527 	.db	14
      0026A1 04                    2528 	.uleb128	4
      0026A2 01                    2529 	.db	1
      0026A3 00 00 95 06           2530 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$42)
      0026A7 0E                    2531 	.db	14
      0026A8 03                    2532 	.uleb128	3
      0026A9 01                    2533 	.db	1
      0026AA 00 00 95 0C           2534 	.dw	0,(Sstm8s_tim4$TIM4_ITConfig$45)
      0026AE 0E                    2535 	.db	14
      0026AF 02                    2536 	.uleb128	2
                                   2537 
                                   2538 	.area .debug_frame (NOLOAD)
      0026B0 00 00                 2539 	.dw	0
      0026B2 00 0E                 2540 	.dw	Ldebug_CIE15_end-Ldebug_CIE15_start
      0026B4                       2541 Ldebug_CIE15_start:
      0026B4 FF FF                 2542 	.dw	0xffff
      0026B6 FF FF                 2543 	.dw	0xffff
      0026B8 01                    2544 	.db	1
      0026B9 00                    2545 	.db	0
      0026BA 01                    2546 	.uleb128	1
      0026BB 7F                    2547 	.sleb128	-1
      0026BC 09                    2548 	.db	9
      0026BD 0C                    2549 	.db	12
      0026BE 08                    2550 	.uleb128	8
      0026BF 02                    2551 	.uleb128	2
      0026C0 89                    2552 	.db	137
      0026C1 01                    2553 	.uleb128	1
      0026C2                       2554 Ldebug_CIE15_end:
      0026C2 00 00 00 13           2555 	.dw	0,19
      0026C6 00 00 26 B0           2556 	.dw	0,(Ldebug_CIE15_start-4)
      0026CA 00 00 94 D4           2557 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$19)	;initial loc
      0026CE 00 00 00 18           2558 	.dw	0,Sstm8s_tim4$TIM4_Cmd$30-Sstm8s_tim4$TIM4_Cmd$19
      0026D2 01                    2559 	.db	1
      0026D3 00 00 94 D4           2560 	.dw	0,(Sstm8s_tim4$TIM4_Cmd$19)
      0026D7 0E                    2561 	.db	14
      0026D8 02                    2562 	.uleb128	2
                                   2563 
                                   2564 	.area .debug_frame (NOLOAD)
      0026D9 00 00                 2565 	.dw	0
      0026DB 00 0E                 2566 	.dw	Ldebug_CIE16_end-Ldebug_CIE16_start
      0026DD                       2567 Ldebug_CIE16_start:
      0026DD FF FF                 2568 	.dw	0xffff
      0026DF FF FF                 2569 	.dw	0xffff
      0026E1 01                    2570 	.db	1
      0026E2 00                    2571 	.db	0
      0026E3 01                    2572 	.uleb128	1
      0026E4 7F                    2573 	.sleb128	-1
      0026E5 09                    2574 	.db	9
      0026E6 0C                    2575 	.db	12
      0026E7 08                    2576 	.uleb128	8
      0026E8 02                    2577 	.uleb128	2
      0026E9 89                    2578 	.db	137
      0026EA 01                    2579 	.uleb128	1
      0026EB                       2580 Ldebug_CIE16_end:
      0026EB 00 00 00 13           2581 	.dw	0,19
      0026EF 00 00 26 D9           2582 	.dw	0,(Ldebug_CIE16_start-4)
      0026F3 00 00 94 C7           2583 	.dw	0,(Sstm8s_tim4$TIM4_TimeBaseInit$12)	;initial loc
      0026F7 00 00 00 0D           2584 	.dw	0,Sstm8s_tim4$TIM4_TimeBaseInit$17-Sstm8s_tim4$TIM4_TimeBaseInit$12
      0026FB 01                    2585 	.db	1
      0026FC 00 00 94 C7           2586 	.dw	0,(Sstm8s_tim4$TIM4_TimeBaseInit$12)
      002700 0E                    2587 	.db	14
      002701 02                    2588 	.uleb128	2
                                   2589 
                                   2590 	.area .debug_frame (NOLOAD)
      002702 00 00                 2591 	.dw	0
      002704 00 0E                 2592 	.dw	Ldebug_CIE17_end-Ldebug_CIE17_start
      002706                       2593 Ldebug_CIE17_start:
      002706 FF FF                 2594 	.dw	0xffff
      002708 FF FF                 2595 	.dw	0xffff
      00270A 01                    2596 	.db	1
      00270B 00                    2597 	.db	0
      00270C 01                    2598 	.uleb128	1
      00270D 7F                    2599 	.sleb128	-1
      00270E 09                    2600 	.db	9
      00270F 0C                    2601 	.db	12
      002710 08                    2602 	.uleb128	8
      002711 02                    2603 	.uleb128	2
      002712 89                    2604 	.db	137
      002713 01                    2605 	.uleb128	1
      002714                       2606 Ldebug_CIE17_end:
      002714 00 00 00 13           2607 	.dw	0,19
      002718 00 00 27 02           2608 	.dw	0,(Ldebug_CIE17_start-4)
      00271C 00 00 94 AE           2609 	.dw	0,(Sstm8s_tim4$TIM4_DeInit$1)	;initial loc
      002720 00 00 00 19           2610 	.dw	0,Sstm8s_tim4$TIM4_DeInit$10-Sstm8s_tim4$TIM4_DeInit$1
      002724 01                    2611 	.db	1
      002725 00 00 94 AE           2612 	.dw	0,(Sstm8s_tim4$TIM4_DeInit$1)
      002729 0E                    2613 	.db	14
      00272A 02                    2614 	.uleb128	2
