                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module swspi
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _GPIO_WriteLow
                                     12 	.globl _GPIO_WriteHigh
                                     13 	.globl _GPIO_Init
                                     14 	.globl _swspi_init
                                     15 	.globl _swspi_tx16
                                     16 ;--------------------------------------------------------
                                     17 ; ram data
                                     18 ;--------------------------------------------------------
                                     19 	.area DATA
                                     20 ;--------------------------------------------------------
                                     21 ; ram data
                                     22 ;--------------------------------------------------------
                                     23 	.area INITIALIZED
                                     24 ;--------------------------------------------------------
                                     25 ; absolute external ram data
                                     26 ;--------------------------------------------------------
                                     27 	.area DABS (ABS)
                                     28 
                                     29 ; default segment ordering for linker
                                     30 	.area HOME
                                     31 	.area GSINIT
                                     32 	.area GSFINAL
                                     33 	.area CONST
                                     34 	.area INITIALIZER
                                     35 	.area CODE
                                     36 
                                     37 ;--------------------------------------------------------
                                     38 ; global & static initialisations
                                     39 ;--------------------------------------------------------
                                     40 	.area HOME
                                     41 	.area GSINIT
                                     42 	.area GSFINAL
                                     43 	.area GSINIT
                                     44 ;--------------------------------------------------------
                                     45 ; Home
                                     46 ;--------------------------------------------------------
                                     47 	.area HOME
                                     48 	.area HOME
                                     49 ;--------------------------------------------------------
                                     50 ; code
                                     51 ;--------------------------------------------------------
                                     52 	.area CODE
                           000000    53 	Sswspi$swspi_init$0 ==.
                                     54 ;	./src/swspi.c: 12: void swspi_init(void){
                                     55 ; genLabel
                                     56 ;	-----------------------------------------
                                     57 ;	 function swspi_init
                                     58 ;	-----------------------------------------
                                     59 ;	Register assignment is optimal.
                                     60 ;	Stack space usage: 0 bytes.
      008E89                         61 _swspi_init:
                           000000    62 	Sswspi$swspi_init$1 ==.
                           000000    63 	Sswspi$swspi_init$2 ==.
                                     64 ;	./src/swspi.c: 13: GPIO_Init(CS_GPIO,CS_PIN,GPIO_MODE_OUT_PP_HIGH_FAST);
                                     65 ; genIPush
      008E89 4B F0            [ 1]   66 	push	#0xf0
                           000002    67 	Sswspi$swspi_init$3 ==.
                                     68 ; genIPush
      008E8B 4B 10            [ 1]   69 	push	#0x10
                           000004    70 	Sswspi$swspi_init$4 ==.
                                     71 ; genIPush
      008E8D 4B 05            [ 1]   72 	push	#0x05
                           000006    73 	Sswspi$swspi_init$5 ==.
      008E8F 4B 50            [ 1]   74 	push	#0x50
                           000008    75 	Sswspi$swspi_init$6 ==.
                                     76 ; genCall
      008E91 CD 8F 7C         [ 4]   77 	call	_GPIO_Init
      008E94 5B 04            [ 2]   78 	addw	sp, #4
                           00000D    79 	Sswspi$swspi_init$7 ==.
                           00000D    80 	Sswspi$swspi_init$8 ==.
                                     81 ;	./src/swspi.c: 14: GPIO_Init(CLK_GPIO,CLK_PIN,GPIO_MODE_OUT_PP_LOW_FAST);
                                     82 ; genIPush
      008E96 4B E0            [ 1]   83 	push	#0xe0
                           00000F    84 	Sswspi$swspi_init$9 ==.
                                     85 ; genIPush
      008E98 4B 08            [ 1]   86 	push	#0x08
                           000011    87 	Sswspi$swspi_init$10 ==.
                                     88 ; genIPush
      008E9A 4B 05            [ 1]   89 	push	#0x05
                           000013    90 	Sswspi$swspi_init$11 ==.
      008E9C 4B 50            [ 1]   91 	push	#0x50
                           000015    92 	Sswspi$swspi_init$12 ==.
                                     93 ; genCall
      008E9E CD 8F 7C         [ 4]   94 	call	_GPIO_Init
      008EA1 5B 04            [ 2]   95 	addw	sp, #4
                           00001A    96 	Sswspi$swspi_init$13 ==.
                           00001A    97 	Sswspi$swspi_init$14 ==.
                                     98 ;	./src/swspi.c: 15: GPIO_Init(DIN_GPIO,DIN_PIN,GPIO_MODE_OUT_PP_LOW_FAST);
                                     99 ; genIPush
      008EA3 4B E0            [ 1]  100 	push	#0xe0
                           00001C   101 	Sswspi$swspi_init$15 ==.
                                    102 ; genIPush
      008EA5 4B 20            [ 1]  103 	push	#0x20
                           00001E   104 	Sswspi$swspi_init$16 ==.
                                    105 ; genIPush
      008EA7 4B 05            [ 1]  106 	push	#0x05
                           000020   107 	Sswspi$swspi_init$17 ==.
      008EA9 4B 50            [ 1]  108 	push	#0x50
                           000022   109 	Sswspi$swspi_init$18 ==.
                                    110 ; genCall
      008EAB CD 8F 7C         [ 4]  111 	call	_GPIO_Init
      008EAE 5B 04            [ 2]  112 	addw	sp, #4
                           000027   113 	Sswspi$swspi_init$19 ==.
                                    114 ; genLabel
      008EB0                        115 00101$:
                           000027   116 	Sswspi$swspi_init$20 ==.
                                    117 ;	./src/swspi.c: 16: }
                                    118 ; genEndFunction
                           000027   119 	Sswspi$swspi_init$21 ==.
                           000027   120 	XG$swspi_init$0$0 ==.
      008EB0 81               [ 4]  121 	ret
                           000028   122 	Sswspi$swspi_init$22 ==.
                           000028   123 	Sswspi$swspi_tx16$23 ==.
                                    124 ;	./src/swspi.c: 19: void swspi_tx16(uint16_t data)
                                    125 ; genLabel
                                    126 ;	-----------------------------------------
                                    127 ;	 function swspi_tx16
                                    128 ;	-----------------------------------------
                                    129 ;	Register assignment is optimal.
                                    130 ;	Stack space usage: 2 bytes.
      008EB1                        131 _swspi_tx16:
                           000028   132 	Sswspi$swspi_tx16$24 ==.
      008EB1 89               [ 2]  133 	pushw	x
                           000029   134 	Sswspi$swspi_tx16$25 ==.
                           000029   135 	Sswspi$swspi_tx16$26 ==.
                                    136 ;	./src/swspi.c: 21: uint16_t maska = 1 << 15;
                                    137 ; genAssign
      008EB2 AE 80 00         [ 2]  138 	ldw	x, #0x8000
      008EB5 1F 01            [ 2]  139 	ldw	(0x01, sp), x
                           00002E   140 	Sswspi$swspi_tx16$27 ==.
                                    141 ;	./src/swspi.c: 23: CS_L;
                                    142 ; genIPush
      008EB7 4B 10            [ 1]  143 	push	#0x10
                           000030   144 	Sswspi$swspi_tx16$28 ==.
                                    145 ; genIPush
      008EB9 4B 05            [ 1]  146 	push	#0x05
                           000032   147 	Sswspi$swspi_tx16$29 ==.
      008EBB 4B 50            [ 1]  148 	push	#0x50
                           000034   149 	Sswspi$swspi_tx16$30 ==.
                                    150 ; genCall
      008EBD CD 90 10         [ 4]  151 	call	_GPIO_WriteLow
      008EC0 5B 03            [ 2]  152 	addw	sp, #3
                           000039   153 	Sswspi$swspi_tx16$31 ==.
                           000039   154 	Sswspi$swspi_tx16$32 ==.
                                    155 ;	./src/swspi.c: 24: while (maska) {
                                    156 ; genLabel
      008EC2                        157 00104$:
                                    158 ; genIfx
      008EC2 1E 01            [ 2]  159 	ldw	x, (0x01, sp)
      008EC4 26 03            [ 1]  160 	jrne	00124$
      008EC6 CC 8F 0F         [ 2]  161 	jp	00106$
      008EC9                        162 00124$:
                           000040   163 	Sswspi$swspi_tx16$33 ==.
                           000040   164 	Sswspi$swspi_tx16$34 ==.
                                    165 ;	./src/swspi.c: 25: if (maska & data) {
                                    166 ; genAnd
      008EC9 7B 02            [ 1]  167 	ld	a, (0x02, sp)
      008ECB 14 06            [ 1]  168 	and	a, (0x06, sp)
      008ECD 97               [ 1]  169 	ld	xl, a
      008ECE 7B 01            [ 1]  170 	ld	a, (0x01, sp)
      008ED0 14 05            [ 1]  171 	and	a, (0x05, sp)
      008ED2 95               [ 1]  172 	ld	xh, a
                                    173 ; genIfx
      008ED3 5D               [ 2]  174 	tnzw	x
      008ED4 26 03            [ 1]  175 	jrne	00125$
      008ED6 CC 8E E7         [ 2]  176 	jp	00102$
      008ED9                        177 00125$:
                           000050   178 	Sswspi$swspi_tx16$35 ==.
                           000050   179 	Sswspi$swspi_tx16$36 ==.
                                    180 ;	./src/swspi.c: 26: DIN_H;
                                    181 ; genIPush
      008ED9 4B 20            [ 1]  182 	push	#0x20
                           000052   183 	Sswspi$swspi_tx16$37 ==.
                                    184 ; genIPush
      008EDB 4B 05            [ 1]  185 	push	#0x05
                           000054   186 	Sswspi$swspi_tx16$38 ==.
      008EDD 4B 50            [ 1]  187 	push	#0x50
                           000056   188 	Sswspi$swspi_tx16$39 ==.
                                    189 ; genCall
      008EDF CD 90 09         [ 4]  190 	call	_GPIO_WriteHigh
      008EE2 5B 03            [ 2]  191 	addw	sp, #3
                           00005B   192 	Sswspi$swspi_tx16$40 ==.
                           00005B   193 	Sswspi$swspi_tx16$41 ==.
                                    194 ; genGoto
      008EE4 CC 8E F2         [ 2]  195 	jp	00103$
                                    196 ; genLabel
      008EE7                        197 00102$:
                           00005E   198 	Sswspi$swspi_tx16$42 ==.
                           00005E   199 	Sswspi$swspi_tx16$43 ==.
                                    200 ;	./src/swspi.c: 28: DIN_L;
                                    201 ; genIPush
      008EE7 4B 20            [ 1]  202 	push	#0x20
                           000060   203 	Sswspi$swspi_tx16$44 ==.
                                    204 ; genIPush
      008EE9 4B 05            [ 1]  205 	push	#0x05
                           000062   206 	Sswspi$swspi_tx16$45 ==.
      008EEB 4B 50            [ 1]  207 	push	#0x50
                           000064   208 	Sswspi$swspi_tx16$46 ==.
                                    209 ; genCall
      008EED CD 90 10         [ 4]  210 	call	_GPIO_WriteLow
      008EF0 5B 03            [ 2]  211 	addw	sp, #3
                           000069   212 	Sswspi$swspi_tx16$47 ==.
                           000069   213 	Sswspi$swspi_tx16$48 ==.
                                    214 ; genLabel
      008EF2                        215 00103$:
                           000069   216 	Sswspi$swspi_tx16$49 ==.
                                    217 ;	./src/swspi.c: 30: CLK_H;
                                    218 ; genIPush
      008EF2 4B 08            [ 1]  219 	push	#0x08
                           00006B   220 	Sswspi$swspi_tx16$50 ==.
                                    221 ; genIPush
      008EF4 4B 05            [ 1]  222 	push	#0x05
                           00006D   223 	Sswspi$swspi_tx16$51 ==.
      008EF6 4B 50            [ 1]  224 	push	#0x50
                           00006F   225 	Sswspi$swspi_tx16$52 ==.
                                    226 ; genCall
      008EF8 CD 90 09         [ 4]  227 	call	_GPIO_WriteHigh
      008EFB 5B 03            [ 2]  228 	addw	sp, #3
                           000074   229 	Sswspi$swspi_tx16$53 ==.
                           000074   230 	Sswspi$swspi_tx16$54 ==.
                                    231 ;	./src/swspi.c: 31: maska = maska >> 1;
                                    232 ; genRightShiftLiteral
      008EFD 04 01            [ 1]  233 	srl	(0x01, sp)
      008EFF 06 02            [ 1]  234 	rrc	(0x02, sp)
                           000078   235 	Sswspi$swspi_tx16$55 ==.
                                    236 ;	./src/swspi.c: 32: CLK_L;
                                    237 ; genIPush
      008F01 4B 08            [ 1]  238 	push	#0x08
                           00007A   239 	Sswspi$swspi_tx16$56 ==.
                                    240 ; genIPush
      008F03 4B 05            [ 1]  241 	push	#0x05
                           00007C   242 	Sswspi$swspi_tx16$57 ==.
      008F05 4B 50            [ 1]  243 	push	#0x50
                           00007E   244 	Sswspi$swspi_tx16$58 ==.
                                    245 ; genCall
      008F07 CD 90 10         [ 4]  246 	call	_GPIO_WriteLow
      008F0A 5B 03            [ 2]  247 	addw	sp, #3
                           000083   248 	Sswspi$swspi_tx16$59 ==.
                           000083   249 	Sswspi$swspi_tx16$60 ==.
                                    250 ; genGoto
      008F0C CC 8E C2         [ 2]  251 	jp	00104$
                                    252 ; genLabel
      008F0F                        253 00106$:
                           000086   254 	Sswspi$swspi_tx16$61 ==.
                                    255 ;	./src/swspi.c: 34: CS_H;
                                    256 ; genIPush
      008F0F 4B 10            [ 1]  257 	push	#0x10
                           000088   258 	Sswspi$swspi_tx16$62 ==.
                                    259 ; genIPush
      008F11 4B 05            [ 1]  260 	push	#0x05
                           00008A   261 	Sswspi$swspi_tx16$63 ==.
      008F13 4B 50            [ 1]  262 	push	#0x50
                           00008C   263 	Sswspi$swspi_tx16$64 ==.
                                    264 ; genCall
      008F15 CD 90 09         [ 4]  265 	call	_GPIO_WriteHigh
      008F18 5B 03            [ 2]  266 	addw	sp, #3
                           000091   267 	Sswspi$swspi_tx16$65 ==.
                                    268 ; genLabel
      008F1A                        269 00107$:
                           000091   270 	Sswspi$swspi_tx16$66 ==.
                                    271 ;	./src/swspi.c: 35: }
                                    272 ; genEndFunction
      008F1A 85               [ 2]  273 	popw	x
                           000092   274 	Sswspi$swspi_tx16$67 ==.
                           000092   275 	Sswspi$swspi_tx16$68 ==.
                           000092   276 	XG$swspi_tx16$0$0 ==.
      008F1B 81               [ 4]  277 	ret
                           000093   278 	Sswspi$swspi_tx16$69 ==.
                                    279 	.area CODE
                                    280 	.area CONST
                                    281 	.area INITIALIZER
                                    282 	.area CABS (ABS)
                                    283 
                                    284 	.area .debug_line (NOLOAD)
      0012DC 00 00 00 EE            285 	.dw	0,Ldebug_line_end-Ldebug_line_start
      0012E0                        286 Ldebug_line_start:
      0012E0 00 02                  287 	.dw	2
      0012E2 00 00 00 6E            288 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      0012E6 01                     289 	.db	1
      0012E7 01                     290 	.db	1
      0012E8 FB                     291 	.db	-5
      0012E9 0F                     292 	.db	15
      0012EA 0A                     293 	.db	10
      0012EB 00                     294 	.db	0
      0012EC 01                     295 	.db	1
      0012ED 01                     296 	.db	1
      0012EE 01                     297 	.db	1
      0012EF 01                     298 	.db	1
      0012F0 00                     299 	.db	0
      0012F1 00                     300 	.db	0
      0012F2 00                     301 	.db	0
      0012F3 01                     302 	.db	1
      0012F4 43 3A 5C 50 72 6F 67   303 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      00131C 00                     304 	.db	0
      00131D 43 3A 5C 50 72 6F 67   305 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      001340 00                     306 	.db	0
      001341 00                     307 	.db	0
      001342 2E 2F 73 72 63 2F 73   308 	.ascii "./src/swspi.c"
             77 73 70 69 2E 63
      00134F 00                     309 	.db	0
      001350 00                     310 	.uleb128	0
      001351 00                     311 	.uleb128	0
      001352 00                     312 	.uleb128	0
      001353 00                     313 	.db	0
      001354                        314 Ldebug_line_stmt:
      001354 00                     315 	.db	0
      001355 05                     316 	.uleb128	5
      001356 02                     317 	.db	2
      001357 00 00 8E 89            318 	.dw	0,(Sswspi$swspi_init$0)
      00135B 03                     319 	.db	3
      00135C 0B                     320 	.sleb128	11
      00135D 01                     321 	.db	1
      00135E 09                     322 	.db	9
      00135F 00 00                  323 	.dw	Sswspi$swspi_init$2-Sswspi$swspi_init$0
      001361 03                     324 	.db	3
      001362 01                     325 	.sleb128	1
      001363 01                     326 	.db	1
      001364 09                     327 	.db	9
      001365 00 0D                  328 	.dw	Sswspi$swspi_init$8-Sswspi$swspi_init$2
      001367 03                     329 	.db	3
      001368 01                     330 	.sleb128	1
      001369 01                     331 	.db	1
      00136A 09                     332 	.db	9
      00136B 00 0D                  333 	.dw	Sswspi$swspi_init$14-Sswspi$swspi_init$8
      00136D 03                     334 	.db	3
      00136E 01                     335 	.sleb128	1
      00136F 01                     336 	.db	1
      001370 09                     337 	.db	9
      001371 00 0D                  338 	.dw	Sswspi$swspi_init$20-Sswspi$swspi_init$14
      001373 03                     339 	.db	3
      001374 01                     340 	.sleb128	1
      001375 01                     341 	.db	1
      001376 09                     342 	.db	9
      001377 00 01                  343 	.dw	1+Sswspi$swspi_init$21-Sswspi$swspi_init$20
      001379 00                     344 	.db	0
      00137A 01                     345 	.uleb128	1
      00137B 01                     346 	.db	1
      00137C 00                     347 	.db	0
      00137D 05                     348 	.uleb128	5
      00137E 02                     349 	.db	2
      00137F 00 00 8E B1            350 	.dw	0,(Sswspi$swspi_tx16$23)
      001383 03                     351 	.db	3
      001384 12                     352 	.sleb128	18
      001385 01                     353 	.db	1
      001386 09                     354 	.db	9
      001387 00 01                  355 	.dw	Sswspi$swspi_tx16$26-Sswspi$swspi_tx16$23
      001389 03                     356 	.db	3
      00138A 02                     357 	.sleb128	2
      00138B 01                     358 	.db	1
      00138C 09                     359 	.db	9
      00138D 00 05                  360 	.dw	Sswspi$swspi_tx16$27-Sswspi$swspi_tx16$26
      00138F 03                     361 	.db	3
      001390 02                     362 	.sleb128	2
      001391 01                     363 	.db	1
      001392 09                     364 	.db	9
      001393 00 0B                  365 	.dw	Sswspi$swspi_tx16$32-Sswspi$swspi_tx16$27
      001395 03                     366 	.db	3
      001396 01                     367 	.sleb128	1
      001397 01                     368 	.db	1
      001398 09                     369 	.db	9
      001399 00 07                  370 	.dw	Sswspi$swspi_tx16$34-Sswspi$swspi_tx16$32
      00139B 03                     371 	.db	3
      00139C 01                     372 	.sleb128	1
      00139D 01                     373 	.db	1
      00139E 09                     374 	.db	9
      00139F 00 10                  375 	.dw	Sswspi$swspi_tx16$36-Sswspi$swspi_tx16$34
      0013A1 03                     376 	.db	3
      0013A2 01                     377 	.sleb128	1
      0013A3 01                     378 	.db	1
      0013A4 09                     379 	.db	9
      0013A5 00 0E                  380 	.dw	Sswspi$swspi_tx16$43-Sswspi$swspi_tx16$36
      0013A7 03                     381 	.db	3
      0013A8 02                     382 	.sleb128	2
      0013A9 01                     383 	.db	1
      0013AA 09                     384 	.db	9
      0013AB 00 0B                  385 	.dw	Sswspi$swspi_tx16$49-Sswspi$swspi_tx16$43
      0013AD 03                     386 	.db	3
      0013AE 02                     387 	.sleb128	2
      0013AF 01                     388 	.db	1
      0013B0 09                     389 	.db	9
      0013B1 00 0B                  390 	.dw	Sswspi$swspi_tx16$54-Sswspi$swspi_tx16$49
      0013B3 03                     391 	.db	3
      0013B4 01                     392 	.sleb128	1
      0013B5 01                     393 	.db	1
      0013B6 09                     394 	.db	9
      0013B7 00 04                  395 	.dw	Sswspi$swspi_tx16$55-Sswspi$swspi_tx16$54
      0013B9 03                     396 	.db	3
      0013BA 01                     397 	.sleb128	1
      0013BB 01                     398 	.db	1
      0013BC 09                     399 	.db	9
      0013BD 00 0E                  400 	.dw	Sswspi$swspi_tx16$61-Sswspi$swspi_tx16$55
      0013BF 03                     401 	.db	3
      0013C0 02                     402 	.sleb128	2
      0013C1 01                     403 	.db	1
      0013C2 09                     404 	.db	9
      0013C3 00 0B                  405 	.dw	Sswspi$swspi_tx16$66-Sswspi$swspi_tx16$61
      0013C5 03                     406 	.db	3
      0013C6 01                     407 	.sleb128	1
      0013C7 01                     408 	.db	1
      0013C8 09                     409 	.db	9
      0013C9 00 02                  410 	.dw	1+Sswspi$swspi_tx16$68-Sswspi$swspi_tx16$66
      0013CB 00                     411 	.db	0
      0013CC 01                     412 	.uleb128	1
      0013CD 01                     413 	.db	1
      0013CE                        414 Ldebug_line_end:
                                    415 
                                    416 	.area .debug_loc (NOLOAD)
      0020CC                        417 Ldebug_loc_start:
      0020CC 00 00 8F 1B            418 	.dw	0,(Sswspi$swspi_tx16$67)
      0020D0 00 00 8F 1C            419 	.dw	0,(Sswspi$swspi_tx16$69)
      0020D4 00 02                  420 	.dw	2
      0020D6 78                     421 	.db	120
      0020D7 01                     422 	.sleb128	1
      0020D8 00 00 8F 1A            423 	.dw	0,(Sswspi$swspi_tx16$65)
      0020DC 00 00 8F 1B            424 	.dw	0,(Sswspi$swspi_tx16$67)
      0020E0 00 02                  425 	.dw	2
      0020E2 78                     426 	.db	120
      0020E3 03                     427 	.sleb128	3
      0020E4 00 00 8F 15            428 	.dw	0,(Sswspi$swspi_tx16$64)
      0020E8 00 00 8F 1A            429 	.dw	0,(Sswspi$swspi_tx16$65)
      0020EC 00 02                  430 	.dw	2
      0020EE 78                     431 	.db	120
      0020EF 06                     432 	.sleb128	6
      0020F0 00 00 8F 13            433 	.dw	0,(Sswspi$swspi_tx16$63)
      0020F4 00 00 8F 15            434 	.dw	0,(Sswspi$swspi_tx16$64)
      0020F8 00 02                  435 	.dw	2
      0020FA 78                     436 	.db	120
      0020FB 05                     437 	.sleb128	5
      0020FC 00 00 8F 11            438 	.dw	0,(Sswspi$swspi_tx16$62)
      002100 00 00 8F 13            439 	.dw	0,(Sswspi$swspi_tx16$63)
      002104 00 02                  440 	.dw	2
      002106 78                     441 	.db	120
      002107 04                     442 	.sleb128	4
      002108 00 00 8F 0C            443 	.dw	0,(Sswspi$swspi_tx16$59)
      00210C 00 00 8F 11            444 	.dw	0,(Sswspi$swspi_tx16$62)
      002110 00 02                  445 	.dw	2
      002112 78                     446 	.db	120
      002113 03                     447 	.sleb128	3
      002114 00 00 8F 07            448 	.dw	0,(Sswspi$swspi_tx16$58)
      002118 00 00 8F 0C            449 	.dw	0,(Sswspi$swspi_tx16$59)
      00211C 00 02                  450 	.dw	2
      00211E 78                     451 	.db	120
      00211F 06                     452 	.sleb128	6
      002120 00 00 8F 05            453 	.dw	0,(Sswspi$swspi_tx16$57)
      002124 00 00 8F 07            454 	.dw	0,(Sswspi$swspi_tx16$58)
      002128 00 02                  455 	.dw	2
      00212A 78                     456 	.db	120
      00212B 05                     457 	.sleb128	5
      00212C 00 00 8F 03            458 	.dw	0,(Sswspi$swspi_tx16$56)
      002130 00 00 8F 05            459 	.dw	0,(Sswspi$swspi_tx16$57)
      002134 00 02                  460 	.dw	2
      002136 78                     461 	.db	120
      002137 04                     462 	.sleb128	4
      002138 00 00 8E FD            463 	.dw	0,(Sswspi$swspi_tx16$53)
      00213C 00 00 8F 03            464 	.dw	0,(Sswspi$swspi_tx16$56)
      002140 00 02                  465 	.dw	2
      002142 78                     466 	.db	120
      002143 03                     467 	.sleb128	3
      002144 00 00 8E F8            468 	.dw	0,(Sswspi$swspi_tx16$52)
      002148 00 00 8E FD            469 	.dw	0,(Sswspi$swspi_tx16$53)
      00214C 00 02                  470 	.dw	2
      00214E 78                     471 	.db	120
      00214F 06                     472 	.sleb128	6
      002150 00 00 8E F6            473 	.dw	0,(Sswspi$swspi_tx16$51)
      002154 00 00 8E F8            474 	.dw	0,(Sswspi$swspi_tx16$52)
      002158 00 02                  475 	.dw	2
      00215A 78                     476 	.db	120
      00215B 05                     477 	.sleb128	5
      00215C 00 00 8E F4            478 	.dw	0,(Sswspi$swspi_tx16$50)
      002160 00 00 8E F6            479 	.dw	0,(Sswspi$swspi_tx16$51)
      002164 00 02                  480 	.dw	2
      002166 78                     481 	.db	120
      002167 04                     482 	.sleb128	4
      002168 00 00 8E F2            483 	.dw	0,(Sswspi$swspi_tx16$47)
      00216C 00 00 8E F4            484 	.dw	0,(Sswspi$swspi_tx16$50)
      002170 00 02                  485 	.dw	2
      002172 78                     486 	.db	120
      002173 03                     487 	.sleb128	3
      002174 00 00 8E ED            488 	.dw	0,(Sswspi$swspi_tx16$46)
      002178 00 00 8E F2            489 	.dw	0,(Sswspi$swspi_tx16$47)
      00217C 00 02                  490 	.dw	2
      00217E 78                     491 	.db	120
      00217F 06                     492 	.sleb128	6
      002180 00 00 8E EB            493 	.dw	0,(Sswspi$swspi_tx16$45)
      002184 00 00 8E ED            494 	.dw	0,(Sswspi$swspi_tx16$46)
      002188 00 02                  495 	.dw	2
      00218A 78                     496 	.db	120
      00218B 05                     497 	.sleb128	5
      00218C 00 00 8E E9            498 	.dw	0,(Sswspi$swspi_tx16$44)
      002190 00 00 8E EB            499 	.dw	0,(Sswspi$swspi_tx16$45)
      002194 00 02                  500 	.dw	2
      002196 78                     501 	.db	120
      002197 04                     502 	.sleb128	4
      002198 00 00 8E E4            503 	.dw	0,(Sswspi$swspi_tx16$40)
      00219C 00 00 8E E9            504 	.dw	0,(Sswspi$swspi_tx16$44)
      0021A0 00 02                  505 	.dw	2
      0021A2 78                     506 	.db	120
      0021A3 03                     507 	.sleb128	3
      0021A4 00 00 8E DF            508 	.dw	0,(Sswspi$swspi_tx16$39)
      0021A8 00 00 8E E4            509 	.dw	0,(Sswspi$swspi_tx16$40)
      0021AC 00 02                  510 	.dw	2
      0021AE 78                     511 	.db	120
      0021AF 06                     512 	.sleb128	6
      0021B0 00 00 8E DD            513 	.dw	0,(Sswspi$swspi_tx16$38)
      0021B4 00 00 8E DF            514 	.dw	0,(Sswspi$swspi_tx16$39)
      0021B8 00 02                  515 	.dw	2
      0021BA 78                     516 	.db	120
      0021BB 05                     517 	.sleb128	5
      0021BC 00 00 8E DB            518 	.dw	0,(Sswspi$swspi_tx16$37)
      0021C0 00 00 8E DD            519 	.dw	0,(Sswspi$swspi_tx16$38)
      0021C4 00 02                  520 	.dw	2
      0021C6 78                     521 	.db	120
      0021C7 04                     522 	.sleb128	4
      0021C8 00 00 8E C2            523 	.dw	0,(Sswspi$swspi_tx16$31)
      0021CC 00 00 8E DB            524 	.dw	0,(Sswspi$swspi_tx16$37)
      0021D0 00 02                  525 	.dw	2
      0021D2 78                     526 	.db	120
      0021D3 03                     527 	.sleb128	3
      0021D4 00 00 8E BD            528 	.dw	0,(Sswspi$swspi_tx16$30)
      0021D8 00 00 8E C2            529 	.dw	0,(Sswspi$swspi_tx16$31)
      0021DC 00 02                  530 	.dw	2
      0021DE 78                     531 	.db	120
      0021DF 06                     532 	.sleb128	6
      0021E0 00 00 8E BB            533 	.dw	0,(Sswspi$swspi_tx16$29)
      0021E4 00 00 8E BD            534 	.dw	0,(Sswspi$swspi_tx16$30)
      0021E8 00 02                  535 	.dw	2
      0021EA 78                     536 	.db	120
      0021EB 05                     537 	.sleb128	5
      0021EC 00 00 8E B9            538 	.dw	0,(Sswspi$swspi_tx16$28)
      0021F0 00 00 8E BB            539 	.dw	0,(Sswspi$swspi_tx16$29)
      0021F4 00 02                  540 	.dw	2
      0021F6 78                     541 	.db	120
      0021F7 04                     542 	.sleb128	4
      0021F8 00 00 8E B2            543 	.dw	0,(Sswspi$swspi_tx16$25)
      0021FC 00 00 8E B9            544 	.dw	0,(Sswspi$swspi_tx16$28)
      002200 00 02                  545 	.dw	2
      002202 78                     546 	.db	120
      002203 03                     547 	.sleb128	3
      002204 00 00 8E B1            548 	.dw	0,(Sswspi$swspi_tx16$24)
      002208 00 00 8E B2            549 	.dw	0,(Sswspi$swspi_tx16$25)
      00220C 00 02                  550 	.dw	2
      00220E 78                     551 	.db	120
      00220F 01                     552 	.sleb128	1
      002210 00 00 00 00            553 	.dw	0,0
      002214 00 00 00 00            554 	.dw	0,0
      002218 00 00 8E B0            555 	.dw	0,(Sswspi$swspi_init$19)
      00221C 00 00 8E B1            556 	.dw	0,(Sswspi$swspi_init$22)
      002220 00 02                  557 	.dw	2
      002222 78                     558 	.db	120
      002223 01                     559 	.sleb128	1
      002224 00 00 8E AB            560 	.dw	0,(Sswspi$swspi_init$18)
      002228 00 00 8E B0            561 	.dw	0,(Sswspi$swspi_init$19)
      00222C 00 02                  562 	.dw	2
      00222E 78                     563 	.db	120
      00222F 05                     564 	.sleb128	5
      002230 00 00 8E A9            565 	.dw	0,(Sswspi$swspi_init$17)
      002234 00 00 8E AB            566 	.dw	0,(Sswspi$swspi_init$18)
      002238 00 02                  567 	.dw	2
      00223A 78                     568 	.db	120
      00223B 04                     569 	.sleb128	4
      00223C 00 00 8E A7            570 	.dw	0,(Sswspi$swspi_init$16)
      002240 00 00 8E A9            571 	.dw	0,(Sswspi$swspi_init$17)
      002244 00 02                  572 	.dw	2
      002246 78                     573 	.db	120
      002247 03                     574 	.sleb128	3
      002248 00 00 8E A5            575 	.dw	0,(Sswspi$swspi_init$15)
      00224C 00 00 8E A7            576 	.dw	0,(Sswspi$swspi_init$16)
      002250 00 02                  577 	.dw	2
      002252 78                     578 	.db	120
      002253 02                     579 	.sleb128	2
      002254 00 00 8E A3            580 	.dw	0,(Sswspi$swspi_init$13)
      002258 00 00 8E A5            581 	.dw	0,(Sswspi$swspi_init$15)
      00225C 00 02                  582 	.dw	2
      00225E 78                     583 	.db	120
      00225F 01                     584 	.sleb128	1
      002260 00 00 8E 9E            585 	.dw	0,(Sswspi$swspi_init$12)
      002264 00 00 8E A3            586 	.dw	0,(Sswspi$swspi_init$13)
      002268 00 02                  587 	.dw	2
      00226A 78                     588 	.db	120
      00226B 05                     589 	.sleb128	5
      00226C 00 00 8E 9C            590 	.dw	0,(Sswspi$swspi_init$11)
      002270 00 00 8E 9E            591 	.dw	0,(Sswspi$swspi_init$12)
      002274 00 02                  592 	.dw	2
      002276 78                     593 	.db	120
      002277 04                     594 	.sleb128	4
      002278 00 00 8E 9A            595 	.dw	0,(Sswspi$swspi_init$10)
      00227C 00 00 8E 9C            596 	.dw	0,(Sswspi$swspi_init$11)
      002280 00 02                  597 	.dw	2
      002282 78                     598 	.db	120
      002283 03                     599 	.sleb128	3
      002284 00 00 8E 98            600 	.dw	0,(Sswspi$swspi_init$9)
      002288 00 00 8E 9A            601 	.dw	0,(Sswspi$swspi_init$10)
      00228C 00 02                  602 	.dw	2
      00228E 78                     603 	.db	120
      00228F 02                     604 	.sleb128	2
      002290 00 00 8E 96            605 	.dw	0,(Sswspi$swspi_init$7)
      002294 00 00 8E 98            606 	.dw	0,(Sswspi$swspi_init$9)
      002298 00 02                  607 	.dw	2
      00229A 78                     608 	.db	120
      00229B 01                     609 	.sleb128	1
      00229C 00 00 8E 91            610 	.dw	0,(Sswspi$swspi_init$6)
      0022A0 00 00 8E 96            611 	.dw	0,(Sswspi$swspi_init$7)
      0022A4 00 02                  612 	.dw	2
      0022A6 78                     613 	.db	120
      0022A7 05                     614 	.sleb128	5
      0022A8 00 00 8E 8F            615 	.dw	0,(Sswspi$swspi_init$5)
      0022AC 00 00 8E 91            616 	.dw	0,(Sswspi$swspi_init$6)
      0022B0 00 02                  617 	.dw	2
      0022B2 78                     618 	.db	120
      0022B3 04                     619 	.sleb128	4
      0022B4 00 00 8E 8D            620 	.dw	0,(Sswspi$swspi_init$4)
      0022B8 00 00 8E 8F            621 	.dw	0,(Sswspi$swspi_init$5)
      0022BC 00 02                  622 	.dw	2
      0022BE 78                     623 	.db	120
      0022BF 03                     624 	.sleb128	3
      0022C0 00 00 8E 8B            625 	.dw	0,(Sswspi$swspi_init$3)
      0022C4 00 00 8E 8D            626 	.dw	0,(Sswspi$swspi_init$4)
      0022C8 00 02                  627 	.dw	2
      0022CA 78                     628 	.db	120
      0022CB 02                     629 	.sleb128	2
      0022CC 00 00 8E 89            630 	.dw	0,(Sswspi$swspi_init$1)
      0022D0 00 00 8E 8B            631 	.dw	0,(Sswspi$swspi_init$3)
      0022D4 00 02                  632 	.dw	2
      0022D6 78                     633 	.db	120
      0022D7 01                     634 	.sleb128	1
      0022D8 00 00 00 00            635 	.dw	0,0
      0022DC 00 00 00 00            636 	.dw	0,0
                                    637 
                                    638 	.area .debug_abbrev (NOLOAD)
      000310                        639 Ldebug_abbrev:
      000310 04                     640 	.uleb128	4
      000311 05                     641 	.uleb128	5
      000312 00                     642 	.db	0
      000313 02                     643 	.uleb128	2
      000314 0A                     644 	.uleb128	10
      000315 03                     645 	.uleb128	3
      000316 08                     646 	.uleb128	8
      000317 49                     647 	.uleb128	73
      000318 13                     648 	.uleb128	19
      000319 00                     649 	.uleb128	0
      00031A 00                     650 	.uleb128	0
      00031B 03                     651 	.uleb128	3
      00031C 2E                     652 	.uleb128	46
      00031D 01                     653 	.db	1
      00031E 01                     654 	.uleb128	1
      00031F 13                     655 	.uleb128	19
      000320 03                     656 	.uleb128	3
      000321 08                     657 	.uleb128	8
      000322 11                     658 	.uleb128	17
      000323 01                     659 	.uleb128	1
      000324 12                     660 	.uleb128	18
      000325 01                     661 	.uleb128	1
      000326 3F                     662 	.uleb128	63
      000327 0C                     663 	.uleb128	12
      000328 40                     664 	.uleb128	64
      000329 06                     665 	.uleb128	6
      00032A 00                     666 	.uleb128	0
      00032B 00                     667 	.uleb128	0
      00032C 07                     668 	.uleb128	7
      00032D 34                     669 	.uleb128	52
      00032E 00                     670 	.db	0
      00032F 02                     671 	.uleb128	2
      000330 0A                     672 	.uleb128	10
      000331 03                     673 	.uleb128	3
      000332 08                     674 	.uleb128	8
      000333 49                     675 	.uleb128	73
      000334 13                     676 	.uleb128	19
      000335 00                     677 	.uleb128	0
      000336 00                     678 	.uleb128	0
      000337 01                     679 	.uleb128	1
      000338 11                     680 	.uleb128	17
      000339 01                     681 	.db	1
      00033A 03                     682 	.uleb128	3
      00033B 08                     683 	.uleb128	8
      00033C 10                     684 	.uleb128	16
      00033D 06                     685 	.uleb128	6
      00033E 13                     686 	.uleb128	19
      00033F 0B                     687 	.uleb128	11
      000340 25                     688 	.uleb128	37
      000341 08                     689 	.uleb128	8
      000342 00                     690 	.uleb128	0
      000343 00                     691 	.uleb128	0
      000344 06                     692 	.uleb128	6
      000345 0B                     693 	.uleb128	11
      000346 00                     694 	.db	0
      000347 11                     695 	.uleb128	17
      000348 01                     696 	.uleb128	1
      000349 12                     697 	.uleb128	18
      00034A 01                     698 	.uleb128	1
      00034B 00                     699 	.uleb128	0
      00034C 00                     700 	.uleb128	0
      00034D 02                     701 	.uleb128	2
      00034E 2E                     702 	.uleb128	46
      00034F 00                     703 	.db	0
      000350 03                     704 	.uleb128	3
      000351 08                     705 	.uleb128	8
      000352 11                     706 	.uleb128	17
      000353 01                     707 	.uleb128	1
      000354 12                     708 	.uleb128	18
      000355 01                     709 	.uleb128	1
      000356 3F                     710 	.uleb128	63
      000357 0C                     711 	.uleb128	12
      000358 40                     712 	.uleb128	64
      000359 06                     713 	.uleb128	6
      00035A 00                     714 	.uleb128	0
      00035B 00                     715 	.uleb128	0
      00035C 05                     716 	.uleb128	5
      00035D 0B                     717 	.uleb128	11
      00035E 01                     718 	.db	1
      00035F 01                     719 	.uleb128	1
      000360 13                     720 	.uleb128	19
      000361 11                     721 	.uleb128	17
      000362 01                     722 	.uleb128	1
      000363 12                     723 	.uleb128	18
      000364 01                     724 	.uleb128	1
      000365 00                     725 	.uleb128	0
      000366 00                     726 	.uleb128	0
      000367 08                     727 	.uleb128	8
      000368 24                     728 	.uleb128	36
      000369 00                     729 	.db	0
      00036A 03                     730 	.uleb128	3
      00036B 08                     731 	.uleb128	8
      00036C 0B                     732 	.uleb128	11
      00036D 0B                     733 	.uleb128	11
      00036E 3E                     734 	.uleb128	62
      00036F 0B                     735 	.uleb128	11
      000370 00                     736 	.uleb128	0
      000371 00                     737 	.uleb128	0
      000372 00                     738 	.uleb128	0
                                    739 
                                    740 	.area .debug_info (NOLOAD)
      00224E 00 00 00 BA            741 	.dw	0,Ldebug_info_end-Ldebug_info_start
      002252                        742 Ldebug_info_start:
      002252 00 02                  743 	.dw	2
      002254 00 00 03 10            744 	.dw	0,(Ldebug_abbrev)
      002258 04                     745 	.db	4
      002259 01                     746 	.uleb128	1
      00225A 2E 2F 73 72 63 2F 73   747 	.ascii "./src/swspi.c"
             77 73 70 69 2E 63
      002267 00                     748 	.db	0
      002268 00 00 12 DC            749 	.dw	0,(Ldebug_line_start+-4)
      00226C 01                     750 	.db	1
      00226D 53 44 43 43 20 76 65   751 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      002286 00                     752 	.db	0
      002287 02                     753 	.uleb128	2
      002288 73 77 73 70 69 5F 69   754 	.ascii "swspi_init"
             6E 69 74
      002292 00                     755 	.db	0
      002293 00 00 8E 89            756 	.dw	0,(_swspi_init)
      002297 00 00 8E B1            757 	.dw	0,(XG$swspi_init$0$0+1)
      00229B 01                     758 	.db	1
      00229C 00 00 22 18            759 	.dw	0,(Ldebug_loc_start+332)
      0022A0 03                     760 	.uleb128	3
      0022A1 00 00 00 AB            761 	.dw	0,171
      0022A5 73 77 73 70 69 5F 74   762 	.ascii "swspi_tx16"
             78 31 36
      0022AF 00                     763 	.db	0
      0022B0 00 00 8E B1            764 	.dw	0,(_swspi_tx16)
      0022B4 00 00 8F 1C            765 	.dw	0,(XG$swspi_tx16$0$0+1)
      0022B8 01                     766 	.db	1
      0022B9 00 00 20 CC            767 	.dw	0,(Ldebug_loc_start)
      0022BD 04                     768 	.uleb128	4
      0022BE 02                     769 	.db	2
      0022BF 91                     770 	.db	145
      0022C0 02                     771 	.sleb128	2
      0022C1 64 61 74 61            772 	.ascii "data"
      0022C5 00                     773 	.db	0
      0022C6 00 00 00 AB            774 	.dw	0,171
      0022CA 05                     775 	.uleb128	5
      0022CB 00 00 00 9C            776 	.dw	0,156
      0022CF 00 00 8E C9            777 	.dw	0,(Sswspi$swspi_tx16$33)
      0022D3 00 00 8F 0C            778 	.dw	0,(Sswspi$swspi_tx16$60)
      0022D7 06                     779 	.uleb128	6
      0022D8 00 00 8E D9            780 	.dw	0,(Sswspi$swspi_tx16$35)
      0022DC 00 00 8E E4            781 	.dw	0,(Sswspi$swspi_tx16$41)
      0022E0 06                     782 	.uleb128	6
      0022E1 00 00 8E E7            783 	.dw	0,(Sswspi$swspi_tx16$42)
      0022E5 00 00 8E F2            784 	.dw	0,(Sswspi$swspi_tx16$48)
      0022E9 00                     785 	.uleb128	0
      0022EA 07                     786 	.uleb128	7
      0022EB 02                     787 	.db	2
      0022EC 91                     788 	.db	145
      0022ED 7E                     789 	.sleb128	-2
      0022EE 6D 61 73 6B 61         790 	.ascii "maska"
      0022F3 00                     791 	.db	0
      0022F4 00 00 00 AB            792 	.dw	0,171
      0022F8 00                     793 	.uleb128	0
      0022F9 08                     794 	.uleb128	8
      0022FA 75 6E 73 69 67 6E 65   795 	.ascii "unsigned int"
             64 20 69 6E 74
      002306 00                     796 	.db	0
      002307 02                     797 	.db	2
      002308 07                     798 	.db	7
      002309 00                     799 	.uleb128	0
      00230A 00                     800 	.uleb128	0
      00230B 00                     801 	.uleb128	0
      00230C                        802 Ldebug_info_end:
                                    803 
                                    804 	.area .debug_pubnames (NOLOAD)
      000545 00 00 00 2C            805 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      000549                        806 Ldebug_pubnames_start:
      000549 00 02                  807 	.dw	2
      00054B 00 00 22 4E            808 	.dw	0,(Ldebug_info_start-4)
      00054F 00 00 00 BE            809 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      000553 00 00 00 39            810 	.dw	0,57
      000557 73 77 73 70 69 5F 69   811 	.ascii "swspi_init"
             6E 69 74
      000561 00                     812 	.db	0
      000562 00 00 00 52            813 	.dw	0,82
      000566 73 77 73 70 69 5F 74   814 	.ascii "swspi_tx16"
             78 31 36
      000570 00                     815 	.db	0
      000571 00 00 00 00            816 	.dw	0,0
      000575                        817 Ldebug_pubnames_end:
                                    818 
                                    819 	.area .debug_frame (NOLOAD)
      001ACF 00 00                  820 	.dw	0
      001AD1 00 0E                  821 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      001AD3                        822 Ldebug_CIE0_start:
      001AD3 FF FF                  823 	.dw	0xffff
      001AD5 FF FF                  824 	.dw	0xffff
      001AD7 01                     825 	.db	1
      001AD8 00                     826 	.db	0
      001AD9 01                     827 	.uleb128	1
      001ADA 7F                     828 	.sleb128	-1
      001ADB 09                     829 	.db	9
      001ADC 0C                     830 	.db	12
      001ADD 08                     831 	.uleb128	8
      001ADE 02                     832 	.uleb128	2
      001ADF 89                     833 	.db	137
      001AE0 01                     834 	.uleb128	1
      001AE1                        835 Ldebug_CIE0_end:
      001AE1 00 00 00 C9            836 	.dw	0,201
      001AE5 00 00 1A CF            837 	.dw	0,(Ldebug_CIE0_start-4)
      001AE9 00 00 8E B1            838 	.dw	0,(Sswspi$swspi_tx16$24)	;initial loc
      001AED 00 00 00 6B            839 	.dw	0,Sswspi$swspi_tx16$69-Sswspi$swspi_tx16$24
      001AF1 01                     840 	.db	1
      001AF2 00 00 8E B1            841 	.dw	0,(Sswspi$swspi_tx16$24)
      001AF6 0E                     842 	.db	14
      001AF7 02                     843 	.uleb128	2
      001AF8 01                     844 	.db	1
      001AF9 00 00 8E B2            845 	.dw	0,(Sswspi$swspi_tx16$25)
      001AFD 0E                     846 	.db	14
      001AFE 04                     847 	.uleb128	4
      001AFF 01                     848 	.db	1
      001B00 00 00 8E B9            849 	.dw	0,(Sswspi$swspi_tx16$28)
      001B04 0E                     850 	.db	14
      001B05 05                     851 	.uleb128	5
      001B06 01                     852 	.db	1
      001B07 00 00 8E BB            853 	.dw	0,(Sswspi$swspi_tx16$29)
      001B0B 0E                     854 	.db	14
      001B0C 06                     855 	.uleb128	6
      001B0D 01                     856 	.db	1
      001B0E 00 00 8E BD            857 	.dw	0,(Sswspi$swspi_tx16$30)
      001B12 0E                     858 	.db	14
      001B13 07                     859 	.uleb128	7
      001B14 01                     860 	.db	1
      001B15 00 00 8E C2            861 	.dw	0,(Sswspi$swspi_tx16$31)
      001B19 0E                     862 	.db	14
      001B1A 04                     863 	.uleb128	4
      001B1B 01                     864 	.db	1
      001B1C 00 00 8E DB            865 	.dw	0,(Sswspi$swspi_tx16$37)
      001B20 0E                     866 	.db	14
      001B21 05                     867 	.uleb128	5
      001B22 01                     868 	.db	1
      001B23 00 00 8E DD            869 	.dw	0,(Sswspi$swspi_tx16$38)
      001B27 0E                     870 	.db	14
      001B28 06                     871 	.uleb128	6
      001B29 01                     872 	.db	1
      001B2A 00 00 8E DF            873 	.dw	0,(Sswspi$swspi_tx16$39)
      001B2E 0E                     874 	.db	14
      001B2F 07                     875 	.uleb128	7
      001B30 01                     876 	.db	1
      001B31 00 00 8E E4            877 	.dw	0,(Sswspi$swspi_tx16$40)
      001B35 0E                     878 	.db	14
      001B36 04                     879 	.uleb128	4
      001B37 01                     880 	.db	1
      001B38 00 00 8E E9            881 	.dw	0,(Sswspi$swspi_tx16$44)
      001B3C 0E                     882 	.db	14
      001B3D 05                     883 	.uleb128	5
      001B3E 01                     884 	.db	1
      001B3F 00 00 8E EB            885 	.dw	0,(Sswspi$swspi_tx16$45)
      001B43 0E                     886 	.db	14
      001B44 06                     887 	.uleb128	6
      001B45 01                     888 	.db	1
      001B46 00 00 8E ED            889 	.dw	0,(Sswspi$swspi_tx16$46)
      001B4A 0E                     890 	.db	14
      001B4B 07                     891 	.uleb128	7
      001B4C 01                     892 	.db	1
      001B4D 00 00 8E F2            893 	.dw	0,(Sswspi$swspi_tx16$47)
      001B51 0E                     894 	.db	14
      001B52 04                     895 	.uleb128	4
      001B53 01                     896 	.db	1
      001B54 00 00 8E F4            897 	.dw	0,(Sswspi$swspi_tx16$50)
      001B58 0E                     898 	.db	14
      001B59 05                     899 	.uleb128	5
      001B5A 01                     900 	.db	1
      001B5B 00 00 8E F6            901 	.dw	0,(Sswspi$swspi_tx16$51)
      001B5F 0E                     902 	.db	14
      001B60 06                     903 	.uleb128	6
      001B61 01                     904 	.db	1
      001B62 00 00 8E F8            905 	.dw	0,(Sswspi$swspi_tx16$52)
      001B66 0E                     906 	.db	14
      001B67 07                     907 	.uleb128	7
      001B68 01                     908 	.db	1
      001B69 00 00 8E FD            909 	.dw	0,(Sswspi$swspi_tx16$53)
      001B6D 0E                     910 	.db	14
      001B6E 04                     911 	.uleb128	4
      001B6F 01                     912 	.db	1
      001B70 00 00 8F 03            913 	.dw	0,(Sswspi$swspi_tx16$56)
      001B74 0E                     914 	.db	14
      001B75 05                     915 	.uleb128	5
      001B76 01                     916 	.db	1
      001B77 00 00 8F 05            917 	.dw	0,(Sswspi$swspi_tx16$57)
      001B7B 0E                     918 	.db	14
      001B7C 06                     919 	.uleb128	6
      001B7D 01                     920 	.db	1
      001B7E 00 00 8F 07            921 	.dw	0,(Sswspi$swspi_tx16$58)
      001B82 0E                     922 	.db	14
      001B83 07                     923 	.uleb128	7
      001B84 01                     924 	.db	1
      001B85 00 00 8F 0C            925 	.dw	0,(Sswspi$swspi_tx16$59)
      001B89 0E                     926 	.db	14
      001B8A 04                     927 	.uleb128	4
      001B8B 01                     928 	.db	1
      001B8C 00 00 8F 11            929 	.dw	0,(Sswspi$swspi_tx16$62)
      001B90 0E                     930 	.db	14
      001B91 05                     931 	.uleb128	5
      001B92 01                     932 	.db	1
      001B93 00 00 8F 13            933 	.dw	0,(Sswspi$swspi_tx16$63)
      001B97 0E                     934 	.db	14
      001B98 06                     935 	.uleb128	6
      001B99 01                     936 	.db	1
      001B9A 00 00 8F 15            937 	.dw	0,(Sswspi$swspi_tx16$64)
      001B9E 0E                     938 	.db	14
      001B9F 07                     939 	.uleb128	7
      001BA0 01                     940 	.db	1
      001BA1 00 00 8F 1A            941 	.dw	0,(Sswspi$swspi_tx16$65)
      001BA5 0E                     942 	.db	14
      001BA6 04                     943 	.uleb128	4
      001BA7 01                     944 	.db	1
      001BA8 00 00 8F 1B            945 	.dw	0,(Sswspi$swspi_tx16$67)
      001BAC 0E                     946 	.db	14
      001BAD 02                     947 	.uleb128	2
                                    948 
                                    949 	.area .debug_frame (NOLOAD)
      001BAE 00 00                  950 	.dw	0
      001BB0 00 0E                  951 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      001BB2                        952 Ldebug_CIE1_start:
      001BB2 FF FF                  953 	.dw	0xffff
      001BB4 FF FF                  954 	.dw	0xffff
      001BB6 01                     955 	.db	1
      001BB7 00                     956 	.db	0
      001BB8 01                     957 	.uleb128	1
      001BB9 7F                     958 	.sleb128	-1
      001BBA 09                     959 	.db	9
      001BBB 0C                     960 	.db	12
      001BBC 08                     961 	.uleb128	8
      001BBD 02                     962 	.uleb128	2
      001BBE 89                     963 	.db	137
      001BBF 01                     964 	.uleb128	1
      001BC0                        965 Ldebug_CIE1_end:
      001BC0 00 00 00 7C            966 	.dw	0,124
      001BC4 00 00 1B AE            967 	.dw	0,(Ldebug_CIE1_start-4)
      001BC8 00 00 8E 89            968 	.dw	0,(Sswspi$swspi_init$1)	;initial loc
      001BCC 00 00 00 28            969 	.dw	0,Sswspi$swspi_init$22-Sswspi$swspi_init$1
      001BD0 01                     970 	.db	1
      001BD1 00 00 8E 89            971 	.dw	0,(Sswspi$swspi_init$1)
      001BD5 0E                     972 	.db	14
      001BD6 02                     973 	.uleb128	2
      001BD7 01                     974 	.db	1
      001BD8 00 00 8E 8B            975 	.dw	0,(Sswspi$swspi_init$3)
      001BDC 0E                     976 	.db	14
      001BDD 03                     977 	.uleb128	3
      001BDE 01                     978 	.db	1
      001BDF 00 00 8E 8D            979 	.dw	0,(Sswspi$swspi_init$4)
      001BE3 0E                     980 	.db	14
      001BE4 04                     981 	.uleb128	4
      001BE5 01                     982 	.db	1
      001BE6 00 00 8E 8F            983 	.dw	0,(Sswspi$swspi_init$5)
      001BEA 0E                     984 	.db	14
      001BEB 05                     985 	.uleb128	5
      001BEC 01                     986 	.db	1
      001BED 00 00 8E 91            987 	.dw	0,(Sswspi$swspi_init$6)
      001BF1 0E                     988 	.db	14
      001BF2 06                     989 	.uleb128	6
      001BF3 01                     990 	.db	1
      001BF4 00 00 8E 96            991 	.dw	0,(Sswspi$swspi_init$7)
      001BF8 0E                     992 	.db	14
      001BF9 02                     993 	.uleb128	2
      001BFA 01                     994 	.db	1
      001BFB 00 00 8E 98            995 	.dw	0,(Sswspi$swspi_init$9)
      001BFF 0E                     996 	.db	14
      001C00 03                     997 	.uleb128	3
      001C01 01                     998 	.db	1
      001C02 00 00 8E 9A            999 	.dw	0,(Sswspi$swspi_init$10)
      001C06 0E                    1000 	.db	14
      001C07 04                    1001 	.uleb128	4
      001C08 01                    1002 	.db	1
      001C09 00 00 8E 9C           1003 	.dw	0,(Sswspi$swspi_init$11)
      001C0D 0E                    1004 	.db	14
      001C0E 05                    1005 	.uleb128	5
      001C0F 01                    1006 	.db	1
      001C10 00 00 8E 9E           1007 	.dw	0,(Sswspi$swspi_init$12)
      001C14 0E                    1008 	.db	14
      001C15 06                    1009 	.uleb128	6
      001C16 01                    1010 	.db	1
      001C17 00 00 8E A3           1011 	.dw	0,(Sswspi$swspi_init$13)
      001C1B 0E                    1012 	.db	14
      001C1C 02                    1013 	.uleb128	2
      001C1D 01                    1014 	.db	1
      001C1E 00 00 8E A5           1015 	.dw	0,(Sswspi$swspi_init$15)
      001C22 0E                    1016 	.db	14
      001C23 03                    1017 	.uleb128	3
      001C24 01                    1018 	.db	1
      001C25 00 00 8E A7           1019 	.dw	0,(Sswspi$swspi_init$16)
      001C29 0E                    1020 	.db	14
      001C2A 04                    1021 	.uleb128	4
      001C2B 01                    1022 	.db	1
      001C2C 00 00 8E A9           1023 	.dw	0,(Sswspi$swspi_init$17)
      001C30 0E                    1024 	.db	14
      001C31 05                    1025 	.uleb128	5
      001C32 01                    1026 	.db	1
      001C33 00 00 8E AB           1027 	.dw	0,(Sswspi$swspi_init$18)
      001C37 0E                    1028 	.db	14
      001C38 06                    1029 	.uleb128	6
      001C39 01                    1030 	.db	1
      001C3A 00 00 8E B0           1031 	.dw	0,(Sswspi$swspi_init$19)
      001C3E 0E                    1032 	.db	14
      001C3F 02                    1033 	.uleb128	2
