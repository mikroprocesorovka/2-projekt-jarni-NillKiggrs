                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module stm8s_adc2
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ADC2_DeInit
                                     12 	.globl _ADC2_Init
                                     13 	.globl _ADC2_Cmd
                                     14 	.globl _ADC2_ITConfig
                                     15 	.globl _ADC2_PrescalerConfig
                                     16 	.globl _ADC2_SchmittTriggerConfig
                                     17 	.globl _ADC2_ConversionConfig
                                     18 	.globl _ADC2_ExternalTriggerConfig
                                     19 	.globl _ADC2_StartConversion
                                     20 	.globl _ADC2_GetConversionValue
                                     21 	.globl _ADC2_GetFlagStatus
                                     22 	.globl _ADC2_ClearFlag
                                     23 	.globl _ADC2_GetITStatus
                                     24 	.globl _ADC2_ClearITPendingBit
                                     25 ;--------------------------------------------------------
                                     26 ; ram data
                                     27 ;--------------------------------------------------------
                                     28 	.area DATA
                                     29 ;--------------------------------------------------------
                                     30 ; ram data
                                     31 ;--------------------------------------------------------
                                     32 	.area INITIALIZED
                                     33 ;--------------------------------------------------------
                                     34 ; absolute external ram data
                                     35 ;--------------------------------------------------------
                                     36 	.area DABS (ABS)
                                     37 
                                     38 ; default segment ordering for linker
                                     39 	.area HOME
                                     40 	.area GSINIT
                                     41 	.area GSFINAL
                                     42 	.area CONST
                                     43 	.area INITIALIZER
                                     44 	.area CODE
                                     45 
                                     46 ;--------------------------------------------------------
                                     47 ; global & static initialisations
                                     48 ;--------------------------------------------------------
                                     49 	.area HOME
                                     50 	.area GSINIT
                                     51 	.area GSFINAL
                                     52 	.area GSINIT
                                     53 ;--------------------------------------------------------
                                     54 ; Home
                                     55 ;--------------------------------------------------------
                                     56 	.area HOME
                                     57 	.area HOME
                                     58 ;--------------------------------------------------------
                                     59 ; code
                                     60 ;--------------------------------------------------------
                                     61 	.area CODE
                           000000    62 	Sstm8s_adc2$ADC2_DeInit$0 ==.
                                     63 ;	../SPL/src/stm8s_adc2.c: 54: void ADC2_DeInit(void)
                                     64 ; genLabel
                                     65 ;	-----------------------------------------
                                     66 ;	 function ADC2_DeInit
                                     67 ;	-----------------------------------------
                                     68 ;	Register assignment is optimal.
                                     69 ;	Stack space usage: 0 bytes.
      009C87                         70 _ADC2_DeInit:
                           000000    71 	Sstm8s_adc2$ADC2_DeInit$1 ==.
                           000000    72 	Sstm8s_adc2$ADC2_DeInit$2 ==.
                                     73 ;	../SPL/src/stm8s_adc2.c: 56: ADC2->CSR  = ADC2_CSR_RESET_VALUE;
                                     74 ; genPointerSet
      009C87 35 00 54 00      [ 1]   75 	mov	0x5400+0, #0x00
                           000004    76 	Sstm8s_adc2$ADC2_DeInit$3 ==.
                                     77 ;	../SPL/src/stm8s_adc2.c: 57: ADC2->CR1  = ADC2_CR1_RESET_VALUE;
                                     78 ; genPointerSet
      009C8B 35 00 54 01      [ 1]   79 	mov	0x5401+0, #0x00
                           000008    80 	Sstm8s_adc2$ADC2_DeInit$4 ==.
                                     81 ;	../SPL/src/stm8s_adc2.c: 58: ADC2->CR2  = ADC2_CR2_RESET_VALUE;
                                     82 ; genPointerSet
      009C8F 35 00 54 02      [ 1]   83 	mov	0x5402+0, #0x00
                           00000C    84 	Sstm8s_adc2$ADC2_DeInit$5 ==.
                                     85 ;	../SPL/src/stm8s_adc2.c: 59: ADC2->TDRH = ADC2_TDRH_RESET_VALUE;
                                     86 ; genPointerSet
      009C93 35 00 54 06      [ 1]   87 	mov	0x5406+0, #0x00
                           000010    88 	Sstm8s_adc2$ADC2_DeInit$6 ==.
                                     89 ;	../SPL/src/stm8s_adc2.c: 60: ADC2->TDRL = ADC2_TDRL_RESET_VALUE;
                                     90 ; genPointerSet
      009C97 35 00 54 07      [ 1]   91 	mov	0x5407+0, #0x00
                                     92 ; genLabel
      009C9B                         93 00101$:
                           000014    94 	Sstm8s_adc2$ADC2_DeInit$7 ==.
                                     95 ;	../SPL/src/stm8s_adc2.c: 61: }
                                     96 ; genEndFunction
                           000014    97 	Sstm8s_adc2$ADC2_DeInit$8 ==.
                           000014    98 	XG$ADC2_DeInit$0$0 ==.
      009C9B 81               [ 4]   99 	ret
                           000015   100 	Sstm8s_adc2$ADC2_DeInit$9 ==.
                           000015   101 	Sstm8s_adc2$ADC2_Init$10 ==.
                                    102 ;	../SPL/src/stm8s_adc2.c: 83: void ADC2_Init(ADC2_ConvMode_TypeDef ADC2_ConversionMode, ADC2_Channel_TypeDef ADC2_Channel, ADC2_PresSel_TypeDef ADC2_PrescalerSelection, ADC2_ExtTrig_TypeDef ADC2_ExtTrigger, FunctionalState ADC2_ExtTriggerState, ADC2_Align_TypeDef ADC2_Align, ADC2_SchmittTrigg_TypeDef ADC2_SchmittTriggerChannel, FunctionalState ADC2_SchmittTriggerState)
                                    103 ; genLabel
                                    104 ;	-----------------------------------------
                                    105 ;	 function ADC2_Init
                                    106 ;	-----------------------------------------
                                    107 ;	Register assignment is optimal.
                                    108 ;	Stack space usage: 0 bytes.
      009C9C                        109 _ADC2_Init:
                           000015   110 	Sstm8s_adc2$ADC2_Init$11 ==.
                           000015   111 	Sstm8s_adc2$ADC2_Init$12 ==.
                                    112 ;	../SPL/src/stm8s_adc2.c: 98: ADC2_ConversionConfig(ADC2_ConversionMode, ADC2_Channel, ADC2_Align);
                                    113 ; genIPush
      009C9C 7B 08            [ 1]  114 	ld	a, (0x08, sp)
      009C9E 88               [ 1]  115 	push	a
                           000018   116 	Sstm8s_adc2$ADC2_Init$13 ==.
                                    117 ; genIPush
      009C9F 7B 05            [ 1]  118 	ld	a, (0x05, sp)
      009CA1 88               [ 1]  119 	push	a
                           00001B   120 	Sstm8s_adc2$ADC2_Init$14 ==.
                                    121 ; genIPush
      009CA2 7B 05            [ 1]  122 	ld	a, (0x05, sp)
      009CA4 88               [ 1]  123 	push	a
                           00001E   124 	Sstm8s_adc2$ADC2_Init$15 ==.
                                    125 ; genCall
      009CA5 CD 9D A3         [ 4]  126 	call	_ADC2_ConversionConfig
      009CA8 5B 03            [ 2]  127 	addw	sp, #3
                           000023   128 	Sstm8s_adc2$ADC2_Init$16 ==.
                           000023   129 	Sstm8s_adc2$ADC2_Init$17 ==.
                                    130 ;	../SPL/src/stm8s_adc2.c: 100: ADC2_PrescalerConfig(ADC2_PrescalerSelection);
                                    131 ; genIPush
      009CAA 7B 05            [ 1]  132 	ld	a, (0x05, sp)
      009CAC 88               [ 1]  133 	push	a
                           000026   134 	Sstm8s_adc2$ADC2_Init$18 ==.
                                    135 ; genCall
      009CAD CD 9C FE         [ 4]  136 	call	_ADC2_PrescalerConfig
      009CB0 84               [ 1]  137 	pop	a
                           00002A   138 	Sstm8s_adc2$ADC2_Init$19 ==.
                           00002A   139 	Sstm8s_adc2$ADC2_Init$20 ==.
                                    140 ;	../SPL/src/stm8s_adc2.c: 105: ADC2_ExternalTriggerConfig(ADC2_ExtTrigger, ADC2_ExtTriggerState);
                                    141 ; genIPush
      009CB1 7B 07            [ 1]  142 	ld	a, (0x07, sp)
      009CB3 88               [ 1]  143 	push	a
                           00002D   144 	Sstm8s_adc2$ADC2_Init$21 ==.
                                    145 ; genIPush
      009CB4 7B 07            [ 1]  146 	ld	a, (0x07, sp)
      009CB6 88               [ 1]  147 	push	a
                           000030   148 	Sstm8s_adc2$ADC2_Init$22 ==.
                                    149 ; genCall
      009CB7 CD 9D E1         [ 4]  150 	call	_ADC2_ExternalTriggerConfig
      009CBA 85               [ 2]  151 	popw	x
                           000034   152 	Sstm8s_adc2$ADC2_Init$23 ==.
                           000034   153 	Sstm8s_adc2$ADC2_Init$24 ==.
                                    154 ;	../SPL/src/stm8s_adc2.c: 110: ADC2_SchmittTriggerConfig(ADC2_SchmittTriggerChannel, ADC2_SchmittTriggerState);
                                    155 ; genIPush
      009CBB 7B 0A            [ 1]  156 	ld	a, (0x0a, sp)
      009CBD 88               [ 1]  157 	push	a
                           000037   158 	Sstm8s_adc2$ADC2_Init$25 ==.
                                    159 ; genIPush
      009CBE 7B 0A            [ 1]  160 	ld	a, (0x0a, sp)
      009CC0 88               [ 1]  161 	push	a
                           00003A   162 	Sstm8s_adc2$ADC2_Init$26 ==.
                                    163 ; genCall
      009CC1 CD 9D 0F         [ 4]  164 	call	_ADC2_SchmittTriggerConfig
      009CC4 85               [ 2]  165 	popw	x
                           00003E   166 	Sstm8s_adc2$ADC2_Init$27 ==.
                           00003E   167 	Sstm8s_adc2$ADC2_Init$28 ==.
                                    168 ;	../SPL/src/stm8s_adc2.c: 113: ADC2->CR1 |= ADC2_CR1_ADON;
                                    169 ; genPointerGet
      009CC5 C6 54 01         [ 1]  170 	ld	a, 0x5401
                                    171 ; genOr
      009CC8 AA 01            [ 1]  172 	or	a, #0x01
                                    173 ; genPointerSet
      009CCA C7 54 01         [ 1]  174 	ld	0x5401, a
                                    175 ; genLabel
      009CCD                        176 00101$:
                           000046   177 	Sstm8s_adc2$ADC2_Init$29 ==.
                                    178 ;	../SPL/src/stm8s_adc2.c: 114: }
                                    179 ; genEndFunction
                           000046   180 	Sstm8s_adc2$ADC2_Init$30 ==.
                           000046   181 	XG$ADC2_Init$0$0 ==.
      009CCD 81               [ 4]  182 	ret
                           000047   183 	Sstm8s_adc2$ADC2_Init$31 ==.
                           000047   184 	Sstm8s_adc2$ADC2_Cmd$32 ==.
                                    185 ;	../SPL/src/stm8s_adc2.c: 121: void ADC2_Cmd(FunctionalState NewState)
                                    186 ; genLabel
                                    187 ;	-----------------------------------------
                                    188 ;	 function ADC2_Cmd
                                    189 ;	-----------------------------------------
                                    190 ;	Register assignment is optimal.
                                    191 ;	Stack space usage: 0 bytes.
      009CCE                        192 _ADC2_Cmd:
                           000047   193 	Sstm8s_adc2$ADC2_Cmd$33 ==.
                           000047   194 	Sstm8s_adc2$ADC2_Cmd$34 ==.
                                    195 ;	../SPL/src/stm8s_adc2.c: 128: ADC2->CR1 |= ADC2_CR1_ADON;
                                    196 ; genPointerGet
      009CCE C6 54 01         [ 1]  197 	ld	a, 0x5401
                           00004A   198 	Sstm8s_adc2$ADC2_Cmd$35 ==.
                                    199 ;	../SPL/src/stm8s_adc2.c: 126: if (NewState != DISABLE)
                                    200 ; genIfx
      009CD1 0D 03            [ 1]  201 	tnz	(0x03, sp)
      009CD3 26 03            [ 1]  202 	jrne	00111$
      009CD5 CC 9C E0         [ 2]  203 	jp	00102$
      009CD8                        204 00111$:
                           000051   205 	Sstm8s_adc2$ADC2_Cmd$36 ==.
                           000051   206 	Sstm8s_adc2$ADC2_Cmd$37 ==.
                                    207 ;	../SPL/src/stm8s_adc2.c: 128: ADC2->CR1 |= ADC2_CR1_ADON;
                                    208 ; genOr
      009CD8 AA 01            [ 1]  209 	or	a, #0x01
                                    210 ; genPointerSet
      009CDA C7 54 01         [ 1]  211 	ld	0x5401, a
                           000056   212 	Sstm8s_adc2$ADC2_Cmd$38 ==.
                                    213 ; genGoto
      009CDD CC 9C E5         [ 2]  214 	jp	00104$
                                    215 ; genLabel
      009CE0                        216 00102$:
                           000059   217 	Sstm8s_adc2$ADC2_Cmd$39 ==.
                           000059   218 	Sstm8s_adc2$ADC2_Cmd$40 ==.
                                    219 ;	../SPL/src/stm8s_adc2.c: 132: ADC2->CR1 &= (uint8_t)(~ADC2_CR1_ADON);
                                    220 ; genAnd
      009CE0 A4 FE            [ 1]  221 	and	a, #0xfe
                                    222 ; genPointerSet
      009CE2 C7 54 01         [ 1]  223 	ld	0x5401, a
                           00005E   224 	Sstm8s_adc2$ADC2_Cmd$41 ==.
                                    225 ; genLabel
      009CE5                        226 00104$:
                           00005E   227 	Sstm8s_adc2$ADC2_Cmd$42 ==.
                                    228 ;	../SPL/src/stm8s_adc2.c: 134: }
                                    229 ; genEndFunction
                           00005E   230 	Sstm8s_adc2$ADC2_Cmd$43 ==.
                           00005E   231 	XG$ADC2_Cmd$0$0 ==.
      009CE5 81               [ 4]  232 	ret
                           00005F   233 	Sstm8s_adc2$ADC2_Cmd$44 ==.
                           00005F   234 	Sstm8s_adc2$ADC2_ITConfig$45 ==.
                                    235 ;	../SPL/src/stm8s_adc2.c: 141: void ADC2_ITConfig(FunctionalState NewState)
                                    236 ; genLabel
                                    237 ;	-----------------------------------------
                                    238 ;	 function ADC2_ITConfig
                                    239 ;	-----------------------------------------
                                    240 ;	Register assignment is optimal.
                                    241 ;	Stack space usage: 0 bytes.
      009CE6                        242 _ADC2_ITConfig:
                           00005F   243 	Sstm8s_adc2$ADC2_ITConfig$46 ==.
                           00005F   244 	Sstm8s_adc2$ADC2_ITConfig$47 ==.
                                    245 ;	../SPL/src/stm8s_adc2.c: 149: ADC2->CSR |= (uint8_t)ADC2_CSR_EOCIE;
                                    246 ; genPointerGet
      009CE6 C6 54 00         [ 1]  247 	ld	a, 0x5400
                           000062   248 	Sstm8s_adc2$ADC2_ITConfig$48 ==.
                                    249 ;	../SPL/src/stm8s_adc2.c: 146: if (NewState != DISABLE)
                                    250 ; genIfx
      009CE9 0D 03            [ 1]  251 	tnz	(0x03, sp)
      009CEB 26 03            [ 1]  252 	jrne	00111$
      009CED CC 9C F8         [ 2]  253 	jp	00102$
      009CF0                        254 00111$:
                           000069   255 	Sstm8s_adc2$ADC2_ITConfig$49 ==.
                           000069   256 	Sstm8s_adc2$ADC2_ITConfig$50 ==.
                                    257 ;	../SPL/src/stm8s_adc2.c: 149: ADC2->CSR |= (uint8_t)ADC2_CSR_EOCIE;
                                    258 ; genOr
      009CF0 AA 20            [ 1]  259 	or	a, #0x20
                                    260 ; genPointerSet
      009CF2 C7 54 00         [ 1]  261 	ld	0x5400, a
                           00006E   262 	Sstm8s_adc2$ADC2_ITConfig$51 ==.
                                    263 ; genGoto
      009CF5 CC 9C FD         [ 2]  264 	jp	00104$
                                    265 ; genLabel
      009CF8                        266 00102$:
                           000071   267 	Sstm8s_adc2$ADC2_ITConfig$52 ==.
                           000071   268 	Sstm8s_adc2$ADC2_ITConfig$53 ==.
                                    269 ;	../SPL/src/stm8s_adc2.c: 154: ADC2->CSR &= (uint8_t)(~ADC2_CSR_EOCIE);
                                    270 ; genAnd
      009CF8 A4 DF            [ 1]  271 	and	a, #0xdf
                                    272 ; genPointerSet
      009CFA C7 54 00         [ 1]  273 	ld	0x5400, a
                           000076   274 	Sstm8s_adc2$ADC2_ITConfig$54 ==.
                                    275 ; genLabel
      009CFD                        276 00104$:
                           000076   277 	Sstm8s_adc2$ADC2_ITConfig$55 ==.
                                    278 ;	../SPL/src/stm8s_adc2.c: 156: }
                                    279 ; genEndFunction
                           000076   280 	Sstm8s_adc2$ADC2_ITConfig$56 ==.
                           000076   281 	XG$ADC2_ITConfig$0$0 ==.
      009CFD 81               [ 4]  282 	ret
                           000077   283 	Sstm8s_adc2$ADC2_ITConfig$57 ==.
                           000077   284 	Sstm8s_adc2$ADC2_PrescalerConfig$58 ==.
                                    285 ;	../SPL/src/stm8s_adc2.c: 164: void ADC2_PrescalerConfig(ADC2_PresSel_TypeDef ADC2_Prescaler)
                                    286 ; genLabel
                                    287 ;	-----------------------------------------
                                    288 ;	 function ADC2_PrescalerConfig
                                    289 ;	-----------------------------------------
                                    290 ;	Register assignment is optimal.
                                    291 ;	Stack space usage: 0 bytes.
      009CFE                        292 _ADC2_PrescalerConfig:
                           000077   293 	Sstm8s_adc2$ADC2_PrescalerConfig$59 ==.
                           000077   294 	Sstm8s_adc2$ADC2_PrescalerConfig$60 ==.
                                    295 ;	../SPL/src/stm8s_adc2.c: 170: ADC2->CR1 &= (uint8_t)(~ADC2_CR1_SPSEL);
                                    296 ; genPointerGet
      009CFE C6 54 01         [ 1]  297 	ld	a, 0x5401
                                    298 ; genAnd
      009D01 A4 8F            [ 1]  299 	and	a, #0x8f
                                    300 ; genPointerSet
      009D03 C7 54 01         [ 1]  301 	ld	0x5401, a
                           00007F   302 	Sstm8s_adc2$ADC2_PrescalerConfig$61 ==.
                                    303 ;	../SPL/src/stm8s_adc2.c: 172: ADC2->CR1 |= (uint8_t)(ADC2_Prescaler);
                                    304 ; genPointerGet
      009D06 C6 54 01         [ 1]  305 	ld	a, 0x5401
                                    306 ; genOr
      009D09 1A 03            [ 1]  307 	or	a, (0x03, sp)
                                    308 ; genPointerSet
      009D0B C7 54 01         [ 1]  309 	ld	0x5401, a
                                    310 ; genLabel
      009D0E                        311 00101$:
                           000087   312 	Sstm8s_adc2$ADC2_PrescalerConfig$62 ==.
                                    313 ;	../SPL/src/stm8s_adc2.c: 173: }
                                    314 ; genEndFunction
                           000087   315 	Sstm8s_adc2$ADC2_PrescalerConfig$63 ==.
                           000087   316 	XG$ADC2_PrescalerConfig$0$0 ==.
      009D0E 81               [ 4]  317 	ret
                           000088   318 	Sstm8s_adc2$ADC2_PrescalerConfig$64 ==.
                           000088   319 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$65 ==.
                                    320 ;	../SPL/src/stm8s_adc2.c: 183: void ADC2_SchmittTriggerConfig(ADC2_SchmittTrigg_TypeDef ADC2_SchmittTriggerChannel, FunctionalState NewState)
                                    321 ; genLabel
                                    322 ;	-----------------------------------------
                                    323 ;	 function ADC2_SchmittTriggerConfig
                                    324 ;	-----------------------------------------
                                    325 ;	Register assignment is optimal.
                                    326 ;	Stack space usage: 1 bytes.
      009D0F                        327 _ADC2_SchmittTriggerConfig:
                           000088   328 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$66 ==.
      009D0F 88               [ 1]  329 	push	a
                           000089   330 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$67 ==.
                           000089   331 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$68 ==.
                                    332 ;	../SPL/src/stm8s_adc2.c: 189: if (ADC2_SchmittTriggerChannel == ADC2_SCHMITTTRIG_ALL)
                                    333 ; genCmpEQorNE
      009D10 7B 04            [ 1]  334 	ld	a, (0x04, sp)
      009D12 A1 1F            [ 1]  335 	cp	a, #0x1f
      009D14 26 03            [ 1]  336 	jrne	00144$
      009D16 CC 9D 1C         [ 2]  337 	jp	00145$
      009D19                        338 00144$:
      009D19 CC 9D 42         [ 2]  339 	jp	00114$
      009D1C                        340 00145$:
                           000095   341 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$69 ==.
                                    342 ; skipping generated iCode
                           000095   343 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$70 ==.
                                    344 ;	../SPL/src/stm8s_adc2.c: 193: ADC2->TDRL &= (uint8_t)0x0;
                                    345 ; genPointerGet
                                    346 ; Dummy read
      009D1C C6 54 07         [ 1]  347 	ld	a, 0x5407
                           000098   348 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$71 ==.
                           000098   349 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$72 ==.
                                    350 ;	../SPL/src/stm8s_adc2.c: 191: if (NewState != DISABLE)
                                    351 ; genIfx
      009D1F 0D 05            [ 1]  352 	tnz	(0x05, sp)
      009D21 26 03            [ 1]  353 	jrne	00146$
      009D23 CC 9D 34         [ 2]  354 	jp	00102$
      009D26                        355 00146$:
                           00009F   356 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$73 ==.
                           00009F   357 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$74 ==.
                                    358 ;	../SPL/src/stm8s_adc2.c: 193: ADC2->TDRL &= (uint8_t)0x0;
                                    359 ; genPointerSet
      009D26 35 00 54 07      [ 1]  360 	mov	0x5407+0, #0x00
                           0000A3   361 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$75 ==.
                                    362 ;	../SPL/src/stm8s_adc2.c: 194: ADC2->TDRH &= (uint8_t)0x0;
                                    363 ; genPointerGet
                                    364 ; Dummy read
      009D2A C6 54 06         [ 1]  365 	ld	a, 0x5406
                                    366 ; genPointerSet
      009D2D 35 00 54 06      [ 1]  367 	mov	0x5406+0, #0x00
                           0000AA   368 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$76 ==.
                                    369 ; genGoto
      009D31 CC 9D A1         [ 2]  370 	jp	00116$
                                    371 ; genLabel
      009D34                        372 00102$:
                           0000AD   373 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$77 ==.
                           0000AD   374 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$78 ==.
                                    375 ;	../SPL/src/stm8s_adc2.c: 198: ADC2->TDRL |= (uint8_t)0xFF;
                                    376 ; genPointerSet
      009D34 35 FF 54 07      [ 1]  377 	mov	0x5407+0, #0xff
                           0000B1   378 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$79 ==.
                                    379 ;	../SPL/src/stm8s_adc2.c: 199: ADC2->TDRH |= (uint8_t)0xFF;
                                    380 ; genPointerGet
                                    381 ; Dummy read
      009D38 C6 54 06         [ 1]  382 	ld	a, 0x5406
                                    383 ; genPointerSet
      009D3B 35 FF 54 06      [ 1]  384 	mov	0x5406+0, #0xff
                           0000B8   385 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$80 ==.
                                    386 ; genGoto
      009D3F CC 9D A1         [ 2]  387 	jp	00116$
                                    388 ; genLabel
      009D42                        389 00114$:
                           0000BB   390 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$81 ==.
                                    391 ;	../SPL/src/stm8s_adc2.c: 202: else if (ADC2_SchmittTriggerChannel < ADC2_SCHMITTTRIG_CHANNEL8)
                                    392 ; genCmp
                                    393 ; genCmpTop
      009D42 7B 04            [ 1]  394 	ld	a, (0x04, sp)
      009D44 A1 08            [ 1]  395 	cp	a, #0x08
      009D46 25 03            [ 1]  396 	jrc	00147$
      009D48 CC 9D 75         [ 2]  397 	jp	00111$
      009D4B                        398 00147$:
                                    399 ; skipping generated iCode
                           0000C4   400 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$82 ==.
                                    401 ;	../SPL/src/stm8s_adc2.c: 193: ADC2->TDRL &= (uint8_t)0x0;
                                    402 ; genPointerGet
      009D4B C6 54 07         [ 1]  403 	ld	a, 0x5407
      009D4E 6B 01            [ 1]  404 	ld	(0x01, sp), a
                           0000C9   405 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$83 ==.
                                    406 ;	../SPL/src/stm8s_adc2.c: 206: ADC2->TDRL &= (uint8_t)(~(uint8_t)((uint8_t)0x01 << (uint8_t)ADC2_SchmittTriggerChannel));
                                    407 ; genLeftShift
      009D50 A6 01            [ 1]  408 	ld	a, #0x01
      009D52 88               [ 1]  409 	push	a
                           0000CC   410 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$84 ==.
      009D53 7B 05            [ 1]  411 	ld	a, (0x05, sp)
      009D55 27 05            [ 1]  412 	jreq	00149$
      009D57                        413 00148$:
      009D57 08 01            [ 1]  414 	sll	(1, sp)
      009D59 4A               [ 1]  415 	dec	a
      009D5A 26 FB            [ 1]  416 	jrne	00148$
      009D5C                        417 00149$:
      009D5C 84               [ 1]  418 	pop	a
                           0000D6   419 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$85 ==.
                           0000D6   420 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$86 ==.
                           0000D6   421 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$87 ==.
                                    422 ;	../SPL/src/stm8s_adc2.c: 204: if (NewState != DISABLE)
                                    423 ; genIfx
      009D5D 0D 05            [ 1]  424 	tnz	(0x05, sp)
      009D5F 26 03            [ 1]  425 	jrne	00150$
      009D61 CC 9D 6D         [ 2]  426 	jp	00105$
      009D64                        427 00150$:
                           0000DD   428 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$88 ==.
                           0000DD   429 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$89 ==.
                                    430 ;	../SPL/src/stm8s_adc2.c: 206: ADC2->TDRL &= (uint8_t)(~(uint8_t)((uint8_t)0x01 << (uint8_t)ADC2_SchmittTriggerChannel));
                                    431 ; genCpl
      009D64 43               [ 1]  432 	cpl	a
                                    433 ; genAnd
      009D65 14 01            [ 1]  434 	and	a, (0x01, sp)
                                    435 ; genPointerSet
      009D67 C7 54 07         [ 1]  436 	ld	0x5407, a
                           0000E3   437 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$90 ==.
                                    438 ; genGoto
      009D6A CC 9D A1         [ 2]  439 	jp	00116$
                                    440 ; genLabel
      009D6D                        441 00105$:
                           0000E6   442 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$91 ==.
                           0000E6   443 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$92 ==.
                                    444 ;	../SPL/src/stm8s_adc2.c: 210: ADC2->TDRL |= (uint8_t)((uint8_t)0x01 << (uint8_t)ADC2_SchmittTriggerChannel);
                                    445 ; genOr
      009D6D 1A 01            [ 1]  446 	or	a, (0x01, sp)
                                    447 ; genPointerSet
      009D6F C7 54 07         [ 1]  448 	ld	0x5407, a
                           0000EB   449 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$93 ==.
                                    450 ; genGoto
      009D72 CC 9D A1         [ 2]  451 	jp	00116$
                                    452 ; genLabel
      009D75                        453 00111$:
                           0000EE   454 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$94 ==.
                                    455 ;	../SPL/src/stm8s_adc2.c: 194: ADC2->TDRH &= (uint8_t)0x0;
                                    456 ; genPointerGet
      009D75 C6 54 06         [ 1]  457 	ld	a, 0x5406
      009D78 6B 01            [ 1]  458 	ld	(0x01, sp), a
                           0000F3   459 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$95 ==.
                                    460 ;	../SPL/src/stm8s_adc2.c: 217: ADC2->TDRH &= (uint8_t)(~(uint8_t)((uint8_t)0x01 << ((uint8_t)ADC2_SchmittTriggerChannel - (uint8_t)8)));
                                    461 ; genMinus
      009D7A 7B 04            [ 1]  462 	ld	a, (0x04, sp)
      009D7C A0 08            [ 1]  463 	sub	a, #0x08
      009D7E 97               [ 1]  464 	ld	xl, a
                                    465 ; genLeftShift
      009D7F A6 01            [ 1]  466 	ld	a, #0x01
      009D81 88               [ 1]  467 	push	a
                           0000FB   468 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$96 ==.
      009D82 9F               [ 1]  469 	ld	a, xl
      009D83 4D               [ 1]  470 	tnz	a
      009D84 27 05            [ 1]  471 	jreq	00152$
      009D86                        472 00151$:
      009D86 08 01            [ 1]  473 	sll	(1, sp)
      009D88 4A               [ 1]  474 	dec	a
      009D89 26 FB            [ 1]  475 	jrne	00151$
      009D8B                        476 00152$:
      009D8B 84               [ 1]  477 	pop	a
                           000105   478 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$97 ==.
                           000105   479 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$98 ==.
                           000105   480 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$99 ==.
                                    481 ;	../SPL/src/stm8s_adc2.c: 215: if (NewState != DISABLE)
                                    482 ; genIfx
      009D8C 0D 05            [ 1]  483 	tnz	(0x05, sp)
      009D8E 26 03            [ 1]  484 	jrne	00153$
      009D90 CC 9D 9C         [ 2]  485 	jp	00108$
      009D93                        486 00153$:
                           00010C   487 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$100 ==.
                           00010C   488 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$101 ==.
                                    489 ;	../SPL/src/stm8s_adc2.c: 217: ADC2->TDRH &= (uint8_t)(~(uint8_t)((uint8_t)0x01 << ((uint8_t)ADC2_SchmittTriggerChannel - (uint8_t)8)));
                                    490 ; genCpl
      009D93 43               [ 1]  491 	cpl	a
                                    492 ; genAnd
      009D94 14 01            [ 1]  493 	and	a, (0x01, sp)
                                    494 ; genPointerSet
      009D96 C7 54 06         [ 1]  495 	ld	0x5406, a
                           000112   496 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$102 ==.
                                    497 ; genGoto
      009D99 CC 9D A1         [ 2]  498 	jp	00116$
                                    499 ; genLabel
      009D9C                        500 00108$:
                           000115   501 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$103 ==.
                           000115   502 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$104 ==.
                                    503 ;	../SPL/src/stm8s_adc2.c: 221: ADC2->TDRH |= (uint8_t)((uint8_t)0x01 << ((uint8_t)ADC2_SchmittTriggerChannel - (uint8_t)8));
                                    504 ; genOr
      009D9C 1A 01            [ 1]  505 	or	a, (0x01, sp)
                                    506 ; genPointerSet
      009D9E C7 54 06         [ 1]  507 	ld	0x5406, a
                           00011A   508 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$105 ==.
                                    509 ; genLabel
      009DA1                        510 00116$:
                           00011A   511 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$106 ==.
                                    512 ;	../SPL/src/stm8s_adc2.c: 224: }
                                    513 ; genEndFunction
      009DA1 84               [ 1]  514 	pop	a
                           00011B   515 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$107 ==.
                           00011B   516 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$108 ==.
                           00011B   517 	XG$ADC2_SchmittTriggerConfig$0$0 ==.
      009DA2 81               [ 4]  518 	ret
                           00011C   519 	Sstm8s_adc2$ADC2_SchmittTriggerConfig$109 ==.
                           00011C   520 	Sstm8s_adc2$ADC2_ConversionConfig$110 ==.
                                    521 ;	../SPL/src/stm8s_adc2.c: 236: void ADC2_ConversionConfig(ADC2_ConvMode_TypeDef ADC2_ConversionMode, ADC2_Channel_TypeDef ADC2_Channel, ADC2_Align_TypeDef ADC2_Align)
                                    522 ; genLabel
                                    523 ;	-----------------------------------------
                                    524 ;	 function ADC2_ConversionConfig
                                    525 ;	-----------------------------------------
                                    526 ;	Register assignment is optimal.
                                    527 ;	Stack space usage: 0 bytes.
      009DA3                        528 _ADC2_ConversionConfig:
                           00011C   529 	Sstm8s_adc2$ADC2_ConversionConfig$111 ==.
                           00011C   530 	Sstm8s_adc2$ADC2_ConversionConfig$112 ==.
                                    531 ;	../SPL/src/stm8s_adc2.c: 244: ADC2->CR2 &= (uint8_t)(~ADC2_CR2_ALIGN);
                                    532 ; genPointerGet
      009DA3 C6 54 02         [ 1]  533 	ld	a, 0x5402
                                    534 ; genAnd
      009DA6 A4 F7            [ 1]  535 	and	a, #0xf7
                                    536 ; genPointerSet
      009DA8 C7 54 02         [ 1]  537 	ld	0x5402, a
                           000124   538 	Sstm8s_adc2$ADC2_ConversionConfig$113 ==.
                                    539 ;	../SPL/src/stm8s_adc2.c: 246: ADC2->CR2 |= (uint8_t)(ADC2_Align);
                                    540 ; genPointerGet
      009DAB C6 54 02         [ 1]  541 	ld	a, 0x5402
                                    542 ; genOr
      009DAE 1A 05            [ 1]  543 	or	a, (0x05, sp)
                                    544 ; genPointerSet
      009DB0 C7 54 02         [ 1]  545 	ld	0x5402, a
                           00012C   546 	Sstm8s_adc2$ADC2_ConversionConfig$114 ==.
                                    547 ;	../SPL/src/stm8s_adc2.c: 251: ADC2->CR1 |= ADC2_CR1_CONT;
                                    548 ; genPointerGet
      009DB3 C6 54 01         [ 1]  549 	ld	a, 0x5401
                           00012F   550 	Sstm8s_adc2$ADC2_ConversionConfig$115 ==.
                                    551 ;	../SPL/src/stm8s_adc2.c: 248: if (ADC2_ConversionMode == ADC2_CONVERSIONMODE_CONTINUOUS)
                                    552 ; genCmpEQorNE
      009DB6 88               [ 1]  553 	push	a
                           000130   554 	Sstm8s_adc2$ADC2_ConversionConfig$116 ==.
      009DB7 7B 04            [ 1]  555 	ld	a, (0x04, sp)
      009DB9 4A               [ 1]  556 	dec	a
      009DBA 84               [ 1]  557 	pop	a
                           000134   558 	Sstm8s_adc2$ADC2_ConversionConfig$117 ==.
      009DBB 26 03            [ 1]  559 	jrne	00112$
      009DBD CC 9D C3         [ 2]  560 	jp	00113$
      009DC0                        561 00112$:
      009DC0 CC 9D CB         [ 2]  562 	jp	00102$
      009DC3                        563 00113$:
                           00013C   564 	Sstm8s_adc2$ADC2_ConversionConfig$118 ==.
                                    565 ; skipping generated iCode
                           00013C   566 	Sstm8s_adc2$ADC2_ConversionConfig$119 ==.
                           00013C   567 	Sstm8s_adc2$ADC2_ConversionConfig$120 ==.
                                    568 ;	../SPL/src/stm8s_adc2.c: 251: ADC2->CR1 |= ADC2_CR1_CONT;
                                    569 ; genOr
      009DC3 AA 02            [ 1]  570 	or	a, #0x02
                                    571 ; genPointerSet
      009DC5 C7 54 01         [ 1]  572 	ld	0x5401, a
                           000141   573 	Sstm8s_adc2$ADC2_ConversionConfig$121 ==.
                                    574 ; genGoto
      009DC8 CC 9D D0         [ 2]  575 	jp	00103$
                                    576 ; genLabel
      009DCB                        577 00102$:
                           000144   578 	Sstm8s_adc2$ADC2_ConversionConfig$122 ==.
                           000144   579 	Sstm8s_adc2$ADC2_ConversionConfig$123 ==.
                                    580 ;	../SPL/src/stm8s_adc2.c: 256: ADC2->CR1 &= (uint8_t)(~ADC2_CR1_CONT);
                                    581 ; genAnd
      009DCB A4 FD            [ 1]  582 	and	a, #0xfd
                                    583 ; genPointerSet
      009DCD C7 54 01         [ 1]  584 	ld	0x5401, a
                           000149   585 	Sstm8s_adc2$ADC2_ConversionConfig$124 ==.
                                    586 ; genLabel
      009DD0                        587 00103$:
                           000149   588 	Sstm8s_adc2$ADC2_ConversionConfig$125 ==.
                                    589 ;	../SPL/src/stm8s_adc2.c: 260: ADC2->CSR &= (uint8_t)(~ADC2_CSR_CH);
                                    590 ; genPointerGet
      009DD0 C6 54 00         [ 1]  591 	ld	a, 0x5400
                                    592 ; genAnd
      009DD3 A4 F0            [ 1]  593 	and	a, #0xf0
                                    594 ; genPointerSet
      009DD5 C7 54 00         [ 1]  595 	ld	0x5400, a
                           000151   596 	Sstm8s_adc2$ADC2_ConversionConfig$126 ==.
                                    597 ;	../SPL/src/stm8s_adc2.c: 262: ADC2->CSR |= (uint8_t)(ADC2_Channel);
                                    598 ; genPointerGet
      009DD8 C6 54 00         [ 1]  599 	ld	a, 0x5400
                                    600 ; genOr
      009DDB 1A 04            [ 1]  601 	or	a, (0x04, sp)
                                    602 ; genPointerSet
      009DDD C7 54 00         [ 1]  603 	ld	0x5400, a
                                    604 ; genLabel
      009DE0                        605 00104$:
                           000159   606 	Sstm8s_adc2$ADC2_ConversionConfig$127 ==.
                                    607 ;	../SPL/src/stm8s_adc2.c: 263: }
                                    608 ; genEndFunction
                           000159   609 	Sstm8s_adc2$ADC2_ConversionConfig$128 ==.
                           000159   610 	XG$ADC2_ConversionConfig$0$0 ==.
      009DE0 81               [ 4]  611 	ret
                           00015A   612 	Sstm8s_adc2$ADC2_ConversionConfig$129 ==.
                           00015A   613 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$130 ==.
                                    614 ;	../SPL/src/stm8s_adc2.c: 275: void ADC2_ExternalTriggerConfig(ADC2_ExtTrig_TypeDef ADC2_ExtTrigger, FunctionalState NewState)
                                    615 ; genLabel
                                    616 ;	-----------------------------------------
                                    617 ;	 function ADC2_ExternalTriggerConfig
                                    618 ;	-----------------------------------------
                                    619 ;	Register assignment is optimal.
                                    620 ;	Stack space usage: 0 bytes.
      009DE1                        621 _ADC2_ExternalTriggerConfig:
                           00015A   622 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$131 ==.
                           00015A   623 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$132 ==.
                                    624 ;	../SPL/src/stm8s_adc2.c: 282: ADC2->CR2 &= (uint8_t)(~ADC2_CR2_EXTSEL);
                                    625 ; genPointerGet
      009DE1 C6 54 02         [ 1]  626 	ld	a, 0x5402
                                    627 ; genAnd
      009DE4 A4 CF            [ 1]  628 	and	a, #0xcf
                                    629 ; genPointerSet
      009DE6 C7 54 02         [ 1]  630 	ld	0x5402, a
                                    631 ; genPointerGet
      009DE9 C6 54 02         [ 1]  632 	ld	a, 0x5402
                           000165   633 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$133 ==.
                                    634 ;	../SPL/src/stm8s_adc2.c: 284: if (NewState != DISABLE)
                                    635 ; genIfx
      009DEC 0D 04            [ 1]  636 	tnz	(0x04, sp)
      009DEE 26 03            [ 1]  637 	jrne	00111$
      009DF0 CC 9D FB         [ 2]  638 	jp	00102$
      009DF3                        639 00111$:
                           00016C   640 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$134 ==.
                           00016C   641 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$135 ==.
                                    642 ;	../SPL/src/stm8s_adc2.c: 287: ADC2->CR2 |= (uint8_t)(ADC2_CR2_EXTTRIG);
                                    643 ; genOr
      009DF3 AA 40            [ 1]  644 	or	a, #0x40
                                    645 ; genPointerSet
      009DF5 C7 54 02         [ 1]  646 	ld	0x5402, a
                           000171   647 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$136 ==.
                                    648 ; genGoto
      009DF8 CC 9E 00         [ 2]  649 	jp	00103$
                                    650 ; genLabel
      009DFB                        651 00102$:
                           000174   652 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$137 ==.
                           000174   653 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$138 ==.
                                    654 ;	../SPL/src/stm8s_adc2.c: 292: ADC2->CR2 &= (uint8_t)(~ADC2_CR2_EXTTRIG);
                                    655 ; genAnd
      009DFB A4 BF            [ 1]  656 	and	a, #0xbf
                                    657 ; genPointerSet
      009DFD C7 54 02         [ 1]  658 	ld	0x5402, a
                           000179   659 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$139 ==.
                                    660 ; genLabel
      009E00                        661 00103$:
                           000179   662 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$140 ==.
                                    663 ;	../SPL/src/stm8s_adc2.c: 296: ADC2->CR2 |= (uint8_t)(ADC2_ExtTrigger);
                                    664 ; genPointerGet
      009E00 C6 54 02         [ 1]  665 	ld	a, 0x5402
                                    666 ; genOr
      009E03 1A 03            [ 1]  667 	or	a, (0x03, sp)
                                    668 ; genPointerSet
      009E05 C7 54 02         [ 1]  669 	ld	0x5402, a
                                    670 ; genLabel
      009E08                        671 00104$:
                           000181   672 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$141 ==.
                                    673 ;	../SPL/src/stm8s_adc2.c: 297: }
                                    674 ; genEndFunction
                           000181   675 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$142 ==.
                           000181   676 	XG$ADC2_ExternalTriggerConfig$0$0 ==.
      009E08 81               [ 4]  677 	ret
                           000182   678 	Sstm8s_adc2$ADC2_ExternalTriggerConfig$143 ==.
                           000182   679 	Sstm8s_adc2$ADC2_StartConversion$144 ==.
                                    680 ;	../SPL/src/stm8s_adc2.c: 308: void ADC2_StartConversion(void)
                                    681 ; genLabel
                                    682 ;	-----------------------------------------
                                    683 ;	 function ADC2_StartConversion
                                    684 ;	-----------------------------------------
                                    685 ;	Register assignment is optimal.
                                    686 ;	Stack space usage: 0 bytes.
      009E09                        687 _ADC2_StartConversion:
                           000182   688 	Sstm8s_adc2$ADC2_StartConversion$145 ==.
                           000182   689 	Sstm8s_adc2$ADC2_StartConversion$146 ==.
                                    690 ;	../SPL/src/stm8s_adc2.c: 310: ADC2->CR1 |= ADC2_CR1_ADON;
                                    691 ; genPointerGet
      009E09 C6 54 01         [ 1]  692 	ld	a, 0x5401
                                    693 ; genOr
      009E0C AA 01            [ 1]  694 	or	a, #0x01
                                    695 ; genPointerSet
      009E0E C7 54 01         [ 1]  696 	ld	0x5401, a
                                    697 ; genLabel
      009E11                        698 00101$:
                           00018A   699 	Sstm8s_adc2$ADC2_StartConversion$147 ==.
                                    700 ;	../SPL/src/stm8s_adc2.c: 311: }
                                    701 ; genEndFunction
                           00018A   702 	Sstm8s_adc2$ADC2_StartConversion$148 ==.
                           00018A   703 	XG$ADC2_StartConversion$0$0 ==.
      009E11 81               [ 4]  704 	ret
                           00018B   705 	Sstm8s_adc2$ADC2_StartConversion$149 ==.
                           00018B   706 	Sstm8s_adc2$ADC2_GetConversionValue$150 ==.
                                    707 ;	../SPL/src/stm8s_adc2.c: 320: uint16_t ADC2_GetConversionValue(void)
                                    708 ; genLabel
                                    709 ;	-----------------------------------------
                                    710 ;	 function ADC2_GetConversionValue
                                    711 ;	-----------------------------------------
                                    712 ;	Register assignment might be sub-optimal.
                                    713 ;	Stack space usage: 4 bytes.
      009E12                        714 _ADC2_GetConversionValue:
                           00018B   715 	Sstm8s_adc2$ADC2_GetConversionValue$151 ==.
      009E12 52 04            [ 2]  716 	sub	sp, #4
                           00018D   717 	Sstm8s_adc2$ADC2_GetConversionValue$152 ==.
                           00018D   718 	Sstm8s_adc2$ADC2_GetConversionValue$153 ==.
                                    719 ;	../SPL/src/stm8s_adc2.c: 325: if ((ADC2->CR2 & ADC2_CR2_ALIGN) != 0) /* Right alignment */
                                    720 ; genPointerGet
      009E14 C6 54 02         [ 1]  721 	ld	a, 0x5402
                                    722 ; genAnd
      009E17 A5 08            [ 1]  723 	bcp	a, #0x08
      009E19 26 03            [ 1]  724 	jrne	00111$
      009E1B CC 9E 37         [ 2]  725 	jp	00102$
      009E1E                        726 00111$:
                                    727 ; skipping generated iCode
                           000197   728 	Sstm8s_adc2$ADC2_GetConversionValue$154 ==.
                           000197   729 	Sstm8s_adc2$ADC2_GetConversionValue$155 ==.
                                    730 ;	../SPL/src/stm8s_adc2.c: 328: templ = ADC2->DRL;
                                    731 ; genPointerGet
      009E1E C6 54 05         [ 1]  732 	ld	a, 0x5405
      009E21 97               [ 1]  733 	ld	xl, a
                           00019B   734 	Sstm8s_adc2$ADC2_GetConversionValue$156 ==.
                                    735 ;	../SPL/src/stm8s_adc2.c: 330: temph = ADC2->DRH;
                                    736 ; genPointerGet
      009E22 C6 54 04         [ 1]  737 	ld	a, 0x5404
                                    738 ; genCast
                                    739 ; genAssign
      009E25 90 5F            [ 1]  740 	clrw	y
                                    741 ; genAssign
                           0001A0   742 	Sstm8s_adc2$ADC2_GetConversionValue$157 ==.
                                    743 ;	../SPL/src/stm8s_adc2.c: 332: temph = (uint16_t)(templ | (uint16_t)(temph << (uint8_t)8));
                                    744 ; genLeftShiftLiteral
      009E27 0F 02            [ 1]  745 	clr	(0x02, sp)
                                    746 ; genCast
                                    747 ; genAssign
      009E29 0F 03            [ 1]  748 	clr	(0x03, sp)
                                    749 ; genOr
      009E2B 1A 03            [ 1]  750 	or	a, (0x03, sp)
      009E2D 95               [ 1]  751 	ld	xh, a
      009E2E 9F               [ 1]  752 	ld	a, xl
      009E2F 1A 02            [ 1]  753 	or	a, (0x02, sp)
      009E31 97               [ 1]  754 	ld	xl, a
                                    755 ; genAssign
      009E32 1F 03            [ 2]  756 	ldw	(0x03, sp), x
                           0001AD   757 	Sstm8s_adc2$ADC2_GetConversionValue$158 ==.
                                    758 ; genGoto
      009E34 CC 9E 55         [ 2]  759 	jp	00103$
                                    760 ; genLabel
      009E37                        761 00102$:
                           0001B0   762 	Sstm8s_adc2$ADC2_GetConversionValue$159 ==.
                           0001B0   763 	Sstm8s_adc2$ADC2_GetConversionValue$160 ==.
                                    764 ;	../SPL/src/stm8s_adc2.c: 337: temph = ADC2->DRH;
                                    765 ; genPointerGet
      009E37 C6 54 04         [ 1]  766 	ld	a, 0x5404
                                    767 ; genCast
                                    768 ; genAssign
      009E3A 5F               [ 1]  769 	clrw	x
      009E3B 97               [ 1]  770 	ld	xl, a
                                    771 ; genAssign
      009E3C 51               [ 1]  772 	exgw	x, y
                           0001B6   773 	Sstm8s_adc2$ADC2_GetConversionValue$161 ==.
                                    774 ;	../SPL/src/stm8s_adc2.c: 339: templ = ADC2->DRL;
                                    775 ; genPointerGet
      009E3D C6 54 05         [ 1]  776 	ld	a, 0x5405
                           0001B9   777 	Sstm8s_adc2$ADC2_GetConversionValue$162 ==.
                                    778 ;	../SPL/src/stm8s_adc2.c: 341: temph = (uint16_t)((uint16_t)((uint16_t)templ << 6) | (uint16_t)((uint16_t)temph << 8));
                                    779 ; genCast
                                    780 ; genAssign
      009E40 5F               [ 1]  781 	clrw	x
      009E41 97               [ 1]  782 	ld	xl, a
                                    783 ; genLeftShiftLiteral
      009E42 58               [ 2]  784 	sllw	x
      009E43 58               [ 2]  785 	sllw	x
      009E44 58               [ 2]  786 	sllw	x
      009E45 58               [ 2]  787 	sllw	x
      009E46 58               [ 2]  788 	sllw	x
      009E47 58               [ 2]  789 	sllw	x
      009E48 1F 03            [ 2]  790 	ldw	(0x03, sp), x
                                    791 ; genLeftShiftLiteral
      009E4A 4F               [ 1]  792 	clr	a
                                    793 ; genOr
      009E4B 1A 04            [ 1]  794 	or	a, (0x04, sp)
      009E4D 97               [ 1]  795 	ld	xl, a
      009E4E 90 9F            [ 1]  796 	ld	a, yl
      009E50 1A 03            [ 1]  797 	or	a, (0x03, sp)
      009E52 95               [ 1]  798 	ld	xh, a
                                    799 ; genAssign
      009E53 1F 03            [ 2]  800 	ldw	(0x03, sp), x
                           0001CE   801 	Sstm8s_adc2$ADC2_GetConversionValue$163 ==.
                                    802 ; genLabel
      009E55                        803 00103$:
                           0001CE   804 	Sstm8s_adc2$ADC2_GetConversionValue$164 ==.
                                    805 ;	../SPL/src/stm8s_adc2.c: 344: return ((uint16_t)temph);
                                    806 ; genReturn
      009E55 1E 03            [ 2]  807 	ldw	x, (0x03, sp)
                                    808 ; genLabel
      009E57                        809 00104$:
                           0001D0   810 	Sstm8s_adc2$ADC2_GetConversionValue$165 ==.
                                    811 ;	../SPL/src/stm8s_adc2.c: 345: }
                                    812 ; genEndFunction
      009E57 5B 04            [ 2]  813 	addw	sp, #4
                           0001D2   814 	Sstm8s_adc2$ADC2_GetConversionValue$166 ==.
                           0001D2   815 	Sstm8s_adc2$ADC2_GetConversionValue$167 ==.
                           0001D2   816 	XG$ADC2_GetConversionValue$0$0 ==.
      009E59 81               [ 4]  817 	ret
                           0001D3   818 	Sstm8s_adc2$ADC2_GetConversionValue$168 ==.
                           0001D3   819 	Sstm8s_adc2$ADC2_GetFlagStatus$169 ==.
                                    820 ;	../SPL/src/stm8s_adc2.c: 352: FlagStatus ADC2_GetFlagStatus(void)
                                    821 ; genLabel
                                    822 ;	-----------------------------------------
                                    823 ;	 function ADC2_GetFlagStatus
                                    824 ;	-----------------------------------------
                                    825 ;	Register assignment is optimal.
                                    826 ;	Stack space usage: 0 bytes.
      009E5A                        827 _ADC2_GetFlagStatus:
                           0001D3   828 	Sstm8s_adc2$ADC2_GetFlagStatus$170 ==.
                           0001D3   829 	Sstm8s_adc2$ADC2_GetFlagStatus$171 ==.
                                    830 ;	../SPL/src/stm8s_adc2.c: 355: return (FlagStatus)(ADC2->CSR & ADC2_CSR_EOC);
                                    831 ; genPointerGet
      009E5A C6 54 00         [ 1]  832 	ld	a, 0x5400
                                    833 ; genAnd
      009E5D A4 80            [ 1]  834 	and	a, #0x80
                                    835 ; genReturn
                                    836 ; genLabel
      009E5F                        837 00101$:
                           0001D8   838 	Sstm8s_adc2$ADC2_GetFlagStatus$172 ==.
                                    839 ;	../SPL/src/stm8s_adc2.c: 356: }
                                    840 ; genEndFunction
                           0001D8   841 	Sstm8s_adc2$ADC2_GetFlagStatus$173 ==.
                           0001D8   842 	XG$ADC2_GetFlagStatus$0$0 ==.
      009E5F 81               [ 4]  843 	ret
                           0001D9   844 	Sstm8s_adc2$ADC2_GetFlagStatus$174 ==.
                           0001D9   845 	Sstm8s_adc2$ADC2_ClearFlag$175 ==.
                                    846 ;	../SPL/src/stm8s_adc2.c: 363: void ADC2_ClearFlag(void)
                                    847 ; genLabel
                                    848 ;	-----------------------------------------
                                    849 ;	 function ADC2_ClearFlag
                                    850 ;	-----------------------------------------
                                    851 ;	Register assignment is optimal.
                                    852 ;	Stack space usage: 0 bytes.
      009E60                        853 _ADC2_ClearFlag:
                           0001D9   854 	Sstm8s_adc2$ADC2_ClearFlag$176 ==.
                           0001D9   855 	Sstm8s_adc2$ADC2_ClearFlag$177 ==.
                                    856 ;	../SPL/src/stm8s_adc2.c: 365: ADC2->CSR &= (uint8_t)(~ADC2_CSR_EOC);
                                    857 ; genPointerGet
      009E60 C6 54 00         [ 1]  858 	ld	a, 0x5400
                                    859 ; genAnd
      009E63 A4 7F            [ 1]  860 	and	a, #0x7f
                                    861 ; genPointerSet
      009E65 C7 54 00         [ 1]  862 	ld	0x5400, a
                                    863 ; genLabel
      009E68                        864 00101$:
                           0001E1   865 	Sstm8s_adc2$ADC2_ClearFlag$178 ==.
                                    866 ;	../SPL/src/stm8s_adc2.c: 366: }
                                    867 ; genEndFunction
                           0001E1   868 	Sstm8s_adc2$ADC2_ClearFlag$179 ==.
                           0001E1   869 	XG$ADC2_ClearFlag$0$0 ==.
      009E68 81               [ 4]  870 	ret
                           0001E2   871 	Sstm8s_adc2$ADC2_ClearFlag$180 ==.
                           0001E2   872 	Sstm8s_adc2$ADC2_GetITStatus$181 ==.
                                    873 ;	../SPL/src/stm8s_adc2.c: 374: ITStatus ADC2_GetITStatus(void)
                                    874 ; genLabel
                                    875 ;	-----------------------------------------
                                    876 ;	 function ADC2_GetITStatus
                                    877 ;	-----------------------------------------
                                    878 ;	Register assignment is optimal.
                                    879 ;	Stack space usage: 0 bytes.
      009E69                        880 _ADC2_GetITStatus:
                           0001E2   881 	Sstm8s_adc2$ADC2_GetITStatus$182 ==.
                           0001E2   882 	Sstm8s_adc2$ADC2_GetITStatus$183 ==.
                                    883 ;	../SPL/src/stm8s_adc2.c: 376: return (ITStatus)(ADC2->CSR & ADC2_CSR_EOC);
                                    884 ; genPointerGet
      009E69 C6 54 00         [ 1]  885 	ld	a, 0x5400
                                    886 ; genAnd
      009E6C A4 80            [ 1]  887 	and	a, #0x80
                                    888 ; genReturn
                                    889 ; genLabel
      009E6E                        890 00101$:
                           0001E7   891 	Sstm8s_adc2$ADC2_GetITStatus$184 ==.
                                    892 ;	../SPL/src/stm8s_adc2.c: 377: }
                                    893 ; genEndFunction
                           0001E7   894 	Sstm8s_adc2$ADC2_GetITStatus$185 ==.
                           0001E7   895 	XG$ADC2_GetITStatus$0$0 ==.
      009E6E 81               [ 4]  896 	ret
                           0001E8   897 	Sstm8s_adc2$ADC2_GetITStatus$186 ==.
                           0001E8   898 	Sstm8s_adc2$ADC2_ClearITPendingBit$187 ==.
                                    899 ;	../SPL/src/stm8s_adc2.c: 384: void ADC2_ClearITPendingBit(void)
                                    900 ; genLabel
                                    901 ;	-----------------------------------------
                                    902 ;	 function ADC2_ClearITPendingBit
                                    903 ;	-----------------------------------------
                                    904 ;	Register assignment is optimal.
                                    905 ;	Stack space usage: 0 bytes.
      009E6F                        906 _ADC2_ClearITPendingBit:
                           0001E8   907 	Sstm8s_adc2$ADC2_ClearITPendingBit$188 ==.
                           0001E8   908 	Sstm8s_adc2$ADC2_ClearITPendingBit$189 ==.
                                    909 ;	../SPL/src/stm8s_adc2.c: 386: ADC2->CSR &= (uint8_t)(~ADC2_CSR_EOC);
                                    910 ; genPointerGet
      009E6F C6 54 00         [ 1]  911 	ld	a, 0x5400
                                    912 ; genAnd
      009E72 A4 7F            [ 1]  913 	and	a, #0x7f
                                    914 ; genPointerSet
      009E74 C7 54 00         [ 1]  915 	ld	0x5400, a
                                    916 ; genLabel
      009E77                        917 00101$:
                           0001F0   918 	Sstm8s_adc2$ADC2_ClearITPendingBit$190 ==.
                                    919 ;	../SPL/src/stm8s_adc2.c: 387: }
                                    920 ; genEndFunction
                           0001F0   921 	Sstm8s_adc2$ADC2_ClearITPendingBit$191 ==.
                           0001F0   922 	XG$ADC2_ClearITPendingBit$0$0 ==.
      009E77 81               [ 4]  923 	ret
                           0001F1   924 	Sstm8s_adc2$ADC2_ClearITPendingBit$192 ==.
                                    925 	.area CODE
                                    926 	.area CONST
                                    927 	.area INITIALIZER
                                    928 	.area CABS (ABS)
                                    929 
                                    930 	.area .debug_line (NOLOAD)
      00290A 00 00 03 3F            931 	.dw	0,Ldebug_line_end-Ldebug_line_start
      00290E                        932 Ldebug_line_start:
      00290E 00 02                  933 	.dw	2
      002910 00 00 00 78            934 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      002914 01                     935 	.db	1
      002915 01                     936 	.db	1
      002916 FB                     937 	.db	-5
      002917 0F                     938 	.db	15
      002918 0A                     939 	.db	10
      002919 00                     940 	.db	0
      00291A 01                     941 	.db	1
      00291B 01                     942 	.db	1
      00291C 01                     943 	.db	1
      00291D 01                     944 	.db	1
      00291E 00                     945 	.db	0
      00291F 00                     946 	.db	0
      002920 00                     947 	.db	0
      002921 01                     948 	.db	1
      002922 43 3A 5C 50 72 6F 67   949 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      00294A 00                     950 	.db	0
      00294B 43 3A 5C 50 72 6F 67   951 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      00296E 00                     952 	.db	0
      00296F 00                     953 	.db	0
      002970 2E 2E 2F 53 50 4C 2F   954 	.ascii "../SPL/src/stm8s_adc2.c"
             73 72 63 2F 73 74 6D
             38 73 5F 61 64 63 32
             2E 63
      002987 00                     955 	.db	0
      002988 00                     956 	.uleb128	0
      002989 00                     957 	.uleb128	0
      00298A 00                     958 	.uleb128	0
      00298B 00                     959 	.db	0
      00298C                        960 Ldebug_line_stmt:
      00298C 00                     961 	.db	0
      00298D 05                     962 	.uleb128	5
      00298E 02                     963 	.db	2
      00298F 00 00 9C 87            964 	.dw	0,(Sstm8s_adc2$ADC2_DeInit$0)
      002993 03                     965 	.db	3
      002994 35                     966 	.sleb128	53
      002995 01                     967 	.db	1
      002996 09                     968 	.db	9
      002997 00 00                  969 	.dw	Sstm8s_adc2$ADC2_DeInit$2-Sstm8s_adc2$ADC2_DeInit$0
      002999 03                     970 	.db	3
      00299A 02                     971 	.sleb128	2
      00299B 01                     972 	.db	1
      00299C 09                     973 	.db	9
      00299D 00 04                  974 	.dw	Sstm8s_adc2$ADC2_DeInit$3-Sstm8s_adc2$ADC2_DeInit$2
      00299F 03                     975 	.db	3
      0029A0 01                     976 	.sleb128	1
      0029A1 01                     977 	.db	1
      0029A2 09                     978 	.db	9
      0029A3 00 04                  979 	.dw	Sstm8s_adc2$ADC2_DeInit$4-Sstm8s_adc2$ADC2_DeInit$3
      0029A5 03                     980 	.db	3
      0029A6 01                     981 	.sleb128	1
      0029A7 01                     982 	.db	1
      0029A8 09                     983 	.db	9
      0029A9 00 04                  984 	.dw	Sstm8s_adc2$ADC2_DeInit$5-Sstm8s_adc2$ADC2_DeInit$4
      0029AB 03                     985 	.db	3
      0029AC 01                     986 	.sleb128	1
      0029AD 01                     987 	.db	1
      0029AE 09                     988 	.db	9
      0029AF 00 04                  989 	.dw	Sstm8s_adc2$ADC2_DeInit$6-Sstm8s_adc2$ADC2_DeInit$5
      0029B1 03                     990 	.db	3
      0029B2 01                     991 	.sleb128	1
      0029B3 01                     992 	.db	1
      0029B4 09                     993 	.db	9
      0029B5 00 04                  994 	.dw	Sstm8s_adc2$ADC2_DeInit$7-Sstm8s_adc2$ADC2_DeInit$6
      0029B7 03                     995 	.db	3
      0029B8 01                     996 	.sleb128	1
      0029B9 01                     997 	.db	1
      0029BA 09                     998 	.db	9
      0029BB 00 01                  999 	.dw	1+Sstm8s_adc2$ADC2_DeInit$8-Sstm8s_adc2$ADC2_DeInit$7
      0029BD 00                    1000 	.db	0
      0029BE 01                    1001 	.uleb128	1
      0029BF 01                    1002 	.db	1
      0029C0 00                    1003 	.db	0
      0029C1 05                    1004 	.uleb128	5
      0029C2 02                    1005 	.db	2
      0029C3 00 00 9C 9C           1006 	.dw	0,(Sstm8s_adc2$ADC2_Init$10)
      0029C7 03                    1007 	.db	3
      0029C8 D2 00                 1008 	.sleb128	82
      0029CA 01                    1009 	.db	1
      0029CB 09                    1010 	.db	9
      0029CC 00 00                 1011 	.dw	Sstm8s_adc2$ADC2_Init$12-Sstm8s_adc2$ADC2_Init$10
      0029CE 03                    1012 	.db	3
      0029CF 0F                    1013 	.sleb128	15
      0029D0 01                    1014 	.db	1
      0029D1 09                    1015 	.db	9
      0029D2 00 0E                 1016 	.dw	Sstm8s_adc2$ADC2_Init$17-Sstm8s_adc2$ADC2_Init$12
      0029D4 03                    1017 	.db	3
      0029D5 02                    1018 	.sleb128	2
      0029D6 01                    1019 	.db	1
      0029D7 09                    1020 	.db	9
      0029D8 00 07                 1021 	.dw	Sstm8s_adc2$ADC2_Init$20-Sstm8s_adc2$ADC2_Init$17
      0029DA 03                    1022 	.db	3
      0029DB 05                    1023 	.sleb128	5
      0029DC 01                    1024 	.db	1
      0029DD 09                    1025 	.db	9
      0029DE 00 0A                 1026 	.dw	Sstm8s_adc2$ADC2_Init$24-Sstm8s_adc2$ADC2_Init$20
      0029E0 03                    1027 	.db	3
      0029E1 05                    1028 	.sleb128	5
      0029E2 01                    1029 	.db	1
      0029E3 09                    1030 	.db	9
      0029E4 00 0A                 1031 	.dw	Sstm8s_adc2$ADC2_Init$28-Sstm8s_adc2$ADC2_Init$24
      0029E6 03                    1032 	.db	3
      0029E7 03                    1033 	.sleb128	3
      0029E8 01                    1034 	.db	1
      0029E9 09                    1035 	.db	9
      0029EA 00 08                 1036 	.dw	Sstm8s_adc2$ADC2_Init$29-Sstm8s_adc2$ADC2_Init$28
      0029EC 03                    1037 	.db	3
      0029ED 01                    1038 	.sleb128	1
      0029EE 01                    1039 	.db	1
      0029EF 09                    1040 	.db	9
      0029F0 00 01                 1041 	.dw	1+Sstm8s_adc2$ADC2_Init$30-Sstm8s_adc2$ADC2_Init$29
      0029F2 00                    1042 	.db	0
      0029F3 01                    1043 	.uleb128	1
      0029F4 01                    1044 	.db	1
      0029F5 00                    1045 	.db	0
      0029F6 05                    1046 	.uleb128	5
      0029F7 02                    1047 	.db	2
      0029F8 00 00 9C CE           1048 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$32)
      0029FC 03                    1049 	.db	3
      0029FD F8 00                 1050 	.sleb128	120
      0029FF 01                    1051 	.db	1
      002A00 09                    1052 	.db	9
      002A01 00 00                 1053 	.dw	Sstm8s_adc2$ADC2_Cmd$34-Sstm8s_adc2$ADC2_Cmd$32
      002A03 03                    1054 	.db	3
      002A04 07                    1055 	.sleb128	7
      002A05 01                    1056 	.db	1
      002A06 09                    1057 	.db	9
      002A07 00 03                 1058 	.dw	Sstm8s_adc2$ADC2_Cmd$35-Sstm8s_adc2$ADC2_Cmd$34
      002A09 03                    1059 	.db	3
      002A0A 7E                    1060 	.sleb128	-2
      002A0B 01                    1061 	.db	1
      002A0C 09                    1062 	.db	9
      002A0D 00 07                 1063 	.dw	Sstm8s_adc2$ADC2_Cmd$37-Sstm8s_adc2$ADC2_Cmd$35
      002A0F 03                    1064 	.db	3
      002A10 02                    1065 	.sleb128	2
      002A11 01                    1066 	.db	1
      002A12 09                    1067 	.db	9
      002A13 00 08                 1068 	.dw	Sstm8s_adc2$ADC2_Cmd$40-Sstm8s_adc2$ADC2_Cmd$37
      002A15 03                    1069 	.db	3
      002A16 04                    1070 	.sleb128	4
      002A17 01                    1071 	.db	1
      002A18 09                    1072 	.db	9
      002A19 00 05                 1073 	.dw	Sstm8s_adc2$ADC2_Cmd$42-Sstm8s_adc2$ADC2_Cmd$40
      002A1B 03                    1074 	.db	3
      002A1C 02                    1075 	.sleb128	2
      002A1D 01                    1076 	.db	1
      002A1E 09                    1077 	.db	9
      002A1F 00 01                 1078 	.dw	1+Sstm8s_adc2$ADC2_Cmd$43-Sstm8s_adc2$ADC2_Cmd$42
      002A21 00                    1079 	.db	0
      002A22 01                    1080 	.uleb128	1
      002A23 01                    1081 	.db	1
      002A24 00                    1082 	.db	0
      002A25 05                    1083 	.uleb128	5
      002A26 02                    1084 	.db	2
      002A27 00 00 9C E6           1085 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$45)
      002A2B 03                    1086 	.db	3
      002A2C 8C 01                 1087 	.sleb128	140
      002A2E 01                    1088 	.db	1
      002A2F 09                    1089 	.db	9
      002A30 00 00                 1090 	.dw	Sstm8s_adc2$ADC2_ITConfig$47-Sstm8s_adc2$ADC2_ITConfig$45
      002A32 03                    1091 	.db	3
      002A33 08                    1092 	.sleb128	8
      002A34 01                    1093 	.db	1
      002A35 09                    1094 	.db	9
      002A36 00 03                 1095 	.dw	Sstm8s_adc2$ADC2_ITConfig$48-Sstm8s_adc2$ADC2_ITConfig$47
      002A38 03                    1096 	.db	3
      002A39 7D                    1097 	.sleb128	-3
      002A3A 01                    1098 	.db	1
      002A3B 09                    1099 	.db	9
      002A3C 00 07                 1100 	.dw	Sstm8s_adc2$ADC2_ITConfig$50-Sstm8s_adc2$ADC2_ITConfig$48
      002A3E 03                    1101 	.db	3
      002A3F 03                    1102 	.sleb128	3
      002A40 01                    1103 	.db	1
      002A41 09                    1104 	.db	9
      002A42 00 08                 1105 	.dw	Sstm8s_adc2$ADC2_ITConfig$53-Sstm8s_adc2$ADC2_ITConfig$50
      002A44 03                    1106 	.db	3
      002A45 05                    1107 	.sleb128	5
      002A46 01                    1108 	.db	1
      002A47 09                    1109 	.db	9
      002A48 00 05                 1110 	.dw	Sstm8s_adc2$ADC2_ITConfig$55-Sstm8s_adc2$ADC2_ITConfig$53
      002A4A 03                    1111 	.db	3
      002A4B 02                    1112 	.sleb128	2
      002A4C 01                    1113 	.db	1
      002A4D 09                    1114 	.db	9
      002A4E 00 01                 1115 	.dw	1+Sstm8s_adc2$ADC2_ITConfig$56-Sstm8s_adc2$ADC2_ITConfig$55
      002A50 00                    1116 	.db	0
      002A51 01                    1117 	.uleb128	1
      002A52 01                    1118 	.db	1
      002A53 00                    1119 	.db	0
      002A54 05                    1120 	.uleb128	5
      002A55 02                    1121 	.db	2
      002A56 00 00 9C FE           1122 	.dw	0,(Sstm8s_adc2$ADC2_PrescalerConfig$58)
      002A5A 03                    1123 	.db	3
      002A5B A3 01                 1124 	.sleb128	163
      002A5D 01                    1125 	.db	1
      002A5E 09                    1126 	.db	9
      002A5F 00 00                 1127 	.dw	Sstm8s_adc2$ADC2_PrescalerConfig$60-Sstm8s_adc2$ADC2_PrescalerConfig$58
      002A61 03                    1128 	.db	3
      002A62 06                    1129 	.sleb128	6
      002A63 01                    1130 	.db	1
      002A64 09                    1131 	.db	9
      002A65 00 08                 1132 	.dw	Sstm8s_adc2$ADC2_PrescalerConfig$61-Sstm8s_adc2$ADC2_PrescalerConfig$60
      002A67 03                    1133 	.db	3
      002A68 02                    1134 	.sleb128	2
      002A69 01                    1135 	.db	1
      002A6A 09                    1136 	.db	9
      002A6B 00 08                 1137 	.dw	Sstm8s_adc2$ADC2_PrescalerConfig$62-Sstm8s_adc2$ADC2_PrescalerConfig$61
      002A6D 03                    1138 	.db	3
      002A6E 01                    1139 	.sleb128	1
      002A6F 01                    1140 	.db	1
      002A70 09                    1141 	.db	9
      002A71 00 01                 1142 	.dw	1+Sstm8s_adc2$ADC2_PrescalerConfig$63-Sstm8s_adc2$ADC2_PrescalerConfig$62
      002A73 00                    1143 	.db	0
      002A74 01                    1144 	.uleb128	1
      002A75 01                    1145 	.db	1
      002A76 00                    1146 	.db	0
      002A77 05                    1147 	.uleb128	5
      002A78 02                    1148 	.db	2
      002A79 00 00 9D 0F           1149 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$65)
      002A7D 03                    1150 	.db	3
      002A7E B6 01                 1151 	.sleb128	182
      002A80 01                    1152 	.db	1
      002A81 09                    1153 	.db	9
      002A82 00 01                 1154 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$68-Sstm8s_adc2$ADC2_SchmittTriggerConfig$65
      002A84 03                    1155 	.db	3
      002A85 06                    1156 	.sleb128	6
      002A86 01                    1157 	.db	1
      002A87 09                    1158 	.db	9
      002A88 00 0C                 1159 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$70-Sstm8s_adc2$ADC2_SchmittTriggerConfig$68
      002A8A 03                    1160 	.db	3
      002A8B 04                    1161 	.sleb128	4
      002A8C 01                    1162 	.db	1
      002A8D 09                    1163 	.db	9
      002A8E 00 03                 1164 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$72-Sstm8s_adc2$ADC2_SchmittTriggerConfig$70
      002A90 03                    1165 	.db	3
      002A91 7E                    1166 	.sleb128	-2
      002A92 01                    1167 	.db	1
      002A93 09                    1168 	.db	9
      002A94 00 07                 1169 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$74-Sstm8s_adc2$ADC2_SchmittTriggerConfig$72
      002A96 03                    1170 	.db	3
      002A97 02                    1171 	.sleb128	2
      002A98 01                    1172 	.db	1
      002A99 09                    1173 	.db	9
      002A9A 00 04                 1174 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$75-Sstm8s_adc2$ADC2_SchmittTriggerConfig$74
      002A9C 03                    1175 	.db	3
      002A9D 01                    1176 	.sleb128	1
      002A9E 01                    1177 	.db	1
      002A9F 09                    1178 	.db	9
      002AA0 00 0A                 1179 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$78-Sstm8s_adc2$ADC2_SchmittTriggerConfig$75
      002AA2 03                    1180 	.db	3
      002AA3 04                    1181 	.sleb128	4
      002AA4 01                    1182 	.db	1
      002AA5 09                    1183 	.db	9
      002AA6 00 04                 1184 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$79-Sstm8s_adc2$ADC2_SchmittTriggerConfig$78
      002AA8 03                    1185 	.db	3
      002AA9 01                    1186 	.sleb128	1
      002AAA 01                    1187 	.db	1
      002AAB 09                    1188 	.db	9
      002AAC 00 0A                 1189 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$81-Sstm8s_adc2$ADC2_SchmittTriggerConfig$79
      002AAE 03                    1190 	.db	3
      002AAF 03                    1191 	.sleb128	3
      002AB0 01                    1192 	.db	1
      002AB1 09                    1193 	.db	9
      002AB2 00 09                 1194 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$82-Sstm8s_adc2$ADC2_SchmittTriggerConfig$81
      002AB4 03                    1195 	.db	3
      002AB5 77                    1196 	.sleb128	-9
      002AB6 01                    1197 	.db	1
      002AB7 09                    1198 	.db	9
      002AB8 00 05                 1199 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$83-Sstm8s_adc2$ADC2_SchmittTriggerConfig$82
      002ABA 03                    1200 	.db	3
      002ABB 0D                    1201 	.sleb128	13
      002ABC 01                    1202 	.db	1
      002ABD 09                    1203 	.db	9
      002ABE 00 0D                 1204 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$87-Sstm8s_adc2$ADC2_SchmittTriggerConfig$83
      002AC0 03                    1205 	.db	3
      002AC1 7E                    1206 	.sleb128	-2
      002AC2 01                    1207 	.db	1
      002AC3 09                    1208 	.db	9
      002AC4 00 07                 1209 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$89-Sstm8s_adc2$ADC2_SchmittTriggerConfig$87
      002AC6 03                    1210 	.db	3
      002AC7 02                    1211 	.sleb128	2
      002AC8 01                    1212 	.db	1
      002AC9 09                    1213 	.db	9
      002ACA 00 09                 1214 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$92-Sstm8s_adc2$ADC2_SchmittTriggerConfig$89
      002ACC 03                    1215 	.db	3
      002ACD 04                    1216 	.sleb128	4
      002ACE 01                    1217 	.db	1
      002ACF 09                    1218 	.db	9
      002AD0 00 08                 1219 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$94-Sstm8s_adc2$ADC2_SchmittTriggerConfig$92
      002AD2 03                    1220 	.db	3
      002AD3 70                    1221 	.sleb128	-16
      002AD4 01                    1222 	.db	1
      002AD5 09                    1223 	.db	9
      002AD6 00 05                 1224 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$95-Sstm8s_adc2$ADC2_SchmittTriggerConfig$94
      002AD8 03                    1225 	.db	3
      002AD9 17                    1226 	.sleb128	23
      002ADA 01                    1227 	.db	1
      002ADB 09                    1228 	.db	9
      002ADC 00 12                 1229 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$99-Sstm8s_adc2$ADC2_SchmittTriggerConfig$95
      002ADE 03                    1230 	.db	3
      002ADF 7E                    1231 	.sleb128	-2
      002AE0 01                    1232 	.db	1
      002AE1 09                    1233 	.db	9
      002AE2 00 07                 1234 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$101-Sstm8s_adc2$ADC2_SchmittTriggerConfig$99
      002AE4 03                    1235 	.db	3
      002AE5 02                    1236 	.sleb128	2
      002AE6 01                    1237 	.db	1
      002AE7 09                    1238 	.db	9
      002AE8 00 09                 1239 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$104-Sstm8s_adc2$ADC2_SchmittTriggerConfig$101
      002AEA 03                    1240 	.db	3
      002AEB 04                    1241 	.sleb128	4
      002AEC 01                    1242 	.db	1
      002AED 09                    1243 	.db	9
      002AEE 00 05                 1244 	.dw	Sstm8s_adc2$ADC2_SchmittTriggerConfig$106-Sstm8s_adc2$ADC2_SchmittTriggerConfig$104
      002AF0 03                    1245 	.db	3
      002AF1 03                    1246 	.sleb128	3
      002AF2 01                    1247 	.db	1
      002AF3 09                    1248 	.db	9
      002AF4 00 02                 1249 	.dw	1+Sstm8s_adc2$ADC2_SchmittTriggerConfig$108-Sstm8s_adc2$ADC2_SchmittTriggerConfig$106
      002AF6 00                    1250 	.db	0
      002AF7 01                    1251 	.uleb128	1
      002AF8 01                    1252 	.db	1
      002AF9 00                    1253 	.db	0
      002AFA 05                    1254 	.uleb128	5
      002AFB 02                    1255 	.db	2
      002AFC 00 00 9D A3           1256 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$110)
      002B00 03                    1257 	.db	3
      002B01 EB 01                 1258 	.sleb128	235
      002B03 01                    1259 	.db	1
      002B04 09                    1260 	.db	9
      002B05 00 00                 1261 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$112-Sstm8s_adc2$ADC2_ConversionConfig$110
      002B07 03                    1262 	.db	3
      002B08 08                    1263 	.sleb128	8
      002B09 01                    1264 	.db	1
      002B0A 09                    1265 	.db	9
      002B0B 00 08                 1266 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$113-Sstm8s_adc2$ADC2_ConversionConfig$112
      002B0D 03                    1267 	.db	3
      002B0E 02                    1268 	.sleb128	2
      002B0F 01                    1269 	.db	1
      002B10 09                    1270 	.db	9
      002B11 00 08                 1271 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$114-Sstm8s_adc2$ADC2_ConversionConfig$113
      002B13 03                    1272 	.db	3
      002B14 05                    1273 	.sleb128	5
      002B15 01                    1274 	.db	1
      002B16 09                    1275 	.db	9
      002B17 00 03                 1276 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$115-Sstm8s_adc2$ADC2_ConversionConfig$114
      002B19 03                    1277 	.db	3
      002B1A 7D                    1278 	.sleb128	-3
      002B1B 01                    1279 	.db	1
      002B1C 09                    1280 	.db	9
      002B1D 00 0D                 1281 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$120-Sstm8s_adc2$ADC2_ConversionConfig$115
      002B1F 03                    1282 	.db	3
      002B20 03                    1283 	.sleb128	3
      002B21 01                    1284 	.db	1
      002B22 09                    1285 	.db	9
      002B23 00 08                 1286 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$123-Sstm8s_adc2$ADC2_ConversionConfig$120
      002B25 03                    1287 	.db	3
      002B26 05                    1288 	.sleb128	5
      002B27 01                    1289 	.db	1
      002B28 09                    1290 	.db	9
      002B29 00 05                 1291 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$125-Sstm8s_adc2$ADC2_ConversionConfig$123
      002B2B 03                    1292 	.db	3
      002B2C 04                    1293 	.sleb128	4
      002B2D 01                    1294 	.db	1
      002B2E 09                    1295 	.db	9
      002B2F 00 08                 1296 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$126-Sstm8s_adc2$ADC2_ConversionConfig$125
      002B31 03                    1297 	.db	3
      002B32 02                    1298 	.sleb128	2
      002B33 01                    1299 	.db	1
      002B34 09                    1300 	.db	9
      002B35 00 08                 1301 	.dw	Sstm8s_adc2$ADC2_ConversionConfig$127-Sstm8s_adc2$ADC2_ConversionConfig$126
      002B37 03                    1302 	.db	3
      002B38 01                    1303 	.sleb128	1
      002B39 01                    1304 	.db	1
      002B3A 09                    1305 	.db	9
      002B3B 00 01                 1306 	.dw	1+Sstm8s_adc2$ADC2_ConversionConfig$128-Sstm8s_adc2$ADC2_ConversionConfig$127
      002B3D 00                    1307 	.db	0
      002B3E 01                    1308 	.uleb128	1
      002B3F 01                    1309 	.db	1
      002B40 00                    1310 	.db	0
      002B41 05                    1311 	.uleb128	5
      002B42 02                    1312 	.db	2
      002B43 00 00 9D E1           1313 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$130)
      002B47 03                    1314 	.db	3
      002B48 92 02                 1315 	.sleb128	274
      002B4A 01                    1316 	.db	1
      002B4B 09                    1317 	.db	9
      002B4C 00 00                 1318 	.dw	Sstm8s_adc2$ADC2_ExternalTriggerConfig$132-Sstm8s_adc2$ADC2_ExternalTriggerConfig$130
      002B4E 03                    1319 	.db	3
      002B4F 07                    1320 	.sleb128	7
      002B50 01                    1321 	.db	1
      002B51 09                    1322 	.db	9
      002B52 00 0B                 1323 	.dw	Sstm8s_adc2$ADC2_ExternalTriggerConfig$133-Sstm8s_adc2$ADC2_ExternalTriggerConfig$132
      002B54 03                    1324 	.db	3
      002B55 02                    1325 	.sleb128	2
      002B56 01                    1326 	.db	1
      002B57 09                    1327 	.db	9
      002B58 00 07                 1328 	.dw	Sstm8s_adc2$ADC2_ExternalTriggerConfig$135-Sstm8s_adc2$ADC2_ExternalTriggerConfig$133
      002B5A 03                    1329 	.db	3
      002B5B 03                    1330 	.sleb128	3
      002B5C 01                    1331 	.db	1
      002B5D 09                    1332 	.db	9
      002B5E 00 08                 1333 	.dw	Sstm8s_adc2$ADC2_ExternalTriggerConfig$138-Sstm8s_adc2$ADC2_ExternalTriggerConfig$135
      002B60 03                    1334 	.db	3
      002B61 05                    1335 	.sleb128	5
      002B62 01                    1336 	.db	1
      002B63 09                    1337 	.db	9
      002B64 00 05                 1338 	.dw	Sstm8s_adc2$ADC2_ExternalTriggerConfig$140-Sstm8s_adc2$ADC2_ExternalTriggerConfig$138
      002B66 03                    1339 	.db	3
      002B67 04                    1340 	.sleb128	4
      002B68 01                    1341 	.db	1
      002B69 09                    1342 	.db	9
      002B6A 00 08                 1343 	.dw	Sstm8s_adc2$ADC2_ExternalTriggerConfig$141-Sstm8s_adc2$ADC2_ExternalTriggerConfig$140
      002B6C 03                    1344 	.db	3
      002B6D 01                    1345 	.sleb128	1
      002B6E 01                    1346 	.db	1
      002B6F 09                    1347 	.db	9
      002B70 00 01                 1348 	.dw	1+Sstm8s_adc2$ADC2_ExternalTriggerConfig$142-Sstm8s_adc2$ADC2_ExternalTriggerConfig$141
      002B72 00                    1349 	.db	0
      002B73 01                    1350 	.uleb128	1
      002B74 01                    1351 	.db	1
      002B75 00                    1352 	.db	0
      002B76 05                    1353 	.uleb128	5
      002B77 02                    1354 	.db	2
      002B78 00 00 9E 09           1355 	.dw	0,(Sstm8s_adc2$ADC2_StartConversion$144)
      002B7C 03                    1356 	.db	3
      002B7D B3 02                 1357 	.sleb128	307
      002B7F 01                    1358 	.db	1
      002B80 09                    1359 	.db	9
      002B81 00 00                 1360 	.dw	Sstm8s_adc2$ADC2_StartConversion$146-Sstm8s_adc2$ADC2_StartConversion$144
      002B83 03                    1361 	.db	3
      002B84 02                    1362 	.sleb128	2
      002B85 01                    1363 	.db	1
      002B86 09                    1364 	.db	9
      002B87 00 08                 1365 	.dw	Sstm8s_adc2$ADC2_StartConversion$147-Sstm8s_adc2$ADC2_StartConversion$146
      002B89 03                    1366 	.db	3
      002B8A 01                    1367 	.sleb128	1
      002B8B 01                    1368 	.db	1
      002B8C 09                    1369 	.db	9
      002B8D 00 01                 1370 	.dw	1+Sstm8s_adc2$ADC2_StartConversion$148-Sstm8s_adc2$ADC2_StartConversion$147
      002B8F 00                    1371 	.db	0
      002B90 01                    1372 	.uleb128	1
      002B91 01                    1373 	.db	1
      002B92 00                    1374 	.db	0
      002B93 05                    1375 	.uleb128	5
      002B94 02                    1376 	.db	2
      002B95 00 00 9E 12           1377 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$150)
      002B99 03                    1378 	.db	3
      002B9A BF 02                 1379 	.sleb128	319
      002B9C 01                    1380 	.db	1
      002B9D 09                    1381 	.db	9
      002B9E 00 02                 1382 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$153-Sstm8s_adc2$ADC2_GetConversionValue$150
      002BA0 03                    1383 	.db	3
      002BA1 05                    1384 	.sleb128	5
      002BA2 01                    1385 	.db	1
      002BA3 09                    1386 	.db	9
      002BA4 00 0A                 1387 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$155-Sstm8s_adc2$ADC2_GetConversionValue$153
      002BA6 03                    1388 	.db	3
      002BA7 03                    1389 	.sleb128	3
      002BA8 01                    1390 	.db	1
      002BA9 09                    1391 	.db	9
      002BAA 00 04                 1392 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$156-Sstm8s_adc2$ADC2_GetConversionValue$155
      002BAC 03                    1393 	.db	3
      002BAD 02                    1394 	.sleb128	2
      002BAE 01                    1395 	.db	1
      002BAF 09                    1396 	.db	9
      002BB0 00 05                 1397 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$157-Sstm8s_adc2$ADC2_GetConversionValue$156
      002BB2 03                    1398 	.db	3
      002BB3 02                    1399 	.sleb128	2
      002BB4 01                    1400 	.db	1
      002BB5 09                    1401 	.db	9
      002BB6 00 10                 1402 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$160-Sstm8s_adc2$ADC2_GetConversionValue$157
      002BB8 03                    1403 	.db	3
      002BB9 05                    1404 	.sleb128	5
      002BBA 01                    1405 	.db	1
      002BBB 09                    1406 	.db	9
      002BBC 00 06                 1407 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$161-Sstm8s_adc2$ADC2_GetConversionValue$160
      002BBE 03                    1408 	.db	3
      002BBF 02                    1409 	.sleb128	2
      002BC0 01                    1410 	.db	1
      002BC1 09                    1411 	.db	9
      002BC2 00 03                 1412 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$162-Sstm8s_adc2$ADC2_GetConversionValue$161
      002BC4 03                    1413 	.db	3
      002BC5 02                    1414 	.sleb128	2
      002BC6 01                    1415 	.db	1
      002BC7 09                    1416 	.db	9
      002BC8 00 15                 1417 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$164-Sstm8s_adc2$ADC2_GetConversionValue$162
      002BCA 03                    1418 	.db	3
      002BCB 03                    1419 	.sleb128	3
      002BCC 01                    1420 	.db	1
      002BCD 09                    1421 	.db	9
      002BCE 00 02                 1422 	.dw	Sstm8s_adc2$ADC2_GetConversionValue$165-Sstm8s_adc2$ADC2_GetConversionValue$164
      002BD0 03                    1423 	.db	3
      002BD1 01                    1424 	.sleb128	1
      002BD2 01                    1425 	.db	1
      002BD3 09                    1426 	.db	9
      002BD4 00 03                 1427 	.dw	1+Sstm8s_adc2$ADC2_GetConversionValue$167-Sstm8s_adc2$ADC2_GetConversionValue$165
      002BD6 00                    1428 	.db	0
      002BD7 01                    1429 	.uleb128	1
      002BD8 01                    1430 	.db	1
      002BD9 00                    1431 	.db	0
      002BDA 05                    1432 	.uleb128	5
      002BDB 02                    1433 	.db	2
      002BDC 00 00 9E 5A           1434 	.dw	0,(Sstm8s_adc2$ADC2_GetFlagStatus$169)
      002BE0 03                    1435 	.db	3
      002BE1 DF 02                 1436 	.sleb128	351
      002BE3 01                    1437 	.db	1
      002BE4 09                    1438 	.db	9
      002BE5 00 00                 1439 	.dw	Sstm8s_adc2$ADC2_GetFlagStatus$171-Sstm8s_adc2$ADC2_GetFlagStatus$169
      002BE7 03                    1440 	.db	3
      002BE8 03                    1441 	.sleb128	3
      002BE9 01                    1442 	.db	1
      002BEA 09                    1443 	.db	9
      002BEB 00 05                 1444 	.dw	Sstm8s_adc2$ADC2_GetFlagStatus$172-Sstm8s_adc2$ADC2_GetFlagStatus$171
      002BED 03                    1445 	.db	3
      002BEE 01                    1446 	.sleb128	1
      002BEF 01                    1447 	.db	1
      002BF0 09                    1448 	.db	9
      002BF1 00 01                 1449 	.dw	1+Sstm8s_adc2$ADC2_GetFlagStatus$173-Sstm8s_adc2$ADC2_GetFlagStatus$172
      002BF3 00                    1450 	.db	0
      002BF4 01                    1451 	.uleb128	1
      002BF5 01                    1452 	.db	1
      002BF6 00                    1453 	.db	0
      002BF7 05                    1454 	.uleb128	5
      002BF8 02                    1455 	.db	2
      002BF9 00 00 9E 60           1456 	.dw	0,(Sstm8s_adc2$ADC2_ClearFlag$175)
      002BFD 03                    1457 	.db	3
      002BFE EA 02                 1458 	.sleb128	362
      002C00 01                    1459 	.db	1
      002C01 09                    1460 	.db	9
      002C02 00 00                 1461 	.dw	Sstm8s_adc2$ADC2_ClearFlag$177-Sstm8s_adc2$ADC2_ClearFlag$175
      002C04 03                    1462 	.db	3
      002C05 02                    1463 	.sleb128	2
      002C06 01                    1464 	.db	1
      002C07 09                    1465 	.db	9
      002C08 00 08                 1466 	.dw	Sstm8s_adc2$ADC2_ClearFlag$178-Sstm8s_adc2$ADC2_ClearFlag$177
      002C0A 03                    1467 	.db	3
      002C0B 01                    1468 	.sleb128	1
      002C0C 01                    1469 	.db	1
      002C0D 09                    1470 	.db	9
      002C0E 00 01                 1471 	.dw	1+Sstm8s_adc2$ADC2_ClearFlag$179-Sstm8s_adc2$ADC2_ClearFlag$178
      002C10 00                    1472 	.db	0
      002C11 01                    1473 	.uleb128	1
      002C12 01                    1474 	.db	1
      002C13 00                    1475 	.db	0
      002C14 05                    1476 	.uleb128	5
      002C15 02                    1477 	.db	2
      002C16 00 00 9E 69           1478 	.dw	0,(Sstm8s_adc2$ADC2_GetITStatus$181)
      002C1A 03                    1479 	.db	3
      002C1B F5 02                 1480 	.sleb128	373
      002C1D 01                    1481 	.db	1
      002C1E 09                    1482 	.db	9
      002C1F 00 00                 1483 	.dw	Sstm8s_adc2$ADC2_GetITStatus$183-Sstm8s_adc2$ADC2_GetITStatus$181
      002C21 03                    1484 	.db	3
      002C22 02                    1485 	.sleb128	2
      002C23 01                    1486 	.db	1
      002C24 09                    1487 	.db	9
      002C25 00 05                 1488 	.dw	Sstm8s_adc2$ADC2_GetITStatus$184-Sstm8s_adc2$ADC2_GetITStatus$183
      002C27 03                    1489 	.db	3
      002C28 01                    1490 	.sleb128	1
      002C29 01                    1491 	.db	1
      002C2A 09                    1492 	.db	9
      002C2B 00 01                 1493 	.dw	1+Sstm8s_adc2$ADC2_GetITStatus$185-Sstm8s_adc2$ADC2_GetITStatus$184
      002C2D 00                    1494 	.db	0
      002C2E 01                    1495 	.uleb128	1
      002C2F 01                    1496 	.db	1
      002C30 00                    1497 	.db	0
      002C31 05                    1498 	.uleb128	5
      002C32 02                    1499 	.db	2
      002C33 00 00 9E 6F           1500 	.dw	0,(Sstm8s_adc2$ADC2_ClearITPendingBit$187)
      002C37 03                    1501 	.db	3
      002C38 FF 02                 1502 	.sleb128	383
      002C3A 01                    1503 	.db	1
      002C3B 09                    1504 	.db	9
      002C3C 00 00                 1505 	.dw	Sstm8s_adc2$ADC2_ClearITPendingBit$189-Sstm8s_adc2$ADC2_ClearITPendingBit$187
      002C3E 03                    1506 	.db	3
      002C3F 02                    1507 	.sleb128	2
      002C40 01                    1508 	.db	1
      002C41 09                    1509 	.db	9
      002C42 00 08                 1510 	.dw	Sstm8s_adc2$ADC2_ClearITPendingBit$190-Sstm8s_adc2$ADC2_ClearITPendingBit$189
      002C44 03                    1511 	.db	3
      002C45 01                    1512 	.sleb128	1
      002C46 01                    1513 	.db	1
      002C47 09                    1514 	.db	9
      002C48 00 01                 1515 	.dw	1+Sstm8s_adc2$ADC2_ClearITPendingBit$191-Sstm8s_adc2$ADC2_ClearITPendingBit$190
      002C4A 00                    1516 	.db	0
      002C4B 01                    1517 	.uleb128	1
      002C4C 01                    1518 	.db	1
      002C4D                       1519 Ldebug_line_end:
                                   1520 
                                   1521 	.area .debug_loc (NOLOAD)
      0030A8                       1522 Ldebug_loc_start:
      0030A8 00 00 9E 6F           1523 	.dw	0,(Sstm8s_adc2$ADC2_ClearITPendingBit$188)
      0030AC 00 00 9E 78           1524 	.dw	0,(Sstm8s_adc2$ADC2_ClearITPendingBit$192)
      0030B0 00 02                 1525 	.dw	2
      0030B2 78                    1526 	.db	120
      0030B3 01                    1527 	.sleb128	1
      0030B4 00 00 00 00           1528 	.dw	0,0
      0030B8 00 00 00 00           1529 	.dw	0,0
      0030BC 00 00 9E 69           1530 	.dw	0,(Sstm8s_adc2$ADC2_GetITStatus$182)
      0030C0 00 00 9E 6F           1531 	.dw	0,(Sstm8s_adc2$ADC2_GetITStatus$186)
      0030C4 00 02                 1532 	.dw	2
      0030C6 78                    1533 	.db	120
      0030C7 01                    1534 	.sleb128	1
      0030C8 00 00 00 00           1535 	.dw	0,0
      0030CC 00 00 00 00           1536 	.dw	0,0
      0030D0 00 00 9E 60           1537 	.dw	0,(Sstm8s_adc2$ADC2_ClearFlag$176)
      0030D4 00 00 9E 69           1538 	.dw	0,(Sstm8s_adc2$ADC2_ClearFlag$180)
      0030D8 00 02                 1539 	.dw	2
      0030DA 78                    1540 	.db	120
      0030DB 01                    1541 	.sleb128	1
      0030DC 00 00 00 00           1542 	.dw	0,0
      0030E0 00 00 00 00           1543 	.dw	0,0
      0030E4 00 00 9E 5A           1544 	.dw	0,(Sstm8s_adc2$ADC2_GetFlagStatus$170)
      0030E8 00 00 9E 60           1545 	.dw	0,(Sstm8s_adc2$ADC2_GetFlagStatus$174)
      0030EC 00 02                 1546 	.dw	2
      0030EE 78                    1547 	.db	120
      0030EF 01                    1548 	.sleb128	1
      0030F0 00 00 00 00           1549 	.dw	0,0
      0030F4 00 00 00 00           1550 	.dw	0,0
      0030F8 00 00 9E 59           1551 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$166)
      0030FC 00 00 9E 5A           1552 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$168)
      003100 00 02                 1553 	.dw	2
      003102 78                    1554 	.db	120
      003103 01                    1555 	.sleb128	1
      003104 00 00 9E 14           1556 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$152)
      003108 00 00 9E 59           1557 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$166)
      00310C 00 02                 1558 	.dw	2
      00310E 78                    1559 	.db	120
      00310F 05                    1560 	.sleb128	5
      003110 00 00 9E 12           1561 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$151)
      003114 00 00 9E 14           1562 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$152)
      003118 00 02                 1563 	.dw	2
      00311A 78                    1564 	.db	120
      00311B 01                    1565 	.sleb128	1
      00311C 00 00 00 00           1566 	.dw	0,0
      003120 00 00 00 00           1567 	.dw	0,0
      003124 00 00 9E 09           1568 	.dw	0,(Sstm8s_adc2$ADC2_StartConversion$145)
      003128 00 00 9E 12           1569 	.dw	0,(Sstm8s_adc2$ADC2_StartConversion$149)
      00312C 00 02                 1570 	.dw	2
      00312E 78                    1571 	.db	120
      00312F 01                    1572 	.sleb128	1
      003130 00 00 00 00           1573 	.dw	0,0
      003134 00 00 00 00           1574 	.dw	0,0
      003138 00 00 9D E1           1575 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$131)
      00313C 00 00 9E 09           1576 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$143)
      003140 00 02                 1577 	.dw	2
      003142 78                    1578 	.db	120
      003143 01                    1579 	.sleb128	1
      003144 00 00 00 00           1580 	.dw	0,0
      003148 00 00 00 00           1581 	.dw	0,0
      00314C 00 00 9D C3           1582 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$118)
      003150 00 00 9D E1           1583 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$129)
      003154 00 02                 1584 	.dw	2
      003156 78                    1585 	.db	120
      003157 01                    1586 	.sleb128	1
      003158 00 00 9D BB           1587 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$117)
      00315C 00 00 9D C3           1588 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$118)
      003160 00 02                 1589 	.dw	2
      003162 78                    1590 	.db	120
      003163 01                    1591 	.sleb128	1
      003164 00 00 9D B7           1592 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$116)
      003168 00 00 9D BB           1593 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$117)
      00316C 00 02                 1594 	.dw	2
      00316E 78                    1595 	.db	120
      00316F 02                    1596 	.sleb128	2
      003170 00 00 9D A3           1597 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$111)
      003174 00 00 9D B7           1598 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$116)
      003178 00 02                 1599 	.dw	2
      00317A 78                    1600 	.db	120
      00317B 01                    1601 	.sleb128	1
      00317C 00 00 00 00           1602 	.dw	0,0
      003180 00 00 00 00           1603 	.dw	0,0
      003184 00 00 9D A2           1604 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$107)
      003188 00 00 9D A3           1605 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$109)
      00318C 00 02                 1606 	.dw	2
      00318E 78                    1607 	.db	120
      00318F 01                    1608 	.sleb128	1
      003190 00 00 9D 8C           1609 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$97)
      003194 00 00 9D A2           1610 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$107)
      003198 00 02                 1611 	.dw	2
      00319A 78                    1612 	.db	120
      00319B 02                    1613 	.sleb128	2
      00319C 00 00 9D 82           1614 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$96)
      0031A0 00 00 9D 8C           1615 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$97)
      0031A4 00 02                 1616 	.dw	2
      0031A6 78                    1617 	.db	120
      0031A7 03                    1618 	.sleb128	3
      0031A8 00 00 9D 5D           1619 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$85)
      0031AC 00 00 9D 82           1620 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$96)
      0031B0 00 02                 1621 	.dw	2
      0031B2 78                    1622 	.db	120
      0031B3 02                    1623 	.sleb128	2
      0031B4 00 00 9D 53           1624 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$84)
      0031B8 00 00 9D 5D           1625 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$85)
      0031BC 00 02                 1626 	.dw	2
      0031BE 78                    1627 	.db	120
      0031BF 03                    1628 	.sleb128	3
      0031C0 00 00 9D 1C           1629 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$69)
      0031C4 00 00 9D 53           1630 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$84)
      0031C8 00 02                 1631 	.dw	2
      0031CA 78                    1632 	.db	120
      0031CB 02                    1633 	.sleb128	2
      0031CC 00 00 9D 10           1634 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$67)
      0031D0 00 00 9D 1C           1635 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$69)
      0031D4 00 02                 1636 	.dw	2
      0031D6 78                    1637 	.db	120
      0031D7 02                    1638 	.sleb128	2
      0031D8 00 00 9D 0F           1639 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$66)
      0031DC 00 00 9D 10           1640 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$67)
      0031E0 00 02                 1641 	.dw	2
      0031E2 78                    1642 	.db	120
      0031E3 01                    1643 	.sleb128	1
      0031E4 00 00 00 00           1644 	.dw	0,0
      0031E8 00 00 00 00           1645 	.dw	0,0
      0031EC 00 00 9C FE           1646 	.dw	0,(Sstm8s_adc2$ADC2_PrescalerConfig$59)
      0031F0 00 00 9D 0F           1647 	.dw	0,(Sstm8s_adc2$ADC2_PrescalerConfig$64)
      0031F4 00 02                 1648 	.dw	2
      0031F6 78                    1649 	.db	120
      0031F7 01                    1650 	.sleb128	1
      0031F8 00 00 00 00           1651 	.dw	0,0
      0031FC 00 00 00 00           1652 	.dw	0,0
      003200 00 00 9C E6           1653 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$46)
      003204 00 00 9C FE           1654 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$57)
      003208 00 02                 1655 	.dw	2
      00320A 78                    1656 	.db	120
      00320B 01                    1657 	.sleb128	1
      00320C 00 00 00 00           1658 	.dw	0,0
      003210 00 00 00 00           1659 	.dw	0,0
      003214 00 00 9C CE           1660 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$33)
      003218 00 00 9C E6           1661 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$44)
      00321C 00 02                 1662 	.dw	2
      00321E 78                    1663 	.db	120
      00321F 01                    1664 	.sleb128	1
      003220 00 00 00 00           1665 	.dw	0,0
      003224 00 00 00 00           1666 	.dw	0,0
      003228 00 00 9C C5           1667 	.dw	0,(Sstm8s_adc2$ADC2_Init$27)
      00322C 00 00 9C CE           1668 	.dw	0,(Sstm8s_adc2$ADC2_Init$31)
      003230 00 02                 1669 	.dw	2
      003232 78                    1670 	.db	120
      003233 01                    1671 	.sleb128	1
      003234 00 00 9C C1           1672 	.dw	0,(Sstm8s_adc2$ADC2_Init$26)
      003238 00 00 9C C5           1673 	.dw	0,(Sstm8s_adc2$ADC2_Init$27)
      00323C 00 02                 1674 	.dw	2
      00323E 78                    1675 	.db	120
      00323F 03                    1676 	.sleb128	3
      003240 00 00 9C BE           1677 	.dw	0,(Sstm8s_adc2$ADC2_Init$25)
      003244 00 00 9C C1           1678 	.dw	0,(Sstm8s_adc2$ADC2_Init$26)
      003248 00 02                 1679 	.dw	2
      00324A 78                    1680 	.db	120
      00324B 02                    1681 	.sleb128	2
      00324C 00 00 9C BB           1682 	.dw	0,(Sstm8s_adc2$ADC2_Init$23)
      003250 00 00 9C BE           1683 	.dw	0,(Sstm8s_adc2$ADC2_Init$25)
      003254 00 02                 1684 	.dw	2
      003256 78                    1685 	.db	120
      003257 01                    1686 	.sleb128	1
      003258 00 00 9C B7           1687 	.dw	0,(Sstm8s_adc2$ADC2_Init$22)
      00325C 00 00 9C BB           1688 	.dw	0,(Sstm8s_adc2$ADC2_Init$23)
      003260 00 02                 1689 	.dw	2
      003262 78                    1690 	.db	120
      003263 03                    1691 	.sleb128	3
      003264 00 00 9C B4           1692 	.dw	0,(Sstm8s_adc2$ADC2_Init$21)
      003268 00 00 9C B7           1693 	.dw	0,(Sstm8s_adc2$ADC2_Init$22)
      00326C 00 02                 1694 	.dw	2
      00326E 78                    1695 	.db	120
      00326F 02                    1696 	.sleb128	2
      003270 00 00 9C B1           1697 	.dw	0,(Sstm8s_adc2$ADC2_Init$19)
      003274 00 00 9C B4           1698 	.dw	0,(Sstm8s_adc2$ADC2_Init$21)
      003278 00 02                 1699 	.dw	2
      00327A 78                    1700 	.db	120
      00327B 01                    1701 	.sleb128	1
      00327C 00 00 9C AD           1702 	.dw	0,(Sstm8s_adc2$ADC2_Init$18)
      003280 00 00 9C B1           1703 	.dw	0,(Sstm8s_adc2$ADC2_Init$19)
      003284 00 02                 1704 	.dw	2
      003286 78                    1705 	.db	120
      003287 02                    1706 	.sleb128	2
      003288 00 00 9C AA           1707 	.dw	0,(Sstm8s_adc2$ADC2_Init$16)
      00328C 00 00 9C AD           1708 	.dw	0,(Sstm8s_adc2$ADC2_Init$18)
      003290 00 02                 1709 	.dw	2
      003292 78                    1710 	.db	120
      003293 01                    1711 	.sleb128	1
      003294 00 00 9C A5           1712 	.dw	0,(Sstm8s_adc2$ADC2_Init$15)
      003298 00 00 9C AA           1713 	.dw	0,(Sstm8s_adc2$ADC2_Init$16)
      00329C 00 02                 1714 	.dw	2
      00329E 78                    1715 	.db	120
      00329F 04                    1716 	.sleb128	4
      0032A0 00 00 9C A2           1717 	.dw	0,(Sstm8s_adc2$ADC2_Init$14)
      0032A4 00 00 9C A5           1718 	.dw	0,(Sstm8s_adc2$ADC2_Init$15)
      0032A8 00 02                 1719 	.dw	2
      0032AA 78                    1720 	.db	120
      0032AB 03                    1721 	.sleb128	3
      0032AC 00 00 9C 9F           1722 	.dw	0,(Sstm8s_adc2$ADC2_Init$13)
      0032B0 00 00 9C A2           1723 	.dw	0,(Sstm8s_adc2$ADC2_Init$14)
      0032B4 00 02                 1724 	.dw	2
      0032B6 78                    1725 	.db	120
      0032B7 02                    1726 	.sleb128	2
      0032B8 00 00 9C 9C           1727 	.dw	0,(Sstm8s_adc2$ADC2_Init$11)
      0032BC 00 00 9C 9F           1728 	.dw	0,(Sstm8s_adc2$ADC2_Init$13)
      0032C0 00 02                 1729 	.dw	2
      0032C2 78                    1730 	.db	120
      0032C3 01                    1731 	.sleb128	1
      0032C4 00 00 00 00           1732 	.dw	0,0
      0032C8 00 00 00 00           1733 	.dw	0,0
      0032CC 00 00 9C 87           1734 	.dw	0,(Sstm8s_adc2$ADC2_DeInit$1)
      0032D0 00 00 9C 9C           1735 	.dw	0,(Sstm8s_adc2$ADC2_DeInit$9)
      0032D4 00 02                 1736 	.dw	2
      0032D6 78                    1737 	.db	120
      0032D7 01                    1738 	.sleb128	1
      0032D8 00 00 00 00           1739 	.dw	0,0
      0032DC 00 00 00 00           1740 	.dw	0,0
                                   1741 
                                   1742 	.area .debug_abbrev (NOLOAD)
      0006BC                       1743 Ldebug_abbrev:
      0006BC 0B                    1744 	.uleb128	11
      0006BD 2E                    1745 	.uleb128	46
      0006BE 00                    1746 	.db	0
      0006BF 03                    1747 	.uleb128	3
      0006C0 08                    1748 	.uleb128	8
      0006C1 11                    1749 	.uleb128	17
      0006C2 01                    1750 	.uleb128	1
      0006C3 12                    1751 	.uleb128	18
      0006C4 01                    1752 	.uleb128	1
      0006C5 3F                    1753 	.uleb128	63
      0006C6 0C                    1754 	.uleb128	12
      0006C7 40                    1755 	.uleb128	64
      0006C8 06                    1756 	.uleb128	6
      0006C9 49                    1757 	.uleb128	73
      0006CA 13                    1758 	.uleb128	19
      0006CB 00                    1759 	.uleb128	0
      0006CC 00                    1760 	.uleb128	0
      0006CD 04                    1761 	.uleb128	4
      0006CE 05                    1762 	.uleb128	5
      0006CF 00                    1763 	.db	0
      0006D0 02                    1764 	.uleb128	2
      0006D1 0A                    1765 	.uleb128	10
      0006D2 03                    1766 	.uleb128	3
      0006D3 08                    1767 	.uleb128	8
      0006D4 49                    1768 	.uleb128	73
      0006D5 13                    1769 	.uleb128	19
      0006D6 00                    1770 	.uleb128	0
      0006D7 00                    1771 	.uleb128	0
      0006D8 03                    1772 	.uleb128	3
      0006D9 2E                    1773 	.uleb128	46
      0006DA 01                    1774 	.db	1
      0006DB 01                    1775 	.uleb128	1
      0006DC 13                    1776 	.uleb128	19
      0006DD 03                    1777 	.uleb128	3
      0006DE 08                    1778 	.uleb128	8
      0006DF 11                    1779 	.uleb128	17
      0006E0 01                    1780 	.uleb128	1
      0006E1 12                    1781 	.uleb128	18
      0006E2 01                    1782 	.uleb128	1
      0006E3 3F                    1783 	.uleb128	63
      0006E4 0C                    1784 	.uleb128	12
      0006E5 40                    1785 	.uleb128	64
      0006E6 06                    1786 	.uleb128	6
      0006E7 00                    1787 	.uleb128	0
      0006E8 00                    1788 	.uleb128	0
      0006E9 0A                    1789 	.uleb128	10
      0006EA 34                    1790 	.uleb128	52
      0006EB 00                    1791 	.db	0
      0006EC 02                    1792 	.uleb128	2
      0006ED 0A                    1793 	.uleb128	10
      0006EE 03                    1794 	.uleb128	3
      0006EF 08                    1795 	.uleb128	8
      0006F0 49                    1796 	.uleb128	73
      0006F1 13                    1797 	.uleb128	19
      0006F2 00                    1798 	.uleb128	0
      0006F3 00                    1799 	.uleb128	0
      0006F4 09                    1800 	.uleb128	9
      0006F5 2E                    1801 	.uleb128	46
      0006F6 01                    1802 	.db	1
      0006F7 01                    1803 	.uleb128	1
      0006F8 13                    1804 	.uleb128	19
      0006F9 03                    1805 	.uleb128	3
      0006FA 08                    1806 	.uleb128	8
      0006FB 11                    1807 	.uleb128	17
      0006FC 01                    1808 	.uleb128	1
      0006FD 12                    1809 	.uleb128	18
      0006FE 01                    1810 	.uleb128	1
      0006FF 3F                    1811 	.uleb128	63
      000700 0C                    1812 	.uleb128	12
      000701 40                    1813 	.uleb128	64
      000702 06                    1814 	.uleb128	6
      000703 49                    1815 	.uleb128	73
      000704 13                    1816 	.uleb128	19
      000705 00                    1817 	.uleb128	0
      000706 00                    1818 	.uleb128	0
      000707 08                    1819 	.uleb128	8
      000708 0B                    1820 	.uleb128	11
      000709 01                    1821 	.db	1
      00070A 11                    1822 	.uleb128	17
      00070B 01                    1823 	.uleb128	1
      00070C 00                    1824 	.uleb128	0
      00070D 00                    1825 	.uleb128	0
      00070E 01                    1826 	.uleb128	1
      00070F 11                    1827 	.uleb128	17
      000710 01                    1828 	.db	1
      000711 03                    1829 	.uleb128	3
      000712 08                    1830 	.uleb128	8
      000713 10                    1831 	.uleb128	16
      000714 06                    1832 	.uleb128	6
      000715 13                    1833 	.uleb128	19
      000716 0B                    1834 	.uleb128	11
      000717 25                    1835 	.uleb128	37
      000718 08                    1836 	.uleb128	8
      000719 00                    1837 	.uleb128	0
      00071A 00                    1838 	.uleb128	0
      00071B 06                    1839 	.uleb128	6
      00071C 0B                    1840 	.uleb128	11
      00071D 00                    1841 	.db	0
      00071E 11                    1842 	.uleb128	17
      00071F 01                    1843 	.uleb128	1
      000720 12                    1844 	.uleb128	18
      000721 01                    1845 	.uleb128	1
      000722 00                    1846 	.uleb128	0
      000723 00                    1847 	.uleb128	0
      000724 07                    1848 	.uleb128	7
      000725 0B                    1849 	.uleb128	11
      000726 01                    1850 	.db	1
      000727 01                    1851 	.uleb128	1
      000728 13                    1852 	.uleb128	19
      000729 11                    1853 	.uleb128	17
      00072A 01                    1854 	.uleb128	1
      00072B 00                    1855 	.uleb128	0
      00072C 00                    1856 	.uleb128	0
      00072D 02                    1857 	.uleb128	2
      00072E 2E                    1858 	.uleb128	46
      00072F 00                    1859 	.db	0
      000730 03                    1860 	.uleb128	3
      000731 08                    1861 	.uleb128	8
      000732 11                    1862 	.uleb128	17
      000733 01                    1863 	.uleb128	1
      000734 12                    1864 	.uleb128	18
      000735 01                    1865 	.uleb128	1
      000736 3F                    1866 	.uleb128	63
      000737 0C                    1867 	.uleb128	12
      000738 40                    1868 	.uleb128	64
      000739 06                    1869 	.uleb128	6
      00073A 00                    1870 	.uleb128	0
      00073B 00                    1871 	.uleb128	0
      00073C 05                    1872 	.uleb128	5
      00073D 24                    1873 	.uleb128	36
      00073E 00                    1874 	.db	0
      00073F 03                    1875 	.uleb128	3
      000740 08                    1876 	.uleb128	8
      000741 0B                    1877 	.uleb128	11
      000742 0B                    1878 	.uleb128	11
      000743 3E                    1879 	.uleb128	62
      000744 0B                    1880 	.uleb128	11
      000745 00                    1881 	.uleb128	0
      000746 00                    1882 	.uleb128	0
      000747 00                    1883 	.uleb128	0
                                   1884 
                                   1885 	.area .debug_info (NOLOAD)
      003FE1 00 00 04 DF           1886 	.dw	0,Ldebug_info_end-Ldebug_info_start
      003FE5                       1887 Ldebug_info_start:
      003FE5 00 02                 1888 	.dw	2
      003FE7 00 00 06 BC           1889 	.dw	0,(Ldebug_abbrev)
      003FEB 04                    1890 	.db	4
      003FEC 01                    1891 	.uleb128	1
      003FED 2E 2E 2F 53 50 4C 2F  1892 	.ascii "../SPL/src/stm8s_adc2.c"
             73 72 63 2F 73 74 6D
             38 73 5F 61 64 63 32
             2E 63
      004004 00                    1893 	.db	0
      004005 00 00 29 0A           1894 	.dw	0,(Ldebug_line_start+-4)
      004009 01                    1895 	.db	1
      00400A 53 44 43 43 20 76 65  1896 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      004023 00                    1897 	.db	0
      004024 02                    1898 	.uleb128	2
      004025 41 44 43 32 5F 44 65  1899 	.ascii "ADC2_DeInit"
             49 6E 69 74
      004030 00                    1900 	.db	0
      004031 00 00 9C 87           1901 	.dw	0,(_ADC2_DeInit)
      004035 00 00 9C 9C           1902 	.dw	0,(XG$ADC2_DeInit$0$0+1)
      004039 01                    1903 	.db	1
      00403A 00 00 32 CC           1904 	.dw	0,(Ldebug_loc_start+548)
      00403E 03                    1905 	.uleb128	3
      00403F 00 00 01 57           1906 	.dw	0,343
      004043 41 44 43 32 5F 49 6E  1907 	.ascii "ADC2_Init"
             69 74
      00404C 00                    1908 	.db	0
      00404D 00 00 9C 9C           1909 	.dw	0,(_ADC2_Init)
      004051 00 00 9C CE           1910 	.dw	0,(XG$ADC2_Init$0$0+1)
      004055 01                    1911 	.db	1
      004056 00 00 32 28           1912 	.dw	0,(Ldebug_loc_start+384)
      00405A 04                    1913 	.uleb128	4
      00405B 02                    1914 	.db	2
      00405C 91                    1915 	.db	145
      00405D 02                    1916 	.sleb128	2
      00405E 41 44 43 32 5F 43 6F  1917 	.ascii "ADC2_ConversionMode"
             6E 76 65 72 73 69 6F
             6E 4D 6F 64 65
      004071 00                    1918 	.db	0
      004072 00 00 01 57           1919 	.dw	0,343
      004076 04                    1920 	.uleb128	4
      004077 02                    1921 	.db	2
      004078 91                    1922 	.db	145
      004079 03                    1923 	.sleb128	3
      00407A 41 44 43 32 5F 43 68  1924 	.ascii "ADC2_Channel"
             61 6E 6E 65 6C
      004086 00                    1925 	.db	0
      004087 00 00 01 57           1926 	.dw	0,343
      00408B 04                    1927 	.uleb128	4
      00408C 02                    1928 	.db	2
      00408D 91                    1929 	.db	145
      00408E 04                    1930 	.sleb128	4
      00408F 41 44 43 32 5F 50 72  1931 	.ascii "ADC2_PrescalerSelection"
             65 73 63 61 6C 65 72
             53 65 6C 65 63 74 69
             6F 6E
      0040A6 00                    1932 	.db	0
      0040A7 00 00 01 57           1933 	.dw	0,343
      0040AB 04                    1934 	.uleb128	4
      0040AC 02                    1935 	.db	2
      0040AD 91                    1936 	.db	145
      0040AE 05                    1937 	.sleb128	5
      0040AF 41 44 43 32 5F 45 78  1938 	.ascii "ADC2_ExtTrigger"
             74 54 72 69 67 67 65
             72
      0040BE 00                    1939 	.db	0
      0040BF 00 00 01 57           1940 	.dw	0,343
      0040C3 04                    1941 	.uleb128	4
      0040C4 02                    1942 	.db	2
      0040C5 91                    1943 	.db	145
      0040C6 06                    1944 	.sleb128	6
      0040C7 41 44 43 32 5F 45 78  1945 	.ascii "ADC2_ExtTriggerState"
             74 54 72 69 67 67 65
             72 53 74 61 74 65
      0040DB 00                    1946 	.db	0
      0040DC 00 00 01 57           1947 	.dw	0,343
      0040E0 04                    1948 	.uleb128	4
      0040E1 02                    1949 	.db	2
      0040E2 91                    1950 	.db	145
      0040E3 07                    1951 	.sleb128	7
      0040E4 41 44 43 32 5F 41 6C  1952 	.ascii "ADC2_Align"
             69 67 6E
      0040EE 00                    1953 	.db	0
      0040EF 00 00 01 57           1954 	.dw	0,343
      0040F3 04                    1955 	.uleb128	4
      0040F4 02                    1956 	.db	2
      0040F5 91                    1957 	.db	145
      0040F6 08                    1958 	.sleb128	8
      0040F7 41 44 43 32 5F 53 63  1959 	.ascii "ADC2_SchmittTriggerChannel"
             68 6D 69 74 74 54 72
             69 67 67 65 72 43 68
             61 6E 6E 65 6C
      004111 00                    1960 	.db	0
      004112 00 00 01 57           1961 	.dw	0,343
      004116 04                    1962 	.uleb128	4
      004117 02                    1963 	.db	2
      004118 91                    1964 	.db	145
      004119 09                    1965 	.sleb128	9
      00411A 41 44 43 32 5F 53 63  1966 	.ascii "ADC2_SchmittTriggerState"
             68 6D 69 74 74 54 72
             69 67 67 65 72 53 74
             61 74 65
      004132 00                    1967 	.db	0
      004133 00 00 01 57           1968 	.dw	0,343
      004137 00                    1969 	.uleb128	0
      004138 05                    1970 	.uleb128	5
      004139 75 6E 73 69 67 6E 65  1971 	.ascii "unsigned char"
             64 20 63 68 61 72
      004146 00                    1972 	.db	0
      004147 01                    1973 	.db	1
      004148 08                    1974 	.db	8
      004149 03                    1975 	.uleb128	3
      00414A 00 00 01 A7           1976 	.dw	0,423
      00414E 41 44 43 32 5F 43 6D  1977 	.ascii "ADC2_Cmd"
             64
      004156 00                    1978 	.db	0
      004157 00 00 9C CE           1979 	.dw	0,(_ADC2_Cmd)
      00415B 00 00 9C E6           1980 	.dw	0,(XG$ADC2_Cmd$0$0+1)
      00415F 01                    1981 	.db	1
      004160 00 00 32 14           1982 	.dw	0,(Ldebug_loc_start+364)
      004164 04                    1983 	.uleb128	4
      004165 02                    1984 	.db	2
      004166 91                    1985 	.db	145
      004167 02                    1986 	.sleb128	2
      004168 4E 65 77 53 74 61 74  1987 	.ascii "NewState"
             65
      004170 00                    1988 	.db	0
      004171 00 00 01 57           1989 	.dw	0,343
      004175 06                    1990 	.uleb128	6
      004176 00 00 9C D8           1991 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$36)
      00417A 00 00 9C DD           1992 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$38)
      00417E 06                    1993 	.uleb128	6
      00417F 00 00 9C E0           1994 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$39)
      004183 00 00 9C E5           1995 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$41)
      004187 00                    1996 	.uleb128	0
      004188 03                    1997 	.uleb128	3
      004189 00 00 01 EB           1998 	.dw	0,491
      00418D 41 44 43 32 5F 49 54  1999 	.ascii "ADC2_ITConfig"
             43 6F 6E 66 69 67
      00419A 00                    2000 	.db	0
      00419B 00 00 9C E6           2001 	.dw	0,(_ADC2_ITConfig)
      00419F 00 00 9C FE           2002 	.dw	0,(XG$ADC2_ITConfig$0$0+1)
      0041A3 01                    2003 	.db	1
      0041A4 00 00 32 00           2004 	.dw	0,(Ldebug_loc_start+344)
      0041A8 04                    2005 	.uleb128	4
      0041A9 02                    2006 	.db	2
      0041AA 91                    2007 	.db	145
      0041AB 02                    2008 	.sleb128	2
      0041AC 4E 65 77 53 74 61 74  2009 	.ascii "NewState"
             65
      0041B4 00                    2010 	.db	0
      0041B5 00 00 01 57           2011 	.dw	0,343
      0041B9 06                    2012 	.uleb128	6
      0041BA 00 00 9C F0           2013 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$49)
      0041BE 00 00 9C F5           2014 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$51)
      0041C2 06                    2015 	.uleb128	6
      0041C3 00 00 9C F8           2016 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$52)
      0041C7 00 00 9C FD           2017 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$54)
      0041CB 00                    2018 	.uleb128	0
      0041CC 03                    2019 	.uleb128	3
      0041CD 00 00 02 2A           2020 	.dw	0,554
      0041D1 41 44 43 32 5F 50 72  2021 	.ascii "ADC2_PrescalerConfig"
             65 73 63 61 6C 65 72
             43 6F 6E 66 69 67
      0041E5 00                    2022 	.db	0
      0041E6 00 00 9C FE           2023 	.dw	0,(_ADC2_PrescalerConfig)
      0041EA 00 00 9D 0F           2024 	.dw	0,(XG$ADC2_PrescalerConfig$0$0+1)
      0041EE 01                    2025 	.db	1
      0041EF 00 00 31 EC           2026 	.dw	0,(Ldebug_loc_start+324)
      0041F3 04                    2027 	.uleb128	4
      0041F4 02                    2028 	.db	2
      0041F5 91                    2029 	.db	145
      0041F6 02                    2030 	.sleb128	2
      0041F7 41 44 43 32 5F 50 72  2031 	.ascii "ADC2_Prescaler"
             65 73 63 61 6C 65 72
      004205 00                    2032 	.db	0
      004206 00 00 01 57           2033 	.dw	0,343
      00420A 00                    2034 	.uleb128	0
      00420B 03                    2035 	.uleb128	3
      00420C 00 00 02 DB           2036 	.dw	0,731
      004210 41 44 43 32 5F 53 63  2037 	.ascii "ADC2_SchmittTriggerConfig"
             68 6D 69 74 74 54 72
             69 67 67 65 72 43 6F
             6E 66 69 67
      004229 00                    2038 	.db	0
      00422A 00 00 9D 0F           2039 	.dw	0,(_ADC2_SchmittTriggerConfig)
      00422E 00 00 9D A3           2040 	.dw	0,(XG$ADC2_SchmittTriggerConfig$0$0+1)
      004232 01                    2041 	.db	1
      004233 00 00 31 84           2042 	.dw	0,(Ldebug_loc_start+220)
      004237 04                    2043 	.uleb128	4
      004238 02                    2044 	.db	2
      004239 91                    2045 	.db	145
      00423A 02                    2046 	.sleb128	2
      00423B 41 44 43 32 5F 53 63  2047 	.ascii "ADC2_SchmittTriggerChannel"
             68 6D 69 74 74 54 72
             69 67 67 65 72 43 68
             61 6E 6E 65 6C
      004255 00                    2048 	.db	0
      004256 00 00 01 57           2049 	.dw	0,343
      00425A 04                    2050 	.uleb128	4
      00425B 02                    2051 	.db	2
      00425C 91                    2052 	.db	145
      00425D 03                    2053 	.sleb128	3
      00425E 4E 65 77 53 74 61 74  2054 	.ascii "NewState"
             65
      004266 00                    2055 	.db	0
      004267 00 00 01 57           2056 	.dw	0,343
      00426B 07                    2057 	.uleb128	7
      00426C 00 00 02 A6           2058 	.dw	0,678
      004270 00 00 9D 1F           2059 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$71)
      004274 06                    2060 	.uleb128	6
      004275 00 00 9D 26           2061 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$73)
      004279 00 00 9D 31           2062 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$76)
      00427D 06                    2063 	.uleb128	6
      00427E 00 00 9D 34           2064 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$77)
      004282 00 00 9D 3F           2065 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$80)
      004286 00                    2066 	.uleb128	0
      004287 07                    2067 	.uleb128	7
      004288 00 00 02 C2           2068 	.dw	0,706
      00428C 00 00 9D 5D           2069 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$86)
      004290 06                    2070 	.uleb128	6
      004291 00 00 9D 64           2071 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$88)
      004295 00 00 9D 6A           2072 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$90)
      004299 06                    2073 	.uleb128	6
      00429A 00 00 9D 6D           2074 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$91)
      00429E 00 00 9D 72           2075 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$93)
      0042A2 00                    2076 	.uleb128	0
      0042A3 08                    2077 	.uleb128	8
      0042A4 00 00 9D 8C           2078 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$98)
      0042A8 06                    2079 	.uleb128	6
      0042A9 00 00 9D 93           2080 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$100)
      0042AD 00 00 9D 99           2081 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$102)
      0042B1 06                    2082 	.uleb128	6
      0042B2 00 00 9D 9C           2083 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$103)
      0042B6 00 00 9D A1           2084 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$105)
      0042BA 00                    2085 	.uleb128	0
      0042BB 00                    2086 	.uleb128	0
      0042BC 03                    2087 	.uleb128	3
      0042BD 00 00 03 5A           2088 	.dw	0,858
      0042C1 41 44 43 32 5F 43 6F  2089 	.ascii "ADC2_ConversionConfig"
             6E 76 65 72 73 69 6F
             6E 43 6F 6E 66 69 67
      0042D6 00                    2090 	.db	0
      0042D7 00 00 9D A3           2091 	.dw	0,(_ADC2_ConversionConfig)
      0042DB 00 00 9D E1           2092 	.dw	0,(XG$ADC2_ConversionConfig$0$0+1)
      0042DF 01                    2093 	.db	1
      0042E0 00 00 31 4C           2094 	.dw	0,(Ldebug_loc_start+164)
      0042E4 04                    2095 	.uleb128	4
      0042E5 02                    2096 	.db	2
      0042E6 91                    2097 	.db	145
      0042E7 02                    2098 	.sleb128	2
      0042E8 41 44 43 32 5F 43 6F  2099 	.ascii "ADC2_ConversionMode"
             6E 76 65 72 73 69 6F
             6E 4D 6F 64 65
      0042FB 00                    2100 	.db	0
      0042FC 00 00 01 57           2101 	.dw	0,343
      004300 04                    2102 	.uleb128	4
      004301 02                    2103 	.db	2
      004302 91                    2104 	.db	145
      004303 03                    2105 	.sleb128	3
      004304 41 44 43 32 5F 43 68  2106 	.ascii "ADC2_Channel"
             61 6E 6E 65 6C
      004310 00                    2107 	.db	0
      004311 00 00 01 57           2108 	.dw	0,343
      004315 04                    2109 	.uleb128	4
      004316 02                    2110 	.db	2
      004317 91                    2111 	.db	145
      004318 04                    2112 	.sleb128	4
      004319 41 44 43 32 5F 41 6C  2113 	.ascii "ADC2_Align"
             69 67 6E
      004323 00                    2114 	.db	0
      004324 00 00 01 57           2115 	.dw	0,343
      004328 06                    2116 	.uleb128	6
      004329 00 00 9D C3           2117 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$119)
      00432D 00 00 9D C8           2118 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$121)
      004331 06                    2119 	.uleb128	6
      004332 00 00 9D CB           2120 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$122)
      004336 00 00 9D D0           2121 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$124)
      00433A 00                    2122 	.uleb128	0
      00433B 03                    2123 	.uleb128	3
      00433C 00 00 03 C3           2124 	.dw	0,963
      004340 41 44 43 32 5F 45 78  2125 	.ascii "ADC2_ExternalTriggerConfig"
             74 65 72 6E 61 6C 54
             72 69 67 67 65 72 43
             6F 6E 66 69 67
      00435A 00                    2126 	.db	0
      00435B 00 00 9D E1           2127 	.dw	0,(_ADC2_ExternalTriggerConfig)
      00435F 00 00 9E 09           2128 	.dw	0,(XG$ADC2_ExternalTriggerConfig$0$0+1)
      004363 01                    2129 	.db	1
      004364 00 00 31 38           2130 	.dw	0,(Ldebug_loc_start+144)
      004368 04                    2131 	.uleb128	4
      004369 02                    2132 	.db	2
      00436A 91                    2133 	.db	145
      00436B 02                    2134 	.sleb128	2
      00436C 41 44 43 32 5F 45 78  2135 	.ascii "ADC2_ExtTrigger"
             74 54 72 69 67 67 65
             72
      00437B 00                    2136 	.db	0
      00437C 00 00 01 57           2137 	.dw	0,343
      004380 04                    2138 	.uleb128	4
      004381 02                    2139 	.db	2
      004382 91                    2140 	.db	145
      004383 03                    2141 	.sleb128	3
      004384 4E 65 77 53 74 61 74  2142 	.ascii "NewState"
             65
      00438C 00                    2143 	.db	0
      00438D 00 00 01 57           2144 	.dw	0,343
      004391 06                    2145 	.uleb128	6
      004392 00 00 9D F3           2146 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$134)
      004396 00 00 9D F8           2147 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$136)
      00439A 06                    2148 	.uleb128	6
      00439B 00 00 9D FB           2149 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$137)
      00439F 00 00 9E 00           2150 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$139)
      0043A3 00                    2151 	.uleb128	0
      0043A4 02                    2152 	.uleb128	2
      0043A5 41 44 43 32 5F 53 74  2153 	.ascii "ADC2_StartConversion"
             61 72 74 43 6F 6E 76
             65 72 73 69 6F 6E
      0043B9 00                    2154 	.db	0
      0043BA 00 00 9E 09           2155 	.dw	0,(_ADC2_StartConversion)
      0043BE 00 00 9E 12           2156 	.dw	0,(XG$ADC2_StartConversion$0$0+1)
      0043C2 01                    2157 	.db	1
      0043C3 00 00 31 24           2158 	.dw	0,(Ldebug_loc_start+124)
      0043C7 05                    2159 	.uleb128	5
      0043C8 75 6E 73 69 67 6E 65  2160 	.ascii "unsigned int"
             64 20 69 6E 74
      0043D4 00                    2161 	.db	0
      0043D5 02                    2162 	.db	2
      0043D6 07                    2163 	.db	7
      0043D7 09                    2164 	.uleb128	9
      0043D8 00 00 04 56           2165 	.dw	0,1110
      0043DC 41 44 43 32 5F 47 65  2166 	.ascii "ADC2_GetConversionValue"
             74 43 6F 6E 76 65 72
             73 69 6F 6E 56 61 6C
             75 65
      0043F3 00                    2167 	.db	0
      0043F4 00 00 9E 12           2168 	.dw	0,(_ADC2_GetConversionValue)
      0043F8 00 00 9E 5A           2169 	.dw	0,(XG$ADC2_GetConversionValue$0$0+1)
      0043FC 01                    2170 	.db	1
      0043FD 00 00 30 F8           2171 	.dw	0,(Ldebug_loc_start+80)
      004401 00 00 03 E6           2172 	.dw	0,998
      004405 06                    2173 	.uleb128	6
      004406 00 00 9E 1E           2174 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$154)
      00440A 00 00 9E 34           2175 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$158)
      00440E 06                    2176 	.uleb128	6
      00440F 00 00 9E 37           2177 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$159)
      004413 00 00 9E 55           2178 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$163)
      004417 0A                    2179 	.uleb128	10
      004418 06                    2180 	.db	6
      004419 54                    2181 	.db	84
      00441A 93                    2182 	.db	147
      00441B 01                    2183 	.uleb128	1
      00441C 53                    2184 	.db	83
      00441D 93                    2185 	.db	147
      00441E 01                    2186 	.uleb128	1
      00441F 74 65 6D 70 68        2187 	.ascii "temph"
      004424 00                    2188 	.db	0
      004425 00 00 03 E6           2189 	.dw	0,998
      004429 0A                    2190 	.uleb128	10
      00442A 01                    2191 	.db	1
      00442B 50                    2192 	.db	80
      00442C 74 65 6D 70 6C        2193 	.ascii "templ"
      004431 00                    2194 	.db	0
      004432 00 00 01 57           2195 	.dw	0,343
      004436 00                    2196 	.uleb128	0
      004437 0B                    2197 	.uleb128	11
      004438 41 44 43 32 5F 47 65  2198 	.ascii "ADC2_GetFlagStatus"
             74 46 6C 61 67 53 74
             61 74 75 73
      00444A 00                    2199 	.db	0
      00444B 00 00 9E 5A           2200 	.dw	0,(_ADC2_GetFlagStatus)
      00444F 00 00 9E 60           2201 	.dw	0,(XG$ADC2_GetFlagStatus$0$0+1)
      004453 01                    2202 	.db	1
      004454 00 00 30 E4           2203 	.dw	0,(Ldebug_loc_start+60)
      004458 00 00 01 57           2204 	.dw	0,343
      00445C 02                    2205 	.uleb128	2
      00445D 41 44 43 32 5F 43 6C  2206 	.ascii "ADC2_ClearFlag"
             65 61 72 46 6C 61 67
      00446B 00                    2207 	.db	0
      00446C 00 00 9E 60           2208 	.dw	0,(_ADC2_ClearFlag)
      004470 00 00 9E 69           2209 	.dw	0,(XG$ADC2_ClearFlag$0$0+1)
      004474 01                    2210 	.db	1
      004475 00 00 30 D0           2211 	.dw	0,(Ldebug_loc_start+40)
      004479 0B                    2212 	.uleb128	11
      00447A 41 44 43 32 5F 47 65  2213 	.ascii "ADC2_GetITStatus"
             74 49 54 53 74 61 74
             75 73
      00448A 00                    2214 	.db	0
      00448B 00 00 9E 69           2215 	.dw	0,(_ADC2_GetITStatus)
      00448F 00 00 9E 6F           2216 	.dw	0,(XG$ADC2_GetITStatus$0$0+1)
      004493 01                    2217 	.db	1
      004494 00 00 30 BC           2218 	.dw	0,(Ldebug_loc_start+20)
      004498 00 00 01 57           2219 	.dw	0,343
      00449C 02                    2220 	.uleb128	2
      00449D 41 44 43 32 5F 43 6C  2221 	.ascii "ADC2_ClearITPendingBit"
             65 61 72 49 54 50 65
             6E 64 69 6E 67 42 69
             74
      0044B3 00                    2222 	.db	0
      0044B4 00 00 9E 6F           2223 	.dw	0,(_ADC2_ClearITPendingBit)
      0044B8 00 00 9E 78           2224 	.dw	0,(XG$ADC2_ClearITPendingBit$0$0+1)
      0044BC 01                    2225 	.db	1
      0044BD 00 00 30 A8           2226 	.dw	0,(Ldebug_loc_start)
      0044C1 00                    2227 	.uleb128	0
      0044C2 00                    2228 	.uleb128	0
      0044C3 00                    2229 	.uleb128	0
      0044C4                       2230 Ldebug_info_end:
                                   2231 
                                   2232 	.area .debug_pubnames (NOLOAD)
      000D2A 00 00 01 4A           2233 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      000D2E                       2234 Ldebug_pubnames_start:
      000D2E 00 02                 2235 	.dw	2
      000D30 00 00 3F E1           2236 	.dw	0,(Ldebug_info_start-4)
      000D34 00 00 04 E3           2237 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      000D38 00 00 00 43           2238 	.dw	0,67
      000D3C 41 44 43 32 5F 44 65  2239 	.ascii "ADC2_DeInit"
             49 6E 69 74
      000D47 00                    2240 	.db	0
      000D48 00 00 00 5D           2241 	.dw	0,93
      000D4C 41 44 43 32 5F 49 6E  2242 	.ascii "ADC2_Init"
             69 74
      000D55 00                    2243 	.db	0
      000D56 00 00 01 68           2244 	.dw	0,360
      000D5A 41 44 43 32 5F 43 6D  2245 	.ascii "ADC2_Cmd"
             64
      000D62 00                    2246 	.db	0
      000D63 00 00 01 A7           2247 	.dw	0,423
      000D67 41 44 43 32 5F 49 54  2248 	.ascii "ADC2_ITConfig"
             43 6F 6E 66 69 67
      000D74 00                    2249 	.db	0
      000D75 00 00 01 EB           2250 	.dw	0,491
      000D79 41 44 43 32 5F 50 72  2251 	.ascii "ADC2_PrescalerConfig"
             65 73 63 61 6C 65 72
             43 6F 6E 66 69 67
      000D8D 00                    2252 	.db	0
      000D8E 00 00 02 2A           2253 	.dw	0,554
      000D92 41 44 43 32 5F 53 63  2254 	.ascii "ADC2_SchmittTriggerConfig"
             68 6D 69 74 74 54 72
             69 67 67 65 72 43 6F
             6E 66 69 67
      000DAB 00                    2255 	.db	0
      000DAC 00 00 02 DB           2256 	.dw	0,731
      000DB0 41 44 43 32 5F 43 6F  2257 	.ascii "ADC2_ConversionConfig"
             6E 76 65 72 73 69 6F
             6E 43 6F 6E 66 69 67
      000DC5 00                    2258 	.db	0
      000DC6 00 00 03 5A           2259 	.dw	0,858
      000DCA 41 44 43 32 5F 45 78  2260 	.ascii "ADC2_ExternalTriggerConfig"
             74 65 72 6E 61 6C 54
             72 69 67 67 65 72 43
             6F 6E 66 69 67
      000DE4 00                    2261 	.db	0
      000DE5 00 00 03 C3           2262 	.dw	0,963
      000DE9 41 44 43 32 5F 53 74  2263 	.ascii "ADC2_StartConversion"
             61 72 74 43 6F 6E 76
             65 72 73 69 6F 6E
      000DFD 00                    2264 	.db	0
      000DFE 00 00 03 F6           2265 	.dw	0,1014
      000E02 41 44 43 32 5F 47 65  2266 	.ascii "ADC2_GetConversionValue"
             74 43 6F 6E 76 65 72
             73 69 6F 6E 56 61 6C
             75 65
      000E19 00                    2267 	.db	0
      000E1A 00 00 04 56           2268 	.dw	0,1110
      000E1E 41 44 43 32 5F 47 65  2269 	.ascii "ADC2_GetFlagStatus"
             74 46 6C 61 67 53 74
             61 74 75 73
      000E30 00                    2270 	.db	0
      000E31 00 00 04 7B           2271 	.dw	0,1147
      000E35 41 44 43 32 5F 43 6C  2272 	.ascii "ADC2_ClearFlag"
             65 61 72 46 6C 61 67
      000E43 00                    2273 	.db	0
      000E44 00 00 04 98           2274 	.dw	0,1176
      000E48 41 44 43 32 5F 47 65  2275 	.ascii "ADC2_GetITStatus"
             74 49 54 53 74 61 74
             75 73
      000E58 00                    2276 	.db	0
      000E59 00 00 04 BB           2277 	.dw	0,1211
      000E5D 41 44 43 32 5F 43 6C  2278 	.ascii "ADC2_ClearITPendingBit"
             65 61 72 49 54 50 65
             6E 64 69 6E 67 42 69
             74
      000E73 00                    2279 	.db	0
      000E74 00 00 00 00           2280 	.dw	0,0
      000E78                       2281 Ldebug_pubnames_end:
                                   2282 
                                   2283 	.area .debug_frame (NOLOAD)
      002DEA 00 00                 2284 	.dw	0
      002DEC 00 0E                 2285 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      002DEE                       2286 Ldebug_CIE0_start:
      002DEE FF FF                 2287 	.dw	0xffff
      002DF0 FF FF                 2288 	.dw	0xffff
      002DF2 01                    2289 	.db	1
      002DF3 00                    2290 	.db	0
      002DF4 01                    2291 	.uleb128	1
      002DF5 7F                    2292 	.sleb128	-1
      002DF6 09                    2293 	.db	9
      002DF7 0C                    2294 	.db	12
      002DF8 08                    2295 	.uleb128	8
      002DF9 02                    2296 	.uleb128	2
      002DFA 89                    2297 	.db	137
      002DFB 01                    2298 	.uleb128	1
      002DFC                       2299 Ldebug_CIE0_end:
      002DFC 00 00 00 13           2300 	.dw	0,19
      002E00 00 00 2D EA           2301 	.dw	0,(Ldebug_CIE0_start-4)
      002E04 00 00 9E 6F           2302 	.dw	0,(Sstm8s_adc2$ADC2_ClearITPendingBit$188)	;initial loc
      002E08 00 00 00 09           2303 	.dw	0,Sstm8s_adc2$ADC2_ClearITPendingBit$192-Sstm8s_adc2$ADC2_ClearITPendingBit$188
      002E0C 01                    2304 	.db	1
      002E0D 00 00 9E 6F           2305 	.dw	0,(Sstm8s_adc2$ADC2_ClearITPendingBit$188)
      002E11 0E                    2306 	.db	14
      002E12 02                    2307 	.uleb128	2
                                   2308 
                                   2309 	.area .debug_frame (NOLOAD)
      002E13 00 00                 2310 	.dw	0
      002E15 00 0E                 2311 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      002E17                       2312 Ldebug_CIE1_start:
      002E17 FF FF                 2313 	.dw	0xffff
      002E19 FF FF                 2314 	.dw	0xffff
      002E1B 01                    2315 	.db	1
      002E1C 00                    2316 	.db	0
      002E1D 01                    2317 	.uleb128	1
      002E1E 7F                    2318 	.sleb128	-1
      002E1F 09                    2319 	.db	9
      002E20 0C                    2320 	.db	12
      002E21 08                    2321 	.uleb128	8
      002E22 02                    2322 	.uleb128	2
      002E23 89                    2323 	.db	137
      002E24 01                    2324 	.uleb128	1
      002E25                       2325 Ldebug_CIE1_end:
      002E25 00 00 00 13           2326 	.dw	0,19
      002E29 00 00 2E 13           2327 	.dw	0,(Ldebug_CIE1_start-4)
      002E2D 00 00 9E 69           2328 	.dw	0,(Sstm8s_adc2$ADC2_GetITStatus$182)	;initial loc
      002E31 00 00 00 06           2329 	.dw	0,Sstm8s_adc2$ADC2_GetITStatus$186-Sstm8s_adc2$ADC2_GetITStatus$182
      002E35 01                    2330 	.db	1
      002E36 00 00 9E 69           2331 	.dw	0,(Sstm8s_adc2$ADC2_GetITStatus$182)
      002E3A 0E                    2332 	.db	14
      002E3B 02                    2333 	.uleb128	2
                                   2334 
                                   2335 	.area .debug_frame (NOLOAD)
      002E3C 00 00                 2336 	.dw	0
      002E3E 00 0E                 2337 	.dw	Ldebug_CIE2_end-Ldebug_CIE2_start
      002E40                       2338 Ldebug_CIE2_start:
      002E40 FF FF                 2339 	.dw	0xffff
      002E42 FF FF                 2340 	.dw	0xffff
      002E44 01                    2341 	.db	1
      002E45 00                    2342 	.db	0
      002E46 01                    2343 	.uleb128	1
      002E47 7F                    2344 	.sleb128	-1
      002E48 09                    2345 	.db	9
      002E49 0C                    2346 	.db	12
      002E4A 08                    2347 	.uleb128	8
      002E4B 02                    2348 	.uleb128	2
      002E4C 89                    2349 	.db	137
      002E4D 01                    2350 	.uleb128	1
      002E4E                       2351 Ldebug_CIE2_end:
      002E4E 00 00 00 13           2352 	.dw	0,19
      002E52 00 00 2E 3C           2353 	.dw	0,(Ldebug_CIE2_start-4)
      002E56 00 00 9E 60           2354 	.dw	0,(Sstm8s_adc2$ADC2_ClearFlag$176)	;initial loc
      002E5A 00 00 00 09           2355 	.dw	0,Sstm8s_adc2$ADC2_ClearFlag$180-Sstm8s_adc2$ADC2_ClearFlag$176
      002E5E 01                    2356 	.db	1
      002E5F 00 00 9E 60           2357 	.dw	0,(Sstm8s_adc2$ADC2_ClearFlag$176)
      002E63 0E                    2358 	.db	14
      002E64 02                    2359 	.uleb128	2
                                   2360 
                                   2361 	.area .debug_frame (NOLOAD)
      002E65 00 00                 2362 	.dw	0
      002E67 00 0E                 2363 	.dw	Ldebug_CIE3_end-Ldebug_CIE3_start
      002E69                       2364 Ldebug_CIE3_start:
      002E69 FF FF                 2365 	.dw	0xffff
      002E6B FF FF                 2366 	.dw	0xffff
      002E6D 01                    2367 	.db	1
      002E6E 00                    2368 	.db	0
      002E6F 01                    2369 	.uleb128	1
      002E70 7F                    2370 	.sleb128	-1
      002E71 09                    2371 	.db	9
      002E72 0C                    2372 	.db	12
      002E73 08                    2373 	.uleb128	8
      002E74 02                    2374 	.uleb128	2
      002E75 89                    2375 	.db	137
      002E76 01                    2376 	.uleb128	1
      002E77                       2377 Ldebug_CIE3_end:
      002E77 00 00 00 13           2378 	.dw	0,19
      002E7B 00 00 2E 65           2379 	.dw	0,(Ldebug_CIE3_start-4)
      002E7F 00 00 9E 5A           2380 	.dw	0,(Sstm8s_adc2$ADC2_GetFlagStatus$170)	;initial loc
      002E83 00 00 00 06           2381 	.dw	0,Sstm8s_adc2$ADC2_GetFlagStatus$174-Sstm8s_adc2$ADC2_GetFlagStatus$170
      002E87 01                    2382 	.db	1
      002E88 00 00 9E 5A           2383 	.dw	0,(Sstm8s_adc2$ADC2_GetFlagStatus$170)
      002E8C 0E                    2384 	.db	14
      002E8D 02                    2385 	.uleb128	2
                                   2386 
                                   2387 	.area .debug_frame (NOLOAD)
      002E8E 00 00                 2388 	.dw	0
      002E90 00 0E                 2389 	.dw	Ldebug_CIE4_end-Ldebug_CIE4_start
      002E92                       2390 Ldebug_CIE4_start:
      002E92 FF FF                 2391 	.dw	0xffff
      002E94 FF FF                 2392 	.dw	0xffff
      002E96 01                    2393 	.db	1
      002E97 00                    2394 	.db	0
      002E98 01                    2395 	.uleb128	1
      002E99 7F                    2396 	.sleb128	-1
      002E9A 09                    2397 	.db	9
      002E9B 0C                    2398 	.db	12
      002E9C 08                    2399 	.uleb128	8
      002E9D 02                    2400 	.uleb128	2
      002E9E 89                    2401 	.db	137
      002E9F 01                    2402 	.uleb128	1
      002EA0                       2403 Ldebug_CIE4_end:
      002EA0 00 00 00 21           2404 	.dw	0,33
      002EA4 00 00 2E 8E           2405 	.dw	0,(Ldebug_CIE4_start-4)
      002EA8 00 00 9E 12           2406 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$151)	;initial loc
      002EAC 00 00 00 48           2407 	.dw	0,Sstm8s_adc2$ADC2_GetConversionValue$168-Sstm8s_adc2$ADC2_GetConversionValue$151
      002EB0 01                    2408 	.db	1
      002EB1 00 00 9E 12           2409 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$151)
      002EB5 0E                    2410 	.db	14
      002EB6 02                    2411 	.uleb128	2
      002EB7 01                    2412 	.db	1
      002EB8 00 00 9E 14           2413 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$152)
      002EBC 0E                    2414 	.db	14
      002EBD 06                    2415 	.uleb128	6
      002EBE 01                    2416 	.db	1
      002EBF 00 00 9E 59           2417 	.dw	0,(Sstm8s_adc2$ADC2_GetConversionValue$166)
      002EC3 0E                    2418 	.db	14
      002EC4 02                    2419 	.uleb128	2
                                   2420 
                                   2421 	.area .debug_frame (NOLOAD)
      002EC5 00 00                 2422 	.dw	0
      002EC7 00 0E                 2423 	.dw	Ldebug_CIE5_end-Ldebug_CIE5_start
      002EC9                       2424 Ldebug_CIE5_start:
      002EC9 FF FF                 2425 	.dw	0xffff
      002ECB FF FF                 2426 	.dw	0xffff
      002ECD 01                    2427 	.db	1
      002ECE 00                    2428 	.db	0
      002ECF 01                    2429 	.uleb128	1
      002ED0 7F                    2430 	.sleb128	-1
      002ED1 09                    2431 	.db	9
      002ED2 0C                    2432 	.db	12
      002ED3 08                    2433 	.uleb128	8
      002ED4 02                    2434 	.uleb128	2
      002ED5 89                    2435 	.db	137
      002ED6 01                    2436 	.uleb128	1
      002ED7                       2437 Ldebug_CIE5_end:
      002ED7 00 00 00 13           2438 	.dw	0,19
      002EDB 00 00 2E C5           2439 	.dw	0,(Ldebug_CIE5_start-4)
      002EDF 00 00 9E 09           2440 	.dw	0,(Sstm8s_adc2$ADC2_StartConversion$145)	;initial loc
      002EE3 00 00 00 09           2441 	.dw	0,Sstm8s_adc2$ADC2_StartConversion$149-Sstm8s_adc2$ADC2_StartConversion$145
      002EE7 01                    2442 	.db	1
      002EE8 00 00 9E 09           2443 	.dw	0,(Sstm8s_adc2$ADC2_StartConversion$145)
      002EEC 0E                    2444 	.db	14
      002EED 02                    2445 	.uleb128	2
                                   2446 
                                   2447 	.area .debug_frame (NOLOAD)
      002EEE 00 00                 2448 	.dw	0
      002EF0 00 0E                 2449 	.dw	Ldebug_CIE6_end-Ldebug_CIE6_start
      002EF2                       2450 Ldebug_CIE6_start:
      002EF2 FF FF                 2451 	.dw	0xffff
      002EF4 FF FF                 2452 	.dw	0xffff
      002EF6 01                    2453 	.db	1
      002EF7 00                    2454 	.db	0
      002EF8 01                    2455 	.uleb128	1
      002EF9 7F                    2456 	.sleb128	-1
      002EFA 09                    2457 	.db	9
      002EFB 0C                    2458 	.db	12
      002EFC 08                    2459 	.uleb128	8
      002EFD 02                    2460 	.uleb128	2
      002EFE 89                    2461 	.db	137
      002EFF 01                    2462 	.uleb128	1
      002F00                       2463 Ldebug_CIE6_end:
      002F00 00 00 00 13           2464 	.dw	0,19
      002F04 00 00 2E EE           2465 	.dw	0,(Ldebug_CIE6_start-4)
      002F08 00 00 9D E1           2466 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$131)	;initial loc
      002F0C 00 00 00 28           2467 	.dw	0,Sstm8s_adc2$ADC2_ExternalTriggerConfig$143-Sstm8s_adc2$ADC2_ExternalTriggerConfig$131
      002F10 01                    2468 	.db	1
      002F11 00 00 9D E1           2469 	.dw	0,(Sstm8s_adc2$ADC2_ExternalTriggerConfig$131)
      002F15 0E                    2470 	.db	14
      002F16 02                    2471 	.uleb128	2
                                   2472 
                                   2473 	.area .debug_frame (NOLOAD)
      002F17 00 00                 2474 	.dw	0
      002F19 00 0E                 2475 	.dw	Ldebug_CIE7_end-Ldebug_CIE7_start
      002F1B                       2476 Ldebug_CIE7_start:
      002F1B FF FF                 2477 	.dw	0xffff
      002F1D FF FF                 2478 	.dw	0xffff
      002F1F 01                    2479 	.db	1
      002F20 00                    2480 	.db	0
      002F21 01                    2481 	.uleb128	1
      002F22 7F                    2482 	.sleb128	-1
      002F23 09                    2483 	.db	9
      002F24 0C                    2484 	.db	12
      002F25 08                    2485 	.uleb128	8
      002F26 02                    2486 	.uleb128	2
      002F27 89                    2487 	.db	137
      002F28 01                    2488 	.uleb128	1
      002F29                       2489 Ldebug_CIE7_end:
      002F29 00 00 00 28           2490 	.dw	0,40
      002F2D 00 00 2F 17           2491 	.dw	0,(Ldebug_CIE7_start-4)
      002F31 00 00 9D A3           2492 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$111)	;initial loc
      002F35 00 00 00 3E           2493 	.dw	0,Sstm8s_adc2$ADC2_ConversionConfig$129-Sstm8s_adc2$ADC2_ConversionConfig$111
      002F39 01                    2494 	.db	1
      002F3A 00 00 9D A3           2495 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$111)
      002F3E 0E                    2496 	.db	14
      002F3F 02                    2497 	.uleb128	2
      002F40 01                    2498 	.db	1
      002F41 00 00 9D B7           2499 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$116)
      002F45 0E                    2500 	.db	14
      002F46 03                    2501 	.uleb128	3
      002F47 01                    2502 	.db	1
      002F48 00 00 9D BB           2503 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$117)
      002F4C 0E                    2504 	.db	14
      002F4D 02                    2505 	.uleb128	2
      002F4E 01                    2506 	.db	1
      002F4F 00 00 9D C3           2507 	.dw	0,(Sstm8s_adc2$ADC2_ConversionConfig$118)
      002F53 0E                    2508 	.db	14
      002F54 02                    2509 	.uleb128	2
                                   2510 
                                   2511 	.area .debug_frame (NOLOAD)
      002F55 00 00                 2512 	.dw	0
      002F57 00 0E                 2513 	.dw	Ldebug_CIE8_end-Ldebug_CIE8_start
      002F59                       2514 Ldebug_CIE8_start:
      002F59 FF FF                 2515 	.dw	0xffff
      002F5B FF FF                 2516 	.dw	0xffff
      002F5D 01                    2517 	.db	1
      002F5E 00                    2518 	.db	0
      002F5F 01                    2519 	.uleb128	1
      002F60 7F                    2520 	.sleb128	-1
      002F61 09                    2521 	.db	9
      002F62 0C                    2522 	.db	12
      002F63 08                    2523 	.uleb128	8
      002F64 02                    2524 	.uleb128	2
      002F65 89                    2525 	.db	137
      002F66 01                    2526 	.uleb128	1
      002F67                       2527 Ldebug_CIE8_end:
      002F67 00 00 00 44           2528 	.dw	0,68
      002F6B 00 00 2F 55           2529 	.dw	0,(Ldebug_CIE8_start-4)
      002F6F 00 00 9D 0F           2530 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$66)	;initial loc
      002F73 00 00 00 94           2531 	.dw	0,Sstm8s_adc2$ADC2_SchmittTriggerConfig$109-Sstm8s_adc2$ADC2_SchmittTriggerConfig$66
      002F77 01                    2532 	.db	1
      002F78 00 00 9D 0F           2533 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$66)
      002F7C 0E                    2534 	.db	14
      002F7D 02                    2535 	.uleb128	2
      002F7E 01                    2536 	.db	1
      002F7F 00 00 9D 10           2537 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$67)
      002F83 0E                    2538 	.db	14
      002F84 03                    2539 	.uleb128	3
      002F85 01                    2540 	.db	1
      002F86 00 00 9D 1C           2541 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$69)
      002F8A 0E                    2542 	.db	14
      002F8B 03                    2543 	.uleb128	3
      002F8C 01                    2544 	.db	1
      002F8D 00 00 9D 53           2545 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$84)
      002F91 0E                    2546 	.db	14
      002F92 04                    2547 	.uleb128	4
      002F93 01                    2548 	.db	1
      002F94 00 00 9D 5D           2549 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$85)
      002F98 0E                    2550 	.db	14
      002F99 03                    2551 	.uleb128	3
      002F9A 01                    2552 	.db	1
      002F9B 00 00 9D 82           2553 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$96)
      002F9F 0E                    2554 	.db	14
      002FA0 04                    2555 	.uleb128	4
      002FA1 01                    2556 	.db	1
      002FA2 00 00 9D 8C           2557 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$97)
      002FA6 0E                    2558 	.db	14
      002FA7 03                    2559 	.uleb128	3
      002FA8 01                    2560 	.db	1
      002FA9 00 00 9D A2           2561 	.dw	0,(Sstm8s_adc2$ADC2_SchmittTriggerConfig$107)
      002FAD 0E                    2562 	.db	14
      002FAE 02                    2563 	.uleb128	2
                                   2564 
                                   2565 	.area .debug_frame (NOLOAD)
      002FAF 00 00                 2566 	.dw	0
      002FB1 00 0E                 2567 	.dw	Ldebug_CIE9_end-Ldebug_CIE9_start
      002FB3                       2568 Ldebug_CIE9_start:
      002FB3 FF FF                 2569 	.dw	0xffff
      002FB5 FF FF                 2570 	.dw	0xffff
      002FB7 01                    2571 	.db	1
      002FB8 00                    2572 	.db	0
      002FB9 01                    2573 	.uleb128	1
      002FBA 7F                    2574 	.sleb128	-1
      002FBB 09                    2575 	.db	9
      002FBC 0C                    2576 	.db	12
      002FBD 08                    2577 	.uleb128	8
      002FBE 02                    2578 	.uleb128	2
      002FBF 89                    2579 	.db	137
      002FC0 01                    2580 	.uleb128	1
      002FC1                       2581 Ldebug_CIE9_end:
      002FC1 00 00 00 13           2582 	.dw	0,19
      002FC5 00 00 2F AF           2583 	.dw	0,(Ldebug_CIE9_start-4)
      002FC9 00 00 9C FE           2584 	.dw	0,(Sstm8s_adc2$ADC2_PrescalerConfig$59)	;initial loc
      002FCD 00 00 00 11           2585 	.dw	0,Sstm8s_adc2$ADC2_PrescalerConfig$64-Sstm8s_adc2$ADC2_PrescalerConfig$59
      002FD1 01                    2586 	.db	1
      002FD2 00 00 9C FE           2587 	.dw	0,(Sstm8s_adc2$ADC2_PrescalerConfig$59)
      002FD6 0E                    2588 	.db	14
      002FD7 02                    2589 	.uleb128	2
                                   2590 
                                   2591 	.area .debug_frame (NOLOAD)
      002FD8 00 00                 2592 	.dw	0
      002FDA 00 0E                 2593 	.dw	Ldebug_CIE10_end-Ldebug_CIE10_start
      002FDC                       2594 Ldebug_CIE10_start:
      002FDC FF FF                 2595 	.dw	0xffff
      002FDE FF FF                 2596 	.dw	0xffff
      002FE0 01                    2597 	.db	1
      002FE1 00                    2598 	.db	0
      002FE2 01                    2599 	.uleb128	1
      002FE3 7F                    2600 	.sleb128	-1
      002FE4 09                    2601 	.db	9
      002FE5 0C                    2602 	.db	12
      002FE6 08                    2603 	.uleb128	8
      002FE7 02                    2604 	.uleb128	2
      002FE8 89                    2605 	.db	137
      002FE9 01                    2606 	.uleb128	1
      002FEA                       2607 Ldebug_CIE10_end:
      002FEA 00 00 00 13           2608 	.dw	0,19
      002FEE 00 00 2F D8           2609 	.dw	0,(Ldebug_CIE10_start-4)
      002FF2 00 00 9C E6           2610 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$46)	;initial loc
      002FF6 00 00 00 18           2611 	.dw	0,Sstm8s_adc2$ADC2_ITConfig$57-Sstm8s_adc2$ADC2_ITConfig$46
      002FFA 01                    2612 	.db	1
      002FFB 00 00 9C E6           2613 	.dw	0,(Sstm8s_adc2$ADC2_ITConfig$46)
      002FFF 0E                    2614 	.db	14
      003000 02                    2615 	.uleb128	2
                                   2616 
                                   2617 	.area .debug_frame (NOLOAD)
      003001 00 00                 2618 	.dw	0
      003003 00 0E                 2619 	.dw	Ldebug_CIE11_end-Ldebug_CIE11_start
      003005                       2620 Ldebug_CIE11_start:
      003005 FF FF                 2621 	.dw	0xffff
      003007 FF FF                 2622 	.dw	0xffff
      003009 01                    2623 	.db	1
      00300A 00                    2624 	.db	0
      00300B 01                    2625 	.uleb128	1
      00300C 7F                    2626 	.sleb128	-1
      00300D 09                    2627 	.db	9
      00300E 0C                    2628 	.db	12
      00300F 08                    2629 	.uleb128	8
      003010 02                    2630 	.uleb128	2
      003011 89                    2631 	.db	137
      003012 01                    2632 	.uleb128	1
      003013                       2633 Ldebug_CIE11_end:
      003013 00 00 00 13           2634 	.dw	0,19
      003017 00 00 30 01           2635 	.dw	0,(Ldebug_CIE11_start-4)
      00301B 00 00 9C CE           2636 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$33)	;initial loc
      00301F 00 00 00 18           2637 	.dw	0,Sstm8s_adc2$ADC2_Cmd$44-Sstm8s_adc2$ADC2_Cmd$33
      003023 01                    2638 	.db	1
      003024 00 00 9C CE           2639 	.dw	0,(Sstm8s_adc2$ADC2_Cmd$33)
      003028 0E                    2640 	.db	14
      003029 02                    2641 	.uleb128	2
                                   2642 
                                   2643 	.area .debug_frame (NOLOAD)
      00302A 00 00                 2644 	.dw	0
      00302C 00 0E                 2645 	.dw	Ldebug_CIE12_end-Ldebug_CIE12_start
      00302E                       2646 Ldebug_CIE12_start:
      00302E FF FF                 2647 	.dw	0xffff
      003030 FF FF                 2648 	.dw	0xffff
      003032 01                    2649 	.db	1
      003033 00                    2650 	.db	0
      003034 01                    2651 	.uleb128	1
      003035 7F                    2652 	.sleb128	-1
      003036 09                    2653 	.db	9
      003037 0C                    2654 	.db	12
      003038 08                    2655 	.uleb128	8
      003039 02                    2656 	.uleb128	2
      00303A 89                    2657 	.db	137
      00303B 01                    2658 	.uleb128	1
      00303C                       2659 Ldebug_CIE12_end:
      00303C 00 00 00 67           2660 	.dw	0,103
      003040 00 00 30 2A           2661 	.dw	0,(Ldebug_CIE12_start-4)
      003044 00 00 9C 9C           2662 	.dw	0,(Sstm8s_adc2$ADC2_Init$11)	;initial loc
      003048 00 00 00 32           2663 	.dw	0,Sstm8s_adc2$ADC2_Init$31-Sstm8s_adc2$ADC2_Init$11
      00304C 01                    2664 	.db	1
      00304D 00 00 9C 9C           2665 	.dw	0,(Sstm8s_adc2$ADC2_Init$11)
      003051 0E                    2666 	.db	14
      003052 02                    2667 	.uleb128	2
      003053 01                    2668 	.db	1
      003054 00 00 9C 9F           2669 	.dw	0,(Sstm8s_adc2$ADC2_Init$13)
      003058 0E                    2670 	.db	14
      003059 03                    2671 	.uleb128	3
      00305A 01                    2672 	.db	1
      00305B 00 00 9C A2           2673 	.dw	0,(Sstm8s_adc2$ADC2_Init$14)
      00305F 0E                    2674 	.db	14
      003060 04                    2675 	.uleb128	4
      003061 01                    2676 	.db	1
      003062 00 00 9C A5           2677 	.dw	0,(Sstm8s_adc2$ADC2_Init$15)
      003066 0E                    2678 	.db	14
      003067 05                    2679 	.uleb128	5
      003068 01                    2680 	.db	1
      003069 00 00 9C AA           2681 	.dw	0,(Sstm8s_adc2$ADC2_Init$16)
      00306D 0E                    2682 	.db	14
      00306E 02                    2683 	.uleb128	2
      00306F 01                    2684 	.db	1
      003070 00 00 9C AD           2685 	.dw	0,(Sstm8s_adc2$ADC2_Init$18)
      003074 0E                    2686 	.db	14
      003075 03                    2687 	.uleb128	3
      003076 01                    2688 	.db	1
      003077 00 00 9C B1           2689 	.dw	0,(Sstm8s_adc2$ADC2_Init$19)
      00307B 0E                    2690 	.db	14
      00307C 02                    2691 	.uleb128	2
      00307D 01                    2692 	.db	1
      00307E 00 00 9C B4           2693 	.dw	0,(Sstm8s_adc2$ADC2_Init$21)
      003082 0E                    2694 	.db	14
      003083 03                    2695 	.uleb128	3
      003084 01                    2696 	.db	1
      003085 00 00 9C B7           2697 	.dw	0,(Sstm8s_adc2$ADC2_Init$22)
      003089 0E                    2698 	.db	14
      00308A 04                    2699 	.uleb128	4
      00308B 01                    2700 	.db	1
      00308C 00 00 9C BB           2701 	.dw	0,(Sstm8s_adc2$ADC2_Init$23)
      003090 0E                    2702 	.db	14
      003091 02                    2703 	.uleb128	2
      003092 01                    2704 	.db	1
      003093 00 00 9C BE           2705 	.dw	0,(Sstm8s_adc2$ADC2_Init$25)
      003097 0E                    2706 	.db	14
      003098 03                    2707 	.uleb128	3
      003099 01                    2708 	.db	1
      00309A 00 00 9C C1           2709 	.dw	0,(Sstm8s_adc2$ADC2_Init$26)
      00309E 0E                    2710 	.db	14
      00309F 04                    2711 	.uleb128	4
      0030A0 01                    2712 	.db	1
      0030A1 00 00 9C C5           2713 	.dw	0,(Sstm8s_adc2$ADC2_Init$27)
      0030A5 0E                    2714 	.db	14
      0030A6 02                    2715 	.uleb128	2
                                   2716 
                                   2717 	.area .debug_frame (NOLOAD)
      0030A7 00 00                 2718 	.dw	0
      0030A9 00 0E                 2719 	.dw	Ldebug_CIE13_end-Ldebug_CIE13_start
      0030AB                       2720 Ldebug_CIE13_start:
      0030AB FF FF                 2721 	.dw	0xffff
      0030AD FF FF                 2722 	.dw	0xffff
      0030AF 01                    2723 	.db	1
      0030B0 00                    2724 	.db	0
      0030B1 01                    2725 	.uleb128	1
      0030B2 7F                    2726 	.sleb128	-1
      0030B3 09                    2727 	.db	9
      0030B4 0C                    2728 	.db	12
      0030B5 08                    2729 	.uleb128	8
      0030B6 02                    2730 	.uleb128	2
      0030B7 89                    2731 	.db	137
      0030B8 01                    2732 	.uleb128	1
      0030B9                       2733 Ldebug_CIE13_end:
      0030B9 00 00 00 13           2734 	.dw	0,19
      0030BD 00 00 30 A7           2735 	.dw	0,(Ldebug_CIE13_start-4)
      0030C1 00 00 9C 87           2736 	.dw	0,(Sstm8s_adc2$ADC2_DeInit$1)	;initial loc
      0030C5 00 00 00 15           2737 	.dw	0,Sstm8s_adc2$ADC2_DeInit$9-Sstm8s_adc2$ADC2_DeInit$1
      0030C9 01                    2738 	.db	1
      0030CA 00 00 9C 87           2739 	.dw	0,(Sstm8s_adc2$ADC2_DeInit$1)
      0030CE 0E                    2740 	.db	14
      0030CF 02                    2741 	.uleb128	2
