                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ANSI-C Compiler
                                      3 ; Version 4.1.0 #12072 (MINGW64)
                                      4 ;--------------------------------------------------------
                                      5 	.module stm8s_clk
                                      6 	.optsdcc -mstm8
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _CLKPrescTable
                                     12 	.globl _HSIDivFactor
                                     13 	.globl _CLK_DeInit
                                     14 	.globl _CLK_FastHaltWakeUpCmd
                                     15 	.globl _CLK_HSECmd
                                     16 	.globl _CLK_HSICmd
                                     17 	.globl _CLK_LSICmd
                                     18 	.globl _CLK_CCOCmd
                                     19 	.globl _CLK_ClockSwitchCmd
                                     20 	.globl _CLK_SlowActiveHaltWakeUpCmd
                                     21 	.globl _CLK_PeripheralClockConfig
                                     22 	.globl _CLK_ClockSwitchConfig
                                     23 	.globl _CLK_HSIPrescalerConfig
                                     24 	.globl _CLK_CCOConfig
                                     25 	.globl _CLK_ITConfig
                                     26 	.globl _CLK_SYSCLKConfig
                                     27 	.globl _CLK_SWIMConfig
                                     28 	.globl _CLK_ClockSecuritySystemEnable
                                     29 	.globl _CLK_GetSYSCLKSource
                                     30 	.globl _CLK_GetClockFreq
                                     31 	.globl _CLK_AdjustHSICalibrationValue
                                     32 	.globl _CLK_SYSCLKEmergencyClear
                                     33 	.globl _CLK_GetFlagStatus
                                     34 	.globl _CLK_GetITStatus
                                     35 	.globl _CLK_ClearITPendingBit
                                     36 ;--------------------------------------------------------
                                     37 ; ram data
                                     38 ;--------------------------------------------------------
                                     39 	.area DATA
                                     40 ;--------------------------------------------------------
                                     41 ; ram data
                                     42 ;--------------------------------------------------------
                                     43 	.area INITIALIZED
                                     44 ;--------------------------------------------------------
                                     45 ; absolute external ram data
                                     46 ;--------------------------------------------------------
                                     47 	.area DABS (ABS)
                                     48 
                                     49 ; default segment ordering for linker
                                     50 	.area HOME
                                     51 	.area GSINIT
                                     52 	.area GSFINAL
                                     53 	.area CONST
                                     54 	.area INITIALIZER
                                     55 	.area CODE
                                     56 
                                     57 ;--------------------------------------------------------
                                     58 ; global & static initialisations
                                     59 ;--------------------------------------------------------
                                     60 	.area HOME
                                     61 	.area GSINIT
                                     62 	.area GSFINAL
                                     63 	.area GSINIT
                                     64 ;--------------------------------------------------------
                                     65 ; Home
                                     66 ;--------------------------------------------------------
                                     67 	.area HOME
                                     68 	.area HOME
                                     69 ;--------------------------------------------------------
                                     70 ; code
                                     71 ;--------------------------------------------------------
                                     72 	.area CODE
                           000000    73 	Sstm8s_clk$CLK_DeInit$0 ==.
                                     74 ;	../SPL/src/stm8s_clk.c: 72: void CLK_DeInit(void)
                                     75 ; genLabel
                                     76 ;	-----------------------------------------
                                     77 ;	 function CLK_DeInit
                                     78 ;	-----------------------------------------
                                     79 ;	Register assignment is optimal.
                                     80 ;	Stack space usage: 0 bytes.
      009055                         81 _CLK_DeInit:
                           000000    82 	Sstm8s_clk$CLK_DeInit$1 ==.
                           000000    83 	Sstm8s_clk$CLK_DeInit$2 ==.
                                     84 ;	../SPL/src/stm8s_clk.c: 74: CLK->ICKR = CLK_ICKR_RESET_VALUE;
                                     85 ; genPointerSet
      009055 35 01 50 C0      [ 1]   86 	mov	0x50c0+0, #0x01
                           000004    87 	Sstm8s_clk$CLK_DeInit$3 ==.
                                     88 ;	../SPL/src/stm8s_clk.c: 75: CLK->ECKR = CLK_ECKR_RESET_VALUE;
                                     89 ; genPointerSet
      009059 35 00 50 C1      [ 1]   90 	mov	0x50c1+0, #0x00
                           000008    91 	Sstm8s_clk$CLK_DeInit$4 ==.
                                     92 ;	../SPL/src/stm8s_clk.c: 76: CLK->SWR  = CLK_SWR_RESET_VALUE;
                                     93 ; genPointerSet
      00905D 35 E1 50 C4      [ 1]   94 	mov	0x50c4+0, #0xe1
                           00000C    95 	Sstm8s_clk$CLK_DeInit$5 ==.
                                     96 ;	../SPL/src/stm8s_clk.c: 77: CLK->SWCR = CLK_SWCR_RESET_VALUE;
                                     97 ; genPointerSet
      009061 35 00 50 C5      [ 1]   98 	mov	0x50c5+0, #0x00
                           000010    99 	Sstm8s_clk$CLK_DeInit$6 ==.
                                    100 ;	../SPL/src/stm8s_clk.c: 78: CLK->CKDIVR = CLK_CKDIVR_RESET_VALUE;
                                    101 ; genPointerSet
      009065 35 18 50 C6      [ 1]  102 	mov	0x50c6+0, #0x18
                           000014   103 	Sstm8s_clk$CLK_DeInit$7 ==.
                                    104 ;	../SPL/src/stm8s_clk.c: 79: CLK->PCKENR1 = CLK_PCKENR1_RESET_VALUE;
                                    105 ; genPointerSet
      009069 35 FF 50 C7      [ 1]  106 	mov	0x50c7+0, #0xff
                           000018   107 	Sstm8s_clk$CLK_DeInit$8 ==.
                                    108 ;	../SPL/src/stm8s_clk.c: 80: CLK->PCKENR2 = CLK_PCKENR2_RESET_VALUE;
                                    109 ; genPointerSet
      00906D 35 FF 50 CA      [ 1]  110 	mov	0x50ca+0, #0xff
                           00001C   111 	Sstm8s_clk$CLK_DeInit$9 ==.
                                    112 ;	../SPL/src/stm8s_clk.c: 81: CLK->CSSR = CLK_CSSR_RESET_VALUE;
                                    113 ; genPointerSet
      009071 35 00 50 C8      [ 1]  114 	mov	0x50c8+0, #0x00
                           000020   115 	Sstm8s_clk$CLK_DeInit$10 ==.
                                    116 ;	../SPL/src/stm8s_clk.c: 82: CLK->CCOR = CLK_CCOR_RESET_VALUE;
                                    117 ; genPointerSet
      009075 35 00 50 C9      [ 1]  118 	mov	0x50c9+0, #0x00
                           000024   119 	Sstm8s_clk$CLK_DeInit$11 ==.
                                    120 ;	../SPL/src/stm8s_clk.c: 83: while ((CLK->CCOR & CLK_CCOR_CCOEN)!= 0)
                                    121 ; genLabel
      009079                        122 00101$:
                                    123 ; genPointerGet
      009079 C6 50 C9         [ 1]  124 	ld	a, 0x50c9
                                    125 ; genAnd
      00907C 44               [ 1]  126 	srl	a
      00907D 24 03            [ 1]  127 	jrnc	00116$
      00907F CC 90 79         [ 2]  128 	jp	00101$
      009082                        129 00116$:
                                    130 ; skipping generated iCode
                           00002D   131 	Sstm8s_clk$CLK_DeInit$12 ==.
                                    132 ;	../SPL/src/stm8s_clk.c: 85: CLK->CCOR = CLK_CCOR_RESET_VALUE;
                                    133 ; genPointerSet
      009082 35 00 50 C9      [ 1]  134 	mov	0x50c9+0, #0x00
                           000031   135 	Sstm8s_clk$CLK_DeInit$13 ==.
                                    136 ;	../SPL/src/stm8s_clk.c: 86: CLK->HSITRIMR = CLK_HSITRIMR_RESET_VALUE;
                                    137 ; genPointerSet
      009086 35 00 50 CC      [ 1]  138 	mov	0x50cc+0, #0x00
                           000035   139 	Sstm8s_clk$CLK_DeInit$14 ==.
                                    140 ;	../SPL/src/stm8s_clk.c: 87: CLK->SWIMCCR = CLK_SWIMCCR_RESET_VALUE;
                                    141 ; genPointerSet
      00908A 35 00 50 CD      [ 1]  142 	mov	0x50cd+0, #0x00
                                    143 ; genLabel
      00908E                        144 00104$:
                           000039   145 	Sstm8s_clk$CLK_DeInit$15 ==.
                                    146 ;	../SPL/src/stm8s_clk.c: 88: }
                                    147 ; genEndFunction
                           000039   148 	Sstm8s_clk$CLK_DeInit$16 ==.
                           000039   149 	XG$CLK_DeInit$0$0 ==.
      00908E 81               [ 4]  150 	ret
                           00003A   151 	Sstm8s_clk$CLK_DeInit$17 ==.
                           00003A   152 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$18 ==.
                                    153 ;	../SPL/src/stm8s_clk.c: 99: void CLK_FastHaltWakeUpCmd(FunctionalState NewState)
                                    154 ; genLabel
                                    155 ;	-----------------------------------------
                                    156 ;	 function CLK_FastHaltWakeUpCmd
                                    157 ;	-----------------------------------------
                                    158 ;	Register assignment is optimal.
                                    159 ;	Stack space usage: 0 bytes.
      00908F                        160 _CLK_FastHaltWakeUpCmd:
                           00003A   161 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$19 ==.
                           00003A   162 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$20 ==.
                                    163 ;	../SPL/src/stm8s_clk.c: 107: CLK->ICKR |= CLK_ICKR_FHWU;
                                    164 ; genPointerGet
      00908F C6 50 C0         [ 1]  165 	ld	a, 0x50c0
                           00003D   166 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$21 ==.
                                    167 ;	../SPL/src/stm8s_clk.c: 104: if (NewState != DISABLE)
                                    168 ; genIfx
      009092 0D 03            [ 1]  169 	tnz	(0x03, sp)
      009094 26 03            [ 1]  170 	jrne	00111$
      009096 CC 90 A1         [ 2]  171 	jp	00102$
      009099                        172 00111$:
                           000044   173 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$22 ==.
                           000044   174 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$23 ==.
                                    175 ;	../SPL/src/stm8s_clk.c: 107: CLK->ICKR |= CLK_ICKR_FHWU;
                                    176 ; genOr
      009099 AA 04            [ 1]  177 	or	a, #0x04
                                    178 ; genPointerSet
      00909B C7 50 C0         [ 1]  179 	ld	0x50c0, a
                           000049   180 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$24 ==.
                                    181 ; genGoto
      00909E CC 90 A6         [ 2]  182 	jp	00104$
                                    183 ; genLabel
      0090A1                        184 00102$:
                           00004C   185 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$25 ==.
                           00004C   186 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$26 ==.
                                    187 ;	../SPL/src/stm8s_clk.c: 112: CLK->ICKR &= (uint8_t)(~CLK_ICKR_FHWU);
                                    188 ; genAnd
      0090A1 A4 FB            [ 1]  189 	and	a, #0xfb
                                    190 ; genPointerSet
      0090A3 C7 50 C0         [ 1]  191 	ld	0x50c0, a
                           000051   192 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$27 ==.
                                    193 ; genLabel
      0090A6                        194 00104$:
                           000051   195 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$28 ==.
                                    196 ;	../SPL/src/stm8s_clk.c: 114: }
                                    197 ; genEndFunction
                           000051   198 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$29 ==.
                           000051   199 	XG$CLK_FastHaltWakeUpCmd$0$0 ==.
      0090A6 81               [ 4]  200 	ret
                           000052   201 	Sstm8s_clk$CLK_FastHaltWakeUpCmd$30 ==.
                           000052   202 	Sstm8s_clk$CLK_HSECmd$31 ==.
                                    203 ;	../SPL/src/stm8s_clk.c: 121: void CLK_HSECmd(FunctionalState NewState)
                                    204 ; genLabel
                                    205 ;	-----------------------------------------
                                    206 ;	 function CLK_HSECmd
                                    207 ;	-----------------------------------------
                                    208 ;	Register assignment is optimal.
                                    209 ;	Stack space usage: 0 bytes.
      0090A7                        210 _CLK_HSECmd:
                           000052   211 	Sstm8s_clk$CLK_HSECmd$32 ==.
                           000052   212 	Sstm8s_clk$CLK_HSECmd$33 ==.
                                    213 ;	../SPL/src/stm8s_clk.c: 129: CLK->ECKR |= CLK_ECKR_HSEEN;
                                    214 ; genPointerGet
      0090A7 C6 50 C1         [ 1]  215 	ld	a, 0x50c1
                           000055   216 	Sstm8s_clk$CLK_HSECmd$34 ==.
                                    217 ;	../SPL/src/stm8s_clk.c: 126: if (NewState != DISABLE)
                                    218 ; genIfx
      0090AA 0D 03            [ 1]  219 	tnz	(0x03, sp)
      0090AC 26 03            [ 1]  220 	jrne	00111$
      0090AE CC 90 B9         [ 2]  221 	jp	00102$
      0090B1                        222 00111$:
                           00005C   223 	Sstm8s_clk$CLK_HSECmd$35 ==.
                           00005C   224 	Sstm8s_clk$CLK_HSECmd$36 ==.
                                    225 ;	../SPL/src/stm8s_clk.c: 129: CLK->ECKR |= CLK_ECKR_HSEEN;
                                    226 ; genOr
      0090B1 AA 01            [ 1]  227 	or	a, #0x01
                                    228 ; genPointerSet
      0090B3 C7 50 C1         [ 1]  229 	ld	0x50c1, a
                           000061   230 	Sstm8s_clk$CLK_HSECmd$37 ==.
                                    231 ; genGoto
      0090B6 CC 90 BE         [ 2]  232 	jp	00104$
                                    233 ; genLabel
      0090B9                        234 00102$:
                           000064   235 	Sstm8s_clk$CLK_HSECmd$38 ==.
                           000064   236 	Sstm8s_clk$CLK_HSECmd$39 ==.
                                    237 ;	../SPL/src/stm8s_clk.c: 134: CLK->ECKR &= (uint8_t)(~CLK_ECKR_HSEEN);
                                    238 ; genAnd
      0090B9 A4 FE            [ 1]  239 	and	a, #0xfe
                                    240 ; genPointerSet
      0090BB C7 50 C1         [ 1]  241 	ld	0x50c1, a
                           000069   242 	Sstm8s_clk$CLK_HSECmd$40 ==.
                                    243 ; genLabel
      0090BE                        244 00104$:
                           000069   245 	Sstm8s_clk$CLK_HSECmd$41 ==.
                                    246 ;	../SPL/src/stm8s_clk.c: 136: }
                                    247 ; genEndFunction
                           000069   248 	Sstm8s_clk$CLK_HSECmd$42 ==.
                           000069   249 	XG$CLK_HSECmd$0$0 ==.
      0090BE 81               [ 4]  250 	ret
                           00006A   251 	Sstm8s_clk$CLK_HSECmd$43 ==.
                           00006A   252 	Sstm8s_clk$CLK_HSICmd$44 ==.
                                    253 ;	../SPL/src/stm8s_clk.c: 143: void CLK_HSICmd(FunctionalState NewState)
                                    254 ; genLabel
                                    255 ;	-----------------------------------------
                                    256 ;	 function CLK_HSICmd
                                    257 ;	-----------------------------------------
                                    258 ;	Register assignment is optimal.
                                    259 ;	Stack space usage: 0 bytes.
      0090BF                        260 _CLK_HSICmd:
                           00006A   261 	Sstm8s_clk$CLK_HSICmd$45 ==.
                           00006A   262 	Sstm8s_clk$CLK_HSICmd$46 ==.
                                    263 ;	../SPL/src/stm8s_clk.c: 151: CLK->ICKR |= CLK_ICKR_HSIEN;
                                    264 ; genPointerGet
      0090BF C6 50 C0         [ 1]  265 	ld	a, 0x50c0
                           00006D   266 	Sstm8s_clk$CLK_HSICmd$47 ==.
                                    267 ;	../SPL/src/stm8s_clk.c: 148: if (NewState != DISABLE)
                                    268 ; genIfx
      0090C2 0D 03            [ 1]  269 	tnz	(0x03, sp)
      0090C4 26 03            [ 1]  270 	jrne	00111$
      0090C6 CC 90 D1         [ 2]  271 	jp	00102$
      0090C9                        272 00111$:
                           000074   273 	Sstm8s_clk$CLK_HSICmd$48 ==.
                           000074   274 	Sstm8s_clk$CLK_HSICmd$49 ==.
                                    275 ;	../SPL/src/stm8s_clk.c: 151: CLK->ICKR |= CLK_ICKR_HSIEN;
                                    276 ; genOr
      0090C9 AA 01            [ 1]  277 	or	a, #0x01
                                    278 ; genPointerSet
      0090CB C7 50 C0         [ 1]  279 	ld	0x50c0, a
                           000079   280 	Sstm8s_clk$CLK_HSICmd$50 ==.
                                    281 ; genGoto
      0090CE CC 90 D6         [ 2]  282 	jp	00104$
                                    283 ; genLabel
      0090D1                        284 00102$:
                           00007C   285 	Sstm8s_clk$CLK_HSICmd$51 ==.
                           00007C   286 	Sstm8s_clk$CLK_HSICmd$52 ==.
                                    287 ;	../SPL/src/stm8s_clk.c: 156: CLK->ICKR &= (uint8_t)(~CLK_ICKR_HSIEN);
                                    288 ; genAnd
      0090D1 A4 FE            [ 1]  289 	and	a, #0xfe
                                    290 ; genPointerSet
      0090D3 C7 50 C0         [ 1]  291 	ld	0x50c0, a
                           000081   292 	Sstm8s_clk$CLK_HSICmd$53 ==.
                                    293 ; genLabel
      0090D6                        294 00104$:
                           000081   295 	Sstm8s_clk$CLK_HSICmd$54 ==.
                                    296 ;	../SPL/src/stm8s_clk.c: 158: }
                                    297 ; genEndFunction
                           000081   298 	Sstm8s_clk$CLK_HSICmd$55 ==.
                           000081   299 	XG$CLK_HSICmd$0$0 ==.
      0090D6 81               [ 4]  300 	ret
                           000082   301 	Sstm8s_clk$CLK_HSICmd$56 ==.
                           000082   302 	Sstm8s_clk$CLK_LSICmd$57 ==.
                                    303 ;	../SPL/src/stm8s_clk.c: 166: void CLK_LSICmd(FunctionalState NewState)
                                    304 ; genLabel
                                    305 ;	-----------------------------------------
                                    306 ;	 function CLK_LSICmd
                                    307 ;	-----------------------------------------
                                    308 ;	Register assignment is optimal.
                                    309 ;	Stack space usage: 0 bytes.
      0090D7                        310 _CLK_LSICmd:
                           000082   311 	Sstm8s_clk$CLK_LSICmd$58 ==.
                           000082   312 	Sstm8s_clk$CLK_LSICmd$59 ==.
                                    313 ;	../SPL/src/stm8s_clk.c: 174: CLK->ICKR |= CLK_ICKR_LSIEN;
                                    314 ; genPointerGet
      0090D7 C6 50 C0         [ 1]  315 	ld	a, 0x50c0
                           000085   316 	Sstm8s_clk$CLK_LSICmd$60 ==.
                                    317 ;	../SPL/src/stm8s_clk.c: 171: if (NewState != DISABLE)
                                    318 ; genIfx
      0090DA 0D 03            [ 1]  319 	tnz	(0x03, sp)
      0090DC 26 03            [ 1]  320 	jrne	00111$
      0090DE CC 90 E9         [ 2]  321 	jp	00102$
      0090E1                        322 00111$:
                           00008C   323 	Sstm8s_clk$CLK_LSICmd$61 ==.
                           00008C   324 	Sstm8s_clk$CLK_LSICmd$62 ==.
                                    325 ;	../SPL/src/stm8s_clk.c: 174: CLK->ICKR |= CLK_ICKR_LSIEN;
                                    326 ; genOr
      0090E1 AA 08            [ 1]  327 	or	a, #0x08
                                    328 ; genPointerSet
      0090E3 C7 50 C0         [ 1]  329 	ld	0x50c0, a
                           000091   330 	Sstm8s_clk$CLK_LSICmd$63 ==.
                                    331 ; genGoto
      0090E6 CC 90 EE         [ 2]  332 	jp	00104$
                                    333 ; genLabel
      0090E9                        334 00102$:
                           000094   335 	Sstm8s_clk$CLK_LSICmd$64 ==.
                           000094   336 	Sstm8s_clk$CLK_LSICmd$65 ==.
                                    337 ;	../SPL/src/stm8s_clk.c: 179: CLK->ICKR &= (uint8_t)(~CLK_ICKR_LSIEN);
                                    338 ; genAnd
      0090E9 A4 F7            [ 1]  339 	and	a, #0xf7
                                    340 ; genPointerSet
      0090EB C7 50 C0         [ 1]  341 	ld	0x50c0, a
                           000099   342 	Sstm8s_clk$CLK_LSICmd$66 ==.
                                    343 ; genLabel
      0090EE                        344 00104$:
                           000099   345 	Sstm8s_clk$CLK_LSICmd$67 ==.
                                    346 ;	../SPL/src/stm8s_clk.c: 181: }
                                    347 ; genEndFunction
                           000099   348 	Sstm8s_clk$CLK_LSICmd$68 ==.
                           000099   349 	XG$CLK_LSICmd$0$0 ==.
      0090EE 81               [ 4]  350 	ret
                           00009A   351 	Sstm8s_clk$CLK_LSICmd$69 ==.
                           00009A   352 	Sstm8s_clk$CLK_CCOCmd$70 ==.
                                    353 ;	../SPL/src/stm8s_clk.c: 189: void CLK_CCOCmd(FunctionalState NewState)
                                    354 ; genLabel
                                    355 ;	-----------------------------------------
                                    356 ;	 function CLK_CCOCmd
                                    357 ;	-----------------------------------------
                                    358 ;	Register assignment is optimal.
                                    359 ;	Stack space usage: 0 bytes.
      0090EF                        360 _CLK_CCOCmd:
                           00009A   361 	Sstm8s_clk$CLK_CCOCmd$71 ==.
                           00009A   362 	Sstm8s_clk$CLK_CCOCmd$72 ==.
                                    363 ;	../SPL/src/stm8s_clk.c: 197: CLK->CCOR |= CLK_CCOR_CCOEN;
                                    364 ; genPointerGet
      0090EF C6 50 C9         [ 1]  365 	ld	a, 0x50c9
                           00009D   366 	Sstm8s_clk$CLK_CCOCmd$73 ==.
                                    367 ;	../SPL/src/stm8s_clk.c: 194: if (NewState != DISABLE)
                                    368 ; genIfx
      0090F2 0D 03            [ 1]  369 	tnz	(0x03, sp)
      0090F4 26 03            [ 1]  370 	jrne	00111$
      0090F6 CC 91 01         [ 2]  371 	jp	00102$
      0090F9                        372 00111$:
                           0000A4   373 	Sstm8s_clk$CLK_CCOCmd$74 ==.
                           0000A4   374 	Sstm8s_clk$CLK_CCOCmd$75 ==.
                                    375 ;	../SPL/src/stm8s_clk.c: 197: CLK->CCOR |= CLK_CCOR_CCOEN;
                                    376 ; genOr
      0090F9 AA 01            [ 1]  377 	or	a, #0x01
                                    378 ; genPointerSet
      0090FB C7 50 C9         [ 1]  379 	ld	0x50c9, a
                           0000A9   380 	Sstm8s_clk$CLK_CCOCmd$76 ==.
                                    381 ; genGoto
      0090FE CC 91 06         [ 2]  382 	jp	00104$
                                    383 ; genLabel
      009101                        384 00102$:
                           0000AC   385 	Sstm8s_clk$CLK_CCOCmd$77 ==.
                           0000AC   386 	Sstm8s_clk$CLK_CCOCmd$78 ==.
                                    387 ;	../SPL/src/stm8s_clk.c: 202: CLK->CCOR &= (uint8_t)(~CLK_CCOR_CCOEN);
                                    388 ; genAnd
      009101 A4 FE            [ 1]  389 	and	a, #0xfe
                                    390 ; genPointerSet
      009103 C7 50 C9         [ 1]  391 	ld	0x50c9, a
                           0000B1   392 	Sstm8s_clk$CLK_CCOCmd$79 ==.
                                    393 ; genLabel
      009106                        394 00104$:
                           0000B1   395 	Sstm8s_clk$CLK_CCOCmd$80 ==.
                                    396 ;	../SPL/src/stm8s_clk.c: 204: }
                                    397 ; genEndFunction
                           0000B1   398 	Sstm8s_clk$CLK_CCOCmd$81 ==.
                           0000B1   399 	XG$CLK_CCOCmd$0$0 ==.
      009106 81               [ 4]  400 	ret
                           0000B2   401 	Sstm8s_clk$CLK_CCOCmd$82 ==.
                           0000B2   402 	Sstm8s_clk$CLK_ClockSwitchCmd$83 ==.
                                    403 ;	../SPL/src/stm8s_clk.c: 213: void CLK_ClockSwitchCmd(FunctionalState NewState)
                                    404 ; genLabel
                                    405 ;	-----------------------------------------
                                    406 ;	 function CLK_ClockSwitchCmd
                                    407 ;	-----------------------------------------
                                    408 ;	Register assignment is optimal.
                                    409 ;	Stack space usage: 0 bytes.
      009107                        410 _CLK_ClockSwitchCmd:
                           0000B2   411 	Sstm8s_clk$CLK_ClockSwitchCmd$84 ==.
                           0000B2   412 	Sstm8s_clk$CLK_ClockSwitchCmd$85 ==.
                                    413 ;	../SPL/src/stm8s_clk.c: 221: CLK->SWCR |= CLK_SWCR_SWEN;
                                    414 ; genPointerGet
      009107 C6 50 C5         [ 1]  415 	ld	a, 0x50c5
                           0000B5   416 	Sstm8s_clk$CLK_ClockSwitchCmd$86 ==.
                                    417 ;	../SPL/src/stm8s_clk.c: 218: if (NewState != DISABLE )
                                    418 ; genIfx
      00910A 0D 03            [ 1]  419 	tnz	(0x03, sp)
      00910C 26 03            [ 1]  420 	jrne	00111$
      00910E CC 91 19         [ 2]  421 	jp	00102$
      009111                        422 00111$:
                           0000BC   423 	Sstm8s_clk$CLK_ClockSwitchCmd$87 ==.
                           0000BC   424 	Sstm8s_clk$CLK_ClockSwitchCmd$88 ==.
                                    425 ;	../SPL/src/stm8s_clk.c: 221: CLK->SWCR |= CLK_SWCR_SWEN;
                                    426 ; genOr
      009111 AA 02            [ 1]  427 	or	a, #0x02
                                    428 ; genPointerSet
      009113 C7 50 C5         [ 1]  429 	ld	0x50c5, a
                           0000C1   430 	Sstm8s_clk$CLK_ClockSwitchCmd$89 ==.
                                    431 ; genGoto
      009116 CC 91 1E         [ 2]  432 	jp	00104$
                                    433 ; genLabel
      009119                        434 00102$:
                           0000C4   435 	Sstm8s_clk$CLK_ClockSwitchCmd$90 ==.
                           0000C4   436 	Sstm8s_clk$CLK_ClockSwitchCmd$91 ==.
                                    437 ;	../SPL/src/stm8s_clk.c: 226: CLK->SWCR &= (uint8_t)(~CLK_SWCR_SWEN);
                                    438 ; genAnd
      009119 A4 FD            [ 1]  439 	and	a, #0xfd
                                    440 ; genPointerSet
      00911B C7 50 C5         [ 1]  441 	ld	0x50c5, a
                           0000C9   442 	Sstm8s_clk$CLK_ClockSwitchCmd$92 ==.
                                    443 ; genLabel
      00911E                        444 00104$:
                           0000C9   445 	Sstm8s_clk$CLK_ClockSwitchCmd$93 ==.
                                    446 ;	../SPL/src/stm8s_clk.c: 228: }
                                    447 ; genEndFunction
                           0000C9   448 	Sstm8s_clk$CLK_ClockSwitchCmd$94 ==.
                           0000C9   449 	XG$CLK_ClockSwitchCmd$0$0 ==.
      00911E 81               [ 4]  450 	ret
                           0000CA   451 	Sstm8s_clk$CLK_ClockSwitchCmd$95 ==.
                           0000CA   452 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$96 ==.
                                    453 ;	../SPL/src/stm8s_clk.c: 238: void CLK_SlowActiveHaltWakeUpCmd(FunctionalState NewState)
                                    454 ; genLabel
                                    455 ;	-----------------------------------------
                                    456 ;	 function CLK_SlowActiveHaltWakeUpCmd
                                    457 ;	-----------------------------------------
                                    458 ;	Register assignment is optimal.
                                    459 ;	Stack space usage: 0 bytes.
      00911F                        460 _CLK_SlowActiveHaltWakeUpCmd:
                           0000CA   461 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$97 ==.
                           0000CA   462 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$98 ==.
                                    463 ;	../SPL/src/stm8s_clk.c: 246: CLK->ICKR |= CLK_ICKR_SWUAH;
                                    464 ; genPointerGet
      00911F C6 50 C0         [ 1]  465 	ld	a, 0x50c0
                           0000CD   466 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$99 ==.
                                    467 ;	../SPL/src/stm8s_clk.c: 243: if (NewState != DISABLE)
                                    468 ; genIfx
      009122 0D 03            [ 1]  469 	tnz	(0x03, sp)
      009124 26 03            [ 1]  470 	jrne	00111$
      009126 CC 91 31         [ 2]  471 	jp	00102$
      009129                        472 00111$:
                           0000D4   473 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$100 ==.
                           0000D4   474 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$101 ==.
                                    475 ;	../SPL/src/stm8s_clk.c: 246: CLK->ICKR |= CLK_ICKR_SWUAH;
                                    476 ; genOr
      009129 AA 20            [ 1]  477 	or	a, #0x20
                                    478 ; genPointerSet
      00912B C7 50 C0         [ 1]  479 	ld	0x50c0, a
                           0000D9   480 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$102 ==.
                                    481 ; genGoto
      00912E CC 91 36         [ 2]  482 	jp	00104$
                                    483 ; genLabel
      009131                        484 00102$:
                           0000DC   485 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$103 ==.
                           0000DC   486 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$104 ==.
                                    487 ;	../SPL/src/stm8s_clk.c: 251: CLK->ICKR &= (uint8_t)(~CLK_ICKR_SWUAH);
                                    488 ; genAnd
      009131 A4 DF            [ 1]  489 	and	a, #0xdf
                                    490 ; genPointerSet
      009133 C7 50 C0         [ 1]  491 	ld	0x50c0, a
                           0000E1   492 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$105 ==.
                                    493 ; genLabel
      009136                        494 00104$:
                           0000E1   495 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$106 ==.
                                    496 ;	../SPL/src/stm8s_clk.c: 253: }
                                    497 ; genEndFunction
                           0000E1   498 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$107 ==.
                           0000E1   499 	XG$CLK_SlowActiveHaltWakeUpCmd$0$0 ==.
      009136 81               [ 4]  500 	ret
                           0000E2   501 	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$108 ==.
                           0000E2   502 	Sstm8s_clk$CLK_PeripheralClockConfig$109 ==.
                                    503 ;	../SPL/src/stm8s_clk.c: 263: void CLK_PeripheralClockConfig(CLK_Peripheral_TypeDef CLK_Peripheral, FunctionalState NewState)
                                    504 ; genLabel
                                    505 ;	-----------------------------------------
                                    506 ;	 function CLK_PeripheralClockConfig
                                    507 ;	-----------------------------------------
                                    508 ;	Register assignment is optimal.
                                    509 ;	Stack space usage: 2 bytes.
      009137                        510 _CLK_PeripheralClockConfig:
                           0000E2   511 	Sstm8s_clk$CLK_PeripheralClockConfig$110 ==.
      009137 89               [ 2]  512 	pushw	x
                           0000E3   513 	Sstm8s_clk$CLK_PeripheralClockConfig$111 ==.
                           0000E3   514 	Sstm8s_clk$CLK_PeripheralClockConfig$112 ==.
                                    515 ;	../SPL/src/stm8s_clk.c: 274: CLK->PCKENR1 |= (uint8_t)((uint8_t)1 << ((uint8_t)CLK_Peripheral & (uint8_t)0x0F));
                                    516 ; genAnd
      009138 7B 05            [ 1]  517 	ld	a, (0x05, sp)
      00913A A4 0F            [ 1]  518 	and	a, #0x0f
                                    519 ; genLeftShift
      00913C 88               [ 1]  520 	push	a
                           0000E8   521 	Sstm8s_clk$CLK_PeripheralClockConfig$113 ==.
      00913D A6 01            [ 1]  522 	ld	a, #0x01
      00913F 6B 02            [ 1]  523 	ld	(0x02, sp), a
      009141 84               [ 1]  524 	pop	a
                           0000ED   525 	Sstm8s_clk$CLK_PeripheralClockConfig$114 ==.
      009142 4D               [ 1]  526 	tnz	a
      009143 27 05            [ 1]  527 	jreq	00128$
      009145                        528 00127$:
      009145 08 01            [ 1]  529 	sll	(0x01, sp)
      009147 4A               [ 1]  530 	dec	a
      009148 26 FB            [ 1]  531 	jrne	00127$
      00914A                        532 00128$:
                           0000F5   533 	Sstm8s_clk$CLK_PeripheralClockConfig$115 ==.
                                    534 ;	../SPL/src/stm8s_clk.c: 279: CLK->PCKENR1 &= (uint8_t)(~(uint8_t)(((uint8_t)1 << ((uint8_t)CLK_Peripheral & (uint8_t)0x0F))));
                                    535 ; genCpl
      00914A 7B 01            [ 1]  536 	ld	a, (0x01, sp)
      00914C 43               [ 1]  537 	cpl	a
      00914D 6B 02            [ 1]  538 	ld	(0x02, sp), a
                           0000FA   539 	Sstm8s_clk$CLK_PeripheralClockConfig$116 ==.
                                    540 ;	../SPL/src/stm8s_clk.c: 269: if (((uint8_t)CLK_Peripheral & (uint8_t)0x10) == 0x00)
                                    541 ; genAnd
      00914F 7B 05            [ 1]  542 	ld	a, (0x05, sp)
      009151 A5 10            [ 1]  543 	bcp	a, #0x10
      009153 27 03            [ 1]  544 	jreq	00129$
      009155 CC 91 72         [ 2]  545 	jp	00108$
      009158                        546 00129$:
                                    547 ; skipping generated iCode
                           000103   548 	Sstm8s_clk$CLK_PeripheralClockConfig$117 ==.
                                    549 ;	../SPL/src/stm8s_clk.c: 274: CLK->PCKENR1 |= (uint8_t)((uint8_t)1 << ((uint8_t)CLK_Peripheral & (uint8_t)0x0F));
                                    550 ; genPointerGet
      009158 C6 50 C7         [ 1]  551 	ld	a, 0x50c7
                           000106   552 	Sstm8s_clk$CLK_PeripheralClockConfig$118 ==.
                           000106   553 	Sstm8s_clk$CLK_PeripheralClockConfig$119 ==.
                                    554 ;	../SPL/src/stm8s_clk.c: 271: if (NewState != DISABLE)
                                    555 ; genIfx
      00915B 0D 06            [ 1]  556 	tnz	(0x06, sp)
      00915D 26 03            [ 1]  557 	jrne	00130$
      00915F CC 91 6A         [ 2]  558 	jp	00102$
      009162                        559 00130$:
                           00010D   560 	Sstm8s_clk$CLK_PeripheralClockConfig$120 ==.
                           00010D   561 	Sstm8s_clk$CLK_PeripheralClockConfig$121 ==.
                                    562 ;	../SPL/src/stm8s_clk.c: 274: CLK->PCKENR1 |= (uint8_t)((uint8_t)1 << ((uint8_t)CLK_Peripheral & (uint8_t)0x0F));
                                    563 ; genOr
      009162 1A 01            [ 1]  564 	or	a, (0x01, sp)
                                    565 ; genPointerSet
      009164 C7 50 C7         [ 1]  566 	ld	0x50c7, a
                           000112   567 	Sstm8s_clk$CLK_PeripheralClockConfig$122 ==.
                                    568 ; genGoto
      009167 CC 91 89         [ 2]  569 	jp	00110$
                                    570 ; genLabel
      00916A                        571 00102$:
                           000115   572 	Sstm8s_clk$CLK_PeripheralClockConfig$123 ==.
                           000115   573 	Sstm8s_clk$CLK_PeripheralClockConfig$124 ==.
                                    574 ;	../SPL/src/stm8s_clk.c: 279: CLK->PCKENR1 &= (uint8_t)(~(uint8_t)(((uint8_t)1 << ((uint8_t)CLK_Peripheral & (uint8_t)0x0F))));
                                    575 ; genAnd
      00916A 14 02            [ 1]  576 	and	a, (0x02, sp)
                                    577 ; genPointerSet
      00916C C7 50 C7         [ 1]  578 	ld	0x50c7, a
                           00011A   579 	Sstm8s_clk$CLK_PeripheralClockConfig$125 ==.
                                    580 ; genGoto
      00916F CC 91 89         [ 2]  581 	jp	00110$
                                    582 ; genLabel
      009172                        583 00108$:
                           00011D   584 	Sstm8s_clk$CLK_PeripheralClockConfig$126 ==.
                                    585 ;	../SPL/src/stm8s_clk.c: 287: CLK->PCKENR2 |= (uint8_t)((uint8_t)1 << ((uint8_t)CLK_Peripheral & (uint8_t)0x0F));
                                    586 ; genPointerGet
      009172 C6 50 CA         [ 1]  587 	ld	a, 0x50ca
                           000120   588 	Sstm8s_clk$CLK_PeripheralClockConfig$127 ==.
                           000120   589 	Sstm8s_clk$CLK_PeripheralClockConfig$128 ==.
                                    590 ;	../SPL/src/stm8s_clk.c: 284: if (NewState != DISABLE)
                                    591 ; genIfx
      009175 0D 06            [ 1]  592 	tnz	(0x06, sp)
      009177 26 03            [ 1]  593 	jrne	00131$
      009179 CC 91 84         [ 2]  594 	jp	00105$
      00917C                        595 00131$:
                           000127   596 	Sstm8s_clk$CLK_PeripheralClockConfig$129 ==.
                           000127   597 	Sstm8s_clk$CLK_PeripheralClockConfig$130 ==.
                                    598 ;	../SPL/src/stm8s_clk.c: 287: CLK->PCKENR2 |= (uint8_t)((uint8_t)1 << ((uint8_t)CLK_Peripheral & (uint8_t)0x0F));
                                    599 ; genOr
      00917C 1A 01            [ 1]  600 	or	a, (0x01, sp)
                                    601 ; genPointerSet
      00917E C7 50 CA         [ 1]  602 	ld	0x50ca, a
                           00012C   603 	Sstm8s_clk$CLK_PeripheralClockConfig$131 ==.
                                    604 ; genGoto
      009181 CC 91 89         [ 2]  605 	jp	00110$
                                    606 ; genLabel
      009184                        607 00105$:
                           00012F   608 	Sstm8s_clk$CLK_PeripheralClockConfig$132 ==.
                           00012F   609 	Sstm8s_clk$CLK_PeripheralClockConfig$133 ==.
                                    610 ;	../SPL/src/stm8s_clk.c: 292: CLK->PCKENR2 &= (uint8_t)(~(uint8_t)(((uint8_t)1 << ((uint8_t)CLK_Peripheral & (uint8_t)0x0F))));
                                    611 ; genAnd
      009184 14 02            [ 1]  612 	and	a, (0x02, sp)
                                    613 ; genPointerSet
      009186 C7 50 CA         [ 1]  614 	ld	0x50ca, a
                           000134   615 	Sstm8s_clk$CLK_PeripheralClockConfig$134 ==.
                                    616 ; genLabel
      009189                        617 00110$:
                           000134   618 	Sstm8s_clk$CLK_PeripheralClockConfig$135 ==.
                                    619 ;	../SPL/src/stm8s_clk.c: 295: }
                                    620 ; genEndFunction
      009189 85               [ 2]  621 	popw	x
                           000135   622 	Sstm8s_clk$CLK_PeripheralClockConfig$136 ==.
                           000135   623 	Sstm8s_clk$CLK_PeripheralClockConfig$137 ==.
                           000135   624 	XG$CLK_PeripheralClockConfig$0$0 ==.
      00918A 81               [ 4]  625 	ret
                           000136   626 	Sstm8s_clk$CLK_PeripheralClockConfig$138 ==.
                           000136   627 	Sstm8s_clk$CLK_ClockSwitchConfig$139 ==.
                                    628 ;	../SPL/src/stm8s_clk.c: 309: ErrorStatus CLK_ClockSwitchConfig(CLK_SwitchMode_TypeDef CLK_SwitchMode, CLK_Source_TypeDef CLK_NewClock, FunctionalState ITState, CLK_CurrentClockState_TypeDef CLK_CurrentClockState)
                                    629 ; genLabel
                                    630 ;	-----------------------------------------
                                    631 ;	 function CLK_ClockSwitchConfig
                                    632 ;	-----------------------------------------
                                    633 ;	Register assignment might be sub-optimal.
                                    634 ;	Stack space usage: 1 bytes.
      00918B                        635 _CLK_ClockSwitchConfig:
                           000136   636 	Sstm8s_clk$CLK_ClockSwitchConfig$140 ==.
      00918B 88               [ 1]  637 	push	a
                           000137   638 	Sstm8s_clk$CLK_ClockSwitchConfig$141 ==.
                           000137   639 	Sstm8s_clk$CLK_ClockSwitchConfig$142 ==.
                                    640 ;	../SPL/src/stm8s_clk.c: 312: uint16_t DownCounter = CLK_TIMEOUT;
                                    641 ; genAssign
      00918C 5F               [ 1]  642 	clrw	x
      00918D 5A               [ 2]  643 	decw	x
                           000139   644 	Sstm8s_clk$CLK_ClockSwitchConfig$143 ==.
                                    645 ;	../SPL/src/stm8s_clk.c: 322: clock_master = (CLK_Source_TypeDef)CLK->CMSR;
                                    646 ; genPointerGet
      00918E C6 50 C3         [ 1]  647 	ld	a, 0x50c3
      009191 6B 01            [ 1]  648 	ld	(0x01, sp), a
                           00013E   649 	Sstm8s_clk$CLK_ClockSwitchConfig$144 ==.
                                    650 ;	../SPL/src/stm8s_clk.c: 328: CLK->SWCR |= CLK_SWCR_SWEN;
                                    651 ; genPointerGet
      009193 C6 50 C5         [ 1]  652 	ld	a, 0x50c5
                           000141   653 	Sstm8s_clk$CLK_ClockSwitchConfig$145 ==.
                                    654 ;	../SPL/src/stm8s_clk.c: 325: if (CLK_SwitchMode == CLK_SWITCHMODE_AUTO)
                                    655 ; genCmpEQorNE
      009196 88               [ 1]  656 	push	a
                           000142   657 	Sstm8s_clk$CLK_ClockSwitchConfig$146 ==.
      009197 7B 05            [ 1]  658 	ld	a, (0x05, sp)
      009199 4A               [ 1]  659 	dec	a
      00919A 84               [ 1]  660 	pop	a
                           000146   661 	Sstm8s_clk$CLK_ClockSwitchConfig$147 ==.
      00919B 26 03            [ 1]  662 	jrne	00232$
      00919D CC 91 A3         [ 2]  663 	jp	00233$
      0091A0                        664 00232$:
      0091A0 CC 91 EA         [ 2]  665 	jp	00122$
      0091A3                        666 00233$:
                           00014E   667 	Sstm8s_clk$CLK_ClockSwitchConfig$148 ==.
                                    668 ; skipping generated iCode
                           00014E   669 	Sstm8s_clk$CLK_ClockSwitchConfig$149 ==.
                           00014E   670 	Sstm8s_clk$CLK_ClockSwitchConfig$150 ==.
                                    671 ;	../SPL/src/stm8s_clk.c: 328: CLK->SWCR |= CLK_SWCR_SWEN;
                                    672 ; genOr
      0091A3 AA 02            [ 1]  673 	or	a, #0x02
                                    674 ; genPointerSet
      0091A5 C7 50 C5         [ 1]  675 	ld	0x50c5, a
                           000153   676 	Sstm8s_clk$CLK_ClockSwitchConfig$151 ==.
                                    677 ; genPointerGet
      0091A8 C6 50 C5         [ 1]  678 	ld	a, 0x50c5
                           000156   679 	Sstm8s_clk$CLK_ClockSwitchConfig$152 ==.
                                    680 ;	../SPL/src/stm8s_clk.c: 331: if (ITState != DISABLE)
                                    681 ; genIfx
      0091AB 0D 06            [ 1]  682 	tnz	(0x06, sp)
      0091AD 26 03            [ 1]  683 	jrne	00234$
      0091AF CC 91 BA         [ 2]  684 	jp	00102$
      0091B2                        685 00234$:
                           00015D   686 	Sstm8s_clk$CLK_ClockSwitchConfig$153 ==.
                           00015D   687 	Sstm8s_clk$CLK_ClockSwitchConfig$154 ==.
                                    688 ;	../SPL/src/stm8s_clk.c: 333: CLK->SWCR |= CLK_SWCR_SWIEN;
                                    689 ; genOr
      0091B2 AA 04            [ 1]  690 	or	a, #0x04
                                    691 ; genPointerSet
      0091B4 C7 50 C5         [ 1]  692 	ld	0x50c5, a
                           000162   693 	Sstm8s_clk$CLK_ClockSwitchConfig$155 ==.
                                    694 ; genGoto
      0091B7 CC 91 BF         [ 2]  695 	jp	00103$
                                    696 ; genLabel
      0091BA                        697 00102$:
                           000165   698 	Sstm8s_clk$CLK_ClockSwitchConfig$156 ==.
                           000165   699 	Sstm8s_clk$CLK_ClockSwitchConfig$157 ==.
                                    700 ;	../SPL/src/stm8s_clk.c: 337: CLK->SWCR &= (uint8_t)(~CLK_SWCR_SWIEN);
                                    701 ; genAnd
      0091BA A4 FB            [ 1]  702 	and	a, #0xfb
                                    703 ; genPointerSet
      0091BC C7 50 C5         [ 1]  704 	ld	0x50c5, a
                           00016A   705 	Sstm8s_clk$CLK_ClockSwitchConfig$158 ==.
                                    706 ; genLabel
      0091BF                        707 00103$:
                           00016A   708 	Sstm8s_clk$CLK_ClockSwitchConfig$159 ==.
                                    709 ;	../SPL/src/stm8s_clk.c: 341: CLK->SWR = (uint8_t)CLK_NewClock;
                                    710 ; genPointerSet
      0091BF 90 AE 50 C4      [ 2]  711 	ldw	y, #0x50c4
      0091C3 7B 05            [ 1]  712 	ld	a, (0x05, sp)
      0091C5 90 F7            [ 1]  713 	ld	(y), a
                           000172   714 	Sstm8s_clk$CLK_ClockSwitchConfig$160 ==.
                           000172   715 	Sstm8s_clk$CLK_ClockSwitchConfig$161 ==.
                                    716 ;	../SPL/src/stm8s_clk.c: 344: while((((CLK->SWCR & CLK_SWCR_SWBSY) != 0 )&& (DownCounter != 0)))
                                    717 ; genAssign
                                    718 ; genLabel
      0091C7                        719 00105$:
                                    720 ; genPointerGet
      0091C7 C6 50 C5         [ 1]  721 	ld	a, 0x50c5
                                    722 ; genAnd
      0091CA 44               [ 1]  723 	srl	a
      0091CB 25 03            [ 1]  724 	jrc	00235$
      0091CD CC 91 DA         [ 2]  725 	jp	00157$
      0091D0                        726 00235$:
                                    727 ; skipping generated iCode
                                    728 ; genIfx
      0091D0 5D               [ 2]  729 	tnzw	x
      0091D1 26 03            [ 1]  730 	jrne	00236$
      0091D3 CC 91 DA         [ 2]  731 	jp	00157$
      0091D6                        732 00236$:
                           000181   733 	Sstm8s_clk$CLK_ClockSwitchConfig$162 ==.
                           000181   734 	Sstm8s_clk$CLK_ClockSwitchConfig$163 ==.
                                    735 ;	../SPL/src/stm8s_clk.c: 346: DownCounter--;
                                    736 ; genMinus
      0091D6 5A               [ 2]  737 	decw	x
                           000182   738 	Sstm8s_clk$CLK_ClockSwitchConfig$164 ==.
                                    739 ; genGoto
      0091D7 CC 91 C7         [ 2]  740 	jp	00105$
                           000185   741 	Sstm8s_clk$CLK_ClockSwitchConfig$165 ==.
                                    742 ; genLabel
      0091DA                        743 00157$:
                                    744 ; genAssign
                           000185   745 	Sstm8s_clk$CLK_ClockSwitchConfig$166 ==.
                                    746 ;	../SPL/src/stm8s_clk.c: 349: if(DownCounter != 0)
                                    747 ; genIfx
      0091DA 5D               [ 2]  748 	tnzw	x
      0091DB 26 03            [ 1]  749 	jrne	00237$
      0091DD CC 91 E6         [ 2]  750 	jp	00109$
      0091E0                        751 00237$:
                           00018B   752 	Sstm8s_clk$CLK_ClockSwitchConfig$167 ==.
                           00018B   753 	Sstm8s_clk$CLK_ClockSwitchConfig$168 ==.
                                    754 ;	../SPL/src/stm8s_clk.c: 351: Swif = SUCCESS;
                                    755 ; genAssign
      0091E0 A6 01            [ 1]  756 	ld	a, #0x01
      0091E2 97               [ 1]  757 	ld	xl, a
                           00018E   758 	Sstm8s_clk$CLK_ClockSwitchConfig$169 ==.
                                    759 ; genGoto
      0091E3 CC 92 2F         [ 2]  760 	jp	00123$
                                    761 ; genLabel
      0091E6                        762 00109$:
                           000191   763 	Sstm8s_clk$CLK_ClockSwitchConfig$170 ==.
                           000191   764 	Sstm8s_clk$CLK_ClockSwitchConfig$171 ==.
                                    765 ;	../SPL/src/stm8s_clk.c: 355: Swif = ERROR;
                                    766 ; genAssign
      0091E6 5F               [ 1]  767 	clrw	x
                           000192   768 	Sstm8s_clk$CLK_ClockSwitchConfig$172 ==.
                                    769 ; genGoto
      0091E7 CC 92 2F         [ 2]  770 	jp	00123$
                                    771 ; genLabel
      0091EA                        772 00122$:
                           000195   773 	Sstm8s_clk$CLK_ClockSwitchConfig$173 ==.
                           000195   774 	Sstm8s_clk$CLK_ClockSwitchConfig$174 ==.
                                    775 ;	../SPL/src/stm8s_clk.c: 361: if (ITState != DISABLE)
                                    776 ; genIfx
      0091EA 0D 06            [ 1]  777 	tnz	(0x06, sp)
      0091EC 26 03            [ 1]  778 	jrne	00238$
      0091EE CC 91 F9         [ 2]  779 	jp	00112$
      0091F1                        780 00238$:
                           00019C   781 	Sstm8s_clk$CLK_ClockSwitchConfig$175 ==.
                           00019C   782 	Sstm8s_clk$CLK_ClockSwitchConfig$176 ==.
                                    783 ;	../SPL/src/stm8s_clk.c: 363: CLK->SWCR |= CLK_SWCR_SWIEN;
                                    784 ; genOr
      0091F1 AA 04            [ 1]  785 	or	a, #0x04
                                    786 ; genPointerSet
      0091F3 C7 50 C5         [ 1]  787 	ld	0x50c5, a
                           0001A1   788 	Sstm8s_clk$CLK_ClockSwitchConfig$177 ==.
                                    789 ; genGoto
      0091F6 CC 91 FE         [ 2]  790 	jp	00113$
                                    791 ; genLabel
      0091F9                        792 00112$:
                           0001A4   793 	Sstm8s_clk$CLK_ClockSwitchConfig$178 ==.
                           0001A4   794 	Sstm8s_clk$CLK_ClockSwitchConfig$179 ==.
                                    795 ;	../SPL/src/stm8s_clk.c: 367: CLK->SWCR &= (uint8_t)(~CLK_SWCR_SWIEN);
                                    796 ; genAnd
      0091F9 A4 FB            [ 1]  797 	and	a, #0xfb
                                    798 ; genPointerSet
      0091FB C7 50 C5         [ 1]  799 	ld	0x50c5, a
                           0001A9   800 	Sstm8s_clk$CLK_ClockSwitchConfig$180 ==.
                                    801 ; genLabel
      0091FE                        802 00113$:
                           0001A9   803 	Sstm8s_clk$CLK_ClockSwitchConfig$181 ==.
                                    804 ;	../SPL/src/stm8s_clk.c: 371: CLK->SWR = (uint8_t)CLK_NewClock;
                                    805 ; genPointerSet
      0091FE 90 AE 50 C4      [ 2]  806 	ldw	y, #0x50c4
      009202 7B 05            [ 1]  807 	ld	a, (0x05, sp)
      009204 90 F7            [ 1]  808 	ld	(y), a
                           0001B1   809 	Sstm8s_clk$CLK_ClockSwitchConfig$182 ==.
                           0001B1   810 	Sstm8s_clk$CLK_ClockSwitchConfig$183 ==.
                                    811 ;	../SPL/src/stm8s_clk.c: 374: while((((CLK->SWCR & CLK_SWCR_SWIF) != 0 ) && (DownCounter != 0)))
                                    812 ; genAssign
                                    813 ; genLabel
      009206                        814 00115$:
                                    815 ; genPointerGet
      009206 C6 50 C5         [ 1]  816 	ld	a, 0x50c5
                                    817 ; genAnd
      009209 A5 08            [ 1]  818 	bcp	a, #0x08
      00920B 26 03            [ 1]  819 	jrne	00239$
      00920D CC 92 1A         [ 2]  820 	jp	00158$
      009210                        821 00239$:
                                    822 ; skipping generated iCode
                                    823 ; genIfx
      009210 5D               [ 2]  824 	tnzw	x
      009211 26 03            [ 1]  825 	jrne	00240$
      009213 CC 92 1A         [ 2]  826 	jp	00158$
      009216                        827 00240$:
                           0001C1   828 	Sstm8s_clk$CLK_ClockSwitchConfig$184 ==.
                           0001C1   829 	Sstm8s_clk$CLK_ClockSwitchConfig$185 ==.
                                    830 ;	../SPL/src/stm8s_clk.c: 376: DownCounter--;
                                    831 ; genMinus
      009216 5A               [ 2]  832 	decw	x
                           0001C2   833 	Sstm8s_clk$CLK_ClockSwitchConfig$186 ==.
                                    834 ; genGoto
      009217 CC 92 06         [ 2]  835 	jp	00115$
                           0001C5   836 	Sstm8s_clk$CLK_ClockSwitchConfig$187 ==.
                                    837 ; genLabel
      00921A                        838 00158$:
                                    839 ; genAssign
                           0001C5   840 	Sstm8s_clk$CLK_ClockSwitchConfig$188 ==.
                                    841 ;	../SPL/src/stm8s_clk.c: 379: if(DownCounter != 0)
                                    842 ; genIfx
      00921A 5D               [ 2]  843 	tnzw	x
      00921B 26 03            [ 1]  844 	jrne	00241$
      00921D CC 92 2E         [ 2]  845 	jp	00119$
      009220                        846 00241$:
                           0001CB   847 	Sstm8s_clk$CLK_ClockSwitchConfig$189 ==.
                           0001CB   848 	Sstm8s_clk$CLK_ClockSwitchConfig$190 ==.
                                    849 ;	../SPL/src/stm8s_clk.c: 382: CLK->SWCR |= CLK_SWCR_SWEN;
                                    850 ; genPointerGet
      009220 C6 50 C5         [ 1]  851 	ld	a, 0x50c5
                                    852 ; genOr
      009223 AA 02            [ 1]  853 	or	a, #0x02
                                    854 ; genPointerSet
      009225 C7 50 C5         [ 1]  855 	ld	0x50c5, a
                           0001D3   856 	Sstm8s_clk$CLK_ClockSwitchConfig$191 ==.
                                    857 ;	../SPL/src/stm8s_clk.c: 383: Swif = SUCCESS;
                                    858 ; genAssign
      009228 A6 01            [ 1]  859 	ld	a, #0x01
      00922A 97               [ 1]  860 	ld	xl, a
                           0001D6   861 	Sstm8s_clk$CLK_ClockSwitchConfig$192 ==.
                                    862 ; genGoto
      00922B CC 92 2F         [ 2]  863 	jp	00123$
                                    864 ; genLabel
      00922E                        865 00119$:
                           0001D9   866 	Sstm8s_clk$CLK_ClockSwitchConfig$193 ==.
                           0001D9   867 	Sstm8s_clk$CLK_ClockSwitchConfig$194 ==.
                                    868 ;	../SPL/src/stm8s_clk.c: 387: Swif = ERROR;
                                    869 ; genAssign
      00922E 5F               [ 1]  870 	clrw	x
                           0001DA   871 	Sstm8s_clk$CLK_ClockSwitchConfig$195 ==.
                                    872 ; genLabel
      00922F                        873 00123$:
                           0001DA   874 	Sstm8s_clk$CLK_ClockSwitchConfig$196 ==.
                                    875 ;	../SPL/src/stm8s_clk.c: 390: if(Swif != ERROR)
                                    876 ; genIfx
      00922F 9F               [ 1]  877 	ld	a, xl
      009230 4D               [ 1]  878 	tnz	a
      009231 26 03            [ 1]  879 	jrne	00242$
      009233 CC 92 8D         [ 2]  880 	jp	00136$
      009236                        881 00242$:
                           0001E1   882 	Sstm8s_clk$CLK_ClockSwitchConfig$197 ==.
                           0001E1   883 	Sstm8s_clk$CLK_ClockSwitchConfig$198 ==.
                                    884 ;	../SPL/src/stm8s_clk.c: 393: if((CLK_CurrentClockState == CLK_CURRENTCLOCKSTATE_DISABLE) && ( clock_master == CLK_SOURCE_HSI))
                                    885 ; genIfx
      009236 0D 07            [ 1]  886 	tnz	(0x07, sp)
      009238 27 03            [ 1]  887 	jreq	00243$
      00923A CC 92 54         [ 2]  888 	jp	00132$
      00923D                        889 00243$:
                                    890 ; genCmpEQorNE
      00923D 7B 01            [ 1]  891 	ld	a, (0x01, sp)
      00923F A1 E1            [ 1]  892 	cp	a, #0xe1
      009241 26 03            [ 1]  893 	jrne	00245$
      009243 CC 92 49         [ 2]  894 	jp	00246$
      009246                        895 00245$:
      009246 CC 92 54         [ 2]  896 	jp	00132$
      009249                        897 00246$:
                           0001F4   898 	Sstm8s_clk$CLK_ClockSwitchConfig$199 ==.
                                    899 ; skipping generated iCode
                           0001F4   900 	Sstm8s_clk$CLK_ClockSwitchConfig$200 ==.
                           0001F4   901 	Sstm8s_clk$CLK_ClockSwitchConfig$201 ==.
                                    902 ;	../SPL/src/stm8s_clk.c: 395: CLK->ICKR &= (uint8_t)(~CLK_ICKR_HSIEN);
                                    903 ; genPointerGet
      009249 C6 50 C0         [ 1]  904 	ld	a, 0x50c0
                                    905 ; genAnd
      00924C A4 FE            [ 1]  906 	and	a, #0xfe
                                    907 ; genPointerSet
      00924E C7 50 C0         [ 1]  908 	ld	0x50c0, a
                           0001FC   909 	Sstm8s_clk$CLK_ClockSwitchConfig$202 ==.
                                    910 ; genGoto
      009251 CC 92 8D         [ 2]  911 	jp	00136$
                                    912 ; genLabel
      009254                        913 00132$:
                           0001FF   914 	Sstm8s_clk$CLK_ClockSwitchConfig$203 ==.
                                    915 ;	../SPL/src/stm8s_clk.c: 397: else if((CLK_CurrentClockState == CLK_CURRENTCLOCKSTATE_DISABLE) && ( clock_master == CLK_SOURCE_LSI))
                                    916 ; genIfx
      009254 0D 07            [ 1]  917 	tnz	(0x07, sp)
      009256 27 03            [ 1]  918 	jreq	00247$
      009258 CC 92 72         [ 2]  919 	jp	00128$
      00925B                        920 00247$:
                                    921 ; genCmpEQorNE
      00925B 7B 01            [ 1]  922 	ld	a, (0x01, sp)
      00925D A1 D2            [ 1]  923 	cp	a, #0xd2
      00925F 26 03            [ 1]  924 	jrne	00249$
      009261 CC 92 67         [ 2]  925 	jp	00250$
      009264                        926 00249$:
      009264 CC 92 72         [ 2]  927 	jp	00128$
      009267                        928 00250$:
                           000212   929 	Sstm8s_clk$CLK_ClockSwitchConfig$204 ==.
                                    930 ; skipping generated iCode
                           000212   931 	Sstm8s_clk$CLK_ClockSwitchConfig$205 ==.
                           000212   932 	Sstm8s_clk$CLK_ClockSwitchConfig$206 ==.
                                    933 ;	../SPL/src/stm8s_clk.c: 399: CLK->ICKR &= (uint8_t)(~CLK_ICKR_LSIEN);
                                    934 ; genPointerGet
      009267 C6 50 C0         [ 1]  935 	ld	a, 0x50c0
                                    936 ; genAnd
      00926A A4 F7            [ 1]  937 	and	a, #0xf7
                                    938 ; genPointerSet
      00926C C7 50 C0         [ 1]  939 	ld	0x50c0, a
                           00021A   940 	Sstm8s_clk$CLK_ClockSwitchConfig$207 ==.
                                    941 ; genGoto
      00926F CC 92 8D         [ 2]  942 	jp	00136$
                                    943 ; genLabel
      009272                        944 00128$:
                           00021D   945 	Sstm8s_clk$CLK_ClockSwitchConfig$208 ==.
                                    946 ;	../SPL/src/stm8s_clk.c: 401: else if ((CLK_CurrentClockState == CLK_CURRENTCLOCKSTATE_DISABLE) && ( clock_master == CLK_SOURCE_HSE))
                                    947 ; genIfx
      009272 0D 07            [ 1]  948 	tnz	(0x07, sp)
      009274 27 03            [ 1]  949 	jreq	00251$
      009276 CC 92 8D         [ 2]  950 	jp	00136$
      009279                        951 00251$:
                                    952 ; genCmpEQorNE
      009279 7B 01            [ 1]  953 	ld	a, (0x01, sp)
      00927B A1 B4            [ 1]  954 	cp	a, #0xb4
      00927D 26 03            [ 1]  955 	jrne	00253$
      00927F CC 92 85         [ 2]  956 	jp	00254$
      009282                        957 00253$:
      009282 CC 92 8D         [ 2]  958 	jp	00136$
      009285                        959 00254$:
                           000230   960 	Sstm8s_clk$CLK_ClockSwitchConfig$209 ==.
                                    961 ; skipping generated iCode
                           000230   962 	Sstm8s_clk$CLK_ClockSwitchConfig$210 ==.
                           000230   963 	Sstm8s_clk$CLK_ClockSwitchConfig$211 ==.
                                    964 ;	../SPL/src/stm8s_clk.c: 403: CLK->ECKR &= (uint8_t)(~CLK_ECKR_HSEEN);
                                    965 ; genPointerGet
      009285 C6 50 C1         [ 1]  966 	ld	a, 0x50c1
                                    967 ; genAnd
      009288 A4 FE            [ 1]  968 	and	a, #0xfe
                                    969 ; genPointerSet
      00928A C7 50 C1         [ 1]  970 	ld	0x50c1, a
                           000238   971 	Sstm8s_clk$CLK_ClockSwitchConfig$212 ==.
                                    972 ; genLabel
      00928D                        973 00136$:
                           000238   974 	Sstm8s_clk$CLK_ClockSwitchConfig$213 ==.
                                    975 ;	../SPL/src/stm8s_clk.c: 406: return(Swif);
                                    976 ; genReturn
      00928D 9F               [ 1]  977 	ld	a, xl
                                    978 ; genLabel
      00928E                        979 00137$:
                           000239   980 	Sstm8s_clk$CLK_ClockSwitchConfig$214 ==.
                                    981 ;	../SPL/src/stm8s_clk.c: 407: }
                                    982 ; genEndFunction
      00928E 5B 01            [ 2]  983 	addw	sp, #1
                           00023B   984 	Sstm8s_clk$CLK_ClockSwitchConfig$215 ==.
                           00023B   985 	Sstm8s_clk$CLK_ClockSwitchConfig$216 ==.
                           00023B   986 	XG$CLK_ClockSwitchConfig$0$0 ==.
      009290 81               [ 4]  987 	ret
                           00023C   988 	Sstm8s_clk$CLK_ClockSwitchConfig$217 ==.
                           00023C   989 	Sstm8s_clk$CLK_HSIPrescalerConfig$218 ==.
                                    990 ;	../SPL/src/stm8s_clk.c: 415: void CLK_HSIPrescalerConfig(CLK_Prescaler_TypeDef HSIPrescaler)
                                    991 ; genLabel
                                    992 ;	-----------------------------------------
                                    993 ;	 function CLK_HSIPrescalerConfig
                                    994 ;	-----------------------------------------
                                    995 ;	Register assignment is optimal.
                                    996 ;	Stack space usage: 0 bytes.
      009291                        997 _CLK_HSIPrescalerConfig:
                           00023C   998 	Sstm8s_clk$CLK_HSIPrescalerConfig$219 ==.
                           00023C   999 	Sstm8s_clk$CLK_HSIPrescalerConfig$220 ==.
                                   1000 ;	../SPL/src/stm8s_clk.c: 421: CLK->CKDIVR &= (uint8_t)(~CLK_CKDIVR_HSIDIV);
                                   1001 ; genPointerGet
      009291 C6 50 C6         [ 1] 1002 	ld	a, 0x50c6
                                   1003 ; genAnd
      009294 A4 E7            [ 1] 1004 	and	a, #0xe7
                                   1005 ; genPointerSet
      009296 C7 50 C6         [ 1] 1006 	ld	0x50c6, a
                           000244  1007 	Sstm8s_clk$CLK_HSIPrescalerConfig$221 ==.
                                   1008 ;	../SPL/src/stm8s_clk.c: 424: CLK->CKDIVR |= (uint8_t)HSIPrescaler;
                                   1009 ; genPointerGet
      009299 C6 50 C6         [ 1] 1010 	ld	a, 0x50c6
                                   1011 ; genOr
      00929C 1A 03            [ 1] 1012 	or	a, (0x03, sp)
                                   1013 ; genPointerSet
      00929E C7 50 C6         [ 1] 1014 	ld	0x50c6, a
                                   1015 ; genLabel
      0092A1                       1016 00101$:
                           00024C  1017 	Sstm8s_clk$CLK_HSIPrescalerConfig$222 ==.
                                   1018 ;	../SPL/src/stm8s_clk.c: 425: }
                                   1019 ; genEndFunction
                           00024C  1020 	Sstm8s_clk$CLK_HSIPrescalerConfig$223 ==.
                           00024C  1021 	XG$CLK_HSIPrescalerConfig$0$0 ==.
      0092A1 81               [ 4] 1022 	ret
                           00024D  1023 	Sstm8s_clk$CLK_HSIPrescalerConfig$224 ==.
                           00024D  1024 	Sstm8s_clk$CLK_CCOConfig$225 ==.
                                   1025 ;	../SPL/src/stm8s_clk.c: 436: void CLK_CCOConfig(CLK_Output_TypeDef CLK_CCO)
                                   1026 ; genLabel
                                   1027 ;	-----------------------------------------
                                   1028 ;	 function CLK_CCOConfig
                                   1029 ;	-----------------------------------------
                                   1030 ;	Register assignment is optimal.
                                   1031 ;	Stack space usage: 0 bytes.
      0092A2                       1032 _CLK_CCOConfig:
                           00024D  1033 	Sstm8s_clk$CLK_CCOConfig$226 ==.
                           00024D  1034 	Sstm8s_clk$CLK_CCOConfig$227 ==.
                                   1035 ;	../SPL/src/stm8s_clk.c: 442: CLK->CCOR &= (uint8_t)(~CLK_CCOR_CCOSEL);
                                   1036 ; genPointerGet
      0092A2 C6 50 C9         [ 1] 1037 	ld	a, 0x50c9
                                   1038 ; genAnd
      0092A5 A4 E1            [ 1] 1039 	and	a, #0xe1
                                   1040 ; genPointerSet
      0092A7 C7 50 C9         [ 1] 1041 	ld	0x50c9, a
                           000255  1042 	Sstm8s_clk$CLK_CCOConfig$228 ==.
                                   1043 ;	../SPL/src/stm8s_clk.c: 445: CLK->CCOR |= (uint8_t)CLK_CCO;
                                   1044 ; genPointerGet
      0092AA C6 50 C9         [ 1] 1045 	ld	a, 0x50c9
                                   1046 ; genOr
      0092AD 1A 03            [ 1] 1047 	or	a, (0x03, sp)
                                   1048 ; genPointerSet
      0092AF C7 50 C9         [ 1] 1049 	ld	0x50c9, a
                           00025D  1050 	Sstm8s_clk$CLK_CCOConfig$229 ==.
                                   1051 ;	../SPL/src/stm8s_clk.c: 448: CLK->CCOR |= CLK_CCOR_CCOEN;
                                   1052 ; genPointerGet
      0092B2 C6 50 C9         [ 1] 1053 	ld	a, 0x50c9
                                   1054 ; genOr
      0092B5 AA 01            [ 1] 1055 	or	a, #0x01
                                   1056 ; genPointerSet
      0092B7 C7 50 C9         [ 1] 1057 	ld	0x50c9, a
                                   1058 ; genLabel
      0092BA                       1059 00101$:
                           000265  1060 	Sstm8s_clk$CLK_CCOConfig$230 ==.
                                   1061 ;	../SPL/src/stm8s_clk.c: 449: }
                                   1062 ; genEndFunction
                           000265  1063 	Sstm8s_clk$CLK_CCOConfig$231 ==.
                           000265  1064 	XG$CLK_CCOConfig$0$0 ==.
      0092BA 81               [ 4] 1065 	ret
                           000266  1066 	Sstm8s_clk$CLK_CCOConfig$232 ==.
                           000266  1067 	Sstm8s_clk$CLK_ITConfig$233 ==.
                                   1068 ;	../SPL/src/stm8s_clk.c: 459: void CLK_ITConfig(CLK_IT_TypeDef CLK_IT, FunctionalState NewState)
                                   1069 ; genLabel
                                   1070 ;	-----------------------------------------
                                   1071 ;	 function CLK_ITConfig
                                   1072 ;	-----------------------------------------
                                   1073 ;	Register assignment is optimal.
                                   1074 ;	Stack space usage: 1 bytes.
      0092BB                       1075 _CLK_ITConfig:
                           000266  1076 	Sstm8s_clk$CLK_ITConfig$234 ==.
      0092BB 88               [ 1] 1077 	push	a
                           000267  1078 	Sstm8s_clk$CLK_ITConfig$235 ==.
                           000267  1079 	Sstm8s_clk$CLK_ITConfig$236 ==.
                                   1080 ;	../SPL/src/stm8s_clk.c: 467: switch (CLK_IT)
                                   1081 ; genCmpEQorNE
      0092BC 7B 04            [ 1] 1082 	ld	a, (0x04, sp)
      0092BE A1 0C            [ 1] 1083 	cp	a, #0x0c
      0092C0 26 07            [ 1] 1084 	jrne	00140$
      0092C2 A6 01            [ 1] 1085 	ld	a, #0x01
      0092C4 6B 01            [ 1] 1086 	ld	(0x01, sp), a
      0092C6 CC 92 CB         [ 2] 1087 	jp	00141$
      0092C9                       1088 00140$:
      0092C9 0F 01            [ 1] 1089 	clr	(0x01, sp)
      0092CB                       1090 00141$:
                           000276  1091 	Sstm8s_clk$CLK_ITConfig$237 ==.
                                   1092 ; genCmpEQorNE
      0092CB 7B 04            [ 1] 1093 	ld	a, (0x04, sp)
      0092CD A1 1C            [ 1] 1094 	cp	a, #0x1c
      0092CF 26 05            [ 1] 1095 	jrne	00143$
      0092D1 A6 01            [ 1] 1096 	ld	a, #0x01
      0092D3 CC 92 D7         [ 2] 1097 	jp	00144$
      0092D6                       1098 00143$:
      0092D6 4F               [ 1] 1099 	clr	a
      0092D7                       1100 00144$:
                           000282  1101 	Sstm8s_clk$CLK_ITConfig$238 ==.
                           000282  1102 	Sstm8s_clk$CLK_ITConfig$239 ==.
                                   1103 ;	../SPL/src/stm8s_clk.c: 465: if (NewState != DISABLE)
                                   1104 ; genIfx
      0092D7 0D 05            [ 1] 1105 	tnz	(0x05, sp)
      0092D9 26 03            [ 1] 1106 	jrne	00145$
      0092DB CC 93 01         [ 2] 1107 	jp	00110$
      0092DE                       1108 00145$:
                           000289  1109 	Sstm8s_clk$CLK_ITConfig$240 ==.
                           000289  1110 	Sstm8s_clk$CLK_ITConfig$241 ==.
                                   1111 ;	../SPL/src/stm8s_clk.c: 467: switch (CLK_IT)
                                   1112 ; genIfx
      0092DE 0D 01            [ 1] 1113 	tnz	(0x01, sp)
      0092E0 27 03            [ 1] 1114 	jreq	00146$
      0092E2 CC 92 F6         [ 2] 1115 	jp	00102$
      0092E5                       1116 00146$:
                                   1117 ; genIfx
      0092E5 4D               [ 1] 1118 	tnz	a
      0092E6 26 03            [ 1] 1119 	jrne	00147$
      0092E8 CC 93 21         [ 2] 1120 	jp	00112$
      0092EB                       1121 00147$:
                           000296  1122 	Sstm8s_clk$CLK_ITConfig$242 ==.
                           000296  1123 	Sstm8s_clk$CLK_ITConfig$243 ==.
                                   1124 ;	../SPL/src/stm8s_clk.c: 470: CLK->SWCR |= CLK_SWCR_SWIEN;
                                   1125 ; genPointerGet
      0092EB C6 50 C5         [ 1] 1126 	ld	a, 0x50c5
                                   1127 ; genOr
      0092EE AA 04            [ 1] 1128 	or	a, #0x04
                                   1129 ; genPointerSet
      0092F0 C7 50 C5         [ 1] 1130 	ld	0x50c5, a
                           00029E  1131 	Sstm8s_clk$CLK_ITConfig$244 ==.
                                   1132 ;	../SPL/src/stm8s_clk.c: 471: break;
                                   1133 ; genGoto
      0092F3 CC 93 21         [ 2] 1134 	jp	00112$
                           0002A1  1135 	Sstm8s_clk$CLK_ITConfig$245 ==.
                                   1136 ;	../SPL/src/stm8s_clk.c: 472: case CLK_IT_CSSD: /* Enable the clock security system detection interrupt */
                                   1137 ; genLabel
      0092F6                       1138 00102$:
                           0002A1  1139 	Sstm8s_clk$CLK_ITConfig$246 ==.
                                   1140 ;	../SPL/src/stm8s_clk.c: 473: CLK->CSSR |= CLK_CSSR_CSSDIE;
                                   1141 ; genPointerGet
      0092F6 C6 50 C8         [ 1] 1142 	ld	a, 0x50c8
                                   1143 ; genOr
      0092F9 AA 04            [ 1] 1144 	or	a, #0x04
                                   1145 ; genPointerSet
      0092FB C7 50 C8         [ 1] 1146 	ld	0x50c8, a
                           0002A9  1147 	Sstm8s_clk$CLK_ITConfig$247 ==.
                                   1148 ;	../SPL/src/stm8s_clk.c: 474: break;
                                   1149 ; genGoto
      0092FE CC 93 21         [ 2] 1150 	jp	00112$
                           0002AC  1151 	Sstm8s_clk$CLK_ITConfig$248 ==.
                           0002AC  1152 	Sstm8s_clk$CLK_ITConfig$249 ==.
                                   1153 ;	../SPL/src/stm8s_clk.c: 477: }
                                   1154 ; genLabel
      009301                       1155 00110$:
                           0002AC  1156 	Sstm8s_clk$CLK_ITConfig$250 ==.
                           0002AC  1157 	Sstm8s_clk$CLK_ITConfig$251 ==.
                                   1158 ;	../SPL/src/stm8s_clk.c: 481: switch (CLK_IT)
                                   1159 ; genIfx
      009301 0D 01            [ 1] 1160 	tnz	(0x01, sp)
      009303 27 03            [ 1] 1161 	jreq	00148$
      009305 CC 93 19         [ 2] 1162 	jp	00106$
      009308                       1163 00148$:
                                   1164 ; genIfx
      009308 4D               [ 1] 1165 	tnz	a
      009309 26 03            [ 1] 1166 	jrne	00149$
      00930B CC 93 21         [ 2] 1167 	jp	00112$
      00930E                       1168 00149$:
                           0002B9  1169 	Sstm8s_clk$CLK_ITConfig$252 ==.
                           0002B9  1170 	Sstm8s_clk$CLK_ITConfig$253 ==.
                                   1171 ;	../SPL/src/stm8s_clk.c: 484: CLK->SWCR  &= (uint8_t)(~CLK_SWCR_SWIEN);
                                   1172 ; genPointerGet
      00930E C6 50 C5         [ 1] 1173 	ld	a, 0x50c5
                                   1174 ; genAnd
      009311 A4 FB            [ 1] 1175 	and	a, #0xfb
                                   1176 ; genPointerSet
      009313 C7 50 C5         [ 1] 1177 	ld	0x50c5, a
                           0002C1  1178 	Sstm8s_clk$CLK_ITConfig$254 ==.
                                   1179 ;	../SPL/src/stm8s_clk.c: 485: break;
                                   1180 ; genGoto
      009316 CC 93 21         [ 2] 1181 	jp	00112$
                           0002C4  1182 	Sstm8s_clk$CLK_ITConfig$255 ==.
                                   1183 ;	../SPL/src/stm8s_clk.c: 486: case CLK_IT_CSSD: /* Disable the clock security system detection interrupt */
                                   1184 ; genLabel
      009319                       1185 00106$:
                           0002C4  1186 	Sstm8s_clk$CLK_ITConfig$256 ==.
                                   1187 ;	../SPL/src/stm8s_clk.c: 487: CLK->CSSR &= (uint8_t)(~CLK_CSSR_CSSDIE);
                                   1188 ; genPointerGet
      009319 C6 50 C8         [ 1] 1189 	ld	a, 0x50c8
                                   1190 ; genAnd
      00931C A4 FB            [ 1] 1191 	and	a, #0xfb
                                   1192 ; genPointerSet
      00931E C7 50 C8         [ 1] 1193 	ld	0x50c8, a
                           0002CC  1194 	Sstm8s_clk$CLK_ITConfig$257 ==.
                           0002CC  1195 	Sstm8s_clk$CLK_ITConfig$258 ==.
                                   1196 ;	../SPL/src/stm8s_clk.c: 491: }
                                   1197 ; genLabel
      009321                       1198 00112$:
                           0002CC  1199 	Sstm8s_clk$CLK_ITConfig$259 ==.
                                   1200 ;	../SPL/src/stm8s_clk.c: 493: }
                                   1201 ; genEndFunction
      009321 84               [ 1] 1202 	pop	a
                           0002CD  1203 	Sstm8s_clk$CLK_ITConfig$260 ==.
                           0002CD  1204 	Sstm8s_clk$CLK_ITConfig$261 ==.
                           0002CD  1205 	XG$CLK_ITConfig$0$0 ==.
      009322 81               [ 4] 1206 	ret
                           0002CE  1207 	Sstm8s_clk$CLK_ITConfig$262 ==.
                           0002CE  1208 	Sstm8s_clk$CLK_SYSCLKConfig$263 ==.
                                   1209 ;	../SPL/src/stm8s_clk.c: 500: void CLK_SYSCLKConfig(CLK_Prescaler_TypeDef CLK_Prescaler)
                                   1210 ; genLabel
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function CLK_SYSCLKConfig
                                   1213 ;	-----------------------------------------
                                   1214 ;	Register assignment is optimal.
                                   1215 ;	Stack space usage: 1 bytes.
      009323                       1216 _CLK_SYSCLKConfig:
                           0002CE  1217 	Sstm8s_clk$CLK_SYSCLKConfig$264 ==.
      009323 88               [ 1] 1218 	push	a
                           0002CF  1219 	Sstm8s_clk$CLK_SYSCLKConfig$265 ==.
                           0002CF  1220 	Sstm8s_clk$CLK_SYSCLKConfig$266 ==.
                                   1221 ;	../SPL/src/stm8s_clk.c: 507: CLK->CKDIVR &= (uint8_t)(~CLK_CKDIVR_HSIDIV);
                                   1222 ; genPointerGet
      009324 C6 50 C6         [ 1] 1223 	ld	a, 0x50c6
                           0002D2  1224 	Sstm8s_clk$CLK_SYSCLKConfig$267 ==.
                                   1225 ;	../SPL/src/stm8s_clk.c: 505: if (((uint8_t)CLK_Prescaler & (uint8_t)0x80) == 0x00) /* Bit7 = 0 means HSI divider */
                                   1226 ; genAnd
      009327 0D 04            [ 1] 1227 	tnz	(0x04, sp)
      009329 2A 03            [ 1] 1228 	jrpl	00111$
      00932B CC 93 44         [ 2] 1229 	jp	00102$
      00932E                       1230 00111$:
                                   1231 ; skipping generated iCode
                           0002D9  1232 	Sstm8s_clk$CLK_SYSCLKConfig$268 ==.
                           0002D9  1233 	Sstm8s_clk$CLK_SYSCLKConfig$269 ==.
                                   1234 ;	../SPL/src/stm8s_clk.c: 507: CLK->CKDIVR &= (uint8_t)(~CLK_CKDIVR_HSIDIV);
                                   1235 ; genAnd
      00932E A4 E7            [ 1] 1236 	and	a, #0xe7
                                   1237 ; genPointerSet
      009330 C7 50 C6         [ 1] 1238 	ld	0x50c6, a
                           0002DE  1239 	Sstm8s_clk$CLK_SYSCLKConfig$270 ==.
                                   1240 ;	../SPL/src/stm8s_clk.c: 508: CLK->CKDIVR |= (uint8_t)((uint8_t)CLK_Prescaler & (uint8_t)CLK_CKDIVR_HSIDIV);
                                   1241 ; genPointerGet
      009333 C6 50 C6         [ 1] 1242 	ld	a, 0x50c6
      009336 6B 01            [ 1] 1243 	ld	(0x01, sp), a
                                   1244 ; genAnd
      009338 7B 04            [ 1] 1245 	ld	a, (0x04, sp)
      00933A A4 18            [ 1] 1246 	and	a, #0x18
                                   1247 ; genOr
      00933C 1A 01            [ 1] 1248 	or	a, (0x01, sp)
                                   1249 ; genPointerSet
      00933E C7 50 C6         [ 1] 1250 	ld	0x50c6, a
                           0002EC  1251 	Sstm8s_clk$CLK_SYSCLKConfig$271 ==.
                                   1252 ; genGoto
      009341 CC 93 57         [ 2] 1253 	jp	00104$
                                   1254 ; genLabel
      009344                       1255 00102$:
                           0002EF  1256 	Sstm8s_clk$CLK_SYSCLKConfig$272 ==.
                           0002EF  1257 	Sstm8s_clk$CLK_SYSCLKConfig$273 ==.
                                   1258 ;	../SPL/src/stm8s_clk.c: 512: CLK->CKDIVR &= (uint8_t)(~CLK_CKDIVR_CPUDIV);
                                   1259 ; genAnd
      009344 A4 F8            [ 1] 1260 	and	a, #0xf8
                                   1261 ; genPointerSet
      009346 C7 50 C6         [ 1] 1262 	ld	0x50c6, a
                           0002F4  1263 	Sstm8s_clk$CLK_SYSCLKConfig$274 ==.
                                   1264 ;	../SPL/src/stm8s_clk.c: 513: CLK->CKDIVR |= (uint8_t)((uint8_t)CLK_Prescaler & (uint8_t)CLK_CKDIVR_CPUDIV);
                                   1265 ; genPointerGet
      009349 C6 50 C6         [ 1] 1266 	ld	a, 0x50c6
      00934C 6B 01            [ 1] 1267 	ld	(0x01, sp), a
                                   1268 ; genAnd
      00934E 7B 04            [ 1] 1269 	ld	a, (0x04, sp)
      009350 A4 07            [ 1] 1270 	and	a, #0x07
                                   1271 ; genOr
      009352 1A 01            [ 1] 1272 	or	a, (0x01, sp)
                                   1273 ; genPointerSet
      009354 C7 50 C6         [ 1] 1274 	ld	0x50c6, a
                           000302  1275 	Sstm8s_clk$CLK_SYSCLKConfig$275 ==.
                                   1276 ; genLabel
      009357                       1277 00104$:
                           000302  1278 	Sstm8s_clk$CLK_SYSCLKConfig$276 ==.
                                   1279 ;	../SPL/src/stm8s_clk.c: 515: }
                                   1280 ; genEndFunction
      009357 84               [ 1] 1281 	pop	a
                           000303  1282 	Sstm8s_clk$CLK_SYSCLKConfig$277 ==.
                           000303  1283 	Sstm8s_clk$CLK_SYSCLKConfig$278 ==.
                           000303  1284 	XG$CLK_SYSCLKConfig$0$0 ==.
      009358 81               [ 4] 1285 	ret
                           000304  1286 	Sstm8s_clk$CLK_SYSCLKConfig$279 ==.
                           000304  1287 	Sstm8s_clk$CLK_SWIMConfig$280 ==.
                                   1288 ;	../SPL/src/stm8s_clk.c: 523: void CLK_SWIMConfig(CLK_SWIMDivider_TypeDef CLK_SWIMDivider)
                                   1289 ; genLabel
                                   1290 ;	-----------------------------------------
                                   1291 ;	 function CLK_SWIMConfig
                                   1292 ;	-----------------------------------------
                                   1293 ;	Register assignment is optimal.
                                   1294 ;	Stack space usage: 0 bytes.
      009359                       1295 _CLK_SWIMConfig:
                           000304  1296 	Sstm8s_clk$CLK_SWIMConfig$281 ==.
                           000304  1297 	Sstm8s_clk$CLK_SWIMConfig$282 ==.
                                   1298 ;	../SPL/src/stm8s_clk.c: 531: CLK->SWIMCCR |= CLK_SWIMCCR_SWIMDIV;
                                   1299 ; genPointerGet
      009359 C6 50 CD         [ 1] 1300 	ld	a, 0x50cd
                           000307  1301 	Sstm8s_clk$CLK_SWIMConfig$283 ==.
                                   1302 ;	../SPL/src/stm8s_clk.c: 528: if (CLK_SWIMDivider != CLK_SWIMDIVIDER_2)
                                   1303 ; genIfx
      00935C 0D 03            [ 1] 1304 	tnz	(0x03, sp)
      00935E 26 03            [ 1] 1305 	jrne	00111$
      009360 CC 93 6B         [ 2] 1306 	jp	00102$
      009363                       1307 00111$:
                           00030E  1308 	Sstm8s_clk$CLK_SWIMConfig$284 ==.
                           00030E  1309 	Sstm8s_clk$CLK_SWIMConfig$285 ==.
                                   1310 ;	../SPL/src/stm8s_clk.c: 531: CLK->SWIMCCR |= CLK_SWIMCCR_SWIMDIV;
                                   1311 ; genOr
      009363 AA 01            [ 1] 1312 	or	a, #0x01
                                   1313 ; genPointerSet
      009365 C7 50 CD         [ 1] 1314 	ld	0x50cd, a
                           000313  1315 	Sstm8s_clk$CLK_SWIMConfig$286 ==.
                                   1316 ; genGoto
      009368 CC 93 70         [ 2] 1317 	jp	00104$
                                   1318 ; genLabel
      00936B                       1319 00102$:
                           000316  1320 	Sstm8s_clk$CLK_SWIMConfig$287 ==.
                           000316  1321 	Sstm8s_clk$CLK_SWIMConfig$288 ==.
                                   1322 ;	../SPL/src/stm8s_clk.c: 536: CLK->SWIMCCR &= (uint8_t)(~CLK_SWIMCCR_SWIMDIV);
                                   1323 ; genAnd
      00936B A4 FE            [ 1] 1324 	and	a, #0xfe
                                   1325 ; genPointerSet
      00936D C7 50 CD         [ 1] 1326 	ld	0x50cd, a
                           00031B  1327 	Sstm8s_clk$CLK_SWIMConfig$289 ==.
                                   1328 ; genLabel
      009370                       1329 00104$:
                           00031B  1330 	Sstm8s_clk$CLK_SWIMConfig$290 ==.
                                   1331 ;	../SPL/src/stm8s_clk.c: 538: }
                                   1332 ; genEndFunction
                           00031B  1333 	Sstm8s_clk$CLK_SWIMConfig$291 ==.
                           00031B  1334 	XG$CLK_SWIMConfig$0$0 ==.
      009370 81               [ 4] 1335 	ret
                           00031C  1336 	Sstm8s_clk$CLK_SWIMConfig$292 ==.
                           00031C  1337 	Sstm8s_clk$CLK_ClockSecuritySystemEnable$293 ==.
                                   1338 ;	../SPL/src/stm8s_clk.c: 547: void CLK_ClockSecuritySystemEnable(void)
                                   1339 ; genLabel
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function CLK_ClockSecuritySystemEnable
                                   1342 ;	-----------------------------------------
                                   1343 ;	Register assignment is optimal.
                                   1344 ;	Stack space usage: 0 bytes.
      009371                       1345 _CLK_ClockSecuritySystemEnable:
                           00031C  1346 	Sstm8s_clk$CLK_ClockSecuritySystemEnable$294 ==.
                           00031C  1347 	Sstm8s_clk$CLK_ClockSecuritySystemEnable$295 ==.
                                   1348 ;	../SPL/src/stm8s_clk.c: 550: CLK->CSSR |= CLK_CSSR_CSSEN;
                                   1349 ; genPointerGet
      009371 C6 50 C8         [ 1] 1350 	ld	a, 0x50c8
                                   1351 ; genOr
      009374 AA 01            [ 1] 1352 	or	a, #0x01
                                   1353 ; genPointerSet
      009376 C7 50 C8         [ 1] 1354 	ld	0x50c8, a
                                   1355 ; genLabel
      009379                       1356 00101$:
                           000324  1357 	Sstm8s_clk$CLK_ClockSecuritySystemEnable$296 ==.
                                   1358 ;	../SPL/src/stm8s_clk.c: 551: }
                                   1359 ; genEndFunction
                           000324  1360 	Sstm8s_clk$CLK_ClockSecuritySystemEnable$297 ==.
                           000324  1361 	XG$CLK_ClockSecuritySystemEnable$0$0 ==.
      009379 81               [ 4] 1362 	ret
                           000325  1363 	Sstm8s_clk$CLK_ClockSecuritySystemEnable$298 ==.
                           000325  1364 	Sstm8s_clk$CLK_GetSYSCLKSource$299 ==.
                                   1365 ;	../SPL/src/stm8s_clk.c: 559: CLK_Source_TypeDef CLK_GetSYSCLKSource(void)
                                   1366 ; genLabel
                                   1367 ;	-----------------------------------------
                                   1368 ;	 function CLK_GetSYSCLKSource
                                   1369 ;	-----------------------------------------
                                   1370 ;	Register assignment is optimal.
                                   1371 ;	Stack space usage: 0 bytes.
      00937A                       1372 _CLK_GetSYSCLKSource:
                           000325  1373 	Sstm8s_clk$CLK_GetSYSCLKSource$300 ==.
                           000325  1374 	Sstm8s_clk$CLK_GetSYSCLKSource$301 ==.
                                   1375 ;	../SPL/src/stm8s_clk.c: 561: return((CLK_Source_TypeDef)CLK->CMSR);
                                   1376 ; genPointerGet
      00937A C6 50 C3         [ 1] 1377 	ld	a, 0x50c3
                                   1378 ; genReturn
                                   1379 ; genLabel
      00937D                       1380 00101$:
                           000328  1381 	Sstm8s_clk$CLK_GetSYSCLKSource$302 ==.
                                   1382 ;	../SPL/src/stm8s_clk.c: 562: }
                                   1383 ; genEndFunction
                           000328  1384 	Sstm8s_clk$CLK_GetSYSCLKSource$303 ==.
                           000328  1385 	XG$CLK_GetSYSCLKSource$0$0 ==.
      00937D 81               [ 4] 1386 	ret
                           000329  1387 	Sstm8s_clk$CLK_GetSYSCLKSource$304 ==.
                           000329  1388 	Sstm8s_clk$CLK_GetClockFreq$305 ==.
                                   1389 ;	../SPL/src/stm8s_clk.c: 569: uint32_t CLK_GetClockFreq(void)
                                   1390 ; genLabel
                                   1391 ;	-----------------------------------------
                                   1392 ;	 function CLK_GetClockFreq
                                   1393 ;	-----------------------------------------
                                   1394 ;	Register assignment might be sub-optimal.
                                   1395 ;	Stack space usage: 4 bytes.
      00937E                       1396 _CLK_GetClockFreq:
                           000329  1397 	Sstm8s_clk$CLK_GetClockFreq$306 ==.
      00937E 52 04            [ 2] 1398 	sub	sp, #4
                           00032B  1399 	Sstm8s_clk$CLK_GetClockFreq$307 ==.
                           00032B  1400 	Sstm8s_clk$CLK_GetClockFreq$308 ==.
                                   1401 ;	../SPL/src/stm8s_clk.c: 576: clocksource = (CLK_Source_TypeDef)CLK->CMSR;
                                   1402 ; genPointerGet
      009380 C6 50 C3         [ 1] 1403 	ld	a, 0x50c3
      009383 6B 04            [ 1] 1404 	ld	(0x04, sp), a
                           000330  1405 	Sstm8s_clk$CLK_GetClockFreq$309 ==.
                                   1406 ;	../SPL/src/stm8s_clk.c: 578: if (clocksource == CLK_SOURCE_HSI)
                                   1407 ; genCmpEQorNE
      009385 7B 04            [ 1] 1408 	ld	a, (0x04, sp)
      009387 A1 E1            [ 1] 1409 	cp	a, #0xe1
      009389 26 03            [ 1] 1410 	jrne	00120$
      00938B CC 93 91         [ 2] 1411 	jp	00121$
      00938E                       1412 00120$:
      00938E CC 93 B9         [ 2] 1413 	jp	00105$
      009391                       1414 00121$:
                           00033C  1415 	Sstm8s_clk$CLK_GetClockFreq$310 ==.
                                   1416 ; skipping generated iCode
                           00033C  1417 	Sstm8s_clk$CLK_GetClockFreq$311 ==.
                           00033C  1418 	Sstm8s_clk$CLK_GetClockFreq$312 ==.
                                   1419 ;	../SPL/src/stm8s_clk.c: 580: tmp = (uint8_t)(CLK->CKDIVR & CLK_CKDIVR_HSIDIV);
                                   1420 ; genPointerGet
      009391 C6 50 C6         [ 1] 1421 	ld	a, 0x50c6
                                   1422 ; genAnd
      009394 A4 18            [ 1] 1423 	and	a, #0x18
                           000341  1424 	Sstm8s_clk$CLK_GetClockFreq$313 ==.
                                   1425 ;	../SPL/src/stm8s_clk.c: 581: tmp = (uint8_t)(tmp >> 3);
                                   1426 ; genRightShiftLiteral
      009396 44               [ 1] 1427 	srl	a
      009397 44               [ 1] 1428 	srl	a
      009398 44               [ 1] 1429 	srl	a
                           000344  1430 	Sstm8s_clk$CLK_GetClockFreq$314 ==.
                                   1431 ;	../SPL/src/stm8s_clk.c: 582: presc = HSIDivFactor[tmp];
                                   1432 ; skipping iCode since result will be rematerialized
                                   1433 ; genPlus
      009399 5F               [ 1] 1434 	clrw	x
      00939A 97               [ 1] 1435 	ld	xl, a
      00939B 1C 80 B4         [ 2] 1436 	addw	x, #(_HSIDivFactor+0)
                                   1437 ; genPointerGet
      00939E F6               [ 1] 1438 	ld	a, (x)
                           00034A  1439 	Sstm8s_clk$CLK_GetClockFreq$315 ==.
                                   1440 ;	../SPL/src/stm8s_clk.c: 583: clockfrequency = HSI_VALUE / presc;
                                   1441 ; genCast
                                   1442 ; genAssign
      00939F 5F               [ 1] 1443 	clrw	x
      0093A0 97               [ 1] 1444 	ld	xl, a
      0093A1 90 5F            [ 1] 1445 	clrw	y
                           00034E  1446 	Sstm8s_clk$CLK_GetClockFreq$316 ==.
                                   1447 ; genIPush
      0093A3 89               [ 2] 1448 	pushw	x
                           00034F  1449 	Sstm8s_clk$CLK_GetClockFreq$317 ==.
      0093A4 90 89            [ 2] 1450 	pushw	y
                           000351  1451 	Sstm8s_clk$CLK_GetClockFreq$318 ==.
                                   1452 ; genIPush
      0093A6 4B 00            [ 1] 1453 	push	#0x00
                           000353  1454 	Sstm8s_clk$CLK_GetClockFreq$319 ==.
      0093A8 4B 24            [ 1] 1455 	push	#0x24
                           000355  1456 	Sstm8s_clk$CLK_GetClockFreq$320 ==.
      0093AA 4B F4            [ 1] 1457 	push	#0xf4
                           000357  1458 	Sstm8s_clk$CLK_GetClockFreq$321 ==.
      0093AC 4B 00            [ 1] 1459 	push	#0x00
                           000359  1460 	Sstm8s_clk$CLK_GetClockFreq$322 ==.
                                   1461 ; genCall
      0093AE CD A4 4C         [ 4] 1462 	call	__divulong
      0093B1 5B 08            [ 2] 1463 	addw	sp, #8
                           00035E  1464 	Sstm8s_clk$CLK_GetClockFreq$323 ==.
      0093B3 51               [ 1] 1465 	exgw	x, y
                                   1466 ; genAssign
      0093B4 17 03            [ 2] 1467 	ldw	(0x03, sp), y
                                   1468 ; genGoto
      0093B6 CC 93 D7         [ 2] 1469 	jp	00106$
                                   1470 ; genLabel
      0093B9                       1471 00105$:
                           000364  1472 	Sstm8s_clk$CLK_GetClockFreq$324 ==.
                                   1473 ;	../SPL/src/stm8s_clk.c: 585: else if ( clocksource == CLK_SOURCE_LSI)
                                   1474 ; genCmpEQorNE
      0093B9 7B 04            [ 1] 1475 	ld	a, (0x04, sp)
      0093BB A1 D2            [ 1] 1476 	cp	a, #0xd2
      0093BD 26 03            [ 1] 1477 	jrne	00123$
      0093BF CC 93 C5         [ 2] 1478 	jp	00124$
      0093C2                       1479 00123$:
      0093C2 CC 93 CF         [ 2] 1480 	jp	00102$
      0093C5                       1481 00124$:
                           000370  1482 	Sstm8s_clk$CLK_GetClockFreq$325 ==.
                                   1483 ; skipping generated iCode
                           000370  1484 	Sstm8s_clk$CLK_GetClockFreq$326 ==.
                           000370  1485 	Sstm8s_clk$CLK_GetClockFreq$327 ==.
                                   1486 ;	../SPL/src/stm8s_clk.c: 587: clockfrequency = LSI_VALUE;
                                   1487 ; genAssign
      0093C5 AE F4 00         [ 2] 1488 	ldw	x, #0xf400
      0093C8 1F 03            [ 2] 1489 	ldw	(0x03, sp), x
      0093CA 5F               [ 1] 1490 	clrw	x
      0093CB 5C               [ 1] 1491 	incw	x
                           000377  1492 	Sstm8s_clk$CLK_GetClockFreq$328 ==.
                                   1493 ; genGoto
      0093CC CC 93 D7         [ 2] 1494 	jp	00106$
                                   1495 ; genLabel
      0093CF                       1496 00102$:
                           00037A  1497 	Sstm8s_clk$CLK_GetClockFreq$329 ==.
                           00037A  1498 	Sstm8s_clk$CLK_GetClockFreq$330 ==.
                                   1499 ;	../SPL/src/stm8s_clk.c: 591: clockfrequency = HSE_VALUE;
                                   1500 ; genAssign
      0093CF AE 36 00         [ 2] 1501 	ldw	x, #0x3600
      0093D2 1F 03            [ 2] 1502 	ldw	(0x03, sp), x
      0093D4 AE 01 6E         [ 2] 1503 	ldw	x, #0x016e
                           000382  1504 	Sstm8s_clk$CLK_GetClockFreq$331 ==.
                                   1505 ; genLabel
      0093D7                       1506 00106$:
                           000382  1507 	Sstm8s_clk$CLK_GetClockFreq$332 ==.
                                   1508 ;	../SPL/src/stm8s_clk.c: 594: return((uint32_t)clockfrequency);
                                   1509 ; genReturn
      0093D7 51               [ 1] 1510 	exgw	x, y
      0093D8 1E 03            [ 2] 1511 	ldw	x, (0x03, sp)
                                   1512 ; genLabel
      0093DA                       1513 00107$:
                           000385  1514 	Sstm8s_clk$CLK_GetClockFreq$333 ==.
                                   1515 ;	../SPL/src/stm8s_clk.c: 595: }
                                   1516 ; genEndFunction
      0093DA 5B 04            [ 2] 1517 	addw	sp, #4
                           000387  1518 	Sstm8s_clk$CLK_GetClockFreq$334 ==.
                           000387  1519 	Sstm8s_clk$CLK_GetClockFreq$335 ==.
                           000387  1520 	XG$CLK_GetClockFreq$0$0 ==.
      0093DC 81               [ 4] 1521 	ret
                           000388  1522 	Sstm8s_clk$CLK_GetClockFreq$336 ==.
                           000388  1523 	Sstm8s_clk$CLK_AdjustHSICalibrationValue$337 ==.
                                   1524 ;	../SPL/src/stm8s_clk.c: 604: void CLK_AdjustHSICalibrationValue(CLK_HSITrimValue_TypeDef CLK_HSICalibrationValue)
                                   1525 ; genLabel
                                   1526 ;	-----------------------------------------
                                   1527 ;	 function CLK_AdjustHSICalibrationValue
                                   1528 ;	-----------------------------------------
                                   1529 ;	Register assignment is optimal.
                                   1530 ;	Stack space usage: 0 bytes.
      0093DD                       1531 _CLK_AdjustHSICalibrationValue:
                           000388  1532 	Sstm8s_clk$CLK_AdjustHSICalibrationValue$338 ==.
                           000388  1533 	Sstm8s_clk$CLK_AdjustHSICalibrationValue$339 ==.
                                   1534 ;	../SPL/src/stm8s_clk.c: 610: CLK->HSITRIMR = (uint8_t)( (uint8_t)(CLK->HSITRIMR & (uint8_t)(~CLK_HSITRIMR_HSITRIM))|((uint8_t)CLK_HSICalibrationValue));
                                   1535 ; genPointerGet
      0093DD C6 50 CC         [ 1] 1536 	ld	a, 0x50cc
                                   1537 ; genAnd
      0093E0 A4 F8            [ 1] 1538 	and	a, #0xf8
                                   1539 ; genOr
      0093E2 1A 03            [ 1] 1540 	or	a, (0x03, sp)
                                   1541 ; genPointerSet
      0093E4 C7 50 CC         [ 1] 1542 	ld	0x50cc, a
                                   1543 ; genLabel
      0093E7                       1544 00101$:
                           000392  1545 	Sstm8s_clk$CLK_AdjustHSICalibrationValue$340 ==.
                                   1546 ;	../SPL/src/stm8s_clk.c: 611: }
                                   1547 ; genEndFunction
                           000392  1548 	Sstm8s_clk$CLK_AdjustHSICalibrationValue$341 ==.
                           000392  1549 	XG$CLK_AdjustHSICalibrationValue$0$0 ==.
      0093E7 81               [ 4] 1550 	ret
                           000393  1551 	Sstm8s_clk$CLK_AdjustHSICalibrationValue$342 ==.
                           000393  1552 	Sstm8s_clk$CLK_SYSCLKEmergencyClear$343 ==.
                                   1553 ;	../SPL/src/stm8s_clk.c: 622: void CLK_SYSCLKEmergencyClear(void)
                                   1554 ; genLabel
                                   1555 ;	-----------------------------------------
                                   1556 ;	 function CLK_SYSCLKEmergencyClear
                                   1557 ;	-----------------------------------------
                                   1558 ;	Register assignment is optimal.
                                   1559 ;	Stack space usage: 0 bytes.
      0093E8                       1560 _CLK_SYSCLKEmergencyClear:
                           000393  1561 	Sstm8s_clk$CLK_SYSCLKEmergencyClear$344 ==.
                           000393  1562 	Sstm8s_clk$CLK_SYSCLKEmergencyClear$345 ==.
                                   1563 ;	../SPL/src/stm8s_clk.c: 624: CLK->SWCR &= (uint8_t)(~CLK_SWCR_SWBSY);
                                   1564 ; genPointerGet
      0093E8 C6 50 C5         [ 1] 1565 	ld	a, 0x50c5
                                   1566 ; genAnd
      0093EB A4 FE            [ 1] 1567 	and	a, #0xfe
                                   1568 ; genPointerSet
      0093ED C7 50 C5         [ 1] 1569 	ld	0x50c5, a
                                   1570 ; genLabel
      0093F0                       1571 00101$:
                           00039B  1572 	Sstm8s_clk$CLK_SYSCLKEmergencyClear$346 ==.
                                   1573 ;	../SPL/src/stm8s_clk.c: 625: }
                                   1574 ; genEndFunction
                           00039B  1575 	Sstm8s_clk$CLK_SYSCLKEmergencyClear$347 ==.
                           00039B  1576 	XG$CLK_SYSCLKEmergencyClear$0$0 ==.
      0093F0 81               [ 4] 1577 	ret
                           00039C  1578 	Sstm8s_clk$CLK_SYSCLKEmergencyClear$348 ==.
                           00039C  1579 	Sstm8s_clk$CLK_GetFlagStatus$349 ==.
                                   1580 ;	../SPL/src/stm8s_clk.c: 634: FlagStatus CLK_GetFlagStatus(CLK_Flag_TypeDef CLK_FLAG)
                                   1581 ; genLabel
                                   1582 ;	-----------------------------------------
                                   1583 ;	 function CLK_GetFlagStatus
                                   1584 ;	-----------------------------------------
                                   1585 ;	Register assignment might be sub-optimal.
                                   1586 ;	Stack space usage: 1 bytes.
      0093F1                       1587 _CLK_GetFlagStatus:
                           00039C  1588 	Sstm8s_clk$CLK_GetFlagStatus$350 ==.
      0093F1 88               [ 1] 1589 	push	a
                           00039D  1590 	Sstm8s_clk$CLK_GetFlagStatus$351 ==.
                           00039D  1591 	Sstm8s_clk$CLK_GetFlagStatus$352 ==.
                                   1592 ;	../SPL/src/stm8s_clk.c: 644: statusreg = (uint16_t)((uint16_t)CLK_FLAG & (uint16_t)0xFF00);
                                   1593 ; genCast
                                   1594 ; genAssign
      0093F2 1E 04            [ 2] 1595 	ldw	x, (0x04, sp)
                                   1596 ; genAnd
      0093F4 4F               [ 1] 1597 	clr	a
                                   1598 ; genAssign
                           0003A0  1599 	Sstm8s_clk$CLK_GetFlagStatus$353 ==.
                                   1600 ;	../SPL/src/stm8s_clk.c: 647: if (statusreg == 0x0100) /* The flag to check is in ICKRregister */
                                   1601 ; genCast
                                   1602 ; genAssign
      0093F5 97               [ 1] 1603 	ld	xl, a
                                   1604 ; genCmpEQorNE
      0093F6 A3 01 00         [ 2] 1605 	cpw	x, #0x0100
      0093F9 26 03            [ 1] 1606 	jrne	00144$
      0093FB CC 94 01         [ 2] 1607 	jp	00145$
      0093FE                       1608 00144$:
      0093FE CC 94 07         [ 2] 1609 	jp	00111$
      009401                       1610 00145$:
                           0003AC  1611 	Sstm8s_clk$CLK_GetFlagStatus$354 ==.
                                   1612 ; skipping generated iCode
                           0003AC  1613 	Sstm8s_clk$CLK_GetFlagStatus$355 ==.
                           0003AC  1614 	Sstm8s_clk$CLK_GetFlagStatus$356 ==.
                                   1615 ;	../SPL/src/stm8s_clk.c: 649: tmpreg = CLK->ICKR;
                                   1616 ; genPointerGet
      009401 C6 50 C0         [ 1] 1617 	ld	a, 0x50c0
                           0003AF  1618 	Sstm8s_clk$CLK_GetFlagStatus$357 ==.
                                   1619 ; genGoto
      009404 CC 94 3D         [ 2] 1620 	jp	00112$
                                   1621 ; genLabel
      009407                       1622 00111$:
                           0003B2  1623 	Sstm8s_clk$CLK_GetFlagStatus$358 ==.
                                   1624 ;	../SPL/src/stm8s_clk.c: 651: else if (statusreg == 0x0200) /* The flag to check is in ECKRregister */
                                   1625 ; genCmpEQorNE
      009407 A3 02 00         [ 2] 1626 	cpw	x, #0x0200
      00940A 26 03            [ 1] 1627 	jrne	00147$
      00940C CC 94 12         [ 2] 1628 	jp	00148$
      00940F                       1629 00147$:
      00940F CC 94 18         [ 2] 1630 	jp	00108$
      009412                       1631 00148$:
                           0003BD  1632 	Sstm8s_clk$CLK_GetFlagStatus$359 ==.
                                   1633 ; skipping generated iCode
                           0003BD  1634 	Sstm8s_clk$CLK_GetFlagStatus$360 ==.
                           0003BD  1635 	Sstm8s_clk$CLK_GetFlagStatus$361 ==.
                                   1636 ;	../SPL/src/stm8s_clk.c: 653: tmpreg = CLK->ECKR;
                                   1637 ; genPointerGet
      009412 C6 50 C1         [ 1] 1638 	ld	a, 0x50c1
                           0003C0  1639 	Sstm8s_clk$CLK_GetFlagStatus$362 ==.
                                   1640 ; genGoto
      009415 CC 94 3D         [ 2] 1641 	jp	00112$
                                   1642 ; genLabel
      009418                       1643 00108$:
                           0003C3  1644 	Sstm8s_clk$CLK_GetFlagStatus$363 ==.
                                   1645 ;	../SPL/src/stm8s_clk.c: 655: else if (statusreg == 0x0300) /* The flag to check is in SWIC register */
                                   1646 ; genCmpEQorNE
      009418 A3 03 00         [ 2] 1647 	cpw	x, #0x0300
      00941B 26 03            [ 1] 1648 	jrne	00150$
      00941D CC 94 23         [ 2] 1649 	jp	00151$
      009420                       1650 00150$:
      009420 CC 94 29         [ 2] 1651 	jp	00105$
      009423                       1652 00151$:
                           0003CE  1653 	Sstm8s_clk$CLK_GetFlagStatus$364 ==.
                                   1654 ; skipping generated iCode
                           0003CE  1655 	Sstm8s_clk$CLK_GetFlagStatus$365 ==.
                           0003CE  1656 	Sstm8s_clk$CLK_GetFlagStatus$366 ==.
                                   1657 ;	../SPL/src/stm8s_clk.c: 657: tmpreg = CLK->SWCR;
                                   1658 ; genPointerGet
      009423 C6 50 C5         [ 1] 1659 	ld	a, 0x50c5
                           0003D1  1660 	Sstm8s_clk$CLK_GetFlagStatus$367 ==.
                                   1661 ; genGoto
      009426 CC 94 3D         [ 2] 1662 	jp	00112$
                                   1663 ; genLabel
      009429                       1664 00105$:
                           0003D4  1665 	Sstm8s_clk$CLK_GetFlagStatus$368 ==.
                                   1666 ;	../SPL/src/stm8s_clk.c: 659: else if (statusreg == 0x0400) /* The flag to check is in CSS register */
                                   1667 ; genCmpEQorNE
      009429 A3 04 00         [ 2] 1668 	cpw	x, #0x0400
      00942C 26 03            [ 1] 1669 	jrne	00153$
      00942E CC 94 34         [ 2] 1670 	jp	00154$
      009431                       1671 00153$:
      009431 CC 94 3A         [ 2] 1672 	jp	00102$
      009434                       1673 00154$:
                           0003DF  1674 	Sstm8s_clk$CLK_GetFlagStatus$369 ==.
                                   1675 ; skipping generated iCode
                           0003DF  1676 	Sstm8s_clk$CLK_GetFlagStatus$370 ==.
                           0003DF  1677 	Sstm8s_clk$CLK_GetFlagStatus$371 ==.
                                   1678 ;	../SPL/src/stm8s_clk.c: 661: tmpreg = CLK->CSSR;
                                   1679 ; genPointerGet
      009434 C6 50 C8         [ 1] 1680 	ld	a, 0x50c8
                           0003E2  1681 	Sstm8s_clk$CLK_GetFlagStatus$372 ==.
                                   1682 ; genGoto
      009437 CC 94 3D         [ 2] 1683 	jp	00112$
                                   1684 ; genLabel
      00943A                       1685 00102$:
                           0003E5  1686 	Sstm8s_clk$CLK_GetFlagStatus$373 ==.
                           0003E5  1687 	Sstm8s_clk$CLK_GetFlagStatus$374 ==.
                                   1688 ;	../SPL/src/stm8s_clk.c: 665: tmpreg = CLK->CCOR;
                                   1689 ; genPointerGet
      00943A C6 50 C9         [ 1] 1690 	ld	a, 0x50c9
                           0003E8  1691 	Sstm8s_clk$CLK_GetFlagStatus$375 ==.
                                   1692 ; genLabel
      00943D                       1693 00112$:
                           0003E8  1694 	Sstm8s_clk$CLK_GetFlagStatus$376 ==.
                                   1695 ;	../SPL/src/stm8s_clk.c: 668: if ((tmpreg & (uint8_t)CLK_FLAG) != (uint8_t)RESET)
                                   1696 ; genCast
                                   1697 ; genAssign
      00943D 88               [ 1] 1698 	push	a
                           0003E9  1699 	Sstm8s_clk$CLK_GetFlagStatus$377 ==.
      00943E 7B 06            [ 1] 1700 	ld	a, (0x06, sp)
      009440 6B 02            [ 1] 1701 	ld	(0x02, sp), a
      009442 84               [ 1] 1702 	pop	a
                           0003EE  1703 	Sstm8s_clk$CLK_GetFlagStatus$378 ==.
                                   1704 ; genAnd
      009443 14 01            [ 1] 1705 	and	a, (0x01, sp)
                                   1706 ; genIfx
      009445 4D               [ 1] 1707 	tnz	a
      009446 26 03            [ 1] 1708 	jrne	00155$
      009448 CC 94 50         [ 2] 1709 	jp	00114$
      00944B                       1710 00155$:
                           0003F6  1711 	Sstm8s_clk$CLK_GetFlagStatus$379 ==.
                           0003F6  1712 	Sstm8s_clk$CLK_GetFlagStatus$380 ==.
                                   1713 ;	../SPL/src/stm8s_clk.c: 670: bitstatus = SET;
                                   1714 ; genAssign
      00944B A6 01            [ 1] 1715 	ld	a, #0x01
                           0003F8  1716 	Sstm8s_clk$CLK_GetFlagStatus$381 ==.
                                   1717 ; genGoto
      00944D CC 94 51         [ 2] 1718 	jp	00115$
                                   1719 ; genLabel
      009450                       1720 00114$:
                           0003FB  1721 	Sstm8s_clk$CLK_GetFlagStatus$382 ==.
                           0003FB  1722 	Sstm8s_clk$CLK_GetFlagStatus$383 ==.
                                   1723 ;	../SPL/src/stm8s_clk.c: 674: bitstatus = RESET;
                                   1724 ; genAssign
      009450 4F               [ 1] 1725 	clr	a
                           0003FC  1726 	Sstm8s_clk$CLK_GetFlagStatus$384 ==.
                                   1727 ; genLabel
      009451                       1728 00115$:
                           0003FC  1729 	Sstm8s_clk$CLK_GetFlagStatus$385 ==.
                                   1730 ;	../SPL/src/stm8s_clk.c: 678: return((FlagStatus)bitstatus);
                                   1731 ; genReturn
                                   1732 ; genLabel
      009451                       1733 00116$:
                           0003FC  1734 	Sstm8s_clk$CLK_GetFlagStatus$386 ==.
                                   1735 ;	../SPL/src/stm8s_clk.c: 679: }
                                   1736 ; genEndFunction
      009451 5B 01            [ 2] 1737 	addw	sp, #1
                           0003FE  1738 	Sstm8s_clk$CLK_GetFlagStatus$387 ==.
                           0003FE  1739 	Sstm8s_clk$CLK_GetFlagStatus$388 ==.
                           0003FE  1740 	XG$CLK_GetFlagStatus$0$0 ==.
      009453 81               [ 4] 1741 	ret
                           0003FF  1742 	Sstm8s_clk$CLK_GetFlagStatus$389 ==.
                           0003FF  1743 	Sstm8s_clk$CLK_GetITStatus$390 ==.
                                   1744 ;	../SPL/src/stm8s_clk.c: 687: ITStatus CLK_GetITStatus(CLK_IT_TypeDef CLK_IT)
                                   1745 ; genLabel
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function CLK_GetITStatus
                                   1748 ;	-----------------------------------------
                                   1749 ;	Register assignment is optimal.
                                   1750 ;	Stack space usage: 0 bytes.
      009454                       1751 _CLK_GetITStatus:
                           0003FF  1752 	Sstm8s_clk$CLK_GetITStatus$391 ==.
                           0003FF  1753 	Sstm8s_clk$CLK_GetITStatus$392 ==.
                                   1754 ;	../SPL/src/stm8s_clk.c: 694: if (CLK_IT == CLK_IT_SWIF)
                                   1755 ; genCmpEQorNE
      009454 7B 03            [ 1] 1756 	ld	a, (0x03, sp)
      009456 A1 1C            [ 1] 1757 	cp	a, #0x1c
      009458 26 03            [ 1] 1758 	jrne	00128$
      00945A CC 94 60         [ 2] 1759 	jp	00129$
      00945D                       1760 00128$:
      00945D CC 94 78         [ 2] 1761 	jp	00108$
      009460                       1762 00129$:
                           00040B  1763 	Sstm8s_clk$CLK_GetITStatus$393 ==.
                                   1764 ; skipping generated iCode
                           00040B  1765 	Sstm8s_clk$CLK_GetITStatus$394 ==.
                           00040B  1766 	Sstm8s_clk$CLK_GetITStatus$395 ==.
                                   1767 ;	../SPL/src/stm8s_clk.c: 697: if ((CLK->SWCR & (uint8_t)CLK_IT) == (uint8_t)0x0C)
                                   1768 ; genPointerGet
      009460 C6 50 C5         [ 1] 1769 	ld	a, 0x50c5
                                   1770 ; genAnd
      009463 14 03            [ 1] 1771 	and	a, (0x03, sp)
                                   1772 ; genCmpEQorNE
      009465 A1 0C            [ 1] 1773 	cp	a, #0x0c
      009467 26 03            [ 1] 1774 	jrne	00131$
      009469 CC 94 6F         [ 2] 1775 	jp	00132$
      00946C                       1776 00131$:
      00946C CC 94 74         [ 2] 1777 	jp	00102$
      00946F                       1778 00132$:
                           00041A  1779 	Sstm8s_clk$CLK_GetITStatus$396 ==.
                                   1780 ; skipping generated iCode
                           00041A  1781 	Sstm8s_clk$CLK_GetITStatus$397 ==.
                           00041A  1782 	Sstm8s_clk$CLK_GetITStatus$398 ==.
                                   1783 ;	../SPL/src/stm8s_clk.c: 699: bitstatus = SET;
                                   1784 ; genAssign
      00946F A6 01            [ 1] 1785 	ld	a, #0x01
                           00041C  1786 	Sstm8s_clk$CLK_GetITStatus$399 ==.
                                   1787 ; genGoto
      009471 CC 94 8D         [ 2] 1788 	jp	00109$
                                   1789 ; genLabel
      009474                       1790 00102$:
                           00041F  1791 	Sstm8s_clk$CLK_GetITStatus$400 ==.
                           00041F  1792 	Sstm8s_clk$CLK_GetITStatus$401 ==.
                                   1793 ;	../SPL/src/stm8s_clk.c: 703: bitstatus = RESET;
                                   1794 ; genAssign
      009474 4F               [ 1] 1795 	clr	a
                           000420  1796 	Sstm8s_clk$CLK_GetITStatus$402 ==.
                                   1797 ; genGoto
      009475 CC 94 8D         [ 2] 1798 	jp	00109$
                                   1799 ; genLabel
      009478                       1800 00108$:
                           000423  1801 	Sstm8s_clk$CLK_GetITStatus$403 ==.
                           000423  1802 	Sstm8s_clk$CLK_GetITStatus$404 ==.
                                   1803 ;	../SPL/src/stm8s_clk.c: 709: if ((CLK->CSSR & (uint8_t)CLK_IT) == (uint8_t)0x0C)
                                   1804 ; genPointerGet
      009478 C6 50 C8         [ 1] 1805 	ld	a, 0x50c8
                                   1806 ; genAnd
      00947B 14 03            [ 1] 1807 	and	a, (0x03, sp)
                                   1808 ; genCmpEQorNE
      00947D A1 0C            [ 1] 1809 	cp	a, #0x0c
      00947F 26 03            [ 1] 1810 	jrne	00134$
      009481 CC 94 87         [ 2] 1811 	jp	00135$
      009484                       1812 00134$:
      009484 CC 94 8C         [ 2] 1813 	jp	00105$
      009487                       1814 00135$:
                           000432  1815 	Sstm8s_clk$CLK_GetITStatus$405 ==.
                                   1816 ; skipping generated iCode
                           000432  1817 	Sstm8s_clk$CLK_GetITStatus$406 ==.
                           000432  1818 	Sstm8s_clk$CLK_GetITStatus$407 ==.
                                   1819 ;	../SPL/src/stm8s_clk.c: 711: bitstatus = SET;
                                   1820 ; genAssign
      009487 A6 01            [ 1] 1821 	ld	a, #0x01
                           000434  1822 	Sstm8s_clk$CLK_GetITStatus$408 ==.
                                   1823 ; genGoto
      009489 CC 94 8D         [ 2] 1824 	jp	00109$
                                   1825 ; genLabel
      00948C                       1826 00105$:
                           000437  1827 	Sstm8s_clk$CLK_GetITStatus$409 ==.
                           000437  1828 	Sstm8s_clk$CLK_GetITStatus$410 ==.
                                   1829 ;	../SPL/src/stm8s_clk.c: 715: bitstatus = RESET;
                                   1830 ; genAssign
      00948C 4F               [ 1] 1831 	clr	a
                           000438  1832 	Sstm8s_clk$CLK_GetITStatus$411 ==.
                                   1833 ; genLabel
      00948D                       1834 00109$:
                           000438  1835 	Sstm8s_clk$CLK_GetITStatus$412 ==.
                                   1836 ;	../SPL/src/stm8s_clk.c: 720: return bitstatus;
                                   1837 ; genReturn
                                   1838 ; genLabel
      00948D                       1839 00110$:
                           000438  1840 	Sstm8s_clk$CLK_GetITStatus$413 ==.
                                   1841 ;	../SPL/src/stm8s_clk.c: 721: }
                                   1842 ; genEndFunction
                           000438  1843 	Sstm8s_clk$CLK_GetITStatus$414 ==.
                           000438  1844 	XG$CLK_GetITStatus$0$0 ==.
      00948D 81               [ 4] 1845 	ret
                           000439  1846 	Sstm8s_clk$CLK_GetITStatus$415 ==.
                           000439  1847 	Sstm8s_clk$CLK_ClearITPendingBit$416 ==.
                                   1848 ;	../SPL/src/stm8s_clk.c: 729: void CLK_ClearITPendingBit(CLK_IT_TypeDef CLK_IT)
                                   1849 ; genLabel
                                   1850 ;	-----------------------------------------
                                   1851 ;	 function CLK_ClearITPendingBit
                                   1852 ;	-----------------------------------------
                                   1853 ;	Register assignment is optimal.
                                   1854 ;	Stack space usage: 0 bytes.
      00948E                       1855 _CLK_ClearITPendingBit:
                           000439  1856 	Sstm8s_clk$CLK_ClearITPendingBit$417 ==.
                           000439  1857 	Sstm8s_clk$CLK_ClearITPendingBit$418 ==.
                                   1858 ;	../SPL/src/stm8s_clk.c: 734: if (CLK_IT == (uint8_t)CLK_IT_CSSD)
                                   1859 ; genCmpEQorNE
      00948E 7B 03            [ 1] 1860 	ld	a, (0x03, sp)
      009490 A1 0C            [ 1] 1861 	cp	a, #0x0c
      009492 26 03            [ 1] 1862 	jrne	00112$
      009494 CC 94 9A         [ 2] 1863 	jp	00113$
      009497                       1864 00112$:
      009497 CC 94 A5         [ 2] 1865 	jp	00102$
      00949A                       1866 00113$:
                           000445  1867 	Sstm8s_clk$CLK_ClearITPendingBit$419 ==.
                                   1868 ; skipping generated iCode
                           000445  1869 	Sstm8s_clk$CLK_ClearITPendingBit$420 ==.
                           000445  1870 	Sstm8s_clk$CLK_ClearITPendingBit$421 ==.
                                   1871 ;	../SPL/src/stm8s_clk.c: 737: CLK->CSSR &= (uint8_t)(~CLK_CSSR_CSSD);
                                   1872 ; genPointerGet
      00949A C6 50 C8         [ 1] 1873 	ld	a, 0x50c8
                                   1874 ; genAnd
      00949D A4 F7            [ 1] 1875 	and	a, #0xf7
                                   1876 ; genPointerSet
      00949F C7 50 C8         [ 1] 1877 	ld	0x50c8, a
                           00044D  1878 	Sstm8s_clk$CLK_ClearITPendingBit$422 ==.
                                   1879 ; genGoto
      0094A2 CC 94 AD         [ 2] 1880 	jp	00104$
                                   1881 ; genLabel
      0094A5                       1882 00102$:
                           000450  1883 	Sstm8s_clk$CLK_ClearITPendingBit$423 ==.
                           000450  1884 	Sstm8s_clk$CLK_ClearITPendingBit$424 ==.
                                   1885 ;	../SPL/src/stm8s_clk.c: 742: CLK->SWCR &= (uint8_t)(~CLK_SWCR_SWIF);
                                   1886 ; genPointerGet
      0094A5 C6 50 C5         [ 1] 1887 	ld	a, 0x50c5
                                   1888 ; genAnd
      0094A8 A4 F7            [ 1] 1889 	and	a, #0xf7
                                   1890 ; genPointerSet
      0094AA C7 50 C5         [ 1] 1891 	ld	0x50c5, a
                           000458  1892 	Sstm8s_clk$CLK_ClearITPendingBit$425 ==.
                                   1893 ; genLabel
      0094AD                       1894 00104$:
                           000458  1895 	Sstm8s_clk$CLK_ClearITPendingBit$426 ==.
                                   1896 ;	../SPL/src/stm8s_clk.c: 745: }
                                   1897 ; genEndFunction
                           000458  1898 	Sstm8s_clk$CLK_ClearITPendingBit$427 ==.
                           000458  1899 	XG$CLK_ClearITPendingBit$0$0 ==.
      0094AD 81               [ 4] 1900 	ret
                           000459  1901 	Sstm8s_clk$CLK_ClearITPendingBit$428 ==.
                                   1902 	.area CODE
                                   1903 	.area CONST
                           000000  1904 G$HSIDivFactor$0_0$0 == .
      0080B4                       1905 _HSIDivFactor:
      0080B4 01                    1906 	.db #0x01	; 1
      0080B5 02                    1907 	.db #0x02	; 2
      0080B6 04                    1908 	.db #0x04	; 4
      0080B7 08                    1909 	.db #0x08	; 8
                           000004  1910 G$CLKPrescTable$0_0$0 == .
      0080B8                       1911 _CLKPrescTable:
      0080B8 01                    1912 	.db #0x01	; 1
      0080B9 02                    1913 	.db #0x02	; 2
      0080BA 04                    1914 	.db #0x04	; 4
      0080BB 08                    1915 	.db #0x08	; 8
      0080BC 0A                    1916 	.db #0x0a	; 10
      0080BD 10                    1917 	.db #0x10	; 16
      0080BE 14                    1918 	.db #0x14	; 20
      0080BF 28                    1919 	.db #0x28	; 40
                                   1920 	.area INITIALIZER
                                   1921 	.area CABS (ABS)
                                   1922 
                                   1923 	.area .debug_line (NOLOAD)
      0016E5 00 00 06 24           1924 	.dw	0,Ldebug_line_end-Ldebug_line_start
      0016E9                       1925 Ldebug_line_start:
      0016E9 00 02                 1926 	.dw	2
      0016EB 00 00 00 77           1927 	.dw	0,Ldebug_line_stmt-6-Ldebug_line_start
      0016EF 01                    1928 	.db	1
      0016F0 01                    1929 	.db	1
      0016F1 FB                    1930 	.db	-5
      0016F2 0F                    1931 	.db	15
      0016F3 0A                    1932 	.db	10
      0016F4 00                    1933 	.db	0
      0016F5 01                    1934 	.db	1
      0016F6 01                    1935 	.db	1
      0016F7 01                    1936 	.db	1
      0016F8 01                    1937 	.db	1
      0016F9 00                    1938 	.db	0
      0016FA 00                    1939 	.db	0
      0016FB 00                    1940 	.db	0
      0016FC 01                    1941 	.db	1
      0016FD 43 3A 5C 50 72 6F 67  1942 	.ascii "C:\Program Files\SDCC\bin\..\include\stm8"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
             5C 73 74 6D 38
      001725 00                    1943 	.db	0
      001726 43 3A 5C 50 72 6F 67  1944 	.ascii "C:\Program Files\SDCC\bin\..\include"
             72 61 6D 20 46 69 6C
             65 73 5C 53 44 43 43
             08 69 6E 5C 2E 2E 5C
             69 6E 63 6C 75 64 65
      001749 00                    1945 	.db	0
      00174A 00                    1946 	.db	0
      00174B 2E 2E 2F 53 50 4C 2F  1947 	.ascii "../SPL/src/stm8s_clk.c"
             73 72 63 2F 73 74 6D
             38 73 5F 63 6C 6B 2E
             63
      001761 00                    1948 	.db	0
      001762 00                    1949 	.uleb128	0
      001763 00                    1950 	.uleb128	0
      001764 00                    1951 	.uleb128	0
      001765 00                    1952 	.db	0
      001766                       1953 Ldebug_line_stmt:
      001766 00                    1954 	.db	0
      001767 05                    1955 	.uleb128	5
      001768 02                    1956 	.db	2
      001769 00 00 90 55           1957 	.dw	0,(Sstm8s_clk$CLK_DeInit$0)
      00176D 03                    1958 	.db	3
      00176E C7 00                 1959 	.sleb128	71
      001770 01                    1960 	.db	1
      001771 09                    1961 	.db	9
      001772 00 00                 1962 	.dw	Sstm8s_clk$CLK_DeInit$2-Sstm8s_clk$CLK_DeInit$0
      001774 03                    1963 	.db	3
      001775 02                    1964 	.sleb128	2
      001776 01                    1965 	.db	1
      001777 09                    1966 	.db	9
      001778 00 04                 1967 	.dw	Sstm8s_clk$CLK_DeInit$3-Sstm8s_clk$CLK_DeInit$2
      00177A 03                    1968 	.db	3
      00177B 01                    1969 	.sleb128	1
      00177C 01                    1970 	.db	1
      00177D 09                    1971 	.db	9
      00177E 00 04                 1972 	.dw	Sstm8s_clk$CLK_DeInit$4-Sstm8s_clk$CLK_DeInit$3
      001780 03                    1973 	.db	3
      001781 01                    1974 	.sleb128	1
      001782 01                    1975 	.db	1
      001783 09                    1976 	.db	9
      001784 00 04                 1977 	.dw	Sstm8s_clk$CLK_DeInit$5-Sstm8s_clk$CLK_DeInit$4
      001786 03                    1978 	.db	3
      001787 01                    1979 	.sleb128	1
      001788 01                    1980 	.db	1
      001789 09                    1981 	.db	9
      00178A 00 04                 1982 	.dw	Sstm8s_clk$CLK_DeInit$6-Sstm8s_clk$CLK_DeInit$5
      00178C 03                    1983 	.db	3
      00178D 01                    1984 	.sleb128	1
      00178E 01                    1985 	.db	1
      00178F 09                    1986 	.db	9
      001790 00 04                 1987 	.dw	Sstm8s_clk$CLK_DeInit$7-Sstm8s_clk$CLK_DeInit$6
      001792 03                    1988 	.db	3
      001793 01                    1989 	.sleb128	1
      001794 01                    1990 	.db	1
      001795 09                    1991 	.db	9
      001796 00 04                 1992 	.dw	Sstm8s_clk$CLK_DeInit$8-Sstm8s_clk$CLK_DeInit$7
      001798 03                    1993 	.db	3
      001799 01                    1994 	.sleb128	1
      00179A 01                    1995 	.db	1
      00179B 09                    1996 	.db	9
      00179C 00 04                 1997 	.dw	Sstm8s_clk$CLK_DeInit$9-Sstm8s_clk$CLK_DeInit$8
      00179E 03                    1998 	.db	3
      00179F 01                    1999 	.sleb128	1
      0017A0 01                    2000 	.db	1
      0017A1 09                    2001 	.db	9
      0017A2 00 04                 2002 	.dw	Sstm8s_clk$CLK_DeInit$10-Sstm8s_clk$CLK_DeInit$9
      0017A4 03                    2003 	.db	3
      0017A5 01                    2004 	.sleb128	1
      0017A6 01                    2005 	.db	1
      0017A7 09                    2006 	.db	9
      0017A8 00 04                 2007 	.dw	Sstm8s_clk$CLK_DeInit$11-Sstm8s_clk$CLK_DeInit$10
      0017AA 03                    2008 	.db	3
      0017AB 01                    2009 	.sleb128	1
      0017AC 01                    2010 	.db	1
      0017AD 09                    2011 	.db	9
      0017AE 00 09                 2012 	.dw	Sstm8s_clk$CLK_DeInit$12-Sstm8s_clk$CLK_DeInit$11
      0017B0 03                    2013 	.db	3
      0017B1 02                    2014 	.sleb128	2
      0017B2 01                    2015 	.db	1
      0017B3 09                    2016 	.db	9
      0017B4 00 04                 2017 	.dw	Sstm8s_clk$CLK_DeInit$13-Sstm8s_clk$CLK_DeInit$12
      0017B6 03                    2018 	.db	3
      0017B7 01                    2019 	.sleb128	1
      0017B8 01                    2020 	.db	1
      0017B9 09                    2021 	.db	9
      0017BA 00 04                 2022 	.dw	Sstm8s_clk$CLK_DeInit$14-Sstm8s_clk$CLK_DeInit$13
      0017BC 03                    2023 	.db	3
      0017BD 01                    2024 	.sleb128	1
      0017BE 01                    2025 	.db	1
      0017BF 09                    2026 	.db	9
      0017C0 00 04                 2027 	.dw	Sstm8s_clk$CLK_DeInit$15-Sstm8s_clk$CLK_DeInit$14
      0017C2 03                    2028 	.db	3
      0017C3 01                    2029 	.sleb128	1
      0017C4 01                    2030 	.db	1
      0017C5 09                    2031 	.db	9
      0017C6 00 01                 2032 	.dw	1+Sstm8s_clk$CLK_DeInit$16-Sstm8s_clk$CLK_DeInit$15
      0017C8 00                    2033 	.db	0
      0017C9 01                    2034 	.uleb128	1
      0017CA 01                    2035 	.db	1
      0017CB 00                    2036 	.db	0
      0017CC 05                    2037 	.uleb128	5
      0017CD 02                    2038 	.db	2
      0017CE 00 00 90 8F           2039 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$18)
      0017D2 03                    2040 	.db	3
      0017D3 E2 00                 2041 	.sleb128	98
      0017D5 01                    2042 	.db	1
      0017D6 09                    2043 	.db	9
      0017D7 00 00                 2044 	.dw	Sstm8s_clk$CLK_FastHaltWakeUpCmd$20-Sstm8s_clk$CLK_FastHaltWakeUpCmd$18
      0017D9 03                    2045 	.db	3
      0017DA 08                    2046 	.sleb128	8
      0017DB 01                    2047 	.db	1
      0017DC 09                    2048 	.db	9
      0017DD 00 03                 2049 	.dw	Sstm8s_clk$CLK_FastHaltWakeUpCmd$21-Sstm8s_clk$CLK_FastHaltWakeUpCmd$20
      0017DF 03                    2050 	.db	3
      0017E0 7D                    2051 	.sleb128	-3
      0017E1 01                    2052 	.db	1
      0017E2 09                    2053 	.db	9
      0017E3 00 07                 2054 	.dw	Sstm8s_clk$CLK_FastHaltWakeUpCmd$23-Sstm8s_clk$CLK_FastHaltWakeUpCmd$21
      0017E5 03                    2055 	.db	3
      0017E6 03                    2056 	.sleb128	3
      0017E7 01                    2057 	.db	1
      0017E8 09                    2058 	.db	9
      0017E9 00 08                 2059 	.dw	Sstm8s_clk$CLK_FastHaltWakeUpCmd$26-Sstm8s_clk$CLK_FastHaltWakeUpCmd$23
      0017EB 03                    2060 	.db	3
      0017EC 05                    2061 	.sleb128	5
      0017ED 01                    2062 	.db	1
      0017EE 09                    2063 	.db	9
      0017EF 00 05                 2064 	.dw	Sstm8s_clk$CLK_FastHaltWakeUpCmd$28-Sstm8s_clk$CLK_FastHaltWakeUpCmd$26
      0017F1 03                    2065 	.db	3
      0017F2 02                    2066 	.sleb128	2
      0017F3 01                    2067 	.db	1
      0017F4 09                    2068 	.db	9
      0017F5 00 01                 2069 	.dw	1+Sstm8s_clk$CLK_FastHaltWakeUpCmd$29-Sstm8s_clk$CLK_FastHaltWakeUpCmd$28
      0017F7 00                    2070 	.db	0
      0017F8 01                    2071 	.uleb128	1
      0017F9 01                    2072 	.db	1
      0017FA 00                    2073 	.db	0
      0017FB 05                    2074 	.uleb128	5
      0017FC 02                    2075 	.db	2
      0017FD 00 00 90 A7           2076 	.dw	0,(Sstm8s_clk$CLK_HSECmd$31)
      001801 03                    2077 	.db	3
      001802 F8 00                 2078 	.sleb128	120
      001804 01                    2079 	.db	1
      001805 09                    2080 	.db	9
      001806 00 00                 2081 	.dw	Sstm8s_clk$CLK_HSECmd$33-Sstm8s_clk$CLK_HSECmd$31
      001808 03                    2082 	.db	3
      001809 08                    2083 	.sleb128	8
      00180A 01                    2084 	.db	1
      00180B 09                    2085 	.db	9
      00180C 00 03                 2086 	.dw	Sstm8s_clk$CLK_HSECmd$34-Sstm8s_clk$CLK_HSECmd$33
      00180E 03                    2087 	.db	3
      00180F 7D                    2088 	.sleb128	-3
      001810 01                    2089 	.db	1
      001811 09                    2090 	.db	9
      001812 00 07                 2091 	.dw	Sstm8s_clk$CLK_HSECmd$36-Sstm8s_clk$CLK_HSECmd$34
      001814 03                    2092 	.db	3
      001815 03                    2093 	.sleb128	3
      001816 01                    2094 	.db	1
      001817 09                    2095 	.db	9
      001818 00 08                 2096 	.dw	Sstm8s_clk$CLK_HSECmd$39-Sstm8s_clk$CLK_HSECmd$36
      00181A 03                    2097 	.db	3
      00181B 05                    2098 	.sleb128	5
      00181C 01                    2099 	.db	1
      00181D 09                    2100 	.db	9
      00181E 00 05                 2101 	.dw	Sstm8s_clk$CLK_HSECmd$41-Sstm8s_clk$CLK_HSECmd$39
      001820 03                    2102 	.db	3
      001821 02                    2103 	.sleb128	2
      001822 01                    2104 	.db	1
      001823 09                    2105 	.db	9
      001824 00 01                 2106 	.dw	1+Sstm8s_clk$CLK_HSECmd$42-Sstm8s_clk$CLK_HSECmd$41
      001826 00                    2107 	.db	0
      001827 01                    2108 	.uleb128	1
      001828 01                    2109 	.db	1
      001829 00                    2110 	.db	0
      00182A 05                    2111 	.uleb128	5
      00182B 02                    2112 	.db	2
      00182C 00 00 90 BF           2113 	.dw	0,(Sstm8s_clk$CLK_HSICmd$44)
      001830 03                    2114 	.db	3
      001831 8E 01                 2115 	.sleb128	142
      001833 01                    2116 	.db	1
      001834 09                    2117 	.db	9
      001835 00 00                 2118 	.dw	Sstm8s_clk$CLK_HSICmd$46-Sstm8s_clk$CLK_HSICmd$44
      001837 03                    2119 	.db	3
      001838 08                    2120 	.sleb128	8
      001839 01                    2121 	.db	1
      00183A 09                    2122 	.db	9
      00183B 00 03                 2123 	.dw	Sstm8s_clk$CLK_HSICmd$47-Sstm8s_clk$CLK_HSICmd$46
      00183D 03                    2124 	.db	3
      00183E 7D                    2125 	.sleb128	-3
      00183F 01                    2126 	.db	1
      001840 09                    2127 	.db	9
      001841 00 07                 2128 	.dw	Sstm8s_clk$CLK_HSICmd$49-Sstm8s_clk$CLK_HSICmd$47
      001843 03                    2129 	.db	3
      001844 03                    2130 	.sleb128	3
      001845 01                    2131 	.db	1
      001846 09                    2132 	.db	9
      001847 00 08                 2133 	.dw	Sstm8s_clk$CLK_HSICmd$52-Sstm8s_clk$CLK_HSICmd$49
      001849 03                    2134 	.db	3
      00184A 05                    2135 	.sleb128	5
      00184B 01                    2136 	.db	1
      00184C 09                    2137 	.db	9
      00184D 00 05                 2138 	.dw	Sstm8s_clk$CLK_HSICmd$54-Sstm8s_clk$CLK_HSICmd$52
      00184F 03                    2139 	.db	3
      001850 02                    2140 	.sleb128	2
      001851 01                    2141 	.db	1
      001852 09                    2142 	.db	9
      001853 00 01                 2143 	.dw	1+Sstm8s_clk$CLK_HSICmd$55-Sstm8s_clk$CLK_HSICmd$54
      001855 00                    2144 	.db	0
      001856 01                    2145 	.uleb128	1
      001857 01                    2146 	.db	1
      001858 00                    2147 	.db	0
      001859 05                    2148 	.uleb128	5
      00185A 02                    2149 	.db	2
      00185B 00 00 90 D7           2150 	.dw	0,(Sstm8s_clk$CLK_LSICmd$57)
      00185F 03                    2151 	.db	3
      001860 A5 01                 2152 	.sleb128	165
      001862 01                    2153 	.db	1
      001863 09                    2154 	.db	9
      001864 00 00                 2155 	.dw	Sstm8s_clk$CLK_LSICmd$59-Sstm8s_clk$CLK_LSICmd$57
      001866 03                    2156 	.db	3
      001867 08                    2157 	.sleb128	8
      001868 01                    2158 	.db	1
      001869 09                    2159 	.db	9
      00186A 00 03                 2160 	.dw	Sstm8s_clk$CLK_LSICmd$60-Sstm8s_clk$CLK_LSICmd$59
      00186C 03                    2161 	.db	3
      00186D 7D                    2162 	.sleb128	-3
      00186E 01                    2163 	.db	1
      00186F 09                    2164 	.db	9
      001870 00 07                 2165 	.dw	Sstm8s_clk$CLK_LSICmd$62-Sstm8s_clk$CLK_LSICmd$60
      001872 03                    2166 	.db	3
      001873 03                    2167 	.sleb128	3
      001874 01                    2168 	.db	1
      001875 09                    2169 	.db	9
      001876 00 08                 2170 	.dw	Sstm8s_clk$CLK_LSICmd$65-Sstm8s_clk$CLK_LSICmd$62
      001878 03                    2171 	.db	3
      001879 05                    2172 	.sleb128	5
      00187A 01                    2173 	.db	1
      00187B 09                    2174 	.db	9
      00187C 00 05                 2175 	.dw	Sstm8s_clk$CLK_LSICmd$67-Sstm8s_clk$CLK_LSICmd$65
      00187E 03                    2176 	.db	3
      00187F 02                    2177 	.sleb128	2
      001880 01                    2178 	.db	1
      001881 09                    2179 	.db	9
      001882 00 01                 2180 	.dw	1+Sstm8s_clk$CLK_LSICmd$68-Sstm8s_clk$CLK_LSICmd$67
      001884 00                    2181 	.db	0
      001885 01                    2182 	.uleb128	1
      001886 01                    2183 	.db	1
      001887 00                    2184 	.db	0
      001888 05                    2185 	.uleb128	5
      001889 02                    2186 	.db	2
      00188A 00 00 90 EF           2187 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$70)
      00188E 03                    2188 	.db	3
      00188F BC 01                 2189 	.sleb128	188
      001891 01                    2190 	.db	1
      001892 09                    2191 	.db	9
      001893 00 00                 2192 	.dw	Sstm8s_clk$CLK_CCOCmd$72-Sstm8s_clk$CLK_CCOCmd$70
      001895 03                    2193 	.db	3
      001896 08                    2194 	.sleb128	8
      001897 01                    2195 	.db	1
      001898 09                    2196 	.db	9
      001899 00 03                 2197 	.dw	Sstm8s_clk$CLK_CCOCmd$73-Sstm8s_clk$CLK_CCOCmd$72
      00189B 03                    2198 	.db	3
      00189C 7D                    2199 	.sleb128	-3
      00189D 01                    2200 	.db	1
      00189E 09                    2201 	.db	9
      00189F 00 07                 2202 	.dw	Sstm8s_clk$CLK_CCOCmd$75-Sstm8s_clk$CLK_CCOCmd$73
      0018A1 03                    2203 	.db	3
      0018A2 03                    2204 	.sleb128	3
      0018A3 01                    2205 	.db	1
      0018A4 09                    2206 	.db	9
      0018A5 00 08                 2207 	.dw	Sstm8s_clk$CLK_CCOCmd$78-Sstm8s_clk$CLK_CCOCmd$75
      0018A7 03                    2208 	.db	3
      0018A8 05                    2209 	.sleb128	5
      0018A9 01                    2210 	.db	1
      0018AA 09                    2211 	.db	9
      0018AB 00 05                 2212 	.dw	Sstm8s_clk$CLK_CCOCmd$80-Sstm8s_clk$CLK_CCOCmd$78
      0018AD 03                    2213 	.db	3
      0018AE 02                    2214 	.sleb128	2
      0018AF 01                    2215 	.db	1
      0018B0 09                    2216 	.db	9
      0018B1 00 01                 2217 	.dw	1+Sstm8s_clk$CLK_CCOCmd$81-Sstm8s_clk$CLK_CCOCmd$80
      0018B3 00                    2218 	.db	0
      0018B4 01                    2219 	.uleb128	1
      0018B5 01                    2220 	.db	1
      0018B6 00                    2221 	.db	0
      0018B7 05                    2222 	.uleb128	5
      0018B8 02                    2223 	.db	2
      0018B9 00 00 91 07           2224 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$83)
      0018BD 03                    2225 	.db	3
      0018BE D4 01                 2226 	.sleb128	212
      0018C0 01                    2227 	.db	1
      0018C1 09                    2228 	.db	9
      0018C2 00 00                 2229 	.dw	Sstm8s_clk$CLK_ClockSwitchCmd$85-Sstm8s_clk$CLK_ClockSwitchCmd$83
      0018C4 03                    2230 	.db	3
      0018C5 08                    2231 	.sleb128	8
      0018C6 01                    2232 	.db	1
      0018C7 09                    2233 	.db	9
      0018C8 00 03                 2234 	.dw	Sstm8s_clk$CLK_ClockSwitchCmd$86-Sstm8s_clk$CLK_ClockSwitchCmd$85
      0018CA 03                    2235 	.db	3
      0018CB 7D                    2236 	.sleb128	-3
      0018CC 01                    2237 	.db	1
      0018CD 09                    2238 	.db	9
      0018CE 00 07                 2239 	.dw	Sstm8s_clk$CLK_ClockSwitchCmd$88-Sstm8s_clk$CLK_ClockSwitchCmd$86
      0018D0 03                    2240 	.db	3
      0018D1 03                    2241 	.sleb128	3
      0018D2 01                    2242 	.db	1
      0018D3 09                    2243 	.db	9
      0018D4 00 08                 2244 	.dw	Sstm8s_clk$CLK_ClockSwitchCmd$91-Sstm8s_clk$CLK_ClockSwitchCmd$88
      0018D6 03                    2245 	.db	3
      0018D7 05                    2246 	.sleb128	5
      0018D8 01                    2247 	.db	1
      0018D9 09                    2248 	.db	9
      0018DA 00 05                 2249 	.dw	Sstm8s_clk$CLK_ClockSwitchCmd$93-Sstm8s_clk$CLK_ClockSwitchCmd$91
      0018DC 03                    2250 	.db	3
      0018DD 02                    2251 	.sleb128	2
      0018DE 01                    2252 	.db	1
      0018DF 09                    2253 	.db	9
      0018E0 00 01                 2254 	.dw	1+Sstm8s_clk$CLK_ClockSwitchCmd$94-Sstm8s_clk$CLK_ClockSwitchCmd$93
      0018E2 00                    2255 	.db	0
      0018E3 01                    2256 	.uleb128	1
      0018E4 01                    2257 	.db	1
      0018E5 00                    2258 	.db	0
      0018E6 05                    2259 	.uleb128	5
      0018E7 02                    2260 	.db	2
      0018E8 00 00 91 1F           2261 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$96)
      0018EC 03                    2262 	.db	3
      0018ED ED 01                 2263 	.sleb128	237
      0018EF 01                    2264 	.db	1
      0018F0 09                    2265 	.db	9
      0018F1 00 00                 2266 	.dw	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$98-Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$96
      0018F3 03                    2267 	.db	3
      0018F4 08                    2268 	.sleb128	8
      0018F5 01                    2269 	.db	1
      0018F6 09                    2270 	.db	9
      0018F7 00 03                 2271 	.dw	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$99-Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$98
      0018F9 03                    2272 	.db	3
      0018FA 7D                    2273 	.sleb128	-3
      0018FB 01                    2274 	.db	1
      0018FC 09                    2275 	.db	9
      0018FD 00 07                 2276 	.dw	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$101-Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$99
      0018FF 03                    2277 	.db	3
      001900 03                    2278 	.sleb128	3
      001901 01                    2279 	.db	1
      001902 09                    2280 	.db	9
      001903 00 08                 2281 	.dw	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$104-Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$101
      001905 03                    2282 	.db	3
      001906 05                    2283 	.sleb128	5
      001907 01                    2284 	.db	1
      001908 09                    2285 	.db	9
      001909 00 05                 2286 	.dw	Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$106-Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$104
      00190B 03                    2287 	.db	3
      00190C 02                    2288 	.sleb128	2
      00190D 01                    2289 	.db	1
      00190E 09                    2290 	.db	9
      00190F 00 01                 2291 	.dw	1+Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$107-Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$106
      001911 00                    2292 	.db	0
      001912 01                    2293 	.uleb128	1
      001913 01                    2294 	.db	1
      001914 00                    2295 	.db	0
      001915 05                    2296 	.uleb128	5
      001916 02                    2297 	.db	2
      001917 00 00 91 37           2298 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$109)
      00191B 03                    2299 	.db	3
      00191C 86 02                 2300 	.sleb128	262
      00191E 01                    2301 	.db	1
      00191F 09                    2302 	.db	9
      001920 00 01                 2303 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$112-Sstm8s_clk$CLK_PeripheralClockConfig$109
      001922 03                    2304 	.db	3
      001923 0B                    2305 	.sleb128	11
      001924 01                    2306 	.db	1
      001925 09                    2307 	.db	9
      001926 00 12                 2308 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$115-Sstm8s_clk$CLK_PeripheralClockConfig$112
      001928 03                    2309 	.db	3
      001929 05                    2310 	.sleb128	5
      00192A 01                    2311 	.db	1
      00192B 09                    2312 	.db	9
      00192C 00 05                 2313 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$116-Sstm8s_clk$CLK_PeripheralClockConfig$115
      00192E 03                    2314 	.db	3
      00192F 76                    2315 	.sleb128	-10
      001930 01                    2316 	.db	1
      001931 09                    2317 	.db	9
      001932 00 09                 2318 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$117-Sstm8s_clk$CLK_PeripheralClockConfig$116
      001934 03                    2319 	.db	3
      001935 05                    2320 	.sleb128	5
      001936 01                    2321 	.db	1
      001937 09                    2322 	.db	9
      001938 00 03                 2323 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$119-Sstm8s_clk$CLK_PeripheralClockConfig$117
      00193A 03                    2324 	.db	3
      00193B 7D                    2325 	.sleb128	-3
      00193C 01                    2326 	.db	1
      00193D 09                    2327 	.db	9
      00193E 00 07                 2328 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$121-Sstm8s_clk$CLK_PeripheralClockConfig$119
      001940 03                    2329 	.db	3
      001941 03                    2330 	.sleb128	3
      001942 01                    2331 	.db	1
      001943 09                    2332 	.db	9
      001944 00 08                 2333 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$124-Sstm8s_clk$CLK_PeripheralClockConfig$121
      001946 03                    2334 	.db	3
      001947 05                    2335 	.sleb128	5
      001948 01                    2336 	.db	1
      001949 09                    2337 	.db	9
      00194A 00 08                 2338 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$126-Sstm8s_clk$CLK_PeripheralClockConfig$124
      00194C 03                    2339 	.db	3
      00194D 08                    2340 	.sleb128	8
      00194E 01                    2341 	.db	1
      00194F 09                    2342 	.db	9
      001950 00 03                 2343 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$128-Sstm8s_clk$CLK_PeripheralClockConfig$126
      001952 03                    2344 	.db	3
      001953 7D                    2345 	.sleb128	-3
      001954 01                    2346 	.db	1
      001955 09                    2347 	.db	9
      001956 00 07                 2348 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$130-Sstm8s_clk$CLK_PeripheralClockConfig$128
      001958 03                    2349 	.db	3
      001959 03                    2350 	.sleb128	3
      00195A 01                    2351 	.db	1
      00195B 09                    2352 	.db	9
      00195C 00 08                 2353 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$133-Sstm8s_clk$CLK_PeripheralClockConfig$130
      00195E 03                    2354 	.db	3
      00195F 05                    2355 	.sleb128	5
      001960 01                    2356 	.db	1
      001961 09                    2357 	.db	9
      001962 00 05                 2358 	.dw	Sstm8s_clk$CLK_PeripheralClockConfig$135-Sstm8s_clk$CLK_PeripheralClockConfig$133
      001964 03                    2359 	.db	3
      001965 03                    2360 	.sleb128	3
      001966 01                    2361 	.db	1
      001967 09                    2362 	.db	9
      001968 00 02                 2363 	.dw	1+Sstm8s_clk$CLK_PeripheralClockConfig$137-Sstm8s_clk$CLK_PeripheralClockConfig$135
      00196A 00                    2364 	.db	0
      00196B 01                    2365 	.uleb128	1
      00196C 01                    2366 	.db	1
      00196D 00                    2367 	.db	0
      00196E 05                    2368 	.uleb128	5
      00196F 02                    2369 	.db	2
      001970 00 00 91 8B           2370 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$139)
      001974 03                    2371 	.db	3
      001975 B4 02                 2372 	.sleb128	308
      001977 01                    2373 	.db	1
      001978 09                    2374 	.db	9
      001979 00 01                 2375 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$142-Sstm8s_clk$CLK_ClockSwitchConfig$139
      00197B 03                    2376 	.db	3
      00197C 03                    2377 	.sleb128	3
      00197D 01                    2378 	.db	1
      00197E 09                    2379 	.db	9
      00197F 00 02                 2380 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$143-Sstm8s_clk$CLK_ClockSwitchConfig$142
      001981 03                    2381 	.db	3
      001982 0A                    2382 	.sleb128	10
      001983 01                    2383 	.db	1
      001984 09                    2384 	.db	9
      001985 00 05                 2385 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$144-Sstm8s_clk$CLK_ClockSwitchConfig$143
      001987 03                    2386 	.db	3
      001988 06                    2387 	.sleb128	6
      001989 01                    2388 	.db	1
      00198A 09                    2389 	.db	9
      00198B 00 03                 2390 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$145-Sstm8s_clk$CLK_ClockSwitchConfig$144
      00198D 03                    2391 	.db	3
      00198E 7D                    2392 	.sleb128	-3
      00198F 01                    2393 	.db	1
      001990 09                    2394 	.db	9
      001991 00 0D                 2395 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$150-Sstm8s_clk$CLK_ClockSwitchConfig$145
      001993 03                    2396 	.db	3
      001994 03                    2397 	.sleb128	3
      001995 01                    2398 	.db	1
      001996 09                    2399 	.db	9
      001997 00 08                 2400 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$152-Sstm8s_clk$CLK_ClockSwitchConfig$150
      001999 03                    2401 	.db	3
      00199A 03                    2402 	.sleb128	3
      00199B 01                    2403 	.db	1
      00199C 09                    2404 	.db	9
      00199D 00 07                 2405 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$154-Sstm8s_clk$CLK_ClockSwitchConfig$152
      00199F 03                    2406 	.db	3
      0019A0 02                    2407 	.sleb128	2
      0019A1 01                    2408 	.db	1
      0019A2 09                    2409 	.db	9
      0019A3 00 08                 2410 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$157-Sstm8s_clk$CLK_ClockSwitchConfig$154
      0019A5 03                    2411 	.db	3
      0019A6 04                    2412 	.sleb128	4
      0019A7 01                    2413 	.db	1
      0019A8 09                    2414 	.db	9
      0019A9 00 05                 2415 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$159-Sstm8s_clk$CLK_ClockSwitchConfig$157
      0019AB 03                    2416 	.db	3
      0019AC 04                    2417 	.sleb128	4
      0019AD 01                    2418 	.db	1
      0019AE 09                    2419 	.db	9
      0019AF 00 08                 2420 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$161-Sstm8s_clk$CLK_ClockSwitchConfig$159
      0019B1 03                    2421 	.db	3
      0019B2 03                    2422 	.sleb128	3
      0019B3 01                    2423 	.db	1
      0019B4 09                    2424 	.db	9
      0019B5 00 0F                 2425 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$163-Sstm8s_clk$CLK_ClockSwitchConfig$161
      0019B7 03                    2426 	.db	3
      0019B8 02                    2427 	.sleb128	2
      0019B9 01                    2428 	.db	1
      0019BA 09                    2429 	.db	9
      0019BB 00 04                 2430 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$166-Sstm8s_clk$CLK_ClockSwitchConfig$163
      0019BD 03                    2431 	.db	3
      0019BE 03                    2432 	.sleb128	3
      0019BF 01                    2433 	.db	1
      0019C0 09                    2434 	.db	9
      0019C1 00 06                 2435 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$168-Sstm8s_clk$CLK_ClockSwitchConfig$166
      0019C3 03                    2436 	.db	3
      0019C4 02                    2437 	.sleb128	2
      0019C5 01                    2438 	.db	1
      0019C6 09                    2439 	.db	9
      0019C7 00 06                 2440 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$171-Sstm8s_clk$CLK_ClockSwitchConfig$168
      0019C9 03                    2441 	.db	3
      0019CA 04                    2442 	.sleb128	4
      0019CB 01                    2443 	.db	1
      0019CC 09                    2444 	.db	9
      0019CD 00 04                 2445 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$174-Sstm8s_clk$CLK_ClockSwitchConfig$171
      0019CF 03                    2446 	.db	3
      0019D0 06                    2447 	.sleb128	6
      0019D1 01                    2448 	.db	1
      0019D2 09                    2449 	.db	9
      0019D3 00 07                 2450 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$176-Sstm8s_clk$CLK_ClockSwitchConfig$174
      0019D5 03                    2451 	.db	3
      0019D6 02                    2452 	.sleb128	2
      0019D7 01                    2453 	.db	1
      0019D8 09                    2454 	.db	9
      0019D9 00 08                 2455 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$179-Sstm8s_clk$CLK_ClockSwitchConfig$176
      0019DB 03                    2456 	.db	3
      0019DC 04                    2457 	.sleb128	4
      0019DD 01                    2458 	.db	1
      0019DE 09                    2459 	.db	9
      0019DF 00 05                 2460 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$181-Sstm8s_clk$CLK_ClockSwitchConfig$179
      0019E1 03                    2461 	.db	3
      0019E2 04                    2462 	.sleb128	4
      0019E3 01                    2463 	.db	1
      0019E4 09                    2464 	.db	9
      0019E5 00 08                 2465 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$183-Sstm8s_clk$CLK_ClockSwitchConfig$181
      0019E7 03                    2466 	.db	3
      0019E8 03                    2467 	.sleb128	3
      0019E9 01                    2468 	.db	1
      0019EA 09                    2469 	.db	9
      0019EB 00 10                 2470 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$185-Sstm8s_clk$CLK_ClockSwitchConfig$183
      0019ED 03                    2471 	.db	3
      0019EE 02                    2472 	.sleb128	2
      0019EF 01                    2473 	.db	1
      0019F0 09                    2474 	.db	9
      0019F1 00 04                 2475 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$188-Sstm8s_clk$CLK_ClockSwitchConfig$185
      0019F3 03                    2476 	.db	3
      0019F4 03                    2477 	.sleb128	3
      0019F5 01                    2478 	.db	1
      0019F6 09                    2479 	.db	9
      0019F7 00 06                 2480 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$190-Sstm8s_clk$CLK_ClockSwitchConfig$188
      0019F9 03                    2481 	.db	3
      0019FA 03                    2482 	.sleb128	3
      0019FB 01                    2483 	.db	1
      0019FC 09                    2484 	.db	9
      0019FD 00 08                 2485 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$191-Sstm8s_clk$CLK_ClockSwitchConfig$190
      0019FF 03                    2486 	.db	3
      001A00 01                    2487 	.sleb128	1
      001A01 01                    2488 	.db	1
      001A02 09                    2489 	.db	9
      001A03 00 06                 2490 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$194-Sstm8s_clk$CLK_ClockSwitchConfig$191
      001A05 03                    2491 	.db	3
      001A06 04                    2492 	.sleb128	4
      001A07 01                    2493 	.db	1
      001A08 09                    2494 	.db	9
      001A09 00 01                 2495 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$196-Sstm8s_clk$CLK_ClockSwitchConfig$194
      001A0B 03                    2496 	.db	3
      001A0C 03                    2497 	.sleb128	3
      001A0D 01                    2498 	.db	1
      001A0E 09                    2499 	.db	9
      001A0F 00 07                 2500 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$198-Sstm8s_clk$CLK_ClockSwitchConfig$196
      001A11 03                    2501 	.db	3
      001A12 03                    2502 	.sleb128	3
      001A13 01                    2503 	.db	1
      001A14 09                    2504 	.db	9
      001A15 00 13                 2505 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$201-Sstm8s_clk$CLK_ClockSwitchConfig$198
      001A17 03                    2506 	.db	3
      001A18 02                    2507 	.sleb128	2
      001A19 01                    2508 	.db	1
      001A1A 09                    2509 	.db	9
      001A1B 00 0B                 2510 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$203-Sstm8s_clk$CLK_ClockSwitchConfig$201
      001A1D 03                    2511 	.db	3
      001A1E 02                    2512 	.sleb128	2
      001A1F 01                    2513 	.db	1
      001A20 09                    2514 	.db	9
      001A21 00 13                 2515 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$206-Sstm8s_clk$CLK_ClockSwitchConfig$203
      001A23 03                    2516 	.db	3
      001A24 02                    2517 	.sleb128	2
      001A25 01                    2518 	.db	1
      001A26 09                    2519 	.db	9
      001A27 00 0B                 2520 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$208-Sstm8s_clk$CLK_ClockSwitchConfig$206
      001A29 03                    2521 	.db	3
      001A2A 02                    2522 	.sleb128	2
      001A2B 01                    2523 	.db	1
      001A2C 09                    2524 	.db	9
      001A2D 00 13                 2525 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$211-Sstm8s_clk$CLK_ClockSwitchConfig$208
      001A2F 03                    2526 	.db	3
      001A30 02                    2527 	.sleb128	2
      001A31 01                    2528 	.db	1
      001A32 09                    2529 	.db	9
      001A33 00 08                 2530 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$213-Sstm8s_clk$CLK_ClockSwitchConfig$211
      001A35 03                    2531 	.db	3
      001A36 03                    2532 	.sleb128	3
      001A37 01                    2533 	.db	1
      001A38 09                    2534 	.db	9
      001A39 00 01                 2535 	.dw	Sstm8s_clk$CLK_ClockSwitchConfig$214-Sstm8s_clk$CLK_ClockSwitchConfig$213
      001A3B 03                    2536 	.db	3
      001A3C 01                    2537 	.sleb128	1
      001A3D 01                    2538 	.db	1
      001A3E 09                    2539 	.db	9
      001A3F 00 03                 2540 	.dw	1+Sstm8s_clk$CLK_ClockSwitchConfig$216-Sstm8s_clk$CLK_ClockSwitchConfig$214
      001A41 00                    2541 	.db	0
      001A42 01                    2542 	.uleb128	1
      001A43 01                    2543 	.db	1
      001A44 00                    2544 	.db	0
      001A45 05                    2545 	.uleb128	5
      001A46 02                    2546 	.db	2
      001A47 00 00 92 91           2547 	.dw	0,(Sstm8s_clk$CLK_HSIPrescalerConfig$218)
      001A4B 03                    2548 	.db	3
      001A4C 9E 03                 2549 	.sleb128	414
      001A4E 01                    2550 	.db	1
      001A4F 09                    2551 	.db	9
      001A50 00 00                 2552 	.dw	Sstm8s_clk$CLK_HSIPrescalerConfig$220-Sstm8s_clk$CLK_HSIPrescalerConfig$218
      001A52 03                    2553 	.db	3
      001A53 06                    2554 	.sleb128	6
      001A54 01                    2555 	.db	1
      001A55 09                    2556 	.db	9
      001A56 00 08                 2557 	.dw	Sstm8s_clk$CLK_HSIPrescalerConfig$221-Sstm8s_clk$CLK_HSIPrescalerConfig$220
      001A58 03                    2558 	.db	3
      001A59 03                    2559 	.sleb128	3
      001A5A 01                    2560 	.db	1
      001A5B 09                    2561 	.db	9
      001A5C 00 08                 2562 	.dw	Sstm8s_clk$CLK_HSIPrescalerConfig$222-Sstm8s_clk$CLK_HSIPrescalerConfig$221
      001A5E 03                    2563 	.db	3
      001A5F 01                    2564 	.sleb128	1
      001A60 01                    2565 	.db	1
      001A61 09                    2566 	.db	9
      001A62 00 01                 2567 	.dw	1+Sstm8s_clk$CLK_HSIPrescalerConfig$223-Sstm8s_clk$CLK_HSIPrescalerConfig$222
      001A64 00                    2568 	.db	0
      001A65 01                    2569 	.uleb128	1
      001A66 01                    2570 	.db	1
      001A67 00                    2571 	.db	0
      001A68 05                    2572 	.uleb128	5
      001A69 02                    2573 	.db	2
      001A6A 00 00 92 A2           2574 	.dw	0,(Sstm8s_clk$CLK_CCOConfig$225)
      001A6E 03                    2575 	.db	3
      001A6F B3 03                 2576 	.sleb128	435
      001A71 01                    2577 	.db	1
      001A72 09                    2578 	.db	9
      001A73 00 00                 2579 	.dw	Sstm8s_clk$CLK_CCOConfig$227-Sstm8s_clk$CLK_CCOConfig$225
      001A75 03                    2580 	.db	3
      001A76 06                    2581 	.sleb128	6
      001A77 01                    2582 	.db	1
      001A78 09                    2583 	.db	9
      001A79 00 08                 2584 	.dw	Sstm8s_clk$CLK_CCOConfig$228-Sstm8s_clk$CLK_CCOConfig$227
      001A7B 03                    2585 	.db	3
      001A7C 03                    2586 	.sleb128	3
      001A7D 01                    2587 	.db	1
      001A7E 09                    2588 	.db	9
      001A7F 00 08                 2589 	.dw	Sstm8s_clk$CLK_CCOConfig$229-Sstm8s_clk$CLK_CCOConfig$228
      001A81 03                    2590 	.db	3
      001A82 03                    2591 	.sleb128	3
      001A83 01                    2592 	.db	1
      001A84 09                    2593 	.db	9
      001A85 00 08                 2594 	.dw	Sstm8s_clk$CLK_CCOConfig$230-Sstm8s_clk$CLK_CCOConfig$229
      001A87 03                    2595 	.db	3
      001A88 01                    2596 	.sleb128	1
      001A89 01                    2597 	.db	1
      001A8A 09                    2598 	.db	9
      001A8B 00 01                 2599 	.dw	1+Sstm8s_clk$CLK_CCOConfig$231-Sstm8s_clk$CLK_CCOConfig$230
      001A8D 00                    2600 	.db	0
      001A8E 01                    2601 	.uleb128	1
      001A8F 01                    2602 	.db	1
      001A90 00                    2603 	.db	0
      001A91 05                    2604 	.uleb128	5
      001A92 02                    2605 	.db	2
      001A93 00 00 92 BB           2606 	.dw	0,(Sstm8s_clk$CLK_ITConfig$233)
      001A97 03                    2607 	.db	3
      001A98 CA 03                 2608 	.sleb128	458
      001A9A 01                    2609 	.db	1
      001A9B 09                    2610 	.db	9
      001A9C 00 01                 2611 	.dw	Sstm8s_clk$CLK_ITConfig$236-Sstm8s_clk$CLK_ITConfig$233
      001A9E 03                    2612 	.db	3
      001A9F 08                    2613 	.sleb128	8
      001AA0 01                    2614 	.db	1
      001AA1 09                    2615 	.db	9
      001AA2 00 1B                 2616 	.dw	Sstm8s_clk$CLK_ITConfig$239-Sstm8s_clk$CLK_ITConfig$236
      001AA4 03                    2617 	.db	3
      001AA5 7E                    2618 	.sleb128	-2
      001AA6 01                    2619 	.db	1
      001AA7 09                    2620 	.db	9
      001AA8 00 07                 2621 	.dw	Sstm8s_clk$CLK_ITConfig$241-Sstm8s_clk$CLK_ITConfig$239
      001AAA 03                    2622 	.db	3
      001AAB 02                    2623 	.sleb128	2
      001AAC 01                    2624 	.db	1
      001AAD 09                    2625 	.db	9
      001AAE 00 0D                 2626 	.dw	Sstm8s_clk$CLK_ITConfig$243-Sstm8s_clk$CLK_ITConfig$241
      001AB0 03                    2627 	.db	3
      001AB1 03                    2628 	.sleb128	3
      001AB2 01                    2629 	.db	1
      001AB3 09                    2630 	.db	9
      001AB4 00 08                 2631 	.dw	Sstm8s_clk$CLK_ITConfig$244-Sstm8s_clk$CLK_ITConfig$243
      001AB6 03                    2632 	.db	3
      001AB7 01                    2633 	.sleb128	1
      001AB8 01                    2634 	.db	1
      001AB9 09                    2635 	.db	9
      001ABA 00 03                 2636 	.dw	Sstm8s_clk$CLK_ITConfig$245-Sstm8s_clk$CLK_ITConfig$244
      001ABC 03                    2637 	.db	3
      001ABD 01                    2638 	.sleb128	1
      001ABE 01                    2639 	.db	1
      001ABF 09                    2640 	.db	9
      001AC0 00 00                 2641 	.dw	Sstm8s_clk$CLK_ITConfig$246-Sstm8s_clk$CLK_ITConfig$245
      001AC2 03                    2642 	.db	3
      001AC3 01                    2643 	.sleb128	1
      001AC4 01                    2644 	.db	1
      001AC5 09                    2645 	.db	9
      001AC6 00 08                 2646 	.dw	Sstm8s_clk$CLK_ITConfig$247-Sstm8s_clk$CLK_ITConfig$246
      001AC8 03                    2647 	.db	3
      001AC9 01                    2648 	.sleb128	1
      001ACA 01                    2649 	.db	1
      001ACB 09                    2650 	.db	9
      001ACC 00 03                 2651 	.dw	Sstm8s_clk$CLK_ITConfig$249-Sstm8s_clk$CLK_ITConfig$247
      001ACE 03                    2652 	.db	3
      001ACF 03                    2653 	.sleb128	3
      001AD0 01                    2654 	.db	1
      001AD1 09                    2655 	.db	9
      001AD2 00 00                 2656 	.dw	Sstm8s_clk$CLK_ITConfig$251-Sstm8s_clk$CLK_ITConfig$249
      001AD4 03                    2657 	.db	3
      001AD5 04                    2658 	.sleb128	4
      001AD6 01                    2659 	.db	1
      001AD7 09                    2660 	.db	9
      001AD8 00 0D                 2661 	.dw	Sstm8s_clk$CLK_ITConfig$253-Sstm8s_clk$CLK_ITConfig$251
      001ADA 03                    2662 	.db	3
      001ADB 03                    2663 	.sleb128	3
      001ADC 01                    2664 	.db	1
      001ADD 09                    2665 	.db	9
      001ADE 00 08                 2666 	.dw	Sstm8s_clk$CLK_ITConfig$254-Sstm8s_clk$CLK_ITConfig$253
      001AE0 03                    2667 	.db	3
      001AE1 01                    2668 	.sleb128	1
      001AE2 01                    2669 	.db	1
      001AE3 09                    2670 	.db	9
      001AE4 00 03                 2671 	.dw	Sstm8s_clk$CLK_ITConfig$255-Sstm8s_clk$CLK_ITConfig$254
      001AE6 03                    2672 	.db	3
      001AE7 01                    2673 	.sleb128	1
      001AE8 01                    2674 	.db	1
      001AE9 09                    2675 	.db	9
      001AEA 00 00                 2676 	.dw	Sstm8s_clk$CLK_ITConfig$256-Sstm8s_clk$CLK_ITConfig$255
      001AEC 03                    2677 	.db	3
      001AED 01                    2678 	.sleb128	1
      001AEE 01                    2679 	.db	1
      001AEF 09                    2680 	.db	9
      001AF0 00 08                 2681 	.dw	Sstm8s_clk$CLK_ITConfig$258-Sstm8s_clk$CLK_ITConfig$256
      001AF2 03                    2682 	.db	3
      001AF3 04                    2683 	.sleb128	4
      001AF4 01                    2684 	.db	1
      001AF5 09                    2685 	.db	9
      001AF6 00 00                 2686 	.dw	Sstm8s_clk$CLK_ITConfig$259-Sstm8s_clk$CLK_ITConfig$258
      001AF8 03                    2687 	.db	3
      001AF9 02                    2688 	.sleb128	2
      001AFA 01                    2689 	.db	1
      001AFB 09                    2690 	.db	9
      001AFC 00 02                 2691 	.dw	1+Sstm8s_clk$CLK_ITConfig$261-Sstm8s_clk$CLK_ITConfig$259
      001AFE 00                    2692 	.db	0
      001AFF 01                    2693 	.uleb128	1
      001B00 01                    2694 	.db	1
      001B01 00                    2695 	.db	0
      001B02 05                    2696 	.uleb128	5
      001B03 02                    2697 	.db	2
      001B04 00 00 93 23           2698 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$263)
      001B08 03                    2699 	.db	3
      001B09 F3 03                 2700 	.sleb128	499
      001B0B 01                    2701 	.db	1
      001B0C 09                    2702 	.db	9
      001B0D 00 01                 2703 	.dw	Sstm8s_clk$CLK_SYSCLKConfig$266-Sstm8s_clk$CLK_SYSCLKConfig$263
      001B0F 03                    2704 	.db	3
      001B10 07                    2705 	.sleb128	7
      001B11 01                    2706 	.db	1
      001B12 09                    2707 	.db	9
      001B13 00 03                 2708 	.dw	Sstm8s_clk$CLK_SYSCLKConfig$267-Sstm8s_clk$CLK_SYSCLKConfig$266
      001B15 03                    2709 	.db	3
      001B16 7E                    2710 	.sleb128	-2
      001B17 01                    2711 	.db	1
      001B18 09                    2712 	.db	9
      001B19 00 07                 2713 	.dw	Sstm8s_clk$CLK_SYSCLKConfig$269-Sstm8s_clk$CLK_SYSCLKConfig$267
      001B1B 03                    2714 	.db	3
      001B1C 02                    2715 	.sleb128	2
      001B1D 01                    2716 	.db	1
      001B1E 09                    2717 	.db	9
      001B1F 00 05                 2718 	.dw	Sstm8s_clk$CLK_SYSCLKConfig$270-Sstm8s_clk$CLK_SYSCLKConfig$269
      001B21 03                    2719 	.db	3
      001B22 01                    2720 	.sleb128	1
      001B23 01                    2721 	.db	1
      001B24 09                    2722 	.db	9
      001B25 00 11                 2723 	.dw	Sstm8s_clk$CLK_SYSCLKConfig$273-Sstm8s_clk$CLK_SYSCLKConfig$270
      001B27 03                    2724 	.db	3
      001B28 04                    2725 	.sleb128	4
      001B29 01                    2726 	.db	1
      001B2A 09                    2727 	.db	9
      001B2B 00 05                 2728 	.dw	Sstm8s_clk$CLK_SYSCLKConfig$274-Sstm8s_clk$CLK_SYSCLKConfig$273
      001B2D 03                    2729 	.db	3
      001B2E 01                    2730 	.sleb128	1
      001B2F 01                    2731 	.db	1
      001B30 09                    2732 	.db	9
      001B31 00 0E                 2733 	.dw	Sstm8s_clk$CLK_SYSCLKConfig$276-Sstm8s_clk$CLK_SYSCLKConfig$274
      001B33 03                    2734 	.db	3
      001B34 02                    2735 	.sleb128	2
      001B35 01                    2736 	.db	1
      001B36 09                    2737 	.db	9
      001B37 00 02                 2738 	.dw	1+Sstm8s_clk$CLK_SYSCLKConfig$278-Sstm8s_clk$CLK_SYSCLKConfig$276
      001B39 00                    2739 	.db	0
      001B3A 01                    2740 	.uleb128	1
      001B3B 01                    2741 	.db	1
      001B3C 00                    2742 	.db	0
      001B3D 05                    2743 	.uleb128	5
      001B3E 02                    2744 	.db	2
      001B3F 00 00 93 59           2745 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$280)
      001B43 03                    2746 	.db	3
      001B44 8A 04                 2747 	.sleb128	522
      001B46 01                    2748 	.db	1
      001B47 09                    2749 	.db	9
      001B48 00 00                 2750 	.dw	Sstm8s_clk$CLK_SWIMConfig$282-Sstm8s_clk$CLK_SWIMConfig$280
      001B4A 03                    2751 	.db	3
      001B4B 08                    2752 	.sleb128	8
      001B4C 01                    2753 	.db	1
      001B4D 09                    2754 	.db	9
      001B4E 00 03                 2755 	.dw	Sstm8s_clk$CLK_SWIMConfig$283-Sstm8s_clk$CLK_SWIMConfig$282
      001B50 03                    2756 	.db	3
      001B51 7D                    2757 	.sleb128	-3
      001B52 01                    2758 	.db	1
      001B53 09                    2759 	.db	9
      001B54 00 07                 2760 	.dw	Sstm8s_clk$CLK_SWIMConfig$285-Sstm8s_clk$CLK_SWIMConfig$283
      001B56 03                    2761 	.db	3
      001B57 03                    2762 	.sleb128	3
      001B58 01                    2763 	.db	1
      001B59 09                    2764 	.db	9
      001B5A 00 08                 2765 	.dw	Sstm8s_clk$CLK_SWIMConfig$288-Sstm8s_clk$CLK_SWIMConfig$285
      001B5C 03                    2766 	.db	3
      001B5D 05                    2767 	.sleb128	5
      001B5E 01                    2768 	.db	1
      001B5F 09                    2769 	.db	9
      001B60 00 05                 2770 	.dw	Sstm8s_clk$CLK_SWIMConfig$290-Sstm8s_clk$CLK_SWIMConfig$288
      001B62 03                    2771 	.db	3
      001B63 02                    2772 	.sleb128	2
      001B64 01                    2773 	.db	1
      001B65 09                    2774 	.db	9
      001B66 00 01                 2775 	.dw	1+Sstm8s_clk$CLK_SWIMConfig$291-Sstm8s_clk$CLK_SWIMConfig$290
      001B68 00                    2776 	.db	0
      001B69 01                    2777 	.uleb128	1
      001B6A 01                    2778 	.db	1
      001B6B 00                    2779 	.db	0
      001B6C 05                    2780 	.uleb128	5
      001B6D 02                    2781 	.db	2
      001B6E 00 00 93 71           2782 	.dw	0,(Sstm8s_clk$CLK_ClockSecuritySystemEnable$293)
      001B72 03                    2783 	.db	3
      001B73 A2 04                 2784 	.sleb128	546
      001B75 01                    2785 	.db	1
      001B76 09                    2786 	.db	9
      001B77 00 00                 2787 	.dw	Sstm8s_clk$CLK_ClockSecuritySystemEnable$295-Sstm8s_clk$CLK_ClockSecuritySystemEnable$293
      001B79 03                    2788 	.db	3
      001B7A 03                    2789 	.sleb128	3
      001B7B 01                    2790 	.db	1
      001B7C 09                    2791 	.db	9
      001B7D 00 08                 2792 	.dw	Sstm8s_clk$CLK_ClockSecuritySystemEnable$296-Sstm8s_clk$CLK_ClockSecuritySystemEnable$295
      001B7F 03                    2793 	.db	3
      001B80 01                    2794 	.sleb128	1
      001B81 01                    2795 	.db	1
      001B82 09                    2796 	.db	9
      001B83 00 01                 2797 	.dw	1+Sstm8s_clk$CLK_ClockSecuritySystemEnable$297-Sstm8s_clk$CLK_ClockSecuritySystemEnable$296
      001B85 00                    2798 	.db	0
      001B86 01                    2799 	.uleb128	1
      001B87 01                    2800 	.db	1
      001B88 00                    2801 	.db	0
      001B89 05                    2802 	.uleb128	5
      001B8A 02                    2803 	.db	2
      001B8B 00 00 93 7A           2804 	.dw	0,(Sstm8s_clk$CLK_GetSYSCLKSource$299)
      001B8F 03                    2805 	.db	3
      001B90 AE 04                 2806 	.sleb128	558
      001B92 01                    2807 	.db	1
      001B93 09                    2808 	.db	9
      001B94 00 00                 2809 	.dw	Sstm8s_clk$CLK_GetSYSCLKSource$301-Sstm8s_clk$CLK_GetSYSCLKSource$299
      001B96 03                    2810 	.db	3
      001B97 02                    2811 	.sleb128	2
      001B98 01                    2812 	.db	1
      001B99 09                    2813 	.db	9
      001B9A 00 03                 2814 	.dw	Sstm8s_clk$CLK_GetSYSCLKSource$302-Sstm8s_clk$CLK_GetSYSCLKSource$301
      001B9C 03                    2815 	.db	3
      001B9D 01                    2816 	.sleb128	1
      001B9E 01                    2817 	.db	1
      001B9F 09                    2818 	.db	9
      001BA0 00 01                 2819 	.dw	1+Sstm8s_clk$CLK_GetSYSCLKSource$303-Sstm8s_clk$CLK_GetSYSCLKSource$302
      001BA2 00                    2820 	.db	0
      001BA3 01                    2821 	.uleb128	1
      001BA4 01                    2822 	.db	1
      001BA5 00                    2823 	.db	0
      001BA6 05                    2824 	.uleb128	5
      001BA7 02                    2825 	.db	2
      001BA8 00 00 93 7E           2826 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$305)
      001BAC 03                    2827 	.db	3
      001BAD B8 04                 2828 	.sleb128	568
      001BAF 01                    2829 	.db	1
      001BB0 09                    2830 	.db	9
      001BB1 00 02                 2831 	.dw	Sstm8s_clk$CLK_GetClockFreq$308-Sstm8s_clk$CLK_GetClockFreq$305
      001BB3 03                    2832 	.db	3
      001BB4 07                    2833 	.sleb128	7
      001BB5 01                    2834 	.db	1
      001BB6 09                    2835 	.db	9
      001BB7 00 05                 2836 	.dw	Sstm8s_clk$CLK_GetClockFreq$309-Sstm8s_clk$CLK_GetClockFreq$308
      001BB9 03                    2837 	.db	3
      001BBA 02                    2838 	.sleb128	2
      001BBB 01                    2839 	.db	1
      001BBC 09                    2840 	.db	9
      001BBD 00 0C                 2841 	.dw	Sstm8s_clk$CLK_GetClockFreq$312-Sstm8s_clk$CLK_GetClockFreq$309
      001BBF 03                    2842 	.db	3
      001BC0 02                    2843 	.sleb128	2
      001BC1 01                    2844 	.db	1
      001BC2 09                    2845 	.db	9
      001BC3 00 05                 2846 	.dw	Sstm8s_clk$CLK_GetClockFreq$313-Sstm8s_clk$CLK_GetClockFreq$312
      001BC5 03                    2847 	.db	3
      001BC6 01                    2848 	.sleb128	1
      001BC7 01                    2849 	.db	1
      001BC8 09                    2850 	.db	9
      001BC9 00 03                 2851 	.dw	Sstm8s_clk$CLK_GetClockFreq$314-Sstm8s_clk$CLK_GetClockFreq$313
      001BCB 03                    2852 	.db	3
      001BCC 01                    2853 	.sleb128	1
      001BCD 01                    2854 	.db	1
      001BCE 09                    2855 	.db	9
      001BCF 00 06                 2856 	.dw	Sstm8s_clk$CLK_GetClockFreq$315-Sstm8s_clk$CLK_GetClockFreq$314
      001BD1 03                    2857 	.db	3
      001BD2 01                    2858 	.sleb128	1
      001BD3 01                    2859 	.db	1
      001BD4 09                    2860 	.db	9
      001BD5 00 1A                 2861 	.dw	Sstm8s_clk$CLK_GetClockFreq$324-Sstm8s_clk$CLK_GetClockFreq$315
      001BD7 03                    2862 	.db	3
      001BD8 02                    2863 	.sleb128	2
      001BD9 01                    2864 	.db	1
      001BDA 09                    2865 	.db	9
      001BDB 00 0C                 2866 	.dw	Sstm8s_clk$CLK_GetClockFreq$327-Sstm8s_clk$CLK_GetClockFreq$324
      001BDD 03                    2867 	.db	3
      001BDE 02                    2868 	.sleb128	2
      001BDF 01                    2869 	.db	1
      001BE0 09                    2870 	.db	9
      001BE1 00 0A                 2871 	.dw	Sstm8s_clk$CLK_GetClockFreq$330-Sstm8s_clk$CLK_GetClockFreq$327
      001BE3 03                    2872 	.db	3
      001BE4 04                    2873 	.sleb128	4
      001BE5 01                    2874 	.db	1
      001BE6 09                    2875 	.db	9
      001BE7 00 08                 2876 	.dw	Sstm8s_clk$CLK_GetClockFreq$332-Sstm8s_clk$CLK_GetClockFreq$330
      001BE9 03                    2877 	.db	3
      001BEA 03                    2878 	.sleb128	3
      001BEB 01                    2879 	.db	1
      001BEC 09                    2880 	.db	9
      001BED 00 03                 2881 	.dw	Sstm8s_clk$CLK_GetClockFreq$333-Sstm8s_clk$CLK_GetClockFreq$332
      001BEF 03                    2882 	.db	3
      001BF0 01                    2883 	.sleb128	1
      001BF1 01                    2884 	.db	1
      001BF2 09                    2885 	.db	9
      001BF3 00 03                 2886 	.dw	1+Sstm8s_clk$CLK_GetClockFreq$335-Sstm8s_clk$CLK_GetClockFreq$333
      001BF5 00                    2887 	.db	0
      001BF6 01                    2888 	.uleb128	1
      001BF7 01                    2889 	.db	1
      001BF8 00                    2890 	.db	0
      001BF9 05                    2891 	.uleb128	5
      001BFA 02                    2892 	.db	2
      001BFB 00 00 93 DD           2893 	.dw	0,(Sstm8s_clk$CLK_AdjustHSICalibrationValue$337)
      001BFF 03                    2894 	.db	3
      001C00 DB 04                 2895 	.sleb128	603
      001C02 01                    2896 	.db	1
      001C03 09                    2897 	.db	9
      001C04 00 00                 2898 	.dw	Sstm8s_clk$CLK_AdjustHSICalibrationValue$339-Sstm8s_clk$CLK_AdjustHSICalibrationValue$337
      001C06 03                    2899 	.db	3
      001C07 06                    2900 	.sleb128	6
      001C08 01                    2901 	.db	1
      001C09 09                    2902 	.db	9
      001C0A 00 0A                 2903 	.dw	Sstm8s_clk$CLK_AdjustHSICalibrationValue$340-Sstm8s_clk$CLK_AdjustHSICalibrationValue$339
      001C0C 03                    2904 	.db	3
      001C0D 01                    2905 	.sleb128	1
      001C0E 01                    2906 	.db	1
      001C0F 09                    2907 	.db	9
      001C10 00 01                 2908 	.dw	1+Sstm8s_clk$CLK_AdjustHSICalibrationValue$341-Sstm8s_clk$CLK_AdjustHSICalibrationValue$340
      001C12 00                    2909 	.db	0
      001C13 01                    2910 	.uleb128	1
      001C14 01                    2911 	.db	1
      001C15 00                    2912 	.db	0
      001C16 05                    2913 	.uleb128	5
      001C17 02                    2914 	.db	2
      001C18 00 00 93 E8           2915 	.dw	0,(Sstm8s_clk$CLK_SYSCLKEmergencyClear$343)
      001C1C 03                    2916 	.db	3
      001C1D ED 04                 2917 	.sleb128	621
      001C1F 01                    2918 	.db	1
      001C20 09                    2919 	.db	9
      001C21 00 00                 2920 	.dw	Sstm8s_clk$CLK_SYSCLKEmergencyClear$345-Sstm8s_clk$CLK_SYSCLKEmergencyClear$343
      001C23 03                    2921 	.db	3
      001C24 02                    2922 	.sleb128	2
      001C25 01                    2923 	.db	1
      001C26 09                    2924 	.db	9
      001C27 00 08                 2925 	.dw	Sstm8s_clk$CLK_SYSCLKEmergencyClear$346-Sstm8s_clk$CLK_SYSCLKEmergencyClear$345
      001C29 03                    2926 	.db	3
      001C2A 01                    2927 	.sleb128	1
      001C2B 01                    2928 	.db	1
      001C2C 09                    2929 	.db	9
      001C2D 00 01                 2930 	.dw	1+Sstm8s_clk$CLK_SYSCLKEmergencyClear$347-Sstm8s_clk$CLK_SYSCLKEmergencyClear$346
      001C2F 00                    2931 	.db	0
      001C30 01                    2932 	.uleb128	1
      001C31 01                    2933 	.db	1
      001C32 00                    2934 	.db	0
      001C33 05                    2935 	.uleb128	5
      001C34 02                    2936 	.db	2
      001C35 00 00 93 F1           2937 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$349)
      001C39 03                    2938 	.db	3
      001C3A F9 04                 2939 	.sleb128	633
      001C3C 01                    2940 	.db	1
      001C3D 09                    2941 	.db	9
      001C3E 00 01                 2942 	.dw	Sstm8s_clk$CLK_GetFlagStatus$352-Sstm8s_clk$CLK_GetFlagStatus$349
      001C40 03                    2943 	.db	3
      001C41 0A                    2944 	.sleb128	10
      001C42 01                    2945 	.db	1
      001C43 09                    2946 	.db	9
      001C44 00 03                 2947 	.dw	Sstm8s_clk$CLK_GetFlagStatus$353-Sstm8s_clk$CLK_GetFlagStatus$352
      001C46 03                    2948 	.db	3
      001C47 03                    2949 	.sleb128	3
      001C48 01                    2950 	.db	1
      001C49 09                    2951 	.db	9
      001C4A 00 0C                 2952 	.dw	Sstm8s_clk$CLK_GetFlagStatus$356-Sstm8s_clk$CLK_GetFlagStatus$353
      001C4C 03                    2953 	.db	3
      001C4D 02                    2954 	.sleb128	2
      001C4E 01                    2955 	.db	1
      001C4F 09                    2956 	.db	9
      001C50 00 06                 2957 	.dw	Sstm8s_clk$CLK_GetFlagStatus$358-Sstm8s_clk$CLK_GetFlagStatus$356
      001C52 03                    2958 	.db	3
      001C53 02                    2959 	.sleb128	2
      001C54 01                    2960 	.db	1
      001C55 09                    2961 	.db	9
      001C56 00 0B                 2962 	.dw	Sstm8s_clk$CLK_GetFlagStatus$361-Sstm8s_clk$CLK_GetFlagStatus$358
      001C58 03                    2963 	.db	3
      001C59 02                    2964 	.sleb128	2
      001C5A 01                    2965 	.db	1
      001C5B 09                    2966 	.db	9
      001C5C 00 06                 2967 	.dw	Sstm8s_clk$CLK_GetFlagStatus$363-Sstm8s_clk$CLK_GetFlagStatus$361
      001C5E 03                    2968 	.db	3
      001C5F 02                    2969 	.sleb128	2
      001C60 01                    2970 	.db	1
      001C61 09                    2971 	.db	9
      001C62 00 0B                 2972 	.dw	Sstm8s_clk$CLK_GetFlagStatus$366-Sstm8s_clk$CLK_GetFlagStatus$363
      001C64 03                    2973 	.db	3
      001C65 02                    2974 	.sleb128	2
      001C66 01                    2975 	.db	1
      001C67 09                    2976 	.db	9
      001C68 00 06                 2977 	.dw	Sstm8s_clk$CLK_GetFlagStatus$368-Sstm8s_clk$CLK_GetFlagStatus$366
      001C6A 03                    2978 	.db	3
      001C6B 02                    2979 	.sleb128	2
      001C6C 01                    2980 	.db	1
      001C6D 09                    2981 	.db	9
      001C6E 00 0B                 2982 	.dw	Sstm8s_clk$CLK_GetFlagStatus$371-Sstm8s_clk$CLK_GetFlagStatus$368
      001C70 03                    2983 	.db	3
      001C71 02                    2984 	.sleb128	2
      001C72 01                    2985 	.db	1
      001C73 09                    2986 	.db	9
      001C74 00 06                 2987 	.dw	Sstm8s_clk$CLK_GetFlagStatus$374-Sstm8s_clk$CLK_GetFlagStatus$371
      001C76 03                    2988 	.db	3
      001C77 04                    2989 	.sleb128	4
      001C78 01                    2990 	.db	1
      001C79 09                    2991 	.db	9
      001C7A 00 03                 2992 	.dw	Sstm8s_clk$CLK_GetFlagStatus$376-Sstm8s_clk$CLK_GetFlagStatus$374
      001C7C 03                    2993 	.db	3
      001C7D 03                    2994 	.sleb128	3
      001C7E 01                    2995 	.db	1
      001C7F 09                    2996 	.db	9
      001C80 00 0E                 2997 	.dw	Sstm8s_clk$CLK_GetFlagStatus$380-Sstm8s_clk$CLK_GetFlagStatus$376
      001C82 03                    2998 	.db	3
      001C83 02                    2999 	.sleb128	2
      001C84 01                    3000 	.db	1
      001C85 09                    3001 	.db	9
      001C86 00 05                 3002 	.dw	Sstm8s_clk$CLK_GetFlagStatus$383-Sstm8s_clk$CLK_GetFlagStatus$380
      001C88 03                    3003 	.db	3
      001C89 04                    3004 	.sleb128	4
      001C8A 01                    3005 	.db	1
      001C8B 09                    3006 	.db	9
      001C8C 00 01                 3007 	.dw	Sstm8s_clk$CLK_GetFlagStatus$385-Sstm8s_clk$CLK_GetFlagStatus$383
      001C8E 03                    3008 	.db	3
      001C8F 04                    3009 	.sleb128	4
      001C90 01                    3010 	.db	1
      001C91 09                    3011 	.db	9
      001C92 00 00                 3012 	.dw	Sstm8s_clk$CLK_GetFlagStatus$386-Sstm8s_clk$CLK_GetFlagStatus$385
      001C94 03                    3013 	.db	3
      001C95 01                    3014 	.sleb128	1
      001C96 01                    3015 	.db	1
      001C97 09                    3016 	.db	9
      001C98 00 03                 3017 	.dw	1+Sstm8s_clk$CLK_GetFlagStatus$388-Sstm8s_clk$CLK_GetFlagStatus$386
      001C9A 00                    3018 	.db	0
      001C9B 01                    3019 	.uleb128	1
      001C9C 01                    3020 	.db	1
      001C9D 00                    3021 	.db	0
      001C9E 05                    3022 	.uleb128	5
      001C9F 02                    3023 	.db	2
      001CA0 00 00 94 54           3024 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$390)
      001CA4 03                    3025 	.db	3
      001CA5 AE 05                 3026 	.sleb128	686
      001CA7 01                    3027 	.db	1
      001CA8 09                    3028 	.db	9
      001CA9 00 00                 3029 	.dw	Sstm8s_clk$CLK_GetITStatus$392-Sstm8s_clk$CLK_GetITStatus$390
      001CAB 03                    3030 	.db	3
      001CAC 07                    3031 	.sleb128	7
      001CAD 01                    3032 	.db	1
      001CAE 09                    3033 	.db	9
      001CAF 00 0C                 3034 	.dw	Sstm8s_clk$CLK_GetITStatus$395-Sstm8s_clk$CLK_GetITStatus$392
      001CB1 03                    3035 	.db	3
      001CB2 03                    3036 	.sleb128	3
      001CB3 01                    3037 	.db	1
      001CB4 09                    3038 	.db	9
      001CB5 00 0F                 3039 	.dw	Sstm8s_clk$CLK_GetITStatus$398-Sstm8s_clk$CLK_GetITStatus$395
      001CB7 03                    3040 	.db	3
      001CB8 02                    3041 	.sleb128	2
      001CB9 01                    3042 	.db	1
      001CBA 09                    3043 	.db	9
      001CBB 00 05                 3044 	.dw	Sstm8s_clk$CLK_GetITStatus$401-Sstm8s_clk$CLK_GetITStatus$398
      001CBD 03                    3045 	.db	3
      001CBE 04                    3046 	.sleb128	4
      001CBF 01                    3047 	.db	1
      001CC0 09                    3048 	.db	9
      001CC1 00 04                 3049 	.dw	Sstm8s_clk$CLK_GetITStatus$404-Sstm8s_clk$CLK_GetITStatus$401
      001CC3 03                    3050 	.db	3
      001CC4 06                    3051 	.sleb128	6
      001CC5 01                    3052 	.db	1
      001CC6 09                    3053 	.db	9
      001CC7 00 0F                 3054 	.dw	Sstm8s_clk$CLK_GetITStatus$407-Sstm8s_clk$CLK_GetITStatus$404
      001CC9 03                    3055 	.db	3
      001CCA 02                    3056 	.sleb128	2
      001CCB 01                    3057 	.db	1
      001CCC 09                    3058 	.db	9
      001CCD 00 05                 3059 	.dw	Sstm8s_clk$CLK_GetITStatus$410-Sstm8s_clk$CLK_GetITStatus$407
      001CCF 03                    3060 	.db	3
      001CD0 04                    3061 	.sleb128	4
      001CD1 01                    3062 	.db	1
      001CD2 09                    3063 	.db	9
      001CD3 00 01                 3064 	.dw	Sstm8s_clk$CLK_GetITStatus$412-Sstm8s_clk$CLK_GetITStatus$410
      001CD5 03                    3065 	.db	3
      001CD6 05                    3066 	.sleb128	5
      001CD7 01                    3067 	.db	1
      001CD8 09                    3068 	.db	9
      001CD9 00 00                 3069 	.dw	Sstm8s_clk$CLK_GetITStatus$413-Sstm8s_clk$CLK_GetITStatus$412
      001CDB 03                    3070 	.db	3
      001CDC 01                    3071 	.sleb128	1
      001CDD 01                    3072 	.db	1
      001CDE 09                    3073 	.db	9
      001CDF 00 01                 3074 	.dw	1+Sstm8s_clk$CLK_GetITStatus$414-Sstm8s_clk$CLK_GetITStatus$413
      001CE1 00                    3075 	.db	0
      001CE2 01                    3076 	.uleb128	1
      001CE3 01                    3077 	.db	1
      001CE4 00                    3078 	.db	0
      001CE5 05                    3079 	.uleb128	5
      001CE6 02                    3080 	.db	2
      001CE7 00 00 94 8E           3081 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$416)
      001CEB 03                    3082 	.db	3
      001CEC D8 05                 3083 	.sleb128	728
      001CEE 01                    3084 	.db	1
      001CEF 09                    3085 	.db	9
      001CF0 00 00                 3086 	.dw	Sstm8s_clk$CLK_ClearITPendingBit$418-Sstm8s_clk$CLK_ClearITPendingBit$416
      001CF2 03                    3087 	.db	3
      001CF3 05                    3088 	.sleb128	5
      001CF4 01                    3089 	.db	1
      001CF5 09                    3090 	.db	9
      001CF6 00 0C                 3091 	.dw	Sstm8s_clk$CLK_ClearITPendingBit$421-Sstm8s_clk$CLK_ClearITPendingBit$418
      001CF8 03                    3092 	.db	3
      001CF9 03                    3093 	.sleb128	3
      001CFA 01                    3094 	.db	1
      001CFB 09                    3095 	.db	9
      001CFC 00 0B                 3096 	.dw	Sstm8s_clk$CLK_ClearITPendingBit$424-Sstm8s_clk$CLK_ClearITPendingBit$421
      001CFE 03                    3097 	.db	3
      001CFF 05                    3098 	.sleb128	5
      001D00 01                    3099 	.db	1
      001D01 09                    3100 	.db	9
      001D02 00 08                 3101 	.dw	Sstm8s_clk$CLK_ClearITPendingBit$426-Sstm8s_clk$CLK_ClearITPendingBit$424
      001D04 03                    3102 	.db	3
      001D05 03                    3103 	.sleb128	3
      001D06 01                    3104 	.db	1
      001D07 09                    3105 	.db	9
      001D08 00 01                 3106 	.dw	1+Sstm8s_clk$CLK_ClearITPendingBit$427-Sstm8s_clk$CLK_ClearITPendingBit$426
      001D0A 00                    3107 	.db	0
      001D0B 01                    3108 	.uleb128	1
      001D0C 01                    3109 	.db	1
      001D0D                       3110 Ldebug_line_end:
                                   3111 
                                   3112 	.area .debug_loc (NOLOAD)
      002594                       3113 Ldebug_loc_start:
      002594 00 00 94 9A           3114 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$419)
      002598 00 00 94 AE           3115 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$428)
      00259C 00 02                 3116 	.dw	2
      00259E 78                    3117 	.db	120
      00259F 01                    3118 	.sleb128	1
      0025A0 00 00 94 8E           3119 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$417)
      0025A4 00 00 94 9A           3120 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$419)
      0025A8 00 02                 3121 	.dw	2
      0025AA 78                    3122 	.db	120
      0025AB 01                    3123 	.sleb128	1
      0025AC 00 00 00 00           3124 	.dw	0,0
      0025B0 00 00 00 00           3125 	.dw	0,0
      0025B4 00 00 94 87           3126 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$405)
      0025B8 00 00 94 8E           3127 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$415)
      0025BC 00 02                 3128 	.dw	2
      0025BE 78                    3129 	.db	120
      0025BF 01                    3130 	.sleb128	1
      0025C0 00 00 94 6F           3131 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$396)
      0025C4 00 00 94 87           3132 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$405)
      0025C8 00 02                 3133 	.dw	2
      0025CA 78                    3134 	.db	120
      0025CB 01                    3135 	.sleb128	1
      0025CC 00 00 94 60           3136 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$393)
      0025D0 00 00 94 6F           3137 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$396)
      0025D4 00 02                 3138 	.dw	2
      0025D6 78                    3139 	.db	120
      0025D7 01                    3140 	.sleb128	1
      0025D8 00 00 94 54           3141 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$391)
      0025DC 00 00 94 60           3142 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$393)
      0025E0 00 02                 3143 	.dw	2
      0025E2 78                    3144 	.db	120
      0025E3 01                    3145 	.sleb128	1
      0025E4 00 00 00 00           3146 	.dw	0,0
      0025E8 00 00 00 00           3147 	.dw	0,0
      0025EC 00 00 94 53           3148 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$387)
      0025F0 00 00 94 54           3149 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$389)
      0025F4 00 02                 3150 	.dw	2
      0025F6 78                    3151 	.db	120
      0025F7 01                    3152 	.sleb128	1
      0025F8 00 00 94 43           3153 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$378)
      0025FC 00 00 94 53           3154 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$387)
      002600 00 02                 3155 	.dw	2
      002602 78                    3156 	.db	120
      002603 02                    3157 	.sleb128	2
      002604 00 00 94 3E           3158 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$377)
      002608 00 00 94 43           3159 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$378)
      00260C 00 02                 3160 	.dw	2
      00260E 78                    3161 	.db	120
      00260F 03                    3162 	.sleb128	3
      002610 00 00 94 34           3163 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$369)
      002614 00 00 94 3E           3164 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$377)
      002618 00 02                 3165 	.dw	2
      00261A 78                    3166 	.db	120
      00261B 02                    3167 	.sleb128	2
      00261C 00 00 94 23           3168 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$364)
      002620 00 00 94 34           3169 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$369)
      002624 00 02                 3170 	.dw	2
      002626 78                    3171 	.db	120
      002627 02                    3172 	.sleb128	2
      002628 00 00 94 12           3173 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$359)
      00262C 00 00 94 23           3174 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$364)
      002630 00 02                 3175 	.dw	2
      002632 78                    3176 	.db	120
      002633 02                    3177 	.sleb128	2
      002634 00 00 94 01           3178 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$354)
      002638 00 00 94 12           3179 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$359)
      00263C 00 02                 3180 	.dw	2
      00263E 78                    3181 	.db	120
      00263F 02                    3182 	.sleb128	2
      002640 00 00 93 F2           3183 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$351)
      002644 00 00 94 01           3184 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$354)
      002648 00 02                 3185 	.dw	2
      00264A 78                    3186 	.db	120
      00264B 02                    3187 	.sleb128	2
      00264C 00 00 93 F1           3188 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$350)
      002650 00 00 93 F2           3189 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$351)
      002654 00 02                 3190 	.dw	2
      002656 78                    3191 	.db	120
      002657 01                    3192 	.sleb128	1
      002658 00 00 00 00           3193 	.dw	0,0
      00265C 00 00 00 00           3194 	.dw	0,0
      002660 00 00 93 E8           3195 	.dw	0,(Sstm8s_clk$CLK_SYSCLKEmergencyClear$344)
      002664 00 00 93 F1           3196 	.dw	0,(Sstm8s_clk$CLK_SYSCLKEmergencyClear$348)
      002668 00 02                 3197 	.dw	2
      00266A 78                    3198 	.db	120
      00266B 01                    3199 	.sleb128	1
      00266C 00 00 00 00           3200 	.dw	0,0
      002670 00 00 00 00           3201 	.dw	0,0
      002674 00 00 93 DD           3202 	.dw	0,(Sstm8s_clk$CLK_AdjustHSICalibrationValue$338)
      002678 00 00 93 E8           3203 	.dw	0,(Sstm8s_clk$CLK_AdjustHSICalibrationValue$342)
      00267C 00 02                 3204 	.dw	2
      00267E 78                    3205 	.db	120
      00267F 01                    3206 	.sleb128	1
      002680 00 00 00 00           3207 	.dw	0,0
      002684 00 00 00 00           3208 	.dw	0,0
      002688 00 00 93 DC           3209 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$334)
      00268C 00 00 93 DD           3210 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$336)
      002690 00 02                 3211 	.dw	2
      002692 78                    3212 	.db	120
      002693 01                    3213 	.sleb128	1
      002694 00 00 93 C5           3214 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$325)
      002698 00 00 93 DC           3215 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$334)
      00269C 00 02                 3216 	.dw	2
      00269E 78                    3217 	.db	120
      00269F 05                    3218 	.sleb128	5
      0026A0 00 00 93 B3           3219 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$323)
      0026A4 00 00 93 C5           3220 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$325)
      0026A8 00 02                 3221 	.dw	2
      0026AA 78                    3222 	.db	120
      0026AB 05                    3223 	.sleb128	5
      0026AC 00 00 93 AE           3224 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$322)
      0026B0 00 00 93 B3           3225 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$323)
      0026B4 00 02                 3226 	.dw	2
      0026B6 78                    3227 	.db	120
      0026B7 0D                    3228 	.sleb128	13
      0026B8 00 00 93 AC           3229 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$321)
      0026BC 00 00 93 AE           3230 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$322)
      0026C0 00 02                 3231 	.dw	2
      0026C2 78                    3232 	.db	120
      0026C3 0C                    3233 	.sleb128	12
      0026C4 00 00 93 AA           3234 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$320)
      0026C8 00 00 93 AC           3235 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$321)
      0026CC 00 02                 3236 	.dw	2
      0026CE 78                    3237 	.db	120
      0026CF 0B                    3238 	.sleb128	11
      0026D0 00 00 93 A8           3239 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$319)
      0026D4 00 00 93 AA           3240 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$320)
      0026D8 00 02                 3241 	.dw	2
      0026DA 78                    3242 	.db	120
      0026DB 0A                    3243 	.sleb128	10
      0026DC 00 00 93 A6           3244 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$318)
      0026E0 00 00 93 A8           3245 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$319)
      0026E4 00 02                 3246 	.dw	2
      0026E6 78                    3247 	.db	120
      0026E7 09                    3248 	.sleb128	9
      0026E8 00 00 93 A4           3249 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$317)
      0026EC 00 00 93 A6           3250 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$318)
      0026F0 00 02                 3251 	.dw	2
      0026F2 78                    3252 	.db	120
      0026F3 07                    3253 	.sleb128	7
      0026F4 00 00 93 91           3254 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$310)
      0026F8 00 00 93 A4           3255 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$317)
      0026FC 00 02                 3256 	.dw	2
      0026FE 78                    3257 	.db	120
      0026FF 05                    3258 	.sleb128	5
      002700 00 00 93 80           3259 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$307)
      002704 00 00 93 91           3260 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$310)
      002708 00 02                 3261 	.dw	2
      00270A 78                    3262 	.db	120
      00270B 05                    3263 	.sleb128	5
      00270C 00 00 93 7E           3264 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$306)
      002710 00 00 93 80           3265 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$307)
      002714 00 02                 3266 	.dw	2
      002716 78                    3267 	.db	120
      002717 01                    3268 	.sleb128	1
      002718 00 00 00 00           3269 	.dw	0,0
      00271C 00 00 00 00           3270 	.dw	0,0
      002720 00 00 93 7A           3271 	.dw	0,(Sstm8s_clk$CLK_GetSYSCLKSource$300)
      002724 00 00 93 7E           3272 	.dw	0,(Sstm8s_clk$CLK_GetSYSCLKSource$304)
      002728 00 02                 3273 	.dw	2
      00272A 78                    3274 	.db	120
      00272B 01                    3275 	.sleb128	1
      00272C 00 00 00 00           3276 	.dw	0,0
      002730 00 00 00 00           3277 	.dw	0,0
      002734 00 00 93 71           3278 	.dw	0,(Sstm8s_clk$CLK_ClockSecuritySystemEnable$294)
      002738 00 00 93 7A           3279 	.dw	0,(Sstm8s_clk$CLK_ClockSecuritySystemEnable$298)
      00273C 00 02                 3280 	.dw	2
      00273E 78                    3281 	.db	120
      00273F 01                    3282 	.sleb128	1
      002740 00 00 00 00           3283 	.dw	0,0
      002744 00 00 00 00           3284 	.dw	0,0
      002748 00 00 93 59           3285 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$281)
      00274C 00 00 93 71           3286 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$292)
      002750 00 02                 3287 	.dw	2
      002752 78                    3288 	.db	120
      002753 01                    3289 	.sleb128	1
      002754 00 00 00 00           3290 	.dw	0,0
      002758 00 00 00 00           3291 	.dw	0,0
      00275C 00 00 93 58           3292 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$277)
      002760 00 00 93 59           3293 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$279)
      002764 00 02                 3294 	.dw	2
      002766 78                    3295 	.db	120
      002767 01                    3296 	.sleb128	1
      002768 00 00 93 24           3297 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$265)
      00276C 00 00 93 58           3298 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$277)
      002770 00 02                 3299 	.dw	2
      002772 78                    3300 	.db	120
      002773 02                    3301 	.sleb128	2
      002774 00 00 93 23           3302 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$264)
      002778 00 00 93 24           3303 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$265)
      00277C 00 02                 3304 	.dw	2
      00277E 78                    3305 	.db	120
      00277F 01                    3306 	.sleb128	1
      002780 00 00 00 00           3307 	.dw	0,0
      002784 00 00 00 00           3308 	.dw	0,0
      002788 00 00 93 22           3309 	.dw	0,(Sstm8s_clk$CLK_ITConfig$260)
      00278C 00 00 93 23           3310 	.dw	0,(Sstm8s_clk$CLK_ITConfig$262)
      002790 00 02                 3311 	.dw	2
      002792 78                    3312 	.db	120
      002793 01                    3313 	.sleb128	1
      002794 00 00 92 D7           3314 	.dw	0,(Sstm8s_clk$CLK_ITConfig$238)
      002798 00 00 93 22           3315 	.dw	0,(Sstm8s_clk$CLK_ITConfig$260)
      00279C 00 02                 3316 	.dw	2
      00279E 78                    3317 	.db	120
      00279F 02                    3318 	.sleb128	2
      0027A0 00 00 92 CB           3319 	.dw	0,(Sstm8s_clk$CLK_ITConfig$237)
      0027A4 00 00 92 D7           3320 	.dw	0,(Sstm8s_clk$CLK_ITConfig$238)
      0027A8 00 02                 3321 	.dw	2
      0027AA 78                    3322 	.db	120
      0027AB 02                    3323 	.sleb128	2
      0027AC 00 00 92 BC           3324 	.dw	0,(Sstm8s_clk$CLK_ITConfig$235)
      0027B0 00 00 92 CB           3325 	.dw	0,(Sstm8s_clk$CLK_ITConfig$237)
      0027B4 00 02                 3326 	.dw	2
      0027B6 78                    3327 	.db	120
      0027B7 02                    3328 	.sleb128	2
      0027B8 00 00 92 BB           3329 	.dw	0,(Sstm8s_clk$CLK_ITConfig$234)
      0027BC 00 00 92 BC           3330 	.dw	0,(Sstm8s_clk$CLK_ITConfig$235)
      0027C0 00 02                 3331 	.dw	2
      0027C2 78                    3332 	.db	120
      0027C3 01                    3333 	.sleb128	1
      0027C4 00 00 00 00           3334 	.dw	0,0
      0027C8 00 00 00 00           3335 	.dw	0,0
      0027CC 00 00 92 A2           3336 	.dw	0,(Sstm8s_clk$CLK_CCOConfig$226)
      0027D0 00 00 92 BB           3337 	.dw	0,(Sstm8s_clk$CLK_CCOConfig$232)
      0027D4 00 02                 3338 	.dw	2
      0027D6 78                    3339 	.db	120
      0027D7 01                    3340 	.sleb128	1
      0027D8 00 00 00 00           3341 	.dw	0,0
      0027DC 00 00 00 00           3342 	.dw	0,0
      0027E0 00 00 92 91           3343 	.dw	0,(Sstm8s_clk$CLK_HSIPrescalerConfig$219)
      0027E4 00 00 92 A2           3344 	.dw	0,(Sstm8s_clk$CLK_HSIPrescalerConfig$224)
      0027E8 00 02                 3345 	.dw	2
      0027EA 78                    3346 	.db	120
      0027EB 01                    3347 	.sleb128	1
      0027EC 00 00 00 00           3348 	.dw	0,0
      0027F0 00 00 00 00           3349 	.dw	0,0
      0027F4 00 00 92 90           3350 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$215)
      0027F8 00 00 92 91           3351 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$217)
      0027FC 00 02                 3352 	.dw	2
      0027FE 78                    3353 	.db	120
      0027FF 01                    3354 	.sleb128	1
      002800 00 00 92 85           3355 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$209)
      002804 00 00 92 90           3356 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$215)
      002808 00 02                 3357 	.dw	2
      00280A 78                    3358 	.db	120
      00280B 02                    3359 	.sleb128	2
      00280C 00 00 92 67           3360 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$204)
      002810 00 00 92 85           3361 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$209)
      002814 00 02                 3362 	.dw	2
      002816 78                    3363 	.db	120
      002817 02                    3364 	.sleb128	2
      002818 00 00 92 49           3365 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$199)
      00281C 00 00 92 67           3366 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$204)
      002820 00 02                 3367 	.dw	2
      002822 78                    3368 	.db	120
      002823 02                    3369 	.sleb128	2
      002824 00 00 91 A3           3370 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$148)
      002828 00 00 92 49           3371 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$199)
      00282C 00 02                 3372 	.dw	2
      00282E 78                    3373 	.db	120
      00282F 02                    3374 	.sleb128	2
      002830 00 00 91 9B           3375 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$147)
      002834 00 00 91 A3           3376 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$148)
      002838 00 02                 3377 	.dw	2
      00283A 78                    3378 	.db	120
      00283B 02                    3379 	.sleb128	2
      00283C 00 00 91 97           3380 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$146)
      002840 00 00 91 9B           3381 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$147)
      002844 00 02                 3382 	.dw	2
      002846 78                    3383 	.db	120
      002847 03                    3384 	.sleb128	3
      002848 00 00 91 8C           3385 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$141)
      00284C 00 00 91 97           3386 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$146)
      002850 00 02                 3387 	.dw	2
      002852 78                    3388 	.db	120
      002853 02                    3389 	.sleb128	2
      002854 00 00 91 8B           3390 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$140)
      002858 00 00 91 8C           3391 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$141)
      00285C 00 02                 3392 	.dw	2
      00285E 78                    3393 	.db	120
      00285F 01                    3394 	.sleb128	1
      002860 00 00 00 00           3395 	.dw	0,0
      002864 00 00 00 00           3396 	.dw	0,0
      002868 00 00 91 8A           3397 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$136)
      00286C 00 00 91 8B           3398 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$138)
      002870 00 02                 3399 	.dw	2
      002872 78                    3400 	.db	120
      002873 01                    3401 	.sleb128	1
      002874 00 00 91 42           3402 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$114)
      002878 00 00 91 8A           3403 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$136)
      00287C 00 02                 3404 	.dw	2
      00287E 78                    3405 	.db	120
      00287F 03                    3406 	.sleb128	3
      002880 00 00 91 3D           3407 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$113)
      002884 00 00 91 42           3408 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$114)
      002888 00 02                 3409 	.dw	2
      00288A 78                    3410 	.db	120
      00288B 04                    3411 	.sleb128	4
      00288C 00 00 91 38           3412 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$111)
      002890 00 00 91 3D           3413 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$113)
      002894 00 02                 3414 	.dw	2
      002896 78                    3415 	.db	120
      002897 03                    3416 	.sleb128	3
      002898 00 00 91 37           3417 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$110)
      00289C 00 00 91 38           3418 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$111)
      0028A0 00 02                 3419 	.dw	2
      0028A2 78                    3420 	.db	120
      0028A3 01                    3421 	.sleb128	1
      0028A4 00 00 00 00           3422 	.dw	0,0
      0028A8 00 00 00 00           3423 	.dw	0,0
      0028AC 00 00 91 1F           3424 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$97)
      0028B0 00 00 91 37           3425 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$108)
      0028B4 00 02                 3426 	.dw	2
      0028B6 78                    3427 	.db	120
      0028B7 01                    3428 	.sleb128	1
      0028B8 00 00 00 00           3429 	.dw	0,0
      0028BC 00 00 00 00           3430 	.dw	0,0
      0028C0 00 00 91 07           3431 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$84)
      0028C4 00 00 91 1F           3432 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$95)
      0028C8 00 02                 3433 	.dw	2
      0028CA 78                    3434 	.db	120
      0028CB 01                    3435 	.sleb128	1
      0028CC 00 00 00 00           3436 	.dw	0,0
      0028D0 00 00 00 00           3437 	.dw	0,0
      0028D4 00 00 90 EF           3438 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$71)
      0028D8 00 00 91 07           3439 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$82)
      0028DC 00 02                 3440 	.dw	2
      0028DE 78                    3441 	.db	120
      0028DF 01                    3442 	.sleb128	1
      0028E0 00 00 00 00           3443 	.dw	0,0
      0028E4 00 00 00 00           3444 	.dw	0,0
      0028E8 00 00 90 D7           3445 	.dw	0,(Sstm8s_clk$CLK_LSICmd$58)
      0028EC 00 00 90 EF           3446 	.dw	0,(Sstm8s_clk$CLK_LSICmd$69)
      0028F0 00 02                 3447 	.dw	2
      0028F2 78                    3448 	.db	120
      0028F3 01                    3449 	.sleb128	1
      0028F4 00 00 00 00           3450 	.dw	0,0
      0028F8 00 00 00 00           3451 	.dw	0,0
      0028FC 00 00 90 BF           3452 	.dw	0,(Sstm8s_clk$CLK_HSICmd$45)
      002900 00 00 90 D7           3453 	.dw	0,(Sstm8s_clk$CLK_HSICmd$56)
      002904 00 02                 3454 	.dw	2
      002906 78                    3455 	.db	120
      002907 01                    3456 	.sleb128	1
      002908 00 00 00 00           3457 	.dw	0,0
      00290C 00 00 00 00           3458 	.dw	0,0
      002910 00 00 90 A7           3459 	.dw	0,(Sstm8s_clk$CLK_HSECmd$32)
      002914 00 00 90 BF           3460 	.dw	0,(Sstm8s_clk$CLK_HSECmd$43)
      002918 00 02                 3461 	.dw	2
      00291A 78                    3462 	.db	120
      00291B 01                    3463 	.sleb128	1
      00291C 00 00 00 00           3464 	.dw	0,0
      002920 00 00 00 00           3465 	.dw	0,0
      002924 00 00 90 8F           3466 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$19)
      002928 00 00 90 A7           3467 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$30)
      00292C 00 02                 3468 	.dw	2
      00292E 78                    3469 	.db	120
      00292F 01                    3470 	.sleb128	1
      002930 00 00 00 00           3471 	.dw	0,0
      002934 00 00 00 00           3472 	.dw	0,0
      002938 00 00 90 55           3473 	.dw	0,(Sstm8s_clk$CLK_DeInit$1)
      00293C 00 00 90 8F           3474 	.dw	0,(Sstm8s_clk$CLK_DeInit$17)
      002940 00 02                 3475 	.dw	2
      002942 78                    3476 	.db	120
      002943 01                    3477 	.sleb128	1
      002944 00 00 00 00           3478 	.dw	0,0
      002948 00 00 00 00           3479 	.dw	0,0
                                   3480 
                                   3481 	.area .debug_abbrev (NOLOAD)
      000466                       3482 Ldebug_abbrev:
      000466 0C                    3483 	.uleb128	12
      000467 2E                    3484 	.uleb128	46
      000468 00                    3485 	.db	0
      000469 03                    3486 	.uleb128	3
      00046A 08                    3487 	.uleb128	8
      00046B 11                    3488 	.uleb128	17
      00046C 01                    3489 	.uleb128	1
      00046D 12                    3490 	.uleb128	18
      00046E 01                    3491 	.uleb128	1
      00046F 3F                    3492 	.uleb128	63
      000470 0C                    3493 	.uleb128	12
      000471 40                    3494 	.uleb128	64
      000472 06                    3495 	.uleb128	6
      000473 49                    3496 	.uleb128	73
      000474 13                    3497 	.uleb128	19
      000475 00                    3498 	.uleb128	0
      000476 00                    3499 	.uleb128	0
      000477 10                    3500 	.uleb128	16
      000478 34                    3501 	.uleb128	52
      000479 00                    3502 	.db	0
      00047A 02                    3503 	.uleb128	2
      00047B 0A                    3504 	.uleb128	10
      00047C 03                    3505 	.uleb128	3
      00047D 08                    3506 	.uleb128	8
      00047E 3F                    3507 	.uleb128	63
      00047F 0C                    3508 	.uleb128	12
      000480 49                    3509 	.uleb128	73
      000481 13                    3510 	.uleb128	19
      000482 00                    3511 	.uleb128	0
      000483 00                    3512 	.uleb128	0
      000484 04                    3513 	.uleb128	4
      000485 05                    3514 	.uleb128	5
      000486 00                    3515 	.db	0
      000487 02                    3516 	.uleb128	2
      000488 0A                    3517 	.uleb128	10
      000489 03                    3518 	.uleb128	3
      00048A 08                    3519 	.uleb128	8
      00048B 49                    3520 	.uleb128	73
      00048C 13                    3521 	.uleb128	19
      00048D 00                    3522 	.uleb128	0
      00048E 00                    3523 	.uleb128	0
      00048F 0E                    3524 	.uleb128	14
      000490 01                    3525 	.uleb128	1
      000491 01                    3526 	.db	1
      000492 01                    3527 	.uleb128	1
      000493 13                    3528 	.uleb128	19
      000494 0B                    3529 	.uleb128	11
      000495 0B                    3530 	.uleb128	11
      000496 49                    3531 	.uleb128	73
      000497 13                    3532 	.uleb128	19
      000498 00                    3533 	.uleb128	0
      000499 00                    3534 	.uleb128	0
      00049A 03                    3535 	.uleb128	3
      00049B 2E                    3536 	.uleb128	46
      00049C 01                    3537 	.db	1
      00049D 01                    3538 	.uleb128	1
      00049E 13                    3539 	.uleb128	19
      00049F 03                    3540 	.uleb128	3
      0004A0 08                    3541 	.uleb128	8
      0004A1 11                    3542 	.uleb128	17
      0004A2 01                    3543 	.uleb128	1
      0004A3 12                    3544 	.uleb128	18
      0004A4 01                    3545 	.uleb128	1
      0004A5 3F                    3546 	.uleb128	63
      0004A6 0C                    3547 	.uleb128	12
      0004A7 40                    3548 	.uleb128	64
      0004A8 06                    3549 	.uleb128	6
      0004A9 00                    3550 	.uleb128	0
      0004AA 00                    3551 	.uleb128	0
      0004AB 0B                    3552 	.uleb128	11
      0004AC 34                    3553 	.uleb128	52
      0004AD 00                    3554 	.db	0
      0004AE 02                    3555 	.uleb128	2
      0004AF 0A                    3556 	.uleb128	10
      0004B0 03                    3557 	.uleb128	3
      0004B1 08                    3558 	.uleb128	8
      0004B2 49                    3559 	.uleb128	73
      0004B3 13                    3560 	.uleb128	19
      0004B4 00                    3561 	.uleb128	0
      0004B5 00                    3562 	.uleb128	0
      0004B6 09                    3563 	.uleb128	9
      0004B7 2E                    3564 	.uleb128	46
      0004B8 01                    3565 	.db	1
      0004B9 01                    3566 	.uleb128	1
      0004BA 13                    3567 	.uleb128	19
      0004BB 03                    3568 	.uleb128	3
      0004BC 08                    3569 	.uleb128	8
      0004BD 11                    3570 	.uleb128	17
      0004BE 01                    3571 	.uleb128	1
      0004BF 12                    3572 	.uleb128	18
      0004C0 01                    3573 	.uleb128	1
      0004C1 3F                    3574 	.uleb128	63
      0004C2 0C                    3575 	.uleb128	12
      0004C3 40                    3576 	.uleb128	64
      0004C4 06                    3577 	.uleb128	6
      0004C5 49                    3578 	.uleb128	73
      0004C6 13                    3579 	.uleb128	19
      0004C7 00                    3580 	.uleb128	0
      0004C8 00                    3581 	.uleb128	0
      0004C9 0D                    3582 	.uleb128	13
      0004CA 26                    3583 	.uleb128	38
      0004CB 00                    3584 	.db	0
      0004CC 49                    3585 	.uleb128	73
      0004CD 13                    3586 	.uleb128	19
      0004CE 00                    3587 	.uleb128	0
      0004CF 00                    3588 	.uleb128	0
      0004D0 08                    3589 	.uleb128	8
      0004D1 0B                    3590 	.uleb128	11
      0004D2 01                    3591 	.db	1
      0004D3 11                    3592 	.uleb128	17
      0004D4 01                    3593 	.uleb128	1
      0004D5 00                    3594 	.uleb128	0
      0004D6 00                    3595 	.uleb128	0
      0004D7 01                    3596 	.uleb128	1
      0004D8 11                    3597 	.uleb128	17
      0004D9 01                    3598 	.db	1
      0004DA 03                    3599 	.uleb128	3
      0004DB 08                    3600 	.uleb128	8
      0004DC 10                    3601 	.uleb128	16
      0004DD 06                    3602 	.uleb128	6
      0004DE 13                    3603 	.uleb128	19
      0004DF 0B                    3604 	.uleb128	11
      0004E0 25                    3605 	.uleb128	37
      0004E1 08                    3606 	.uleb128	8
      0004E2 00                    3607 	.uleb128	0
      0004E3 00                    3608 	.uleb128	0
      0004E4 05                    3609 	.uleb128	5
      0004E5 0B                    3610 	.uleb128	11
      0004E6 00                    3611 	.db	0
      0004E7 11                    3612 	.uleb128	17
      0004E8 01                    3613 	.uleb128	1
      0004E9 12                    3614 	.uleb128	18
      0004EA 01                    3615 	.uleb128	1
      0004EB 00                    3616 	.uleb128	0
      0004EC 00                    3617 	.uleb128	0
      0004ED 07                    3618 	.uleb128	7
      0004EE 0B                    3619 	.uleb128	11
      0004EF 01                    3620 	.db	1
      0004F0 01                    3621 	.uleb128	1
      0004F1 13                    3622 	.uleb128	19
      0004F2 11                    3623 	.uleb128	17
      0004F3 01                    3624 	.uleb128	1
      0004F4 00                    3625 	.uleb128	0
      0004F5 00                    3626 	.uleb128	0
      0004F6 02                    3627 	.uleb128	2
      0004F7 2E                    3628 	.uleb128	46
      0004F8 00                    3629 	.db	0
      0004F9 03                    3630 	.uleb128	3
      0004FA 08                    3631 	.uleb128	8
      0004FB 11                    3632 	.uleb128	17
      0004FC 01                    3633 	.uleb128	1
      0004FD 12                    3634 	.uleb128	18
      0004FE 01                    3635 	.uleb128	1
      0004FF 3F                    3636 	.uleb128	63
      000500 0C                    3637 	.uleb128	12
      000501 40                    3638 	.uleb128	64
      000502 06                    3639 	.uleb128	6
      000503 00                    3640 	.uleb128	0
      000504 00                    3641 	.uleb128	0
      000505 0A                    3642 	.uleb128	10
      000506 0B                    3643 	.uleb128	11
      000507 01                    3644 	.db	1
      000508 01                    3645 	.uleb128	1
      000509 13                    3646 	.uleb128	19
      00050A 11                    3647 	.uleb128	17
      00050B 01                    3648 	.uleb128	1
      00050C 12                    3649 	.uleb128	18
      00050D 01                    3650 	.uleb128	1
      00050E 00                    3651 	.uleb128	0
      00050F 00                    3652 	.uleb128	0
      000510 0F                    3653 	.uleb128	15
      000511 21                    3654 	.uleb128	33
      000512 00                    3655 	.db	0
      000513 2F                    3656 	.uleb128	47
      000514 0B                    3657 	.uleb128	11
      000515 00                    3658 	.uleb128	0
      000516 00                    3659 	.uleb128	0
      000517 06                    3660 	.uleb128	6
      000518 24                    3661 	.uleb128	36
      000519 00                    3662 	.db	0
      00051A 03                    3663 	.uleb128	3
      00051B 08                    3664 	.uleb128	8
      00051C 0B                    3665 	.uleb128	11
      00051D 0B                    3666 	.uleb128	11
      00051E 3E                    3667 	.uleb128	62
      00051F 0B                    3668 	.uleb128	11
      000520 00                    3669 	.uleb128	0
      000521 00                    3670 	.uleb128	0
      000522 00                    3671 	.uleb128	0
                                   3672 
                                   3673 	.area .debug_info (NOLOAD)
      002769 00 00 08 FA           3674 	.dw	0,Ldebug_info_end-Ldebug_info_start
      00276D                       3675 Ldebug_info_start:
      00276D 00 02                 3676 	.dw	2
      00276F 00 00 04 66           3677 	.dw	0,(Ldebug_abbrev)
      002773 04                    3678 	.db	4
      002774 01                    3679 	.uleb128	1
      002775 2E 2E 2F 53 50 4C 2F  3680 	.ascii "../SPL/src/stm8s_clk.c"
             73 72 63 2F 73 74 6D
             38 73 5F 63 6C 6B 2E
             63
      00278B 00                    3681 	.db	0
      00278C 00 00 16 E5           3682 	.dw	0,(Ldebug_line_start+-4)
      002790 01                    3683 	.db	1
      002791 53 44 43 43 20 76 65  3684 	.ascii "SDCC version 4.1.0 #12072"
             72 73 69 6F 6E 20 34
             2E 31 2E 30 20 23 31
             32 30 37 32
      0027AA 00                    3685 	.db	0
      0027AB 02                    3686 	.uleb128	2
      0027AC 43 4C 4B 5F 44 65 49  3687 	.ascii "CLK_DeInit"
             6E 69 74
      0027B6 00                    3688 	.db	0
      0027B7 00 00 90 55           3689 	.dw	0,(_CLK_DeInit)
      0027BB 00 00 90 8F           3690 	.dw	0,(XG$CLK_DeInit$0$0+1)
      0027BF 01                    3691 	.db	1
      0027C0 00 00 29 38           3692 	.dw	0,(Ldebug_loc_start+932)
      0027C4 03                    3693 	.uleb128	3
      0027C5 00 00 00 A7           3694 	.dw	0,167
      0027C9 43 4C 4B 5F 46 61 73  3695 	.ascii "CLK_FastHaltWakeUpCmd"
             74 48 61 6C 74 57 61
             6B 65 55 70 43 6D 64
      0027DE 00                    3696 	.db	0
      0027DF 00 00 90 8F           3697 	.dw	0,(_CLK_FastHaltWakeUpCmd)
      0027E3 00 00 90 A7           3698 	.dw	0,(XG$CLK_FastHaltWakeUpCmd$0$0+1)
      0027E7 01                    3699 	.db	1
      0027E8 00 00 29 24           3700 	.dw	0,(Ldebug_loc_start+912)
      0027EC 04                    3701 	.uleb128	4
      0027ED 02                    3702 	.db	2
      0027EE 91                    3703 	.db	145
      0027EF 02                    3704 	.sleb128	2
      0027F0 4E 65 77 53 74 61 74  3705 	.ascii "NewState"
             65
      0027F8 00                    3706 	.db	0
      0027F9 00 00 00 A7           3707 	.dw	0,167
      0027FD 05                    3708 	.uleb128	5
      0027FE 00 00 90 99           3709 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$22)
      002802 00 00 90 9E           3710 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$24)
      002806 05                    3711 	.uleb128	5
      002807 00 00 90 A1           3712 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$25)
      00280B 00 00 90 A6           3713 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$27)
      00280F 00                    3714 	.uleb128	0
      002810 06                    3715 	.uleb128	6
      002811 75 6E 73 69 67 6E 65  3716 	.ascii "unsigned char"
             64 20 63 68 61 72
      00281E 00                    3717 	.db	0
      00281F 01                    3718 	.db	1
      002820 08                    3719 	.db	8
      002821 03                    3720 	.uleb128	3
      002822 00 00 00 F9           3721 	.dw	0,249
      002826 43 4C 4B 5F 48 53 45  3722 	.ascii "CLK_HSECmd"
             43 6D 64
      002830 00                    3723 	.db	0
      002831 00 00 90 A7           3724 	.dw	0,(_CLK_HSECmd)
      002835 00 00 90 BF           3725 	.dw	0,(XG$CLK_HSECmd$0$0+1)
      002839 01                    3726 	.db	1
      00283A 00 00 29 10           3727 	.dw	0,(Ldebug_loc_start+892)
      00283E 04                    3728 	.uleb128	4
      00283F 02                    3729 	.db	2
      002840 91                    3730 	.db	145
      002841 02                    3731 	.sleb128	2
      002842 4E 65 77 53 74 61 74  3732 	.ascii "NewState"
             65
      00284A 00                    3733 	.db	0
      00284B 00 00 00 A7           3734 	.dw	0,167
      00284F 05                    3735 	.uleb128	5
      002850 00 00 90 B1           3736 	.dw	0,(Sstm8s_clk$CLK_HSECmd$35)
      002854 00 00 90 B6           3737 	.dw	0,(Sstm8s_clk$CLK_HSECmd$37)
      002858 05                    3738 	.uleb128	5
      002859 00 00 90 B9           3739 	.dw	0,(Sstm8s_clk$CLK_HSECmd$38)
      00285D 00 00 90 BE           3740 	.dw	0,(Sstm8s_clk$CLK_HSECmd$40)
      002861 00                    3741 	.uleb128	0
      002862 03                    3742 	.uleb128	3
      002863 00 00 01 3A           3743 	.dw	0,314
      002867 43 4C 4B 5F 48 53 49  3744 	.ascii "CLK_HSICmd"
             43 6D 64
      002871 00                    3745 	.db	0
      002872 00 00 90 BF           3746 	.dw	0,(_CLK_HSICmd)
      002876 00 00 90 D7           3747 	.dw	0,(XG$CLK_HSICmd$0$0+1)
      00287A 01                    3748 	.db	1
      00287B 00 00 28 FC           3749 	.dw	0,(Ldebug_loc_start+872)
      00287F 04                    3750 	.uleb128	4
      002880 02                    3751 	.db	2
      002881 91                    3752 	.db	145
      002882 02                    3753 	.sleb128	2
      002883 4E 65 77 53 74 61 74  3754 	.ascii "NewState"
             65
      00288B 00                    3755 	.db	0
      00288C 00 00 00 A7           3756 	.dw	0,167
      002890 05                    3757 	.uleb128	5
      002891 00 00 90 C9           3758 	.dw	0,(Sstm8s_clk$CLK_HSICmd$48)
      002895 00 00 90 CE           3759 	.dw	0,(Sstm8s_clk$CLK_HSICmd$50)
      002899 05                    3760 	.uleb128	5
      00289A 00 00 90 D1           3761 	.dw	0,(Sstm8s_clk$CLK_HSICmd$51)
      00289E 00 00 90 D6           3762 	.dw	0,(Sstm8s_clk$CLK_HSICmd$53)
      0028A2 00                    3763 	.uleb128	0
      0028A3 03                    3764 	.uleb128	3
      0028A4 00 00 01 7B           3765 	.dw	0,379
      0028A8 43 4C 4B 5F 4C 53 49  3766 	.ascii "CLK_LSICmd"
             43 6D 64
      0028B2 00                    3767 	.db	0
      0028B3 00 00 90 D7           3768 	.dw	0,(_CLK_LSICmd)
      0028B7 00 00 90 EF           3769 	.dw	0,(XG$CLK_LSICmd$0$0+1)
      0028BB 01                    3770 	.db	1
      0028BC 00 00 28 E8           3771 	.dw	0,(Ldebug_loc_start+852)
      0028C0 04                    3772 	.uleb128	4
      0028C1 02                    3773 	.db	2
      0028C2 91                    3774 	.db	145
      0028C3 02                    3775 	.sleb128	2
      0028C4 4E 65 77 53 74 61 74  3776 	.ascii "NewState"
             65
      0028CC 00                    3777 	.db	0
      0028CD 00 00 00 A7           3778 	.dw	0,167
      0028D1 05                    3779 	.uleb128	5
      0028D2 00 00 90 E1           3780 	.dw	0,(Sstm8s_clk$CLK_LSICmd$61)
      0028D6 00 00 90 E6           3781 	.dw	0,(Sstm8s_clk$CLK_LSICmd$63)
      0028DA 05                    3782 	.uleb128	5
      0028DB 00 00 90 E9           3783 	.dw	0,(Sstm8s_clk$CLK_LSICmd$64)
      0028DF 00 00 90 EE           3784 	.dw	0,(Sstm8s_clk$CLK_LSICmd$66)
      0028E3 00                    3785 	.uleb128	0
      0028E4 03                    3786 	.uleb128	3
      0028E5 00 00 01 BC           3787 	.dw	0,444
      0028E9 43 4C 4B 5F 43 43 4F  3788 	.ascii "CLK_CCOCmd"
             43 6D 64
      0028F3 00                    3789 	.db	0
      0028F4 00 00 90 EF           3790 	.dw	0,(_CLK_CCOCmd)
      0028F8 00 00 91 07           3791 	.dw	0,(XG$CLK_CCOCmd$0$0+1)
      0028FC 01                    3792 	.db	1
      0028FD 00 00 28 D4           3793 	.dw	0,(Ldebug_loc_start+832)
      002901 04                    3794 	.uleb128	4
      002902 02                    3795 	.db	2
      002903 91                    3796 	.db	145
      002904 02                    3797 	.sleb128	2
      002905 4E 65 77 53 74 61 74  3798 	.ascii "NewState"
             65
      00290D 00                    3799 	.db	0
      00290E 00 00 00 A7           3800 	.dw	0,167
      002912 05                    3801 	.uleb128	5
      002913 00 00 90 F9           3802 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$74)
      002917 00 00 90 FE           3803 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$76)
      00291B 05                    3804 	.uleb128	5
      00291C 00 00 91 01           3805 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$77)
      002920 00 00 91 06           3806 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$79)
      002924 00                    3807 	.uleb128	0
      002925 03                    3808 	.uleb128	3
      002926 00 00 02 05           3809 	.dw	0,517
      00292A 43 4C 4B 5F 43 6C 6F  3810 	.ascii "CLK_ClockSwitchCmd"
             63 6B 53 77 69 74 63
             68 43 6D 64
      00293C 00                    3811 	.db	0
      00293D 00 00 91 07           3812 	.dw	0,(_CLK_ClockSwitchCmd)
      002941 00 00 91 1F           3813 	.dw	0,(XG$CLK_ClockSwitchCmd$0$0+1)
      002945 01                    3814 	.db	1
      002946 00 00 28 C0           3815 	.dw	0,(Ldebug_loc_start+812)
      00294A 04                    3816 	.uleb128	4
      00294B 02                    3817 	.db	2
      00294C 91                    3818 	.db	145
      00294D 02                    3819 	.sleb128	2
      00294E 4E 65 77 53 74 61 74  3820 	.ascii "NewState"
             65
      002956 00                    3821 	.db	0
      002957 00 00 00 A7           3822 	.dw	0,167
      00295B 05                    3823 	.uleb128	5
      00295C 00 00 91 11           3824 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$87)
      002960 00 00 91 16           3825 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$89)
      002964 05                    3826 	.uleb128	5
      002965 00 00 91 19           3827 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$90)
      002969 00 00 91 1E           3828 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$92)
      00296D 00                    3829 	.uleb128	0
      00296E 03                    3830 	.uleb128	3
      00296F 00 00 02 57           3831 	.dw	0,599
      002973 43 4C 4B 5F 53 6C 6F  3832 	.ascii "CLK_SlowActiveHaltWakeUpCmd"
             77 41 63 74 69 76 65
             48 61 6C 74 57 61 6B
             65 55 70 43 6D 64
      00298E 00                    3833 	.db	0
      00298F 00 00 91 1F           3834 	.dw	0,(_CLK_SlowActiveHaltWakeUpCmd)
      002993 00 00 91 37           3835 	.dw	0,(XG$CLK_SlowActiveHaltWakeUpCmd$0$0+1)
      002997 01                    3836 	.db	1
      002998 00 00 28 AC           3837 	.dw	0,(Ldebug_loc_start+792)
      00299C 04                    3838 	.uleb128	4
      00299D 02                    3839 	.db	2
      00299E 91                    3840 	.db	145
      00299F 02                    3841 	.sleb128	2
      0029A0 4E 65 77 53 74 61 74  3842 	.ascii "NewState"
             65
      0029A8 00                    3843 	.db	0
      0029A9 00 00 00 A7           3844 	.dw	0,167
      0029AD 05                    3845 	.uleb128	5
      0029AE 00 00 91 29           3846 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$100)
      0029B2 00 00 91 2E           3847 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$102)
      0029B6 05                    3848 	.uleb128	5
      0029B7 00 00 91 31           3849 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$103)
      0029BB 00 00 91 36           3850 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$105)
      0029BF 00                    3851 	.uleb128	0
      0029C0 03                    3852 	.uleb128	3
      0029C1 00 00 02 E0           3853 	.dw	0,736
      0029C5 43 4C 4B 5F 50 65 72  3854 	.ascii "CLK_PeripheralClockConfig"
             69 70 68 65 72 61 6C
             43 6C 6F 63 6B 43 6F
             6E 66 69 67
      0029DE 00                    3855 	.db	0
      0029DF 00 00 91 37           3856 	.dw	0,(_CLK_PeripheralClockConfig)
      0029E3 00 00 91 8B           3857 	.dw	0,(XG$CLK_PeripheralClockConfig$0$0+1)
      0029E7 01                    3858 	.db	1
      0029E8 00 00 28 68           3859 	.dw	0,(Ldebug_loc_start+724)
      0029EC 04                    3860 	.uleb128	4
      0029ED 02                    3861 	.db	2
      0029EE 91                    3862 	.db	145
      0029EF 02                    3863 	.sleb128	2
      0029F0 43 4C 4B 5F 50 65 72  3864 	.ascii "CLK_Peripheral"
             69 70 68 65 72 61 6C
      0029FE 00                    3865 	.db	0
      0029FF 00 00 00 A7           3866 	.dw	0,167
      002A03 04                    3867 	.uleb128	4
      002A04 02                    3868 	.db	2
      002A05 91                    3869 	.db	145
      002A06 03                    3870 	.sleb128	3
      002A07 4E 65 77 53 74 61 74  3871 	.ascii "NewState"
             65
      002A0F 00                    3872 	.db	0
      002A10 00 00 00 A7           3873 	.dw	0,167
      002A14 07                    3874 	.uleb128	7
      002A15 00 00 02 C7           3875 	.dw	0,711
      002A19 00 00 91 5B           3876 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$118)
      002A1D 05                    3877 	.uleb128	5
      002A1E 00 00 91 62           3878 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$120)
      002A22 00 00 91 67           3879 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$122)
      002A26 05                    3880 	.uleb128	5
      002A27 00 00 91 6A           3881 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$123)
      002A2B 00 00 91 6F           3882 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$125)
      002A2F 00                    3883 	.uleb128	0
      002A30 08                    3884 	.uleb128	8
      002A31 00 00 91 75           3885 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$127)
      002A35 05                    3886 	.uleb128	5
      002A36 00 00 91 7C           3887 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$129)
      002A3A 00 00 91 81           3888 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$131)
      002A3E 05                    3889 	.uleb128	5
      002A3F 00 00 91 84           3890 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$132)
      002A43 00 00 91 89           3891 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$134)
      002A47 00                    3892 	.uleb128	0
      002A48 00                    3893 	.uleb128	0
      002A49 09                    3894 	.uleb128	9
      002A4A 00 00 04 3B           3895 	.dw	0,1083
      002A4E 43 4C 4B 5F 43 6C 6F  3896 	.ascii "CLK_ClockSwitchConfig"
             63 6B 53 77 69 74 63
             68 43 6F 6E 66 69 67
      002A63 00                    3897 	.db	0
      002A64 00 00 91 8B           3898 	.dw	0,(_CLK_ClockSwitchConfig)
      002A68 00 00 92 91           3899 	.dw	0,(XG$CLK_ClockSwitchConfig$0$0+1)
      002A6C 01                    3900 	.db	1
      002A6D 00 00 27 F4           3901 	.dw	0,(Ldebug_loc_start+608)
      002A71 00 00 00 A7           3902 	.dw	0,167
      002A75 04                    3903 	.uleb128	4
      002A76 02                    3904 	.db	2
      002A77 91                    3905 	.db	145
      002A78 02                    3906 	.sleb128	2
      002A79 43 4C 4B 5F 53 77 69  3907 	.ascii "CLK_SwitchMode"
             74 63 68 4D 6F 64 65
      002A87 00                    3908 	.db	0
      002A88 00 00 00 A7           3909 	.dw	0,167
      002A8C 04                    3910 	.uleb128	4
      002A8D 02                    3911 	.db	2
      002A8E 91                    3912 	.db	145
      002A8F 03                    3913 	.sleb128	3
      002A90 43 4C 4B 5F 4E 65 77  3914 	.ascii "CLK_NewClock"
             43 6C 6F 63 6B
      002A9C 00                    3915 	.db	0
      002A9D 00 00 00 A7           3916 	.dw	0,167
      002AA1 04                    3917 	.uleb128	4
      002AA2 02                    3918 	.db	2
      002AA3 91                    3919 	.db	145
      002AA4 04                    3920 	.sleb128	4
      002AA5 49 54 53 74 61 74 65  3921 	.ascii "ITState"
      002AAC 00                    3922 	.db	0
      002AAD 00 00 00 A7           3923 	.dw	0,167
      002AB1 04                    3924 	.uleb128	4
      002AB2 02                    3925 	.db	2
      002AB3 91                    3926 	.db	145
      002AB4 05                    3927 	.sleb128	5
      002AB5 43 4C 4B 5F 43 75 72  3928 	.ascii "CLK_CurrentClockState"
             72 65 6E 74 43 6C 6F
             63 6B 53 74 61 74 65
      002ACA 00                    3929 	.db	0
      002ACB 00 00 00 A7           3930 	.dw	0,167
      002ACF 0A                    3931 	.uleb128	10
      002AD0 00 00 03 A1           3932 	.dw	0,929
      002AD4 00 00 91 A3           3933 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$149)
      002AD8 00 00 91 DA           3934 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$165)
      002ADC 05                    3935 	.uleb128	5
      002ADD 00 00 91 B2           3936 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$153)
      002AE1 00 00 91 B7           3937 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$155)
      002AE5 05                    3938 	.uleb128	5
      002AE6 00 00 91 BA           3939 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$156)
      002AEA 00 00 91 BF           3940 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$158)
      002AEE 05                    3941 	.uleb128	5
      002AEF 00 00 91 D6           3942 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$162)
      002AF3 00 00 91 D7           3943 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$164)
      002AF7 05                    3944 	.uleb128	5
      002AF8 00 00 91 E0           3945 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$167)
      002AFC 00 00 91 E3           3946 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$169)
      002B00 05                    3947 	.uleb128	5
      002B01 00 00 91 E6           3948 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$170)
      002B05 00 00 91 E7           3949 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$172)
      002B09 00                    3950 	.uleb128	0
      002B0A 0A                    3951 	.uleb128	10
      002B0B 00 00 03 DC           3952 	.dw	0,988
      002B0F 00 00 91 EA           3953 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$173)
      002B13 00 00 92 1A           3954 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$187)
      002B17 05                    3955 	.uleb128	5
      002B18 00 00 91 F1           3956 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$175)
      002B1C 00 00 91 F6           3957 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$177)
      002B20 05                    3958 	.uleb128	5
      002B21 00 00 91 F9           3959 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$178)
      002B25 00 00 91 FE           3960 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$180)
      002B29 05                    3961 	.uleb128	5
      002B2A 00 00 92 16           3962 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$184)
      002B2E 00 00 92 17           3963 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$186)
      002B32 05                    3964 	.uleb128	5
      002B33 00 00 92 20           3965 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$189)
      002B37 00 00 92 2B           3966 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$192)
      002B3B 05                    3967 	.uleb128	5
      002B3C 00 00 92 2E           3968 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$193)
      002B40 00 00 92 2F           3969 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$195)
      002B44 00                    3970 	.uleb128	0
      002B45 07                    3971 	.uleb128	7
      002B46 00 00 04 01           3972 	.dw	0,1025
      002B4A 00 00 92 36           3973 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$197)
      002B4E 05                    3974 	.uleb128	5
      002B4F 00 00 92 49           3975 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$200)
      002B53 00 00 92 51           3976 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$202)
      002B57 05                    3977 	.uleb128	5
      002B58 00 00 92 67           3978 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$205)
      002B5C 00 00 92 6F           3979 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$207)
      002B60 05                    3980 	.uleb128	5
      002B61 00 00 92 85           3981 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$210)
      002B65 00 00 92 8D           3982 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$212)
      002B69 00                    3983 	.uleb128	0
      002B6A 0B                    3984 	.uleb128	11
      002B6B 02                    3985 	.db	2
      002B6C 91                    3986 	.db	145
      002B6D 7F                    3987 	.sleb128	-1
      002B6E 63 6C 6F 63 6B 5F 6D  3988 	.ascii "clock_master"
             61 73 74 65 72
      002B7A 00                    3989 	.db	0
      002B7B 00 00 00 A7           3990 	.dw	0,167
      002B7F 0B                    3991 	.uleb128	11
      002B80 06                    3992 	.db	6
      002B81 52                    3993 	.db	82
      002B82 93                    3994 	.db	147
      002B83 01                    3995 	.uleb128	1
      002B84 51                    3996 	.db	81
      002B85 93                    3997 	.db	147
      002B86 01                    3998 	.uleb128	1
      002B87 44 6F 77 6E 43 6F 75  3999 	.ascii "DownCounter"
             6E 74 65 72
      002B92 00                    4000 	.db	0
      002B93 00 00 04 3B           4001 	.dw	0,1083
      002B97 0B                    4002 	.uleb128	11
      002B98 01                    4003 	.db	1
      002B99 51                    4004 	.db	81
      002B9A 53 77 69 66           4005 	.ascii "Swif"
      002B9E 00                    4006 	.db	0
      002B9F 00 00 00 A7           4007 	.dw	0,167
      002BA3 00                    4008 	.uleb128	0
      002BA4 06                    4009 	.uleb128	6
      002BA5 75 6E 73 69 67 6E 65  4010 	.ascii "unsigned int"
             64 20 69 6E 74
      002BB1 00                    4011 	.db	0
      002BB2 02                    4012 	.db	2
      002BB3 07                    4013 	.db	7
      002BB4 03                    4014 	.uleb128	3
      002BB5 00 00 04 8A           4015 	.dw	0,1162
      002BB9 43 4C 4B 5F 48 53 49  4016 	.ascii "CLK_HSIPrescalerConfig"
             50 72 65 73 63 61 6C
             65 72 43 6F 6E 66 69
             67
      002BCF 00                    4017 	.db	0
      002BD0 00 00 92 91           4018 	.dw	0,(_CLK_HSIPrescalerConfig)
      002BD4 00 00 92 A2           4019 	.dw	0,(XG$CLK_HSIPrescalerConfig$0$0+1)
      002BD8 01                    4020 	.db	1
      002BD9 00 00 27 E0           4021 	.dw	0,(Ldebug_loc_start+588)
      002BDD 04                    4022 	.uleb128	4
      002BDE 02                    4023 	.db	2
      002BDF 91                    4024 	.db	145
      002BE0 02                    4025 	.sleb128	2
      002BE1 48 53 49 50 72 65 73  4026 	.ascii "HSIPrescaler"
             63 61 6C 65 72
      002BED 00                    4027 	.db	0
      002BEE 00 00 00 A7           4028 	.dw	0,167
      002BF2 00                    4029 	.uleb128	0
      002BF3 03                    4030 	.uleb128	3
      002BF4 00 00 04 BB           4031 	.dw	0,1211
      002BF8 43 4C 4B 5F 43 43 4F  4032 	.ascii "CLK_CCOConfig"
             43 6F 6E 66 69 67
      002C05 00                    4033 	.db	0
      002C06 00 00 92 A2           4034 	.dw	0,(_CLK_CCOConfig)
      002C0A 00 00 92 BB           4035 	.dw	0,(XG$CLK_CCOConfig$0$0+1)
      002C0E 01                    4036 	.db	1
      002C0F 00 00 27 CC           4037 	.dw	0,(Ldebug_loc_start+568)
      002C13 04                    4038 	.uleb128	4
      002C14 02                    4039 	.db	2
      002C15 91                    4040 	.db	145
      002C16 02                    4041 	.sleb128	2
      002C17 43 4C 4B 5F 43 43 4F  4042 	.ascii "CLK_CCO"
      002C1E 00                    4043 	.db	0
      002C1F 00 00 00 A7           4044 	.dw	0,167
      002C23 00                    4045 	.uleb128	0
      002C24 03                    4046 	.uleb128	3
      002C25 00 00 05 1D           4047 	.dw	0,1309
      002C29 43 4C 4B 5F 49 54 43  4048 	.ascii "CLK_ITConfig"
             6F 6E 66 69 67
      002C35 00                    4049 	.db	0
      002C36 00 00 92 BB           4050 	.dw	0,(_CLK_ITConfig)
      002C3A 00 00 93 23           4051 	.dw	0,(XG$CLK_ITConfig$0$0+1)
      002C3E 01                    4052 	.db	1
      002C3F 00 00 27 88           4053 	.dw	0,(Ldebug_loc_start+500)
      002C43 04                    4054 	.uleb128	4
      002C44 02                    4055 	.db	2
      002C45 91                    4056 	.db	145
      002C46 02                    4057 	.sleb128	2
      002C47 43 4C 4B 5F 49 54     4058 	.ascii "CLK_IT"
      002C4D 00                    4059 	.db	0
      002C4E 00 00 00 A7           4060 	.dw	0,167
      002C52 04                    4061 	.uleb128	4
      002C53 02                    4062 	.db	2
      002C54 91                    4063 	.db	145
      002C55 03                    4064 	.sleb128	3
      002C56 4E 65 77 53 74 61 74  4065 	.ascii "NewState"
             65
      002C5E 00                    4066 	.db	0
      002C5F 00 00 00 A7           4067 	.dw	0,167
      002C63 07                    4068 	.uleb128	7
      002C64 00 00 05 0D           4069 	.dw	0,1293
      002C68 00 00 92 DE           4070 	.dw	0,(Sstm8s_clk$CLK_ITConfig$240)
      002C6C 05                    4071 	.uleb128	5
      002C6D 00 00 92 EB           4072 	.dw	0,(Sstm8s_clk$CLK_ITConfig$242)
      002C71 00 00 93 01           4073 	.dw	0,(Sstm8s_clk$CLK_ITConfig$248)
      002C75 00                    4074 	.uleb128	0
      002C76 08                    4075 	.uleb128	8
      002C77 00 00 93 01           4076 	.dw	0,(Sstm8s_clk$CLK_ITConfig$250)
      002C7B 05                    4077 	.uleb128	5
      002C7C 00 00 93 0E           4078 	.dw	0,(Sstm8s_clk$CLK_ITConfig$252)
      002C80 00 00 93 21           4079 	.dw	0,(Sstm8s_clk$CLK_ITConfig$257)
      002C84 00                    4080 	.uleb128	0
      002C85 00                    4081 	.uleb128	0
      002C86 03                    4082 	.uleb128	3
      002C87 00 00 05 69           4083 	.dw	0,1385
      002C8B 43 4C 4B 5F 53 59 53  4084 	.ascii "CLK_SYSCLKConfig"
             43 4C 4B 43 6F 6E 66
             69 67
      002C9B 00                    4085 	.db	0
      002C9C 00 00 93 23           4086 	.dw	0,(_CLK_SYSCLKConfig)
      002CA0 00 00 93 59           4087 	.dw	0,(XG$CLK_SYSCLKConfig$0$0+1)
      002CA4 01                    4088 	.db	1
      002CA5 00 00 27 5C           4089 	.dw	0,(Ldebug_loc_start+456)
      002CA9 04                    4090 	.uleb128	4
      002CAA 02                    4091 	.db	2
      002CAB 91                    4092 	.db	145
      002CAC 02                    4093 	.sleb128	2
      002CAD 43 4C 4B 5F 50 72 65  4094 	.ascii "CLK_Prescaler"
             73 63 61 6C 65 72
      002CBA 00                    4095 	.db	0
      002CBB 00 00 00 A7           4096 	.dw	0,167
      002CBF 05                    4097 	.uleb128	5
      002CC0 00 00 93 2E           4098 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$268)
      002CC4 00 00 93 41           4099 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$271)
      002CC8 05                    4100 	.uleb128	5
      002CC9 00 00 93 44           4101 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$272)
      002CCD 00 00 93 57           4102 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$275)
      002CD1 00                    4103 	.uleb128	0
      002CD2 03                    4104 	.uleb128	3
      002CD3 00 00 05 B5           4105 	.dw	0,1461
      002CD7 43 4C 4B 5F 53 57 49  4106 	.ascii "CLK_SWIMConfig"
             4D 43 6F 6E 66 69 67
      002CE5 00                    4107 	.db	0
      002CE6 00 00 93 59           4108 	.dw	0,(_CLK_SWIMConfig)
      002CEA 00 00 93 71           4109 	.dw	0,(XG$CLK_SWIMConfig$0$0+1)
      002CEE 01                    4110 	.db	1
      002CEF 00 00 27 48           4111 	.dw	0,(Ldebug_loc_start+436)
      002CF3 04                    4112 	.uleb128	4
      002CF4 02                    4113 	.db	2
      002CF5 91                    4114 	.db	145
      002CF6 02                    4115 	.sleb128	2
      002CF7 43 4C 4B 5F 53 57 49  4116 	.ascii "CLK_SWIMDivider"
             4D 44 69 76 69 64 65
             72
      002D06 00                    4117 	.db	0
      002D07 00 00 00 A7           4118 	.dw	0,167
      002D0B 05                    4119 	.uleb128	5
      002D0C 00 00 93 63           4120 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$284)
      002D10 00 00 93 68           4121 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$286)
      002D14 05                    4122 	.uleb128	5
      002D15 00 00 93 6B           4123 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$287)
      002D19 00 00 93 70           4124 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$289)
      002D1D 00                    4125 	.uleb128	0
      002D1E 02                    4126 	.uleb128	2
      002D1F 43 4C 4B 5F 43 6C 6F  4127 	.ascii "CLK_ClockSecuritySystemEnable"
             63 6B 53 65 63 75 72
             69 74 79 53 79 73 74
             65 6D 45 6E 61 62 6C
             65
      002D3C 00                    4128 	.db	0
      002D3D 00 00 93 71           4129 	.dw	0,(_CLK_ClockSecuritySystemEnable)
      002D41 00 00 93 7A           4130 	.dw	0,(XG$CLK_ClockSecuritySystemEnable$0$0+1)
      002D45 01                    4131 	.db	1
      002D46 00 00 27 34           4132 	.dw	0,(Ldebug_loc_start+416)
      002D4A 0C                    4133 	.uleb128	12
      002D4B 43 4C 4B 5F 47 65 74  4134 	.ascii "CLK_GetSYSCLKSource"
             53 59 53 43 4C 4B 53
             6F 75 72 63 65
      002D5E 00                    4135 	.db	0
      002D5F 00 00 93 7A           4136 	.dw	0,(_CLK_GetSYSCLKSource)
      002D63 00 00 93 7E           4137 	.dw	0,(XG$CLK_GetSYSCLKSource$0$0+1)
      002D67 01                    4138 	.db	1
      002D68 00 00 27 20           4139 	.dw	0,(Ldebug_loc_start+396)
      002D6C 00 00 00 A7           4140 	.dw	0,167
      002D70 06                    4141 	.uleb128	6
      002D71 75 6E 73 69 67 6E 65  4142 	.ascii "unsigned long"
             64 20 6C 6F 6E 67
      002D7E 00                    4143 	.db	0
      002D7F 04                    4144 	.db	4
      002D80 07                    4145 	.db	7
      002D81 09                    4146 	.uleb128	9
      002D82 00 00 06 AA           4147 	.dw	0,1706
      002D86 43 4C 4B 5F 47 65 74  4148 	.ascii "CLK_GetClockFreq"
             43 6C 6F 63 6B 46 72
             65 71
      002D96 00                    4149 	.db	0
      002D97 00 00 93 7E           4150 	.dw	0,(_CLK_GetClockFreq)
      002D9B 00 00 93 DD           4151 	.dw	0,(XG$CLK_GetClockFreq$0$0+1)
      002D9F 01                    4152 	.db	1
      002DA0 00 00 26 88           4153 	.dw	0,(Ldebug_loc_start+244)
      002DA4 00 00 06 07           4154 	.dw	0,1543
      002DA8 05                    4155 	.uleb128	5
      002DA9 00 00 93 91           4156 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$311)
      002DAD 00 00 93 A3           4157 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$316)
      002DB1 05                    4158 	.uleb128	5
      002DB2 00 00 93 C5           4159 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$326)
      002DB6 00 00 93 CC           4160 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$328)
      002DBA 05                    4161 	.uleb128	5
      002DBB 00 00 93 CF           4162 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$329)
      002DBF 00 00 93 D7           4163 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$331)
      002DC3 0B                    4164 	.uleb128	11
      002DC4 0E                    4165 	.db	14
      002DC5 52                    4166 	.db	82
      002DC6 93                    4167 	.db	147
      002DC7 01                    4168 	.uleb128	1
      002DC8 51                    4169 	.db	81
      002DC9 93                    4170 	.db	147
      002DCA 01                    4171 	.uleb128	1
      002DCB 91                    4172 	.db	145
      002DCC 7E                    4173 	.sleb128	-2
      002DCD 93                    4174 	.db	147
      002DCE 01                    4175 	.uleb128	1
      002DCF 91                    4176 	.db	145
      002DD0 7F                    4177 	.sleb128	-1
      002DD1 93                    4178 	.db	147
      002DD2 01                    4179 	.uleb128	1
      002DD3 63 6C 6F 63 6B 66 72  4180 	.ascii "clockfrequency"
             65 71 75 65 6E 63 79
      002DE1 00                    4181 	.db	0
      002DE2 00 00 06 07           4182 	.dw	0,1543
      002DE6 0B                    4183 	.uleb128	11
      002DE7 02                    4184 	.db	2
      002DE8 91                    4185 	.db	145
      002DE9 7F                    4186 	.sleb128	-1
      002DEA 63 6C 6F 63 6B 73 6F  4187 	.ascii "clocksource"
             75 72 63 65
      002DF5 00                    4188 	.db	0
      002DF6 00 00 00 A7           4189 	.dw	0,167
      002DFA 0B                    4190 	.uleb128	11
      002DFB 01                    4191 	.db	1
      002DFC 50                    4192 	.db	80
      002DFD 74 6D 70              4193 	.ascii "tmp"
      002E00 00                    4194 	.db	0
      002E01 00 00 00 A7           4195 	.dw	0,167
      002E05 0B                    4196 	.uleb128	11
      002E06 01                    4197 	.db	1
      002E07 50                    4198 	.db	80
      002E08 70 72 65 73 63        4199 	.ascii "presc"
      002E0D 00                    4200 	.db	0
      002E0E 00 00 00 A7           4201 	.dw	0,167
      002E12 00                    4202 	.uleb128	0
      002E13 03                    4203 	.uleb128	3
      002E14 00 00 06 FB           4204 	.dw	0,1787
      002E18 43 4C 4B 5F 41 64 6A  4205 	.ascii "CLK_AdjustHSICalibrationValue"
             75 73 74 48 53 49 43
             61 6C 69 62 72 61 74
             69 6F 6E 56 61 6C 75
             65
      002E35 00                    4206 	.db	0
      002E36 00 00 93 DD           4207 	.dw	0,(_CLK_AdjustHSICalibrationValue)
      002E3A 00 00 93 E8           4208 	.dw	0,(XG$CLK_AdjustHSICalibrationValue$0$0+1)
      002E3E 01                    4209 	.db	1
      002E3F 00 00 26 74           4210 	.dw	0,(Ldebug_loc_start+224)
      002E43 04                    4211 	.uleb128	4
      002E44 02                    4212 	.db	2
      002E45 91                    4213 	.db	145
      002E46 02                    4214 	.sleb128	2
      002E47 43 4C 4B 5F 48 53 49  4215 	.ascii "CLK_HSICalibrationValue"
             43 61 6C 69 62 72 61
             74 69 6F 6E 56 61 6C
             75 65
      002E5E 00                    4216 	.db	0
      002E5F 00 00 00 A7           4217 	.dw	0,167
      002E63 00                    4218 	.uleb128	0
      002E64 02                    4219 	.uleb128	2
      002E65 43 4C 4B 5F 53 59 53  4220 	.ascii "CLK_SYSCLKEmergencyClear"
             43 4C 4B 45 6D 65 72
             67 65 6E 63 79 43 6C
             65 61 72
      002E7D 00                    4221 	.db	0
      002E7E 00 00 93 E8           4222 	.dw	0,(_CLK_SYSCLKEmergencyClear)
      002E82 00 00 93 F1           4223 	.dw	0,(XG$CLK_SYSCLKEmergencyClear$0$0+1)
      002E86 01                    4224 	.db	1
      002E87 00 00 26 60           4225 	.dw	0,(Ldebug_loc_start+204)
      002E8B 09                    4226 	.uleb128	9
      002E8C 00 00 07 D0           4227 	.dw	0,2000
      002E90 43 4C 4B 5F 47 65 74  4228 	.ascii "CLK_GetFlagStatus"
             46 6C 61 67 53 74 61
             74 75 73
      002EA1 00                    4229 	.db	0
      002EA2 00 00 93 F1           4230 	.dw	0,(_CLK_GetFlagStatus)
      002EA6 00 00 94 54           4231 	.dw	0,(XG$CLK_GetFlagStatus$0$0+1)
      002EAA 01                    4232 	.db	1
      002EAB 00 00 25 EC           4233 	.dw	0,(Ldebug_loc_start+88)
      002EAF 00 00 00 A7           4234 	.dw	0,167
      002EB3 04                    4235 	.uleb128	4
      002EB4 02                    4236 	.db	2
      002EB5 91                    4237 	.db	145
      002EB6 02                    4238 	.sleb128	2
      002EB7 43 4C 4B 5F 46 4C 41  4239 	.ascii "CLK_FLAG"
             47
      002EBF 00                    4240 	.db	0
      002EC0 00 00 07 D0           4241 	.dw	0,2000
      002EC4 05                    4242 	.uleb128	5
      002EC5 00 00 94 01           4243 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$355)
      002EC9 00 00 94 04           4244 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$357)
      002ECD 05                    4245 	.uleb128	5
      002ECE 00 00 94 12           4246 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$360)
      002ED2 00 00 94 15           4247 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$362)
      002ED6 05                    4248 	.uleb128	5
      002ED7 00 00 94 23           4249 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$365)
      002EDB 00 00 94 26           4250 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$367)
      002EDF 05                    4251 	.uleb128	5
      002EE0 00 00 94 34           4252 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$370)
      002EE4 00 00 94 37           4253 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$372)
      002EE8 05                    4254 	.uleb128	5
      002EE9 00 00 94 3A           4255 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$373)
      002EED 00 00 94 3D           4256 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$375)
      002EF1 05                    4257 	.uleb128	5
      002EF2 00 00 94 4B           4258 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$379)
      002EF6 00 00 94 4D           4259 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$381)
      002EFA 05                    4260 	.uleb128	5
      002EFB 00 00 94 50           4261 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$382)
      002EFF 00 00 94 51           4262 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$384)
      002F03 0B                    4263 	.uleb128	11
      002F04 06                    4264 	.db	6
      002F05 52                    4265 	.db	82
      002F06 93                    4266 	.db	147
      002F07 01                    4267 	.uleb128	1
      002F08 50                    4268 	.db	80
      002F09 93                    4269 	.db	147
      002F0A 01                    4270 	.uleb128	1
      002F0B 73 74 61 74 75 73 72  4271 	.ascii "statusreg"
             65 67
      002F14 00                    4272 	.db	0
      002F15 00 00 04 3B           4273 	.dw	0,1083
      002F19 0B                    4274 	.uleb128	11
      002F1A 01                    4275 	.db	1
      002F1B 50                    4276 	.db	80
      002F1C 74 6D 70 72 65 67     4277 	.ascii "tmpreg"
      002F22 00                    4278 	.db	0
      002F23 00 00 00 A7           4279 	.dw	0,167
      002F27 0B                    4280 	.uleb128	11
      002F28 01                    4281 	.db	1
      002F29 50                    4282 	.db	80
      002F2A 62 69 74 73 74 61 74  4283 	.ascii "bitstatus"
             75 73
      002F33 00                    4284 	.db	0
      002F34 00 00 00 A7           4285 	.dw	0,167
      002F38 00                    4286 	.uleb128	0
      002F39 06                    4287 	.uleb128	6
      002F3A 75 6E 73 69 67 6E 65  4288 	.ascii "unsigned int"
             64 20 69 6E 74
      002F46 00                    4289 	.db	0
      002F47 02                    4290 	.db	2
      002F48 07                    4291 	.db	7
      002F49 09                    4292 	.uleb128	9
      002F4A 00 00 08 5F           4293 	.dw	0,2143
      002F4E 43 4C 4B 5F 47 65 74  4294 	.ascii "CLK_GetITStatus"
             49 54 53 74 61 74 75
             73
      002F5D 00                    4295 	.db	0
      002F5E 00 00 94 54           4296 	.dw	0,(_CLK_GetITStatus)
      002F62 00 00 94 8E           4297 	.dw	0,(XG$CLK_GetITStatus$0$0+1)
      002F66 01                    4298 	.db	1
      002F67 00 00 25 B4           4299 	.dw	0,(Ldebug_loc_start+32)
      002F6B 00 00 00 A7           4300 	.dw	0,167
      002F6F 04                    4301 	.uleb128	4
      002F70 02                    4302 	.db	2
      002F71 91                    4303 	.db	145
      002F72 02                    4304 	.sleb128	2
      002F73 43 4C 4B 5F 49 54     4305 	.ascii "CLK_IT"
      002F79 00                    4306 	.db	0
      002F7A 00 00 00 A7           4307 	.dw	0,167
      002F7E 07                    4308 	.uleb128	7
      002F7F 00 00 08 31           4309 	.dw	0,2097
      002F83 00 00 94 60           4310 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$394)
      002F87 05                    4311 	.uleb128	5
      002F88 00 00 94 6F           4312 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$397)
      002F8C 00 00 94 71           4313 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$399)
      002F90 05                    4314 	.uleb128	5
      002F91 00 00 94 74           4315 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$400)
      002F95 00 00 94 75           4316 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$402)
      002F99 00                    4317 	.uleb128	0
      002F9A 07                    4318 	.uleb128	7
      002F9B 00 00 08 4D           4319 	.dw	0,2125
      002F9F 00 00 94 78           4320 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$403)
      002FA3 05                    4321 	.uleb128	5
      002FA4 00 00 94 87           4322 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$406)
      002FA8 00 00 94 89           4323 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$408)
      002FAC 05                    4324 	.uleb128	5
      002FAD 00 00 94 8C           4325 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$409)
      002FB1 00 00 94 8D           4326 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$411)
      002FB5 00                    4327 	.uleb128	0
      002FB6 0B                    4328 	.uleb128	11
      002FB7 01                    4329 	.db	1
      002FB8 50                    4330 	.db	80
      002FB9 62 69 74 73 74 61 74  4331 	.ascii "bitstatus"
             75 73
      002FC2 00                    4332 	.db	0
      002FC3 00 00 00 A7           4333 	.dw	0,167
      002FC7 00                    4334 	.uleb128	0
      002FC8 03                    4335 	.uleb128	3
      002FC9 00 00 08 A9           4336 	.dw	0,2217
      002FCD 43 4C 4B 5F 43 6C 65  4337 	.ascii "CLK_ClearITPendingBit"
             61 72 49 54 50 65 6E
             64 69 6E 67 42 69 74
      002FE2 00                    4338 	.db	0
      002FE3 00 00 94 8E           4339 	.dw	0,(_CLK_ClearITPendingBit)
      002FE7 00 00 94 AE           4340 	.dw	0,(XG$CLK_ClearITPendingBit$0$0+1)
      002FEB 01                    4341 	.db	1
      002FEC 00 00 25 94           4342 	.dw	0,(Ldebug_loc_start)
      002FF0 04                    4343 	.uleb128	4
      002FF1 02                    4344 	.db	2
      002FF2 91                    4345 	.db	145
      002FF3 02                    4346 	.sleb128	2
      002FF4 43 4C 4B 5F 49 54     4347 	.ascii "CLK_IT"
      002FFA 00                    4348 	.db	0
      002FFB 00 00 00 A7           4349 	.dw	0,167
      002FFF 05                    4350 	.uleb128	5
      003000 00 00 94 9A           4351 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$420)
      003004 00 00 94 A2           4352 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$422)
      003008 05                    4353 	.uleb128	5
      003009 00 00 94 A5           4354 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$423)
      00300D 00 00 94 AD           4355 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$425)
      003011 00                    4356 	.uleb128	0
      003012 0D                    4357 	.uleb128	13
      003013 00 00 00 A7           4358 	.dw	0,167
      003017 0E                    4359 	.uleb128	14
      003018 00 00 08 BB           4360 	.dw	0,2235
      00301C 04                    4361 	.db	4
      00301D 00 00 08 A9           4362 	.dw	0,2217
      003021 0F                    4363 	.uleb128	15
      003022 03                    4364 	.db	3
      003023 00                    4365 	.uleb128	0
      003024 10                    4366 	.uleb128	16
      003025 05                    4367 	.db	5
      003026 03                    4368 	.db	3
      003027 00 00 80 B4           4369 	.dw	0,(_HSIDivFactor)
      00302B 48 53 49 44 69 76 46  4370 	.ascii "HSIDivFactor"
             61 63 74 6F 72
      003037 00                    4371 	.db	0
      003038 01                    4372 	.db	1
      003039 00 00 08 AE           4373 	.dw	0,2222
      00303D 0E                    4374 	.uleb128	14
      00303E 00 00 08 E1           4375 	.dw	0,2273
      003042 08                    4376 	.db	8
      003043 00 00 08 A9           4377 	.dw	0,2217
      003047 0F                    4378 	.uleb128	15
      003048 07                    4379 	.db	7
      003049 00                    4380 	.uleb128	0
      00304A 10                    4381 	.uleb128	16
      00304B 05                    4382 	.db	5
      00304C 03                    4383 	.db	3
      00304D 00 00 80 B8           4384 	.dw	0,(_CLKPrescTable)
      003051 43 4C 4B 50 72 65 73  4385 	.ascii "CLKPrescTable"
             63 54 61 62 6C 65
      00305E 00                    4386 	.db	0
      00305F 01                    4387 	.db	1
      003060 00 00 08 D4           4388 	.dw	0,2260
      003064 00                    4389 	.uleb128	0
      003065 00                    4390 	.uleb128	0
      003066 00                    4391 	.uleb128	0
      003067                       4392 Ldebug_info_end:
                                   4393 
                                   4394 	.area .debug_pubnames (NOLOAD)
      00068B 00 00 02 3D           4395 	.dw	0,Ldebug_pubnames_end-Ldebug_pubnames_start
      00068F                       4396 Ldebug_pubnames_start:
      00068F 00 02                 4397 	.dw	2
      000691 00 00 27 69           4398 	.dw	0,(Ldebug_info_start-4)
      000695 00 00 08 FE           4399 	.dw	0,4+Ldebug_info_end-Ldebug_info_start
      000699 00 00 00 42           4400 	.dw	0,66
      00069D 43 4C 4B 5F 44 65 49  4401 	.ascii "CLK_DeInit"
             6E 69 74
      0006A7 00                    4402 	.db	0
      0006A8 00 00 00 5B           4403 	.dw	0,91
      0006AC 43 4C 4B 5F 46 61 73  4404 	.ascii "CLK_FastHaltWakeUpCmd"
             74 48 61 6C 74 57 61
             6B 65 55 70 43 6D 64
      0006C1 00                    4405 	.db	0
      0006C2 00 00 00 B8           4406 	.dw	0,184
      0006C6 43 4C 4B 5F 48 53 45  4407 	.ascii "CLK_HSECmd"
             43 6D 64
      0006D0 00                    4408 	.db	0
      0006D1 00 00 00 F9           4409 	.dw	0,249
      0006D5 43 4C 4B 5F 48 53 49  4410 	.ascii "CLK_HSICmd"
             43 6D 64
      0006DF 00                    4411 	.db	0
      0006E0 00 00 01 3A           4412 	.dw	0,314
      0006E4 43 4C 4B 5F 4C 53 49  4413 	.ascii "CLK_LSICmd"
             43 6D 64
      0006EE 00                    4414 	.db	0
      0006EF 00 00 01 7B           4415 	.dw	0,379
      0006F3 43 4C 4B 5F 43 43 4F  4416 	.ascii "CLK_CCOCmd"
             43 6D 64
      0006FD 00                    4417 	.db	0
      0006FE 00 00 01 BC           4418 	.dw	0,444
      000702 43 4C 4B 5F 43 6C 6F  4419 	.ascii "CLK_ClockSwitchCmd"
             63 6B 53 77 69 74 63
             68 43 6D 64
      000714 00                    4420 	.db	0
      000715 00 00 02 05           4421 	.dw	0,517
      000719 43 4C 4B 5F 53 6C 6F  4422 	.ascii "CLK_SlowActiveHaltWakeUpCmd"
             77 41 63 74 69 76 65
             48 61 6C 74 57 61 6B
             65 55 70 43 6D 64
      000734 00                    4423 	.db	0
      000735 00 00 02 57           4424 	.dw	0,599
      000739 43 4C 4B 5F 50 65 72  4425 	.ascii "CLK_PeripheralClockConfig"
             69 70 68 65 72 61 6C
             43 6C 6F 63 6B 43 6F
             6E 66 69 67
      000752 00                    4426 	.db	0
      000753 00 00 02 E0           4427 	.dw	0,736
      000757 43 4C 4B 5F 43 6C 6F  4428 	.ascii "CLK_ClockSwitchConfig"
             63 6B 53 77 69 74 63
             68 43 6F 6E 66 69 67
      00076C 00                    4429 	.db	0
      00076D 00 00 04 4B           4430 	.dw	0,1099
      000771 43 4C 4B 5F 48 53 49  4431 	.ascii "CLK_HSIPrescalerConfig"
             50 72 65 73 63 61 6C
             65 72 43 6F 6E 66 69
             67
      000787 00                    4432 	.db	0
      000788 00 00 04 8A           4433 	.dw	0,1162
      00078C 43 4C 4B 5F 43 43 4F  4434 	.ascii "CLK_CCOConfig"
             43 6F 6E 66 69 67
      000799 00                    4435 	.db	0
      00079A 00 00 04 BB           4436 	.dw	0,1211
      00079E 43 4C 4B 5F 49 54 43  4437 	.ascii "CLK_ITConfig"
             6F 6E 66 69 67
      0007AA 00                    4438 	.db	0
      0007AB 00 00 05 1D           4439 	.dw	0,1309
      0007AF 43 4C 4B 5F 53 59 53  4440 	.ascii "CLK_SYSCLKConfig"
             43 4C 4B 43 6F 6E 66
             69 67
      0007BF 00                    4441 	.db	0
      0007C0 00 00 05 69           4442 	.dw	0,1385
      0007C4 43 4C 4B 5F 53 57 49  4443 	.ascii "CLK_SWIMConfig"
             4D 43 6F 6E 66 69 67
      0007D2 00                    4444 	.db	0
      0007D3 00 00 05 B5           4445 	.dw	0,1461
      0007D7 43 4C 4B 5F 43 6C 6F  4446 	.ascii "CLK_ClockSecuritySystemEnable"
             63 6B 53 65 63 75 72
             69 74 79 53 79 73 74
             65 6D 45 6E 61 62 6C
             65
      0007F4 00                    4447 	.db	0
      0007F5 00 00 05 E1           4448 	.dw	0,1505
      0007F9 43 4C 4B 5F 47 65 74  4449 	.ascii "CLK_GetSYSCLKSource"
             53 59 53 43 4C 4B 53
             6F 75 72 63 65
      00080C 00                    4450 	.db	0
      00080D 00 00 06 18           4451 	.dw	0,1560
      000811 43 4C 4B 5F 47 65 74  4452 	.ascii "CLK_GetClockFreq"
             43 6C 6F 63 6B 46 72
             65 71
      000821 00                    4453 	.db	0
      000822 00 00 06 AA           4454 	.dw	0,1706
      000826 43 4C 4B 5F 41 64 6A  4455 	.ascii "CLK_AdjustHSICalibrationValue"
             75 73 74 48 53 49 43
             61 6C 69 62 72 61 74
             69 6F 6E 56 61 6C 75
             65
      000843 00                    4456 	.db	0
      000844 00 00 06 FB           4457 	.dw	0,1787
      000848 43 4C 4B 5F 53 59 53  4458 	.ascii "CLK_SYSCLKEmergencyClear"
             43 4C 4B 45 6D 65 72
             67 65 6E 63 79 43 6C
             65 61 72
      000860 00                    4459 	.db	0
      000861 00 00 07 22           4460 	.dw	0,1826
      000865 43 4C 4B 5F 47 65 74  4461 	.ascii "CLK_GetFlagStatus"
             46 6C 61 67 53 74 61
             74 75 73
      000876 00                    4462 	.db	0
      000877 00 00 07 E0           4463 	.dw	0,2016
      00087B 43 4C 4B 5F 47 65 74  4464 	.ascii "CLK_GetITStatus"
             49 54 53 74 61 74 75
             73
      00088A 00                    4465 	.db	0
      00088B 00 00 08 5F           4466 	.dw	0,2143
      00088F 43 4C 4B 5F 43 6C 65  4467 	.ascii "CLK_ClearITPendingBit"
             61 72 49 54 50 65 6E
             64 69 6E 67 42 69 74
      0008A4 00                    4468 	.db	0
      0008A5 00 00 08 BB           4469 	.dw	0,2235
      0008A9 48 53 49 44 69 76 46  4470 	.ascii "HSIDivFactor"
             61 63 74 6F 72
      0008B5 00                    4471 	.db	0
      0008B6 00 00 08 E1           4472 	.dw	0,2273
      0008BA 43 4C 4B 50 72 65 73  4473 	.ascii "CLKPrescTable"
             63 54 61 62 6C 65
      0008C7 00                    4474 	.db	0
      0008C8 00 00 00 00           4475 	.dw	0,0
      0008CC                       4476 Ldebug_pubnames_end:
                                   4477 
                                   4478 	.area .debug_frame (NOLOAD)
      001F51 00 00                 4479 	.dw	0
      001F53 00 0E                 4480 	.dw	Ldebug_CIE0_end-Ldebug_CIE0_start
      001F55                       4481 Ldebug_CIE0_start:
      001F55 FF FF                 4482 	.dw	0xffff
      001F57 FF FF                 4483 	.dw	0xffff
      001F59 01                    4484 	.db	1
      001F5A 00                    4485 	.db	0
      001F5B 01                    4486 	.uleb128	1
      001F5C 7F                    4487 	.sleb128	-1
      001F5D 09                    4488 	.db	9
      001F5E 0C                    4489 	.db	12
      001F5F 08                    4490 	.uleb128	8
      001F60 02                    4491 	.uleb128	2
      001F61 89                    4492 	.db	137
      001F62 01                    4493 	.uleb128	1
      001F63                       4494 Ldebug_CIE0_end:
      001F63 00 00 00 1A           4495 	.dw	0,26
      001F67 00 00 1F 51           4496 	.dw	0,(Ldebug_CIE0_start-4)
      001F6B 00 00 94 8E           4497 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$417)	;initial loc
      001F6F 00 00 00 20           4498 	.dw	0,Sstm8s_clk$CLK_ClearITPendingBit$428-Sstm8s_clk$CLK_ClearITPendingBit$417
      001F73 01                    4499 	.db	1
      001F74 00 00 94 8E           4500 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$417)
      001F78 0E                    4501 	.db	14
      001F79 02                    4502 	.uleb128	2
      001F7A 01                    4503 	.db	1
      001F7B 00 00 94 9A           4504 	.dw	0,(Sstm8s_clk$CLK_ClearITPendingBit$419)
      001F7F 0E                    4505 	.db	14
      001F80 02                    4506 	.uleb128	2
                                   4507 
                                   4508 	.area .debug_frame (NOLOAD)
      001F81 00 00                 4509 	.dw	0
      001F83 00 0E                 4510 	.dw	Ldebug_CIE1_end-Ldebug_CIE1_start
      001F85                       4511 Ldebug_CIE1_start:
      001F85 FF FF                 4512 	.dw	0xffff
      001F87 FF FF                 4513 	.dw	0xffff
      001F89 01                    4514 	.db	1
      001F8A 00                    4515 	.db	0
      001F8B 01                    4516 	.uleb128	1
      001F8C 7F                    4517 	.sleb128	-1
      001F8D 09                    4518 	.db	9
      001F8E 0C                    4519 	.db	12
      001F8F 08                    4520 	.uleb128	8
      001F90 02                    4521 	.uleb128	2
      001F91 89                    4522 	.db	137
      001F92 01                    4523 	.uleb128	1
      001F93                       4524 Ldebug_CIE1_end:
      001F93 00 00 00 28           4525 	.dw	0,40
      001F97 00 00 1F 81           4526 	.dw	0,(Ldebug_CIE1_start-4)
      001F9B 00 00 94 54           4527 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$391)	;initial loc
      001F9F 00 00 00 3A           4528 	.dw	0,Sstm8s_clk$CLK_GetITStatus$415-Sstm8s_clk$CLK_GetITStatus$391
      001FA3 01                    4529 	.db	1
      001FA4 00 00 94 54           4530 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$391)
      001FA8 0E                    4531 	.db	14
      001FA9 02                    4532 	.uleb128	2
      001FAA 01                    4533 	.db	1
      001FAB 00 00 94 60           4534 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$393)
      001FAF 0E                    4535 	.db	14
      001FB0 02                    4536 	.uleb128	2
      001FB1 01                    4537 	.db	1
      001FB2 00 00 94 6F           4538 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$396)
      001FB6 0E                    4539 	.db	14
      001FB7 02                    4540 	.uleb128	2
      001FB8 01                    4541 	.db	1
      001FB9 00 00 94 87           4542 	.dw	0,(Sstm8s_clk$CLK_GetITStatus$405)
      001FBD 0E                    4543 	.db	14
      001FBE 02                    4544 	.uleb128	2
                                   4545 
                                   4546 	.area .debug_frame (NOLOAD)
      001FBF 00 00                 4547 	.dw	0
      001FC1 00 0E                 4548 	.dw	Ldebug_CIE2_end-Ldebug_CIE2_start
      001FC3                       4549 Ldebug_CIE2_start:
      001FC3 FF FF                 4550 	.dw	0xffff
      001FC5 FF FF                 4551 	.dw	0xffff
      001FC7 01                    4552 	.db	1
      001FC8 00                    4553 	.db	0
      001FC9 01                    4554 	.uleb128	1
      001FCA 7F                    4555 	.sleb128	-1
      001FCB 09                    4556 	.db	9
      001FCC 0C                    4557 	.db	12
      001FCD 08                    4558 	.uleb128	8
      001FCE 02                    4559 	.uleb128	2
      001FCF 89                    4560 	.db	137
      001FD0 01                    4561 	.uleb128	1
      001FD1                       4562 Ldebug_CIE2_end:
      001FD1 00 00 00 4B           4563 	.dw	0,75
      001FD5 00 00 1F BF           4564 	.dw	0,(Ldebug_CIE2_start-4)
      001FD9 00 00 93 F1           4565 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$350)	;initial loc
      001FDD 00 00 00 63           4566 	.dw	0,Sstm8s_clk$CLK_GetFlagStatus$389-Sstm8s_clk$CLK_GetFlagStatus$350
      001FE1 01                    4567 	.db	1
      001FE2 00 00 93 F1           4568 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$350)
      001FE6 0E                    4569 	.db	14
      001FE7 02                    4570 	.uleb128	2
      001FE8 01                    4571 	.db	1
      001FE9 00 00 93 F2           4572 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$351)
      001FED 0E                    4573 	.db	14
      001FEE 03                    4574 	.uleb128	3
      001FEF 01                    4575 	.db	1
      001FF0 00 00 94 01           4576 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$354)
      001FF4 0E                    4577 	.db	14
      001FF5 03                    4578 	.uleb128	3
      001FF6 01                    4579 	.db	1
      001FF7 00 00 94 12           4580 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$359)
      001FFB 0E                    4581 	.db	14
      001FFC 03                    4582 	.uleb128	3
      001FFD 01                    4583 	.db	1
      001FFE 00 00 94 23           4584 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$364)
      002002 0E                    4585 	.db	14
      002003 03                    4586 	.uleb128	3
      002004 01                    4587 	.db	1
      002005 00 00 94 34           4588 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$369)
      002009 0E                    4589 	.db	14
      00200A 03                    4590 	.uleb128	3
      00200B 01                    4591 	.db	1
      00200C 00 00 94 3E           4592 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$377)
      002010 0E                    4593 	.db	14
      002011 04                    4594 	.uleb128	4
      002012 01                    4595 	.db	1
      002013 00 00 94 43           4596 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$378)
      002017 0E                    4597 	.db	14
      002018 03                    4598 	.uleb128	3
      002019 01                    4599 	.db	1
      00201A 00 00 94 53           4600 	.dw	0,(Sstm8s_clk$CLK_GetFlagStatus$387)
      00201E 0E                    4601 	.db	14
      00201F 02                    4602 	.uleb128	2
                                   4603 
                                   4604 	.area .debug_frame (NOLOAD)
      002020 00 00                 4605 	.dw	0
      002022 00 0E                 4606 	.dw	Ldebug_CIE3_end-Ldebug_CIE3_start
      002024                       4607 Ldebug_CIE3_start:
      002024 FF FF                 4608 	.dw	0xffff
      002026 FF FF                 4609 	.dw	0xffff
      002028 01                    4610 	.db	1
      002029 00                    4611 	.db	0
      00202A 01                    4612 	.uleb128	1
      00202B 7F                    4613 	.sleb128	-1
      00202C 09                    4614 	.db	9
      00202D 0C                    4615 	.db	12
      00202E 08                    4616 	.uleb128	8
      00202F 02                    4617 	.uleb128	2
      002030 89                    4618 	.db	137
      002031 01                    4619 	.uleb128	1
      002032                       4620 Ldebug_CIE3_end:
      002032 00 00 00 13           4621 	.dw	0,19
      002036 00 00 20 20           4622 	.dw	0,(Ldebug_CIE3_start-4)
      00203A 00 00 93 E8           4623 	.dw	0,(Sstm8s_clk$CLK_SYSCLKEmergencyClear$344)	;initial loc
      00203E 00 00 00 09           4624 	.dw	0,Sstm8s_clk$CLK_SYSCLKEmergencyClear$348-Sstm8s_clk$CLK_SYSCLKEmergencyClear$344
      002042 01                    4625 	.db	1
      002043 00 00 93 E8           4626 	.dw	0,(Sstm8s_clk$CLK_SYSCLKEmergencyClear$344)
      002047 0E                    4627 	.db	14
      002048 02                    4628 	.uleb128	2
                                   4629 
                                   4630 	.area .debug_frame (NOLOAD)
      002049 00 00                 4631 	.dw	0
      00204B 00 0E                 4632 	.dw	Ldebug_CIE4_end-Ldebug_CIE4_start
      00204D                       4633 Ldebug_CIE4_start:
      00204D FF FF                 4634 	.dw	0xffff
      00204F FF FF                 4635 	.dw	0xffff
      002051 01                    4636 	.db	1
      002052 00                    4637 	.db	0
      002053 01                    4638 	.uleb128	1
      002054 7F                    4639 	.sleb128	-1
      002055 09                    4640 	.db	9
      002056 0C                    4641 	.db	12
      002057 08                    4642 	.uleb128	8
      002058 02                    4643 	.uleb128	2
      002059 89                    4644 	.db	137
      00205A 01                    4645 	.uleb128	1
      00205B                       4646 Ldebug_CIE4_end:
      00205B 00 00 00 13           4647 	.dw	0,19
      00205F 00 00 20 49           4648 	.dw	0,(Ldebug_CIE4_start-4)
      002063 00 00 93 DD           4649 	.dw	0,(Sstm8s_clk$CLK_AdjustHSICalibrationValue$338)	;initial loc
      002067 00 00 00 0B           4650 	.dw	0,Sstm8s_clk$CLK_AdjustHSICalibrationValue$342-Sstm8s_clk$CLK_AdjustHSICalibrationValue$338
      00206B 01                    4651 	.db	1
      00206C 00 00 93 DD           4652 	.dw	0,(Sstm8s_clk$CLK_AdjustHSICalibrationValue$338)
      002070 0E                    4653 	.db	14
      002071 02                    4654 	.uleb128	2
                                   4655 
                                   4656 	.area .debug_frame (NOLOAD)
      002072 00 00                 4657 	.dw	0
      002074 00 0E                 4658 	.dw	Ldebug_CIE5_end-Ldebug_CIE5_start
      002076                       4659 Ldebug_CIE5_start:
      002076 FF FF                 4660 	.dw	0xffff
      002078 FF FF                 4661 	.dw	0xffff
      00207A 01                    4662 	.db	1
      00207B 00                    4663 	.db	0
      00207C 01                    4664 	.uleb128	1
      00207D 7F                    4665 	.sleb128	-1
      00207E 09                    4666 	.db	9
      00207F 0C                    4667 	.db	12
      002080 08                    4668 	.uleb128	8
      002081 02                    4669 	.uleb128	2
      002082 89                    4670 	.db	137
      002083 01                    4671 	.uleb128	1
      002084                       4672 Ldebug_CIE5_end:
      002084 00 00 00 60           4673 	.dw	0,96
      002088 00 00 20 72           4674 	.dw	0,(Ldebug_CIE5_start-4)
      00208C 00 00 93 7E           4675 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$306)	;initial loc
      002090 00 00 00 5F           4676 	.dw	0,Sstm8s_clk$CLK_GetClockFreq$336-Sstm8s_clk$CLK_GetClockFreq$306
      002094 01                    4677 	.db	1
      002095 00 00 93 7E           4678 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$306)
      002099 0E                    4679 	.db	14
      00209A 02                    4680 	.uleb128	2
      00209B 01                    4681 	.db	1
      00209C 00 00 93 80           4682 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$307)
      0020A0 0E                    4683 	.db	14
      0020A1 06                    4684 	.uleb128	6
      0020A2 01                    4685 	.db	1
      0020A3 00 00 93 91           4686 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$310)
      0020A7 0E                    4687 	.db	14
      0020A8 06                    4688 	.uleb128	6
      0020A9 01                    4689 	.db	1
      0020AA 00 00 93 A4           4690 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$317)
      0020AE 0E                    4691 	.db	14
      0020AF 08                    4692 	.uleb128	8
      0020B0 01                    4693 	.db	1
      0020B1 00 00 93 A6           4694 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$318)
      0020B5 0E                    4695 	.db	14
      0020B6 0A                    4696 	.uleb128	10
      0020B7 01                    4697 	.db	1
      0020B8 00 00 93 A8           4698 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$319)
      0020BC 0E                    4699 	.db	14
      0020BD 0B                    4700 	.uleb128	11
      0020BE 01                    4701 	.db	1
      0020BF 00 00 93 AA           4702 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$320)
      0020C3 0E                    4703 	.db	14
      0020C4 0C                    4704 	.uleb128	12
      0020C5 01                    4705 	.db	1
      0020C6 00 00 93 AC           4706 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$321)
      0020CA 0E                    4707 	.db	14
      0020CB 0D                    4708 	.uleb128	13
      0020CC 01                    4709 	.db	1
      0020CD 00 00 93 AE           4710 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$322)
      0020D1 0E                    4711 	.db	14
      0020D2 0E                    4712 	.uleb128	14
      0020D3 01                    4713 	.db	1
      0020D4 00 00 93 B3           4714 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$323)
      0020D8 0E                    4715 	.db	14
      0020D9 06                    4716 	.uleb128	6
      0020DA 01                    4717 	.db	1
      0020DB 00 00 93 C5           4718 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$325)
      0020DF 0E                    4719 	.db	14
      0020E0 06                    4720 	.uleb128	6
      0020E1 01                    4721 	.db	1
      0020E2 00 00 93 DC           4722 	.dw	0,(Sstm8s_clk$CLK_GetClockFreq$334)
      0020E6 0E                    4723 	.db	14
      0020E7 02                    4724 	.uleb128	2
                                   4725 
                                   4726 	.area .debug_frame (NOLOAD)
      0020E8 00 00                 4727 	.dw	0
      0020EA 00 0E                 4728 	.dw	Ldebug_CIE6_end-Ldebug_CIE6_start
      0020EC                       4729 Ldebug_CIE6_start:
      0020EC FF FF                 4730 	.dw	0xffff
      0020EE FF FF                 4731 	.dw	0xffff
      0020F0 01                    4732 	.db	1
      0020F1 00                    4733 	.db	0
      0020F2 01                    4734 	.uleb128	1
      0020F3 7F                    4735 	.sleb128	-1
      0020F4 09                    4736 	.db	9
      0020F5 0C                    4737 	.db	12
      0020F6 08                    4738 	.uleb128	8
      0020F7 02                    4739 	.uleb128	2
      0020F8 89                    4740 	.db	137
      0020F9 01                    4741 	.uleb128	1
      0020FA                       4742 Ldebug_CIE6_end:
      0020FA 00 00 00 13           4743 	.dw	0,19
      0020FE 00 00 20 E8           4744 	.dw	0,(Ldebug_CIE6_start-4)
      002102 00 00 93 7A           4745 	.dw	0,(Sstm8s_clk$CLK_GetSYSCLKSource$300)	;initial loc
      002106 00 00 00 04           4746 	.dw	0,Sstm8s_clk$CLK_GetSYSCLKSource$304-Sstm8s_clk$CLK_GetSYSCLKSource$300
      00210A 01                    4747 	.db	1
      00210B 00 00 93 7A           4748 	.dw	0,(Sstm8s_clk$CLK_GetSYSCLKSource$300)
      00210F 0E                    4749 	.db	14
      002110 02                    4750 	.uleb128	2
                                   4751 
                                   4752 	.area .debug_frame (NOLOAD)
      002111 00 00                 4753 	.dw	0
      002113 00 0E                 4754 	.dw	Ldebug_CIE7_end-Ldebug_CIE7_start
      002115                       4755 Ldebug_CIE7_start:
      002115 FF FF                 4756 	.dw	0xffff
      002117 FF FF                 4757 	.dw	0xffff
      002119 01                    4758 	.db	1
      00211A 00                    4759 	.db	0
      00211B 01                    4760 	.uleb128	1
      00211C 7F                    4761 	.sleb128	-1
      00211D 09                    4762 	.db	9
      00211E 0C                    4763 	.db	12
      00211F 08                    4764 	.uleb128	8
      002120 02                    4765 	.uleb128	2
      002121 89                    4766 	.db	137
      002122 01                    4767 	.uleb128	1
      002123                       4768 Ldebug_CIE7_end:
      002123 00 00 00 13           4769 	.dw	0,19
      002127 00 00 21 11           4770 	.dw	0,(Ldebug_CIE7_start-4)
      00212B 00 00 93 71           4771 	.dw	0,(Sstm8s_clk$CLK_ClockSecuritySystemEnable$294)	;initial loc
      00212F 00 00 00 09           4772 	.dw	0,Sstm8s_clk$CLK_ClockSecuritySystemEnable$298-Sstm8s_clk$CLK_ClockSecuritySystemEnable$294
      002133 01                    4773 	.db	1
      002134 00 00 93 71           4774 	.dw	0,(Sstm8s_clk$CLK_ClockSecuritySystemEnable$294)
      002138 0E                    4775 	.db	14
      002139 02                    4776 	.uleb128	2
                                   4777 
                                   4778 	.area .debug_frame (NOLOAD)
      00213A 00 00                 4779 	.dw	0
      00213C 00 0E                 4780 	.dw	Ldebug_CIE8_end-Ldebug_CIE8_start
      00213E                       4781 Ldebug_CIE8_start:
      00213E FF FF                 4782 	.dw	0xffff
      002140 FF FF                 4783 	.dw	0xffff
      002142 01                    4784 	.db	1
      002143 00                    4785 	.db	0
      002144 01                    4786 	.uleb128	1
      002145 7F                    4787 	.sleb128	-1
      002146 09                    4788 	.db	9
      002147 0C                    4789 	.db	12
      002148 08                    4790 	.uleb128	8
      002149 02                    4791 	.uleb128	2
      00214A 89                    4792 	.db	137
      00214B 01                    4793 	.uleb128	1
      00214C                       4794 Ldebug_CIE8_end:
      00214C 00 00 00 13           4795 	.dw	0,19
      002150 00 00 21 3A           4796 	.dw	0,(Ldebug_CIE8_start-4)
      002154 00 00 93 59           4797 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$281)	;initial loc
      002158 00 00 00 18           4798 	.dw	0,Sstm8s_clk$CLK_SWIMConfig$292-Sstm8s_clk$CLK_SWIMConfig$281
      00215C 01                    4799 	.db	1
      00215D 00 00 93 59           4800 	.dw	0,(Sstm8s_clk$CLK_SWIMConfig$281)
      002161 0E                    4801 	.db	14
      002162 02                    4802 	.uleb128	2
                                   4803 
                                   4804 	.area .debug_frame (NOLOAD)
      002163 00 00                 4805 	.dw	0
      002165 00 0E                 4806 	.dw	Ldebug_CIE9_end-Ldebug_CIE9_start
      002167                       4807 Ldebug_CIE9_start:
      002167 FF FF                 4808 	.dw	0xffff
      002169 FF FF                 4809 	.dw	0xffff
      00216B 01                    4810 	.db	1
      00216C 00                    4811 	.db	0
      00216D 01                    4812 	.uleb128	1
      00216E 7F                    4813 	.sleb128	-1
      00216F 09                    4814 	.db	9
      002170 0C                    4815 	.db	12
      002171 08                    4816 	.uleb128	8
      002172 02                    4817 	.uleb128	2
      002173 89                    4818 	.db	137
      002174 01                    4819 	.uleb128	1
      002175                       4820 Ldebug_CIE9_end:
      002175 00 00 00 21           4821 	.dw	0,33
      002179 00 00 21 63           4822 	.dw	0,(Ldebug_CIE9_start-4)
      00217D 00 00 93 23           4823 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$264)	;initial loc
      002181 00 00 00 36           4824 	.dw	0,Sstm8s_clk$CLK_SYSCLKConfig$279-Sstm8s_clk$CLK_SYSCLKConfig$264
      002185 01                    4825 	.db	1
      002186 00 00 93 23           4826 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$264)
      00218A 0E                    4827 	.db	14
      00218B 02                    4828 	.uleb128	2
      00218C 01                    4829 	.db	1
      00218D 00 00 93 24           4830 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$265)
      002191 0E                    4831 	.db	14
      002192 03                    4832 	.uleb128	3
      002193 01                    4833 	.db	1
      002194 00 00 93 58           4834 	.dw	0,(Sstm8s_clk$CLK_SYSCLKConfig$277)
      002198 0E                    4835 	.db	14
      002199 02                    4836 	.uleb128	2
                                   4837 
                                   4838 	.area .debug_frame (NOLOAD)
      00219A 00 00                 4839 	.dw	0
      00219C 00 0E                 4840 	.dw	Ldebug_CIE10_end-Ldebug_CIE10_start
      00219E                       4841 Ldebug_CIE10_start:
      00219E FF FF                 4842 	.dw	0xffff
      0021A0 FF FF                 4843 	.dw	0xffff
      0021A2 01                    4844 	.db	1
      0021A3 00                    4845 	.db	0
      0021A4 01                    4846 	.uleb128	1
      0021A5 7F                    4847 	.sleb128	-1
      0021A6 09                    4848 	.db	9
      0021A7 0C                    4849 	.db	12
      0021A8 08                    4850 	.uleb128	8
      0021A9 02                    4851 	.uleb128	2
      0021AA 89                    4852 	.db	137
      0021AB 01                    4853 	.uleb128	1
      0021AC                       4854 Ldebug_CIE10_end:
      0021AC 00 00 00 2F           4855 	.dw	0,47
      0021B0 00 00 21 9A           4856 	.dw	0,(Ldebug_CIE10_start-4)
      0021B4 00 00 92 BB           4857 	.dw	0,(Sstm8s_clk$CLK_ITConfig$234)	;initial loc
      0021B8 00 00 00 68           4858 	.dw	0,Sstm8s_clk$CLK_ITConfig$262-Sstm8s_clk$CLK_ITConfig$234
      0021BC 01                    4859 	.db	1
      0021BD 00 00 92 BB           4860 	.dw	0,(Sstm8s_clk$CLK_ITConfig$234)
      0021C1 0E                    4861 	.db	14
      0021C2 02                    4862 	.uleb128	2
      0021C3 01                    4863 	.db	1
      0021C4 00 00 92 BC           4864 	.dw	0,(Sstm8s_clk$CLK_ITConfig$235)
      0021C8 0E                    4865 	.db	14
      0021C9 03                    4866 	.uleb128	3
      0021CA 01                    4867 	.db	1
      0021CB 00 00 92 CB           4868 	.dw	0,(Sstm8s_clk$CLK_ITConfig$237)
      0021CF 0E                    4869 	.db	14
      0021D0 03                    4870 	.uleb128	3
      0021D1 01                    4871 	.db	1
      0021D2 00 00 92 D7           4872 	.dw	0,(Sstm8s_clk$CLK_ITConfig$238)
      0021D6 0E                    4873 	.db	14
      0021D7 03                    4874 	.uleb128	3
      0021D8 01                    4875 	.db	1
      0021D9 00 00 93 22           4876 	.dw	0,(Sstm8s_clk$CLK_ITConfig$260)
      0021DD 0E                    4877 	.db	14
      0021DE 02                    4878 	.uleb128	2
                                   4879 
                                   4880 	.area .debug_frame (NOLOAD)
      0021DF 00 00                 4881 	.dw	0
      0021E1 00 0E                 4882 	.dw	Ldebug_CIE11_end-Ldebug_CIE11_start
      0021E3                       4883 Ldebug_CIE11_start:
      0021E3 FF FF                 4884 	.dw	0xffff
      0021E5 FF FF                 4885 	.dw	0xffff
      0021E7 01                    4886 	.db	1
      0021E8 00                    4887 	.db	0
      0021E9 01                    4888 	.uleb128	1
      0021EA 7F                    4889 	.sleb128	-1
      0021EB 09                    4890 	.db	9
      0021EC 0C                    4891 	.db	12
      0021ED 08                    4892 	.uleb128	8
      0021EE 02                    4893 	.uleb128	2
      0021EF 89                    4894 	.db	137
      0021F0 01                    4895 	.uleb128	1
      0021F1                       4896 Ldebug_CIE11_end:
      0021F1 00 00 00 13           4897 	.dw	0,19
      0021F5 00 00 21 DF           4898 	.dw	0,(Ldebug_CIE11_start-4)
      0021F9 00 00 92 A2           4899 	.dw	0,(Sstm8s_clk$CLK_CCOConfig$226)	;initial loc
      0021FD 00 00 00 19           4900 	.dw	0,Sstm8s_clk$CLK_CCOConfig$232-Sstm8s_clk$CLK_CCOConfig$226
      002201 01                    4901 	.db	1
      002202 00 00 92 A2           4902 	.dw	0,(Sstm8s_clk$CLK_CCOConfig$226)
      002206 0E                    4903 	.db	14
      002207 02                    4904 	.uleb128	2
                                   4905 
                                   4906 	.area .debug_frame (NOLOAD)
      002208 00 00                 4907 	.dw	0
      00220A 00 0E                 4908 	.dw	Ldebug_CIE12_end-Ldebug_CIE12_start
      00220C                       4909 Ldebug_CIE12_start:
      00220C FF FF                 4910 	.dw	0xffff
      00220E FF FF                 4911 	.dw	0xffff
      002210 01                    4912 	.db	1
      002211 00                    4913 	.db	0
      002212 01                    4914 	.uleb128	1
      002213 7F                    4915 	.sleb128	-1
      002214 09                    4916 	.db	9
      002215 0C                    4917 	.db	12
      002216 08                    4918 	.uleb128	8
      002217 02                    4919 	.uleb128	2
      002218 89                    4920 	.db	137
      002219 01                    4921 	.uleb128	1
      00221A                       4922 Ldebug_CIE12_end:
      00221A 00 00 00 13           4923 	.dw	0,19
      00221E 00 00 22 08           4924 	.dw	0,(Ldebug_CIE12_start-4)
      002222 00 00 92 91           4925 	.dw	0,(Sstm8s_clk$CLK_HSIPrescalerConfig$219)	;initial loc
      002226 00 00 00 11           4926 	.dw	0,Sstm8s_clk$CLK_HSIPrescalerConfig$224-Sstm8s_clk$CLK_HSIPrescalerConfig$219
      00222A 01                    4927 	.db	1
      00222B 00 00 92 91           4928 	.dw	0,(Sstm8s_clk$CLK_HSIPrescalerConfig$219)
      00222F 0E                    4929 	.db	14
      002230 02                    4930 	.uleb128	2
                                   4931 
                                   4932 	.area .debug_frame (NOLOAD)
      002231 00 00                 4933 	.dw	0
      002233 00 0E                 4934 	.dw	Ldebug_CIE13_end-Ldebug_CIE13_start
      002235                       4935 Ldebug_CIE13_start:
      002235 FF FF                 4936 	.dw	0xffff
      002237 FF FF                 4937 	.dw	0xffff
      002239 01                    4938 	.db	1
      00223A 00                    4939 	.db	0
      00223B 01                    4940 	.uleb128	1
      00223C 7F                    4941 	.sleb128	-1
      00223D 09                    4942 	.db	9
      00223E 0C                    4943 	.db	12
      00223F 08                    4944 	.uleb128	8
      002240 02                    4945 	.uleb128	2
      002241 89                    4946 	.db	137
      002242 01                    4947 	.uleb128	1
      002243                       4948 Ldebug_CIE13_end:
      002243 00 00 00 4B           4949 	.dw	0,75
      002247 00 00 22 31           4950 	.dw	0,(Ldebug_CIE13_start-4)
      00224B 00 00 91 8B           4951 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$140)	;initial loc
      00224F 00 00 01 06           4952 	.dw	0,Sstm8s_clk$CLK_ClockSwitchConfig$217-Sstm8s_clk$CLK_ClockSwitchConfig$140
      002253 01                    4953 	.db	1
      002254 00 00 91 8B           4954 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$140)
      002258 0E                    4955 	.db	14
      002259 02                    4956 	.uleb128	2
      00225A 01                    4957 	.db	1
      00225B 00 00 91 8C           4958 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$141)
      00225F 0E                    4959 	.db	14
      002260 03                    4960 	.uleb128	3
      002261 01                    4961 	.db	1
      002262 00 00 91 97           4962 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$146)
      002266 0E                    4963 	.db	14
      002267 04                    4964 	.uleb128	4
      002268 01                    4965 	.db	1
      002269 00 00 91 9B           4966 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$147)
      00226D 0E                    4967 	.db	14
      00226E 03                    4968 	.uleb128	3
      00226F 01                    4969 	.db	1
      002270 00 00 91 A3           4970 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$148)
      002274 0E                    4971 	.db	14
      002275 03                    4972 	.uleb128	3
      002276 01                    4973 	.db	1
      002277 00 00 92 49           4974 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$199)
      00227B 0E                    4975 	.db	14
      00227C 03                    4976 	.uleb128	3
      00227D 01                    4977 	.db	1
      00227E 00 00 92 67           4978 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$204)
      002282 0E                    4979 	.db	14
      002283 03                    4980 	.uleb128	3
      002284 01                    4981 	.db	1
      002285 00 00 92 85           4982 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$209)
      002289 0E                    4983 	.db	14
      00228A 03                    4984 	.uleb128	3
      00228B 01                    4985 	.db	1
      00228C 00 00 92 90           4986 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchConfig$215)
      002290 0E                    4987 	.db	14
      002291 02                    4988 	.uleb128	2
                                   4989 
                                   4990 	.area .debug_frame (NOLOAD)
      002292 00 00                 4991 	.dw	0
      002294 00 0E                 4992 	.dw	Ldebug_CIE14_end-Ldebug_CIE14_start
      002296                       4993 Ldebug_CIE14_start:
      002296 FF FF                 4994 	.dw	0xffff
      002298 FF FF                 4995 	.dw	0xffff
      00229A 01                    4996 	.db	1
      00229B 00                    4997 	.db	0
      00229C 01                    4998 	.uleb128	1
      00229D 7F                    4999 	.sleb128	-1
      00229E 09                    5000 	.db	9
      00229F 0C                    5001 	.db	12
      0022A0 08                    5002 	.uleb128	8
      0022A1 02                    5003 	.uleb128	2
      0022A2 89                    5004 	.db	137
      0022A3 01                    5005 	.uleb128	1
      0022A4                       5006 Ldebug_CIE14_end:
      0022A4 00 00 00 2F           5007 	.dw	0,47
      0022A8 00 00 22 92           5008 	.dw	0,(Ldebug_CIE14_start-4)
      0022AC 00 00 91 37           5009 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$110)	;initial loc
      0022B0 00 00 00 54           5010 	.dw	0,Sstm8s_clk$CLK_PeripheralClockConfig$138-Sstm8s_clk$CLK_PeripheralClockConfig$110
      0022B4 01                    5011 	.db	1
      0022B5 00 00 91 37           5012 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$110)
      0022B9 0E                    5013 	.db	14
      0022BA 02                    5014 	.uleb128	2
      0022BB 01                    5015 	.db	1
      0022BC 00 00 91 38           5016 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$111)
      0022C0 0E                    5017 	.db	14
      0022C1 04                    5018 	.uleb128	4
      0022C2 01                    5019 	.db	1
      0022C3 00 00 91 3D           5020 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$113)
      0022C7 0E                    5021 	.db	14
      0022C8 05                    5022 	.uleb128	5
      0022C9 01                    5023 	.db	1
      0022CA 00 00 91 42           5024 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$114)
      0022CE 0E                    5025 	.db	14
      0022CF 04                    5026 	.uleb128	4
      0022D0 01                    5027 	.db	1
      0022D1 00 00 91 8A           5028 	.dw	0,(Sstm8s_clk$CLK_PeripheralClockConfig$136)
      0022D5 0E                    5029 	.db	14
      0022D6 02                    5030 	.uleb128	2
                                   5031 
                                   5032 	.area .debug_frame (NOLOAD)
      0022D7 00 00                 5033 	.dw	0
      0022D9 00 0E                 5034 	.dw	Ldebug_CIE15_end-Ldebug_CIE15_start
      0022DB                       5035 Ldebug_CIE15_start:
      0022DB FF FF                 5036 	.dw	0xffff
      0022DD FF FF                 5037 	.dw	0xffff
      0022DF 01                    5038 	.db	1
      0022E0 00                    5039 	.db	0
      0022E1 01                    5040 	.uleb128	1
      0022E2 7F                    5041 	.sleb128	-1
      0022E3 09                    5042 	.db	9
      0022E4 0C                    5043 	.db	12
      0022E5 08                    5044 	.uleb128	8
      0022E6 02                    5045 	.uleb128	2
      0022E7 89                    5046 	.db	137
      0022E8 01                    5047 	.uleb128	1
      0022E9                       5048 Ldebug_CIE15_end:
      0022E9 00 00 00 13           5049 	.dw	0,19
      0022ED 00 00 22 D7           5050 	.dw	0,(Ldebug_CIE15_start-4)
      0022F1 00 00 91 1F           5051 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$97)	;initial loc
      0022F5 00 00 00 18           5052 	.dw	0,Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$108-Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$97
      0022F9 01                    5053 	.db	1
      0022FA 00 00 91 1F           5054 	.dw	0,(Sstm8s_clk$CLK_SlowActiveHaltWakeUpCmd$97)
      0022FE 0E                    5055 	.db	14
      0022FF 02                    5056 	.uleb128	2
                                   5057 
                                   5058 	.area .debug_frame (NOLOAD)
      002300 00 00                 5059 	.dw	0
      002302 00 0E                 5060 	.dw	Ldebug_CIE16_end-Ldebug_CIE16_start
      002304                       5061 Ldebug_CIE16_start:
      002304 FF FF                 5062 	.dw	0xffff
      002306 FF FF                 5063 	.dw	0xffff
      002308 01                    5064 	.db	1
      002309 00                    5065 	.db	0
      00230A 01                    5066 	.uleb128	1
      00230B 7F                    5067 	.sleb128	-1
      00230C 09                    5068 	.db	9
      00230D 0C                    5069 	.db	12
      00230E 08                    5070 	.uleb128	8
      00230F 02                    5071 	.uleb128	2
      002310 89                    5072 	.db	137
      002311 01                    5073 	.uleb128	1
      002312                       5074 Ldebug_CIE16_end:
      002312 00 00 00 13           5075 	.dw	0,19
      002316 00 00 23 00           5076 	.dw	0,(Ldebug_CIE16_start-4)
      00231A 00 00 91 07           5077 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$84)	;initial loc
      00231E 00 00 00 18           5078 	.dw	0,Sstm8s_clk$CLK_ClockSwitchCmd$95-Sstm8s_clk$CLK_ClockSwitchCmd$84
      002322 01                    5079 	.db	1
      002323 00 00 91 07           5080 	.dw	0,(Sstm8s_clk$CLK_ClockSwitchCmd$84)
      002327 0E                    5081 	.db	14
      002328 02                    5082 	.uleb128	2
                                   5083 
                                   5084 	.area .debug_frame (NOLOAD)
      002329 00 00                 5085 	.dw	0
      00232B 00 0E                 5086 	.dw	Ldebug_CIE17_end-Ldebug_CIE17_start
      00232D                       5087 Ldebug_CIE17_start:
      00232D FF FF                 5088 	.dw	0xffff
      00232F FF FF                 5089 	.dw	0xffff
      002331 01                    5090 	.db	1
      002332 00                    5091 	.db	0
      002333 01                    5092 	.uleb128	1
      002334 7F                    5093 	.sleb128	-1
      002335 09                    5094 	.db	9
      002336 0C                    5095 	.db	12
      002337 08                    5096 	.uleb128	8
      002338 02                    5097 	.uleb128	2
      002339 89                    5098 	.db	137
      00233A 01                    5099 	.uleb128	1
      00233B                       5100 Ldebug_CIE17_end:
      00233B 00 00 00 13           5101 	.dw	0,19
      00233F 00 00 23 29           5102 	.dw	0,(Ldebug_CIE17_start-4)
      002343 00 00 90 EF           5103 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$71)	;initial loc
      002347 00 00 00 18           5104 	.dw	0,Sstm8s_clk$CLK_CCOCmd$82-Sstm8s_clk$CLK_CCOCmd$71
      00234B 01                    5105 	.db	1
      00234C 00 00 90 EF           5106 	.dw	0,(Sstm8s_clk$CLK_CCOCmd$71)
      002350 0E                    5107 	.db	14
      002351 02                    5108 	.uleb128	2
                                   5109 
                                   5110 	.area .debug_frame (NOLOAD)
      002352 00 00                 5111 	.dw	0
      002354 00 0E                 5112 	.dw	Ldebug_CIE18_end-Ldebug_CIE18_start
      002356                       5113 Ldebug_CIE18_start:
      002356 FF FF                 5114 	.dw	0xffff
      002358 FF FF                 5115 	.dw	0xffff
      00235A 01                    5116 	.db	1
      00235B 00                    5117 	.db	0
      00235C 01                    5118 	.uleb128	1
      00235D 7F                    5119 	.sleb128	-1
      00235E 09                    5120 	.db	9
      00235F 0C                    5121 	.db	12
      002360 08                    5122 	.uleb128	8
      002361 02                    5123 	.uleb128	2
      002362 89                    5124 	.db	137
      002363 01                    5125 	.uleb128	1
      002364                       5126 Ldebug_CIE18_end:
      002364 00 00 00 13           5127 	.dw	0,19
      002368 00 00 23 52           5128 	.dw	0,(Ldebug_CIE18_start-4)
      00236C 00 00 90 D7           5129 	.dw	0,(Sstm8s_clk$CLK_LSICmd$58)	;initial loc
      002370 00 00 00 18           5130 	.dw	0,Sstm8s_clk$CLK_LSICmd$69-Sstm8s_clk$CLK_LSICmd$58
      002374 01                    5131 	.db	1
      002375 00 00 90 D7           5132 	.dw	0,(Sstm8s_clk$CLK_LSICmd$58)
      002379 0E                    5133 	.db	14
      00237A 02                    5134 	.uleb128	2
                                   5135 
                                   5136 	.area .debug_frame (NOLOAD)
      00237B 00 00                 5137 	.dw	0
      00237D 00 0E                 5138 	.dw	Ldebug_CIE19_end-Ldebug_CIE19_start
      00237F                       5139 Ldebug_CIE19_start:
      00237F FF FF                 5140 	.dw	0xffff
      002381 FF FF                 5141 	.dw	0xffff
      002383 01                    5142 	.db	1
      002384 00                    5143 	.db	0
      002385 01                    5144 	.uleb128	1
      002386 7F                    5145 	.sleb128	-1
      002387 09                    5146 	.db	9
      002388 0C                    5147 	.db	12
      002389 08                    5148 	.uleb128	8
      00238A 02                    5149 	.uleb128	2
      00238B 89                    5150 	.db	137
      00238C 01                    5151 	.uleb128	1
      00238D                       5152 Ldebug_CIE19_end:
      00238D 00 00 00 13           5153 	.dw	0,19
      002391 00 00 23 7B           5154 	.dw	0,(Ldebug_CIE19_start-4)
      002395 00 00 90 BF           5155 	.dw	0,(Sstm8s_clk$CLK_HSICmd$45)	;initial loc
      002399 00 00 00 18           5156 	.dw	0,Sstm8s_clk$CLK_HSICmd$56-Sstm8s_clk$CLK_HSICmd$45
      00239D 01                    5157 	.db	1
      00239E 00 00 90 BF           5158 	.dw	0,(Sstm8s_clk$CLK_HSICmd$45)
      0023A2 0E                    5159 	.db	14
      0023A3 02                    5160 	.uleb128	2
                                   5161 
                                   5162 	.area .debug_frame (NOLOAD)
      0023A4 00 00                 5163 	.dw	0
      0023A6 00 0E                 5164 	.dw	Ldebug_CIE20_end-Ldebug_CIE20_start
      0023A8                       5165 Ldebug_CIE20_start:
      0023A8 FF FF                 5166 	.dw	0xffff
      0023AA FF FF                 5167 	.dw	0xffff
      0023AC 01                    5168 	.db	1
      0023AD 00                    5169 	.db	0
      0023AE 01                    5170 	.uleb128	1
      0023AF 7F                    5171 	.sleb128	-1
      0023B0 09                    5172 	.db	9
      0023B1 0C                    5173 	.db	12
      0023B2 08                    5174 	.uleb128	8
      0023B3 02                    5175 	.uleb128	2
      0023B4 89                    5176 	.db	137
      0023B5 01                    5177 	.uleb128	1
      0023B6                       5178 Ldebug_CIE20_end:
      0023B6 00 00 00 13           5179 	.dw	0,19
      0023BA 00 00 23 A4           5180 	.dw	0,(Ldebug_CIE20_start-4)
      0023BE 00 00 90 A7           5181 	.dw	0,(Sstm8s_clk$CLK_HSECmd$32)	;initial loc
      0023C2 00 00 00 18           5182 	.dw	0,Sstm8s_clk$CLK_HSECmd$43-Sstm8s_clk$CLK_HSECmd$32
      0023C6 01                    5183 	.db	1
      0023C7 00 00 90 A7           5184 	.dw	0,(Sstm8s_clk$CLK_HSECmd$32)
      0023CB 0E                    5185 	.db	14
      0023CC 02                    5186 	.uleb128	2
                                   5187 
                                   5188 	.area .debug_frame (NOLOAD)
      0023CD 00 00                 5189 	.dw	0
      0023CF 00 0E                 5190 	.dw	Ldebug_CIE21_end-Ldebug_CIE21_start
      0023D1                       5191 Ldebug_CIE21_start:
      0023D1 FF FF                 5192 	.dw	0xffff
      0023D3 FF FF                 5193 	.dw	0xffff
      0023D5 01                    5194 	.db	1
      0023D6 00                    5195 	.db	0
      0023D7 01                    5196 	.uleb128	1
      0023D8 7F                    5197 	.sleb128	-1
      0023D9 09                    5198 	.db	9
      0023DA 0C                    5199 	.db	12
      0023DB 08                    5200 	.uleb128	8
      0023DC 02                    5201 	.uleb128	2
      0023DD 89                    5202 	.db	137
      0023DE 01                    5203 	.uleb128	1
      0023DF                       5204 Ldebug_CIE21_end:
      0023DF 00 00 00 13           5205 	.dw	0,19
      0023E3 00 00 23 CD           5206 	.dw	0,(Ldebug_CIE21_start-4)
      0023E7 00 00 90 8F           5207 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$19)	;initial loc
      0023EB 00 00 00 18           5208 	.dw	0,Sstm8s_clk$CLK_FastHaltWakeUpCmd$30-Sstm8s_clk$CLK_FastHaltWakeUpCmd$19
      0023EF 01                    5209 	.db	1
      0023F0 00 00 90 8F           5210 	.dw	0,(Sstm8s_clk$CLK_FastHaltWakeUpCmd$19)
      0023F4 0E                    5211 	.db	14
      0023F5 02                    5212 	.uleb128	2
                                   5213 
                                   5214 	.area .debug_frame (NOLOAD)
      0023F6 00 00                 5215 	.dw	0
      0023F8 00 0E                 5216 	.dw	Ldebug_CIE22_end-Ldebug_CIE22_start
      0023FA                       5217 Ldebug_CIE22_start:
      0023FA FF FF                 5218 	.dw	0xffff
      0023FC FF FF                 5219 	.dw	0xffff
      0023FE 01                    5220 	.db	1
      0023FF 00                    5221 	.db	0
      002400 01                    5222 	.uleb128	1
      002401 7F                    5223 	.sleb128	-1
      002402 09                    5224 	.db	9
      002403 0C                    5225 	.db	12
      002404 08                    5226 	.uleb128	8
      002405 02                    5227 	.uleb128	2
      002406 89                    5228 	.db	137
      002407 01                    5229 	.uleb128	1
      002408                       5230 Ldebug_CIE22_end:
      002408 00 00 00 13           5231 	.dw	0,19
      00240C 00 00 23 F6           5232 	.dw	0,(Ldebug_CIE22_start-4)
      002410 00 00 90 55           5233 	.dw	0,(Sstm8s_clk$CLK_DeInit$1)	;initial loc
      002414 00 00 00 3A           5234 	.dw	0,Sstm8s_clk$CLK_DeInit$17-Sstm8s_clk$CLK_DeInit$1
      002418 01                    5235 	.db	1
      002419 00 00 90 55           5236 	.dw	0,(Sstm8s_clk$CLK_DeInit$1)
      00241D 0E                    5237 	.db	14
      00241E 02                    5238 	.uleb128	2
